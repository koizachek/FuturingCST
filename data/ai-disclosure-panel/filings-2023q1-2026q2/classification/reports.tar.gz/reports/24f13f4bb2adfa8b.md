# Salesforce, Inc. | 10-Q | fiscal year 2026

- Report length: 44,899 words
- Direct AI mentions (classified): 24, of which about AI: 24, false candidates: 0, flagged for review: 0
- Context passages (not classified): 17; groups: industry (9), compute_infrastructure (9)
- Frames: risk_factor (15), business (9)
- Roles: risk (15), offering (7), adoption (2)
- Risk types: regulatory_legal (5), reputational_ethical (2), environmental (2), workforce (2), market_demand (2), cybersecurity (1), third_party (1), strategic_competitive (1), information_integrity (1), operational_reliability (1), national_security (1)
- MIT subdomains: other (5), regulation_lagging_behind_ai (3), environmental_harm (2), power_centralization_unfair_benefits (2), inequality_decline_employment_quality (2), compromise_of_privacy (2), devaluation_of_human_effort (2), unfair_discrimination_misrepresentation (2), ai_system_security_vulnerabilities_attacks (1), cyberattacks_weapons_mass_harm (1), false_or_misleading_information (1), lack_of_capability_robustness (1), loss_of_human_agency_autonomy (1)
- Adoption stage: unclear (2)
- Business functions: not_stated (1), decision_analytics (1), marketing_sales (1), rd_product (1)
- Governance responses: none
- Kinds of AI: unspecified (13), agentic (7), generative_llm (6), traditional_ml (1)
- Substantiveness: generic (15), specific (4), detailed (3), boilerplate (2)
- Disclosure traits: hedging (12), boilerplate (2), vagueness (2)
- Trait activation rate: 0.583 (boilerplate (0.083), hedging (0.5), externalisation (0.0), vagueness (0.083), safe_harbour (0.0))
- Sections: Item 1A (16), Item 2 (5), Item 1 (3)
- Named entities: Agentforce, CCPA, Colorado Artificial Intelligence Act, DSA, Data Cloud, EU AI Act, EU’s AI Act, GDPR, Genesys Cloud Services Topco LLC, Informatica, Informatica Inc., Regrello, Regrello Corp., Salesforce, Utah Artificial Intelligence Policy Act

## Item 1 LEGAL PROCEEDINGS (blocks 256-257)

**AI reference: explicit | frame: business | roles: offering | kinds: agentic | substantiveness: specific**

> Salesforce, Inc. (the “Company”) is a global leader in customer relationship management technology that brings companies and customers together.

> During the third quarter of fiscal 2025, the Company introduced Agentforce, a new layer of the trusted Salesforce Platform that enables companies to build and deploy AI agents that can respond to inputs, make decisions and take action autonomously across business functions.

<details><summary>Passage</summary>

Description of Business

Salesforce, Inc. (the “Company”) is a global leader in customer relationship management technology that brings companies and customers together. With the deeply unified Salesforce Platform, the Company delivers a single source of truth, connecting customer data with integrated artificial intelligence (“AI”) across systems, apps and devices to help companies sell, service, market and conduct commerce from anywhere. During the third quarter of fiscal 2025, the Company introduced Agentforce, a new layer of the trusted Salesforce Platform that enables companies to build and deploy AI agents that can respond to inputs, make decisions and take action autonomously across business functions. Agentforce includes a suite of customizable agents for use across sales, service, marketing and commerce. Since its founding in 1999, the Company has pioneered innovations in cloud, mobile, social, analytics and AI, enabling companies of every size and industry to transform their businesses in the digital-first world.

</details>

## Item 1 LEGAL PROCEEDINGS (blocks 544-546)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> In May 2025, the Company entered into a definitive agreement to acquire Informatica Inc. (“Informatica”), an AI-powered enterprise cloud data management platform.

<details><summary>Passage</summary>

Informatica Inc.

In May 2025, the Company entered into a definitive agreement to acquire Informatica Inc. (“Informatica”), an AI-powered enterprise cloud data management platform. Under the terms of the agreement, holders of Informatica’s Class A and Class B-1 common stock will receive $ 25 in cash per share and the Company will acquire all outstanding shares of common stock of Informatica that the Company does not already own. The transaction represents an equity value of approximately $ 8 billion, net of the Company’s current investment in Informatica. The agreement also provides for the Company’s assumption of unvested equity awards held by Informatica employees. The Company expects to fund the transaction with a combination of new debt and cash on the Company’s balance sheet. See Note 8 “Debt” for further information related to new debt.

The transaction is expected to close in the fourth quarter of fiscal 2026 or early fiscal 2027, subject to the receipt of required regulatory clearances and satisfaction of other customary closing conditions. Stockholders holding in aggregate approximately 63 percent of the voting power of Informatica Class A and Class B-1 common stock have delivered a written consent approving the transaction.

</details>

## Item 1 LEGAL PROCEEDINGS (blocks 685-686)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> In August 2025, the Company entered into an agreement to acquire Regrello Corp. (“Regrello”), a developer of an AI-native business process automation solution.

<details><summary>Passage</summary>

14. Subsequent Events

In August 2025, the Company entered into an agreement to acquire Regrello Corp. (“Regrello”), a developer of an AI-native business process automation solution. Under the terms of the agreement, the Company will acquire Regrello for approximately $ 900 million in cash, subject to customary purchase price adjustments. The agreement also provides for the Company’s assumption of unvested outstanding equity awards held by Regrello employees. The acquisition is expected to close in the third quarter of fiscal 2026, subject to customary closing conditions.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 691-695)

**AI reference: explicit | frame: business | roles: offering | kinds: agentic, generative_llm | substantiveness: detailed**

> During the third quarter of fiscal 2025, we introduced Agentforce, a new layer of our trusted platform that enables companies to build and deploy AI agents that can respond to inputs, make decisions and take action autonomously across business functions.

> We continue to invest for growth, including investing in generative and agentic AI across all products, which we believe will change how our customers help their customers, and continuously look to expand our leadership role in the cloud computing industry.

> These acquisitions, along with our pending acquisition of Informatica Inc. (“Informatica”), are bringing in key talent and technology to accelerate innovation.

<details><summary>Passage</summary>

Overview

Salesforce is a global leader in customer relationship management (“CRM”) technology, enabling companies of every size and industry to connect with their customers through the power of data, artificial intelligence (“AI”), CRM and trust. Founded in 1999, we bring humans together with AI agents to drive customer success on one deeply unified platform.

Our platform unites sales, service, marketing, commerce and IT teams by connecting customer data across systems, apps and devices to create a complete view of customers. With this single source of customer truth and integrated AI, teams can be more responsive, productive and efficient, deliver intelligent, personalized experiences across every channel and increase productivity. During the third quarter of fiscal 2025, we introduced Agentforce, a new layer of our trusted platform that enables companies to build and deploy AI agents that can respond to inputs, make decisions and take action autonomously across business functions. Agentforce includes a suite of customizable agents for use across sales, service, marketing and commerce. We continue to invest for growth, including investing in generative and agentic AI across all products, which we believe will change how our customers help their customers, and continuously look to expand our leadership role in the cloud computing industry.

We continue to focus on several key growth levers, including driving multiple service offering adoption, increasing our penetration with enterprise and international customers and expanding our industry-specific reach with more vertical software solutions. These growth levers often require a more sophisticated go-to-market approach and, as a result, we may incur additional costs upfront to obtain new customers and expand our relationships with existing customers, including additional sales and marketing expenses specific to subscription and support revenue. As a result, we have seen that customers with many of these characteristics drive higher annual revenues and have lower attrition rates than our company average. In addition to these growth levers, our mergers and acquisitions framework has included several acquisitions that accelerate our agentic roadmap, including our recently announced acquisition of Regrello Corp. (“Regrello”). These acquisitions, along with our pending acquisition of Informatica Inc. (“Informatica”), are bringing in key talent and technology to accelerate innovation.

We are also focused on reducing our operating expenses to improve our operating margin. We have undertaken various restructuring initiatives to improve operating margins and continue advancing our ongoing commitment to profitable growth which included a reduction of our workforce and office space reductions within certain markets. We continue to evaluate and operationalize future programs to drive further operational efficiencies, optimize our management structure and increase cost optimization efforts to realize long-term sustainable growth. We expect to continue to experience improvements in our operating expenses as a percentage of revenue, which could include various restructuring initiatives or measured hiring initiatives to drive operational efficiencies.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 705-708)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> During the six months ended July 31, 2025, we announced our pending acquisition of Informatica, an AI-powered enterprise cloud data management platform, which is expected to close in the fourth quarter of fiscal 2026 or early fiscal 2027, subject to the satisfaction of customary closing conditions, including regulatory approvals, for an estimated $8.0 billion, net of the Company’s current investment in Informatica.

<details><summary>Passage</summary>

Dividend Program : During the six months ended July 31, 2025, we paid approximately $801 million in dividends and dividend equivalents.

Pending Informatica Acquisition: During the six months ended July 31, 2025, we announced our pending acquisition of Informatica, an AI-powered enterprise cloud data management platform, which is expected to close in the fourth quarter of fiscal 2026 or early fiscal 2027, subject to the satisfaction of customary closing conditions, including regulatory approvals, for an estimated $8.0 billion, net of the Company’s current investment in Informatica.

Over the first half of fiscal 2026, we continued to see strong momentum in Data Cloud, Agentforce and our broader AI service offerings. As we have a diversified portfolio of products and a customer base across various geographies, segments and industries, demand for our offerings has remained relatively resilient in a changing economic environment.

In addition, the expanding global scope of our business and the heightened volatility of global markets expose us to the risk of fluctuations in foreign currency markets. Total revenues in the six months ended July 31, 2025 were minimally impacted by foreign currency fluctuations compared to the six months ended July 31, 2024. Our current remaining performance obligation growth as of July 31, 2025 compared to July 31, 2024 was positively impacted by one percent compared to what would have been reported using constant currency rates. The impact of foreign currency fluctuations could impact our near-term results and ability to accurately predict our future results and earnings. The impact of these fluctuations can also be compounded by the seasonality of our business in which our fourth quarter has historically been our strongest quarter for new business and renewals.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 853-855)

**AI reference: explicit | frame: business | roles: adoption | adoption: unclear | functions: not_stated | kinds: agentic | substantiveness: generic**

> The timing of these expenses, which also includes the use of AI and agents, may cause our cost of revenues as a percentage of revenues to fluctuate over time due to changes in demand for our service offerings.

<details><summary>Passage</summary>

Cost of revenue as a percentage of total revenue during the three and six months ended July 31, 2025 decreased by one percent fr om the same periods a year ago primarily as a result of a decrease in amortization of intangible assets acquired through business combinations. For the three and six months ended July 31, 2025 , the increase in cost of revenues in absolute dollars was primarily due to an increase in service delivery expenses associated with our platform and an increase in employee-related costs, primarily in lower cost regions, partially offset by a decrease in amortization of intangible assets acquired through business combinations.

We intend to continue to invest additional resources in enterprise cloud computing services to allow us to scale with our customers and continue to evolve our security measures. The timing of these expenses, which also includes the use of AI and agents, may cause our cost of revenues as a percentage of revenues to fluctuate over time due to changes in demand for our service offerings.

Operating Expenses

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 868-875)

**AI reference: explicit | frame: business | roles: adoption | adoption: unclear | functions: decision_analytics, marketing_sales, rd_product | kinds: agentic | substantiveness: generic**

> We expect that research and development expenses will likely remain consistent as a percentage of revenues over time as we continue to invest in the development of new, and improve existing, technologies, including AI, agents and our Data Cloud service offerings, and the integration of acquired technologies.

> We expect that sales and marketing expenses may decrease as a percentage of revenues over time as we continue to focus on leveraging our self-serve and partner-led channels and increasing our sales productivity, which includes the use of AI and agents.

> We expect that general and administrative expens es may decrease as a percentage of revenues over time as we continue to invest in process efficiency initiatives, which includes the use of AI and agents.

<details><summary>Passage</summary>

Research and development expenses as a percentage of total revenues during the three and six months ended July 31, 2025 were consistent with the same periods a year ago. For the three and six months ended July 31, 2025, the increase in research and development expenses in absolute dollars was primarily due to an increase in employee-related costs, including stock-based compensation expense, primarily in lower cost regions.

We expect that research and development expenses will likely remain consistent as a percentage of revenues over time as we continue to invest in the development of new, and improve existing, technologies, including AI, agents and our Data Cloud service offerings, and the integration of acquired technologies.

Sales and marketing expenses as a percentage of total revenues during the three and six months ended July 31, 2025 decreased by one percent from the same periods a year ago due to a decrease in relative employee-related costs. For the three and six months ended July 31, 2025, the increase in sales and marketing expenses in absolute dollars was primarily due to an increase in employee-related costs and an increase in marketing events, which includes our Agentforce World Tours.

We expect that sales and marketing expenses may decrease as a percentage of revenues over time as we continue to focus on leveraging our self-serve and partner-led channels and increasing our sales productivity, which includes the use of AI and agents.

General and administrative expenses as a percentage of total revenues during the three months ended July 31, 2025 decreased by one percent from the same period a year ago due to decreased bad debt expenses and were consistent during the six months ended July 31, 2025 compared to the same period a year ago. For the three and six months ended July 31, 2025, the increase in general and administrative expenses in absolute dollars was primarily due to an increase in employee-related costs and professional services expenses, partially offset by a decrease in bad debt expenses.

We expect that general and administrative expens es may decrease as a percentage of revenues over time as we continue to invest in process efficiency initiatives, which includes the use of AI and agents.

In the three and six months ended July 31, 2025, approximately $4 million and $40 million, respectively, of costs were incurred related to our restructuring initiatives, which were primarily related to employee transitions, severance payments and employee benefits.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 946-950)

**AI reference: explicit | frame: business | roles: offering | kinds: agentic | substantiveness: detailed**

> In May 2025, we entered into a definitive agreement to acquire Informatica, an AI-powered enterprise cloud data management platform.

> In July 2025, we committed up to $750 million for a strategic investment in Genesys Cloud Services Topco LLC, which offers a cloud-based AI customer experience platform.

> Our mergers and acquisitions framework has included several acquisitions that accelerate our agentic roadmap, including our recently announced acquisition of Regrello, a developer of an AI-native business process automation solution.

<details><summary>Passage</summary>

As of July 31, 2025, we expect approximately $30 million to $50 million in future cash payments related to our restructuring initiatives, primarily related to workforce costs such as severance payments. We generally expect to satisfy these commitments with cash on our balance sheet and cash provided by operating activities.

In May 2025, we entered into a definitive agreement to acquire Informatica, an AI-powered enterprise cloud data management platform. Under the terms of the agreement, holders of Informatica’s Class A and Class B-1 common stock will receive $25 in cash per share and we will acquire all outstanding shares of common stock of Informatica that it does not already own. The transaction represents an equity value of approximately $8 billion, net of our current investment in Informatica. The agreement also provides for our assumption of unvested equity awards held by Informatica employees. We expect to fund the transaction with a combination of new debt and cash on our balance sheet.

In July 2025, we committed up to $750 million for a strategic investment in Genesys Cloud Services Topco LLC, which offers a cloud-based AI customer experience platform. We expect to fund this investment in fiscal 2026 with cash on our balance sheet.

Our mergers and acquisitions framework has included several acquisitions that accelerate our agentic roadmap, including our recently announced acquisition of Regrello, a developer of an AI-native business process automation solution. These acquisitions, along with our pending acquisition of Informatica, are bringing in key talent and technology to accelerate innovation. Under the terms of the agreement to acquire Regrello, which was entered into in August 2025, we will acquire the company for approximately $900 million in cash, subject to customary purchase price adjustments. The agreement also provides for our assumption of unvested outstanding equity awards held by Regrello employees. The acquisition is expected to close in the third quarter of fiscal 2026, subject to customary closing conditions.

</details>

## Item 1A RISK FACTORS (blocks 1035-1037)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: reputational_ethical | mit: other | kinds: unspecified | substantiveness: boilerplate | traits: boilerplate, vagueness**

> Social and ethical issues, including the use or capabilities of AI in our offerings.

<details><summary>Passage</summary>

Any discontinuance by third-party developers and providers in embracing our technology delivery model and enterprise cloud computing services, or customers asking us for warranties for third-party applications, integrations, data and content.

Social and ethical issues, including the use or capabilities of AI in our offerings.

The evolving landscape related to environmental, social and governance matters.

</details>

## Item 1A RISK FACTORS (blocks 1071-1076)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: cybersecurity | mit: ai_system_security_vulnerabilities_attacks, cyberattacks_weapons_mass_harm | kinds: generative_llm | substantiveness: generic | traits: hedging**

> evolving techniques used to breach or sabotage IT systems and infrastructure, including as a result of the increased use of AI technologies by bad actors, which are generally not recognized until launched against a target, and could result in our inability to anticipate or implement adequate measures to prevent such techniques;

> Additionally, as our market presence grows, we may face increased risks of cyberattacks or security threats, and as AI technologies, including generative AI models, develop rapidly, threat actors are using these technologies to create new sophisticated attack methods that are increasingly automated, targeted and coordinated and more difficult to defend against.

<details><summary>Passage</summary>

These risks are mitigated, to the extent feasible, by our ability to maintain and improve business and data governance policies and enhance processes and internal security controls, including our ability to escalate and respond to known and potential risks. We can provide no assurances that our security measures, including implemented systems and processes designed to protect our customers’ and our customers’ customers’ proprietary and other sensitive data, will provide absolute security or otherwise be effective or that a material breach will not occur. For example, our ability to mitigate these risks may be impacted by the following:

evolving techniques used to breach or sabotage IT systems and infrastructure, including as a result of the increased use of AI technologies by bad actors, which are generally not recognized until launched against a target, and could result in our inability to anticipate or implement adequate measures to prevent such techniques;

the increasing complexity of our internal IT systems as we incorporate and secure IT environments from acquired companies and early adoption of new technologies and new ways of sharing data; and

our limited control over our customers or third-party technology providers (including those authorized by customers to access their data), or the processing of data by third-party technology providers, which may not allow us to maintain the integrity or security of such transmissions or processing.

In the normal course of business, we and our customers are and have been the target of malicious cyberattacks and have experienced other security incidents. Although, to date, we have not identified any security events involving our systems that have had a material financial impact on us, there can be no assurance that future cyberattacks will not be material or significant. Additionally, as our market presence grows, we may face increased risks of cyberattacks or security threats, and as AI technologies, including generative AI models, develop rapidly, threat actors are using these technologies to create new sophisticated attack methods that are increasingly automated, targeted and coordinated and more difficult to defend against.

A security breach or incident could result in unauthorized parties obtaining access to, or the denial of authorized access to, our IT systems or data, or our customers’ systems or data, including intellectual property and proprietary, sensitive or other confidential information. We have contractual and other legal obligations to notify relevant stakeholders of security breaches. For example, SEC rules require disclosure on Form 8-K of the nature, scope and timing of any material cybersecurity incident and the reasonably likely impact of any such incident. A security breach or resulting mandatory disclosure could result in a loss of confidence in the security of our services, damage our reputation, negatively impact our future sales, disrupt our business and lead to increases in insurance premiums and legal, regulatory and financial exposure and liability. Further, there can be no assurance that our insurance coverage will be sufficient to cover the financial, legal, business, or reputational losses that may result from a cybersecurity incident or breach of our IT systems. Finally, the prevention, detection and remediation of known or potential security vulnerabilities, including determining whether a cybersecurity incident is notifiable or reportable, may not be straightforward and may result in additional financial burdens due to additional direct and indirect costs to respond to or alleviate problems caused by the actual or perceived security breach, such as additional infrastructure capacity spending to mitigate any system degradation and the reallocation of resources from development activities.

</details>

## Item 1A RISK FACTORS (blocks 1082-1089)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: environmental, third_party | mit: environmental_harm, power_centralization_unfair_benefits | kinds: generative_llm | substantiveness: generic | traits: hedging**

> The hardware, software, data and cloud computing platforms that we rely on, including, for example, the large language models leveraged in our AI offerings, may not continue to be available at reasonable prices, on commercially reasonable terms or at all.

> Additionally, increased energy consumption, including as a result of AI-related growth, climate-related events, energy market volatility, and power grid disruptions, may increase the operational costs related to inputs across our value chain, including for data centers.

<details><summary>Passage</summary>

Since our customers use our services for important aspects of their business, errors, defects, disruptions in service or other performance problems have in the past adversely impacted our customers’ businesses and could do so in the future. As a result, customers could elect to not renew our services or delay or withhold payment to us. We could also lose future sales or customers may make warranty or other claims against us, which could result in an increase in our allowance for doubtful accounts, an increase in collection cycles for accounts receivable or the expense and risk of litigation.

Any interruptions or delays in services from third parties, including data center hosting facilities, cloud computing platform providers and other hardware and software vendors, as well as internet availability, or from our inability to adequately plan for and manage service interruptions or infrastructure capacity requirements, could impair the delivery of our services and harm our business.

We currently rely on third-party data center hosting facilities and cloud computing platform providers located in the United States and other countries, as well as the many different underlying networks and services that power the Internet, to deliver our products, services and business operations and to operate critical business systems. We also rely on computer hardware purchased or leased from, software licensed from, and cloud computing platforms provided by third parties in order to offer our services, including database software, hardware and data from a variety of vendors. Any disruption or damage to, or failure of our systems generally, including the systems of third-party providers we rely on, could result in service interruptions and harm our business. We have from time to time experienced service interruptions and such interruptions may occur in the future. As we increase our reliance on these third-party systems, particularly with respect to third-party cloud computing platforms, our exposure to damage from service interruptions or other performance or quality issues may increase. Service interruptions or other performance or quality issues may cause us to issue credits or pay penalties, cause customers to make warranty or other claims against us or to terminate their subscriptions, and adversely affect our attrition rates and our ability to attract new customers, all of which would reduce our revenue. Our business and reputation would also be harmed if our customers and potential customers believe our services are unreliable.

For many of our offerings, our production environment and customers’ data are replicated in a separate facility located elsewhere. Certain offerings, including some offerings of companies added through acquisitions, may be served through alternate facilities or arrangements. We do not control the operation of any of these facilities, and they may be vulnerable to damage or interruption from earthquakes, floods, fires, power loss, telecommunications failures and similar events. They may also be subject to break-ins, sabotage, intentional acts of destruction or vandalism or similar misconduct, as well as local administrative actions, changes to legal or permitting requirements and litigation to stop, limit or delay operation. In addition, supply chain disruptions due to geopolitical developments in Europe may lead to power disruptions in regions where our facilities are located. Despite precautions taken at these facilities, such as disaster recovery and business continuity arrangements, the occurrence of any of the foregoing events or risks, or a natural disaster or public health emergency, an act of terrorism, a decision to close the facilities without adequate notice or other unanticipated problems or operational failures at these facilities could result in lengthy service interruptions, and no assurance can be provided that any such interruptions would be remediated without significant cost or in a timely manner or at all.

The hardware, software, data and cloud computing platforms that we rely on, including, for example, the large language models leveraged in our AI offerings, may not continue to be available at reasonable prices, on commercially reasonable terms or at all. Any loss of the right to use any of these hardware, software, data or cloud computing platforms could significantly increase our expenses and disrupt or otherwise result in delays in the provisioning of our services until equivalent technology is either developed by us, or, if available, is identified, obtained through purchase or license and integrated into our services, and no assurance can be provided that such equivalent technology would be developed or obtained in a timely manner or at all.

As we scale our operations, the amount and type of information transferred on our offerings continue to evolve, including as a result of the deployment of AI technologies, and our infrastructure capacity requirements, including network capacity, computing power and energy requirements, may increase as a result. Additionally, increased energy consumption, including as a result of AI-related growth, climate-related events, energy market volatility, and power grid disruptions, may increase the operational costs related to inputs across our value chain, including for data centers. If we experience significant strains on our

data center capacity, whether due to insufficient infrastructure capacity or for other reasons outside of our control, our customers could experience performance degradation or service outages that may subject us to financial liabilities, result in customer losses, subject us to litigation and harm our reputation and business. As we add data centers and capacity and continue to move to cloud computing platform providers, we move or transfer our data and our customers’ data from time to time. Despite precautions taken during this process, any unsuccessful data transfers may impair the delivery of our services, which may damage our business.

</details>

## Item 1A RISK FACTORS (blocks 1115-1117)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: workforce | mit: inequality_decline_employment_quality | kinds: agentic | substantiveness: generic | traits: hedging**

> We anticipate that significant additional investments, including in human capital software, as well as leveraging agentic AI and other technologies, will be required to scale our operations and increase productivity, to address the needs of our customers, to further develop and enhance our services, to expand into new geographic areas and to scale with our overall growth.

<details><summary>Passage</summary>

Supporting our existing and growing customer base could strain our personnel resources and infrastructure, and if we are unable to scale our operations and increase productivity, we may not be able to successfully implement our business plan.

We continue to experience significant growth in our customer base, including through acquisitions, which has placed a strain on and in the future may strain our management, administrative, operational and financial infrastructure. We anticipate that significant additional investments, including in human capital software, as well as leveraging agentic AI and other technologies, will be required to scale our operations and increase productivity, to address the needs of our customers, to further develop and enhance our services, to expand into new geographic areas and to scale with our overall growth. These investments will increase our cost base, making it more difficult for us to offset any future revenue shortfalls by reducing expenses in the short term. We may not be able to make these investments as quickly or effectively as necessary to successfully scale our operations.

We regularly upgrade or replace our various software systems and processes. If the implementations of these new applications are delayed, or if we encounter unforeseen problems with our new systems and processes or in migrating away from our existing systems and processes, our operations and our ability to manage our business could be negatively impacted. For example, in the second quarter of fiscal 2026, we implemented a new enterprise resource planning system (“ERP”). Among other things, our ERP is essential to our financial planning, reporting, and compliance programs, and any unforeseen problems with our new ERP or in migrating away from previous systems and processes could harm our ability to manage our business.

</details>

## Item 1A RISK FACTORS (blocks 1123-1124)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: market_demand | mit: other | kinds: unspecified | substantiveness: generic | traits: hedging**

> In addition, the markets and monetization strategies for certain offerings, including Agentforce and Data Cloud, remain relatively new and uncertain and as a result our expansion into such offerings, and related investments, may present additional risks and challenges.

<details><summary>Passage</summary>

depends on a number of factors, including general economic conditions and customer receptiveness to any price changes related to these additional features and services.

In addition, the markets and monetization strategies for certain offerings, including Agentforce and Data Cloud, remain relatively new and uncertain and as a result our expansion into such offerings, and related investments, may present additional risks and challenges. For example, we offer certain products, including Agentforce and Data Cloud, through a consumption-based business model and may increase the number of products through which we do so. We have limited experience with determining optimal pricing for our consumption-based contracts. Additionally, due to customer flexibility in the timing of their consumption, we could have lower levels of customer consumption of our products than we expect which may result in suboptimal pricing for consumption-based contracts.

</details>

## Item 1A RISK FACTORS (blocks 1150-1151)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: market_demand | mit: other | kinds: unspecified | substantiveness: generic | traits: hedging**

> Pricing and packaging strategies for enterprise and other customers for our existing and future service offerings, including for our AI offerings such as Agentforce, may not be widely accepted by new or existing customers.

<details><summary>Passage</summary>

In addition, larger customers and governmental entities often demand more configuration, integration services and features. As a result of these factors, these sales opportunities often require us to devote greater sales support and professional services resources to individual customers, driving up costs and time required to complete sales and diverting our own sales and professional services resources to a smaller number of larger transactions, while potentially requiring us to delay revenue recognition on some of these transactions until the technical or implementation requirements have been met.

Pricing and packaging strategies for enterprise and other customers for our existing and future service offerings, including for our AI offerings such as Agentforce, may not be widely accepted by new or existing customers. We offer certain products, such as Agentforce and Data Cloud, through a consumption-based pricing model, and we have limited experience with determining the optimal pricing for our consumption-based contracts. Due to customer flexibility in the timing of their consumption, we could have lower levels of customer consumption of our products than we expect may result in suboptimal pricing for consumption-based contracts. Our adoption of or failure to adopt, as well as the manner and time of, changes to our pricing and packaging models and strategies may harm our business.

</details>

## Item 1A RISK FACTORS (blocks 1153-1155)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: workforce | mit: inequality_decline_employment_quality | kinds: unspecified | substantiveness: generic | traits: hedging**

> We have experienced challenges with significant competition in talent recruitment and retention, particularly for engineers with experience in AI, and may not in the future be successful in recruiting or retaining such talent.

<details><summary>Passage</summary>

Our success depends substantially upon the continued services of our executive officers and other key members of management, particularly our chief executive officer. We are also substantially dependent on the continued service of our existing development and operations personnel because of the complexity of our services and technologies. Our executive officers, key management, development or operations personnel could terminate their employment with us at any time. Effective succession planning for management is important to our long-term success, and changes in our management team resulting from the hiring, departure or realignment of executives may be disruptive to our business. If we do not develop adequate succession planning for our key personnel, the loss of one or more of our key employees or groups of employees could seriously harm our business.

The technology industry is subject to substantial and continuous competition for engineers with high levels of experience in designing, developing and managing software and technology services, as well as competition for sales executives, data scientists and operations personnel. We have experienced challenges with significant competition in talent recruitment and retention, particularly for engineers with experience in AI, and may not in the future be successful in recruiting or retaining such talent. We have experienced and expect to continue to experience difficulty in hiring, developing, integrating and retaining highly skilled employees with appropriate qualifications. These difficulties may be amplified by evolving restrictions on immigration, travel, or availability of visas for skilled technology workers. Additionally, our compensation arrangements and benefits may not always be successful in attracting new employees or retaining and motivating our existing personnel. If we fail to attract new personnel or fail to retain and motivate our current personnel, our business and future growth prospects could be severely harmed.

In January 2023, we announced a restructuring plan intended to reduce operating costs, improve operating margins and continue advancing our ongoing commitment to profitable growth, which included a reduction of our workforce and office space reductions within certain markets. The workforce reduction was substantially completed by the end of fiscal 2024, and real estate actions are expected to be completed by the end of fiscal 2026. Additionally, throughout fiscal 2025 we initiated further targeted workforce and office space reductions. These restructuring actions, or any similar actions taken in the future, could negatively impact our ability to attract, integrate, retain and motivate key employees.

</details>

## Item 1A RISK FACTORS (blocks 1165-1174)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: strategic_competitive | mit: other | kinds: unspecified | substantiveness: generic | traits: hedging**

> Additionally, as we continue to increasingly build AI into many of our offerings, we face more competition as AI technologies are increasingly integrated into the markets in which we compete.

> New AI offerings may disrupt workforce needs and negatively impact demand for our offerings, or our competitors may be able to incorporate AI into their offerings more efficiently or successfully than we are able to and achieve greater and faster adoption.

<details><summary>Passage</summary>

software companies that provide their product or service free of charge as a single product or when bundled with other offerings, or only charge a premium for advanced features and functionality, as well as companies that offer solutions that are sold without a direct sales organization;

vendors who offer software tailored to specific services, industries or market segments, as opposed to our full suite of service offerings, including suppliers of traditional business intelligence and data preparation products, integration software vendors, marketing vendors, e-commerce solutions vendors or AI software and service vendors;

productivity tool and email providers, unified communications providers and consumer application companies that have entered the business software market; and

traditional platform development environment companies and cloud computing development platform companies who may develop toolsets and products that allow customers to build new applications, including AI-augmented applications, that run on the customers’ current infrastructure or as hosted services, as well as would-be customers who may develop enterprise applications for internal use.

In addition, we may face more competition as we expand our product offerings. Some of our current and potential competitors may have competitive advantages, such as greater name recognition, longer operating histories, more significant installed bases, broader geographic scope, broader suites of service offerings and larger marketing budgets, as well as substantially greater financial, technical, personnel and other resources. In addition, many of our current and potential competitors have established marketing relationships and access to larger customer bases, and have major distribution agreements with consultants, system integrators and resellers. We also experience competition from smaller, younger

competitors that may be more agile in responding to customers’ demands and offer more targeted and simplified solutions. Our competitors may be able to respond more quickly and effectively than we can to new or changing opportunities, technologies, standards or customer requirements, or provide competitive pricing, more flexible contracts or faster implementations. Additionally, as we continue to increasingly build AI into many of our offerings, we face more competition as AI technologies are increasingly integrated into the markets in which we compete. New AI offerings may disrupt workforce needs and negatively impact demand for our offerings, or our competitors may be able to incorporate AI into their offerings more efficiently or successfully than we are able to and achieve greater and faster adoption. Even if our services are more effective than the products and services that our competitors offer, potential customers might select competitive products and services in lieu of purchasing our services. For all of these reasons, we may not be able to compete successfully against our competitors, which could negatively impact our future sales and harm our business.

Our efforts to expand our service offerings and to develop and integrate our existing services in order to keep pace with technological developments may not succeed and may reduce our revenue growth rate and harm our business.

Our efforts to expand our current service offerings may not succeed and may reduce our revenue growth rate. In addition, the markets and monetization strategies for certain offerings, including Agentforce and Data Cloud, remain relatively new and uncertain and as a result our expansion into such offerings, and related investments, may present additional risks and challenges. For example, we offer certain products, including Agentforce and Data Cloud, through a consumption-based business model and may increase the number of products through which we do so. We have limited experience with determining optimal pricing for our consumption-based contracts. Additionally, due to customer flexibility in the timing of their consumption, we could have lower levels of customer consumption of our products than we expect which may result in suboptimal pricing for consumption-based contracts. Further, the introduction of future platform changes and upgrades may not result in long term revenue growth.

If we are unable to develop enhancements to, and new features for, our existing or new services that keep pace with rapid technological developments, our business could be harmed. The success of enhancements, new features and services depends on several factors, including its timely completion, introduction and market acceptance, as well as our ability to integrate all of our product and service offerings and develop adequate selling capabilities in new markets. Failure in this regard may significantly impair our revenue growth as well as negatively impact our operating results if the additional costs are not offset by additional revenues. In addition, because our services are designed to operate over various network technologies and on a variety of mobile devices, operating systems and computer hardware and software platforms, we need to continuously modify and enhance our services to keep pace with changes in these technologies, as well as continue to maintain and support our services on legacy systems. We may not be successful in either developing these modifications and enhancements or in bringing them to market timely.

</details>

## Item 1A RISK FACTORS (blocks 1181-1183)

**AI reference: explicit | frame: business | roles: offering | kinds: generative_llm | substantiveness: generic**

> While we invest in companies that we believe are digitally transforming their industries, advancing responsible generative AI, improving customer experiences, helping us expand our solution ecosystem or supporting other corporate initiatives, we may still experience unforeseen brand or reputational harm associated with our investments.

<details><summary>Passage</summary>

We are subject to risks associated with our strategic investments, including partial or complete loss of invested capital. Significant changes in the fair value of this portfolio could negatively impact our financial results.

We manage a portfolio of strategic investments in both privately held and publicly traded companies focused primarily on enterprise cloud companies, technology startups and system integrators. While we invest in companies that we believe are digitally transforming their industries, advancing responsible generative AI, improving customer experiences, helping us expand our solution ecosystem or supporting other corporate initiatives, we may still experience unforeseen brand or reputational harm associated with our investments. Our investments range from early to late stage companies, including investments made concurrent with a company’s initial public offering. Investments in early stage companies are inherently speculative, as these companies may not yet be revenue-generating and could still be in the process of developing their products and services at the time of our investment. The financial success of our investment in any company is typically dependent on a liquidity event, such as a public offering, acquisition or other favorable market event reflecting appreciation to the cost of our initial investment. Our investments may face challenges from regulatory authorities, including antitrust authorities, potentially resulting in unexpected costs, delays, or unfavorable conditions imposed on transactions involving our investment portfolio. In certain cases, our ability to sell these investments may be impacted by contractual obligations to hold the securities for a set period of time after a public offering. All of our investments are subject to a risk of partial or total loss of invested capital.

We are exposed to volatility in our operating results due to changes in market prices, observable price changes and impairments of our strategic investments. The measurement of our non-marketable equity securities at fair value is inherently subjective and requires management judgment and estimation. The resulting gains or losses could be material depending on market conditions and events, particularly in periods with economic uncertainty, inflation, geopolitical conflict, volatile public equity markets or unsettled global market conditions.

</details>

## Item 1A RISK FACTORS (blocks 1185-1190)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: information_integrity, operational_reliability, regulatory_legal, reputational_ethical | mit: compromise_of_privacy, devaluation_of_human_effort, false_or_misleading_information, lack_of_capability_robustness, other, unfair_discrimination_misrepresentation | kinds: agentic, generative_llm, traditional_ml | substantiveness: detailed | traits: hedging**

> If we enable or offer solutions that draw controversy due to their perceived or actual impact on human rights, privacy, employment, or in other social contexts, we may experience new or enhanced governmental or regulatory scrutiny, brand or reputational harm, competitive harm or legal liability, especially as geopolitical turmoil creates increasingly volatile political and market conditions.

> Uncertainty around new and emerging AI applications such as generative AI content creation and AI agents will require additional investment in compliance, governance and the licensing or development of proprietary datasets, machine learning models and systems to test for accuracy, bias and other variables, which are often complex, may be costly and could impact our profit margin.

> For example, AI technologies, including generative AI, may create content that appears correct but is factually inaccurate or flawed, or contains copyrighted or other protected material, and if our customers or others use this flawed or protected content to their detriment, or the owners of such copyrighted material seek to enforce their rights, we may be exposed to brand or reputational harm, competitive harm and/or legal liability.

<details><summary>Passage</summary>

Our success depends on the willingness of a growing community of third-party developers and technology providers to build applications and provide integrations, data and content that are complementary to our services. Without the continued development of these applications and provision of such integrations, data and content, both current and potential customers may not find our services sufficiently attractive, which could impact future sales. In addition, for those customers who authorize a third-party technology partner to access their data, we do not provide any warranty related to the functionality, security or integrity of the data access, transmission or processing. Despite contract provisions to protect us, customers may look to us to support and provide warranties for the third-party applications, integrations, data and content, even though not developed or sold by us, which may expose us to potential claims, liabilities and obligations, all of which could harm our reputation and our business.

Social and ethical issues, including the use or capabilities of AI in our offerings, may result in reputational harm and liability.

Policies we adopt or choose not to adopt on social and ethical issues, especially regarding the use of our products, may be unpopular with some of our employees or with our customers or potential customers, and have in the past impacted and may in the future impact our ability to attract or retain employees and customers. Our decisions about whether to conduct business with potential customers, or whether to continue or expand business with existing customers, may also impact our ability to attract or retain employees and customers, and could result in negative publicity or reputational harm. Further, actions taken by our customers and employees, including through the use or misuse of our products or new technologies for illegal activities or improper information sharing, may result in reputational harm or possible liability, particularly in light of regulatory requirements like the Digital Services Act (“DSA”) from the EU. For example, we have been subject to allegations in legal proceedings that we should be liable for the use of certain of our products by third parties. Although we believe that we have a strong defense against these allegations, legal proceedings can be lengthy, expensive and disruptive to our operations and the outcome of any claims or litigation, regardless of the merits, is inherently uncertain. Regardless of outcome, these types of claims could cause reputational harm to our brand or result in liability.

We are increasingly building AI into many of our offerings, including generative and agentic AI. As with many innovations, AI offerings, such as Agentforce, and our Salesforce Platform present additional risks and challenges that could affect their adoption and therefore our business. For example, the development of our AI offerings and the Salesforce Platform, which provides information regarding our customers’ customers, present emerging ethical issues. If we enable or offer solutions that draw controversy due to their perceived or actual impact on human rights, privacy, employment, or in other social contexts, we may experience new or enhanced governmental or regulatory scrutiny, brand or reputational harm, competitive harm or legal liability, especially as geopolitical turmoil creates increasingly volatile political and market conditions. Inadequate or ineffective AI development, deployment, content labeling or governance by us or others that result in controversy could also impair the acceptance of AI solutions or result in unintended performance of the services. This in turn could undermine confidence in the decisions, predictions, analysis or other content that our AI applications produce, subjecting us to competitive

harm, legal liability and brand or reputational harm. The rapid evolution of AI will require the application of resources to develop, test and maintain our products and services to help ensure that AI is implemented ethically in order to minimize unintended, harmful impact. Uncertainty around new and emerging AI applications such as generative AI content creation and AI agents will require additional investment in compliance, governance and the licensing or development of proprietary datasets, machine learning models and systems to test for accuracy, bias and other variables, which are often complex, may be costly and could impact our profit margin. Moreover, the move from AI content classification to AI content generation through our development of Agentforce and other generative AI products brings additional risks and responsibility. Known risks of generative AI currently include risks related to accuracy, bias, toxicity, privacy and security and data provenance. For example, AI technologies, including generative AI, may create content that appears correct but is factually inaccurate or flawed, or contains copyrighted or other protected material, and if our customers or others use this flawed or protected content to their detriment, or the owners of such copyrighted material seek to enforce their rights, we may be exposed to brand or reputational harm, competitive harm and/or legal liability. Developing, testing and deploying AI systems may also increase the cost profile of our offerings due to the nature of the computing costs involved in such systems. If we are unable to mitigate these risks, or if we incur excessive expenses in our efforts to do so, our reputation, business, operating results and financial condition may be harmed.

</details>

## Item 1A RISK FACTORS (blocks 1193-1200)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: compromise_of_privacy, regulation_lagging_behind_ai | kinds: unspecified | substantiveness: generic | traits: hedging**

> Privacy concerns and laws as well as evolving regulation of cloud computing, AI services, cross-border data transfer restrictions and other domestic or foreign regulations may limit the use and adoption of our services and adversely affect our business.

> New EU laws, including the DSA, the Data Act and the AI Act, may impose additional rules and restrictions on the use of our products and services.

<details><summary>Passage</summary>

Legal and Regulatory Risks

Privacy concerns and laws as well as evolving regulation of cloud computing, AI services, cross-border data transfer restrictions and other domestic or foreign regulations may limit the use and adoption of our services and adversely affect our business.

Regulation related to the provision of services over the Internet is evolving, as federal, state and foreign governments continue to adopt new, or modify existing, laws and regulations addressing data privacy, cybersecurity, data protection, data sovereignty and the collection, processing, storage, hosting, transfer and use of data, generally. Such regulatory actions may increase in quantity, complexity and scope in response to heightened geopolitical tensions. In some cases, data privacy laws and regulations, such as the EU’s General Data Protection Regulation (“GDPR”), impose obligations directly on us as both a data controller and a data processor, as well as on many of our customers. In addition, domestic data privacy laws, such as the California Consumer Privacy Act as amended by the California Privacy Rights Act (“CCPA”), and laws that have recently passed and/or gone into effect in many other states similarly impose new obligations on us and many of our customers, potentially as both a covered business and service provider. These laws continue to evolve, including, for example, India’s Digital Personal Data Protection Act 2023, and as various jurisdictions introduce similar proposals, which often include subsequent rules and regulation, we and our customers become subject to additional regulatory burdens. New EU laws, including the DSA, the Data Act and the AI Act, may impose additional rules and restrictions on the use of our products and services.

In addition, various safe harbors have historically been provided to those who hosted content provided by others, such as safe harbors from monetary damages for copyright infringement arising from copyrighted content provided by customers and others and for defamation and other torts arising from information provided by customers and others. There is an increasing demand for repealing or limiting these safe harbors by either judicial decision or legislation, and we have active legal

proceedings that have been impacted by the repeal or limiting of safe harbors that were previously available to us. Loss of these safe harbors may require altering or limiting some of our services or may require additional contractual terms to avoid liabilities for our customers’ misconduct.

Although we monitor the regulatory, judicial and legislative environment and have invested in addressing these developments, these laws may require us to make additional changes to our practices and services to enable us or our customers to meet the new legal requirements, and may also increase our potential liability exposure through new or higher potential penalties for noncompliance, including as a result of penalties, fines and lawsuits related to data breaches. Furthermore, privacy laws and regulations are subject to differing interpretations and may be inconsistent among jurisdictions. These and other requirements are causing increased scrutiny among customers, particularly in the public sector and highly regulated industries, and may be perceived differently from customer to customer. In addition, we may be subject to increased liability exposure and scrutiny for the use of certain technology related to the collection and management of customer data, including the use of cookies. These developments could reduce demand for our services, require us to take on more onerous obligations in our contracts, restrict our ability to store, transfer and process data or, in some cases, impact our ability or our customers’ ability to offer our services in certain locations, to deploy our solutions, to reach current and prospective customers, or to derive insights from customer data globally. For example, statutory damages available through a private right of action for certain data breaches under the CCPA may increase our and our customers’ potential liability and the demands our customers place on us. In addition, in July 2020, the Court of Justice of the European Union (“CJEU”) invalidated the EU-U.S. Privacy Shield Framework, one of the mechanisms that allowed companies, including us, to transfer personal data from the European Economic Area (“EEA”) to the United States. Even though the CJEU decision upheld the Standard Contractual Clauses (“SCCs”) as an adequate transfer mechanism, the decision created uncertainty around the validity of all EU-to-U.S. data transfers. While the EU and U.S. governments have since adopted the EU-U.S. Data Privacy Framework to foster EU-to-U.S. data transfers and address the concerns raised in the aforementioned CJEU decision, it is uncertain whether this framework will be overturned in court like the previous two EU-U.S. bilateral cross-border transfer frameworks. As a result, regulators may continue to be inclined to interpret the CJEU’s decision, and the logic behind it, as significantly restricting certain cross-border transfers and the cost and complexity of providing our services in certain markets may increase. Certain countries outside of the EEA have also passed or are considering passing laws requiring varying degrees of local data residency. Additionally, recent government actions have increased the perceived risk that our services, particularly in the EU, could be disrupted, suspended, or terminated in response to evolving geopolitical and regulatory developments.

The costs of compliance with, and other burdens imposed by, privacy laws, regulations and standards may limit the use and adoption of our services, reduce overall demand for our services, make it more difficult to meet expectations from our commitments to customers and our customers’ customers, lead to significant fines, penalties or liabilities for noncompliance, impact our reputation, or slow the pace at which we close sales transactions, in particular where customers request specific warranties and unlimited indemnity for noncompliance with privacy laws, any of which could harm our business.

</details>

## Item 1A RISK FACTORS (blocks 1204-1208)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: loss_of_human_agency_autonomy, regulation_lagging_behind_ai, unfair_discrimination_misrepresentation | kinds: generative_llm | substantiveness: generic | traits: hedging**

> Regulators in certain industries have adopted and may in the future adopt regulations or interpretive positions regarding the use of cloud computing, AI services and other outsourced services.

> Further, countries and states are applying their data and consumer protection laws to AI, and particularly generative AI, and/or are enacting or considering legal frameworks on AI, such as the EU’s AI Act, and the Utah Artificial Intelligence Policy Act, the Colorado Artificial Intelligence Act and the draft CCPA regulations on automated decision-making technology.

<details><summary>Passage</summary>

Industry-specific regulations and other requirements and standards are evolving and industry-specific laws, regulations, interpretive positions or standards could harm our business.

Our customers and potential customers conduct business in a variety of industries, including financial services, the public sector, healthcare and telecommunications. Regulators in certain industries have adopted and may in the future adopt regulations or interpretive positions regarding the use of cloud computing, AI services and other outsourced services. The costs of compliance with, and other burdens imposed by, industry-specific laws, regulations and interpretive positions may limit our customers’ use and adoption of our services and reduce overall demand for our services. Compliance with these regulations may also require us to devote greater resources to support certain customers, which may increase costs and lengthen sales cycles. For example, some financial services regulators have imposed guidelines for use of cloud computing services that mandate specific controls or require financial services enterprises to obtain regulatory approval prior to outsourcing certain functions. If we are unable to comply with these guidelines or controls, or if our customers are unable to obtain regulatory approval to use our services where required, our business may be harmed. In addition, an inability to satisfy the standards of certain voluntary third-party certification bodies that our customers may expect, such as an attestation of compliance with the Payment Card Industry Data Security Standards, may have an adverse impact on our business and results. Any inability in the future to achieve or maintain industry-specific certifications or other requirements or standards relevant to our customers may harm our business and adversely affect our results.

Further, in some cases, industry-specific, regionally-specific or product-specific laws, regulations or interpretive positions may impact our ability, as well as the ability of our customers, partners and data providers, to collect, augment, analyze, use, transfer and share personal and other information that is integral to certain services we provide. The interpretation of many of these statutes, regulations and rulings is evolving in the courts and administrative agencies and an inability to comply may have an adverse impact on our business and results. This impact may be particularly acute in countries that have passed or are considering passing legislation that requires data to remain localized “in country,” as this may impose financial costs on companies required to store data in jurisdictions not of their choosing and to use nonstandard operational processes that add complexity and are difficult and costly to integrate with global processes. This is also true with respect to the global proliferation of laws regulating the financial services industry, including its use of cloud services. In Europe, the Digital Operational Resilience Act (“DORA”), which aims to ensure the resilience of the EU financial sectors, including through mandatory risk management, incident reporting, resilience testing and third-party outsourcing restrictions, went into effect in January 2025. The UK is advancing similar legislation and other countries may follow.

Further, countries and states are applying their data and consumer protection laws to AI, and particularly generative AI, and/or are enacting or considering legal frameworks on AI, such as the EU’s AI Act, and the Utah Artificial Intelligence Policy Act, the Colorado Artificial Intelligence Act and the draft CCPA regulations on automated decision-making technology. Any failure or perceived failure by us to comply with such requirements could have an adverse impact on our business.

There are various statutes, regulations and rulings relevant to direct email marketing and text-messaging, including the Telephone Consumer Protection Act (“TCPA”) and related Federal Communication Commission orders, which impose significant restrictions on the ability to utilize telephone calls and text messages to mobile telephone numbers as a means of communication, when the prior consent of the person being contacted has not been obtained. We have been, and may in the future be, subject to one or more class-action lawsuits, as well as individual lawsuits, containing allegations that one of our businesses or customers violated the TCPA. A determination that we or our customers violated the TCPA or other communications-based statutes could expose us to significant damage awards that could, individually or in the aggregate, materially harm our business. In addition, many jurisdictions across the world are currently considering, or have already begun implementing, changes to antitrust and competition laws, regulations or interpretative positions to enhance competition in digital markets and address practices by certain digital platforms that they perceive to be anticompetitive. These regulatory efforts could result in laws, regulations or interpretative positions that may require us to change certain of our business practices, undertake new compliance obligations or otherwise may have an adverse impact on our business and results.

</details>

## Item 1A RISK FACTORS (blocks 1218-1220)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: devaluation_of_human_effort | kinds: unspecified | substantiveness: generic | traits: hedging**

> Additionally, the intellectual property ownership and license rights, including copyright, surrounding AI technologies, which we are increasingly building into our product offerings, has not been fully addressed by U.S. courts or other federal or state laws or regulations, and the use or adoption of AI technologies in our products and services may expose us to copyright infringement or other intellectual property misappropriation claims related to AI training or output.

<details><summary>Passage</summary>

Any failure to obtain registration or protection of our intellectual property rights could impair our ability to protect our proprietary technology and our brand, causing us to incur significant expenses and harm our business.

If we fail to protect our intellectual property rights adequately, our competitors may gain access to our technology, affecting our brand, causing us to incur significant expenses and harming our business. Any of our patents, trademarks or other intellectual property rights may be challenged by others or invalidated through administrative process or litigation. While we have many U.S. patents and pending U.S. and international patent applications, we may be unable to obtain patent protection for the technology covered in our patent applications or the patent protection may not be obtained quickly enough to meet our business needs. In addition, our existing patents and any patents issued in the future may not provide us with competitive advantages, or may be successfully challenged by third parties. Similar uncertainty applies to our U.S. and international trademark registrations and applications. Furthermore, legal standards relating to the validity, enforceability and scope of protection of intellectual property rights are uncertain, and we also may face proposals to change the scope of protection for some intellectual property rights in the U.S. and elsewhere. Additionally, the intellectual property ownership and license rights, including copyright, surrounding AI technologies, which we are increasingly building into our product offerings, has not been fully addressed by U.S. courts or other federal or state laws or regulations, and the use or adoption of AI technologies in our products and services may expose us to copyright infringement or other intellectual property misappropriation claims related to AI training or output. Effective patent, trademark, copyright and trade secret protection may not be available to us in every country in which our services are available and legal changes and uncertainty in various countries’ intellectual property regimes may result in making conduct that we believe is lawful to be deemed violative of others’ rights. The laws of some foreign countries may not be as protective of intellectual property rights as those in the U.S., and mechanisms for enforcement of intellectual property rights may be inadequate. Also, our involvement in standard-setting activity, our contribution to open source projects, various competition law regimes or the need to obtain licenses from others may require us to license our intellectual property in certain circumstances. Accordingly, despite our efforts, we may be unable to prevent third parties from using our intellectual property.

We may be required to spend significant resources and expense to monitor and protect our intellectual property rights. We may initiate claims or litigation against third parties for infringement of our proprietary rights or to establish the validity of our proprietary rights. If we fail to protect our intellectual property rights, it could impact our ability to protect our technology and brand. Furthermore, any litigation, whether or not it is resolved in our favor, could result in significant expense to us, cause us to divert time and resources from our core business, and harm our business.

</details>

## Item 1A RISK FACTORS (blocks 1225-1226)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: national_security | mit: power_centralization_unfair_benefits | kinds: unspecified | substantiveness: generic | traits: hedging**

> Sanctions and export and import control regulations in the United States and other countries are subject to change and uncertainty, including as a result of tariff policy changes, rapidly evolving technology, increased government regulation of AI and cloud service solutions, and geopolitical developments such as events affecting relations between the United States and China, multi-jurisdictional sanctions on Russia, the war in Ukraine and regional conflict in the Middle East.

<details><summary>Passage</summary>

We are subject to governmental sanctions and export and import controls that could impair our ability to compete in international markets and may subject us to liability if we are not in full compliance with applicable laws.

Our solutions are subject to trade control laws and regulations where we conduct our business activities, including the U.S. Commerce Department’s Export Administration Regulations, U.S. customs regulations, U.S. supply chain regulations and various economic and trade sanctions regulations administered by the U.S. Treasury Department’s Office of Foreign Assets Control. If we fail to comply with applicable trade control laws and regulations, we and certain of our employees could be subject to substantial civil or criminal penalties, including the possible loss of trade privileges; fines, which may be imposed on us and responsible employees or managers; and, in extreme cases, the incarceration of responsible employees or managers. Obtaining necessary authorizations, including any required licenses, may be time-consuming, requires expenditure of corporate resources, is not guaranteed, and may result in the delay or loss of sales opportunities or the ability to realize value from certain acquisitions or engagements. Acquisitions may also subject us to successor liability and other integration compliance risks. Furthermore, export control and economic sanctions laws and regulations may prohibit or limit the transfer of certain products and services to embargoed or sanctioned countries, governments and parties. We can provide no assurance that any of the precautions we take to prevent our solutions from being provisioned or provided to sanctions targets in violation of applicable regulations will be effective, and, accordingly, our solutions could be provisioned or provided to those targets, including by our resellers or other third parties, which could have negative consequences for our business, including government investigations, penalties and reputational harm. Changes in our solutions or trade control laws and regulations may create delays in the introduction, sale and deployment of our solutions in international markets or prevent the export or import of our solutions to certain countries, governments or persons altogether. Any decreased use of our solutions or limitation on our ability to export or sell our solutions may adversely affect our business, financial condition and results of operations. Sanctions and export and import control regulations in the United States and other countries are subject to change and uncertainty, including as a result of tariff policy changes, rapidly evolving technology, increased government regulation of AI and cloud service solutions, and geopolitical developments such as events affecting relations between the United States and China, multi-jurisdictional sanctions on Russia, the war in Ukraine and regional conflict in the Middle East. Regulators in the United States and elsewhere have signaled an increased emphasis on sanctions and export control enforcement, including efforts to combat diversion of services to sanctioned countries and parties, several recent high-profile enforcement actions and increased pressure for companies to self-disclose potential violations.

</details>

## Item 1A RISK FACTORS (blocks 1287-1290)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: regulation_lagging_behind_ai | kinds: unspecified | substantiveness: boilerplate | traits: boilerplate, vagueness**

> evolving regulations of cloud computing, AI and cross-border data transfer restrictions and similar regulations;

<details><summary>Passage</summary>

equity or debt issuances, including as consideration in or in conjunction with acquisitions;

evolving regulations of cloud computing, AI and cross-border data transfer restrictions and similar regulations; and

regulatory compliance and acquisition costs.

</details>

## Item 1A RISK FACTORS (blocks 1332-1333)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: environmental | mit: environmental_harm | kinds: unspecified | substantiveness: generic**

> In particular, increased energy consumption, including as a result of AI-related growth, climate-related events, energy market volatility, and power grid disruptions, may increase the operational costs related to inputs across our value chain, including for data centers.

<details><summary>Passage</summary>

Climate change may have an impact on our business.

While we seek to mitigate our business risks associated with climate change by establishing appropriate environmental programs and partnering with organizations who are also focused on mitigating their own climate-related risks, there are inherent climate-related risks where our business is conducted. In particular, increased energy consumption, including as a result of AI-related growth, climate-related events, energy market volatility, and power grid disruptions, may increase the operational costs related to inputs across our value chain, including for data centers. Any of our primary locations may be vulnerable to the adverse effects of climate change. For example, our offices globally have historically experienced, and are projected to continue to experience, climate-related events at an increasing frequency, including drought, water scarcity, heat waves, cold waves, flooding, wildfires and resultant air quality impacts and power shutoffs associated with climate-related events. These events in turn have impacts on inflation risks, the cost and availability of insurance, food security, water security (including for water availability for data center cooling), energy security and on our employees’ health, productivity and well-being. Furthermore, it is more difficult to mitigate the impact of these events on our employees working remotely or at client sites. Changing market dynamics, global policy developments and the increasing frequency and impact of extreme weather events on critical infrastructure in the United States and elsewhere have the potential to disrupt our business, the business of companies we invest in, the business of third-party providers or suppliers that we rely on to conduct our business and the business of our customers, and may cause us to experience higher attrition, losses and additional costs to maintain or resume operations. Additionally, failure to uphold, meet or make timely forward progress against our public commitments and goals related to climate action could adversely impact the resilience of our business to the impacts of climate-related events.

</details>

# Context passages: implicit mentions, not classified

## Item 1 LEGAL PROCEEDINGS (blocks 279-283)

**Terms: customer concentration (Significant Customers, single customer)**

The Company’s significant segment expenses, which are the expenses included in operating income as well as gains (losses) on strategic investments, and other segment items, which includes other income and provision for income taxes, are included in the Company’s condensed consolidated statement of operations. Additionally, further components of the Company’s measure of profit or loss, which is net income, are included throughout the Company’s financial statements.

Concentrations of Credit Risk, Significant Customers and Investments

The Company’s financial instruments that are exposed to concentrations of credit risk consist primarily of cash and cash equivalents, marketable securities and accounts receivable. The Company monitors and manages the overall exposure of its cash balances to individual financial institutions on an ongoing basis. The Company’s marketable securities portfolio consists primarily of investment-grade securities and the Company’s policies limit the amount of credit exposure to any one issuer. The Company does not require collateral for accounts receivable. The Company maintains an allowance for its doubtful accounts receivable for estimated credit losses. This allowance is based upon historical loss patterns, the number of days that billings are past due, an evaluation of the potential risk of loss associated with delinquent accounts and current market conditions and reasonable and supportable forecasts of future economic conditions to inform adjustments to historical loss patterns. The Company records the allowance against bad debt expense through the condensed consolidated statements of operations, included in general and administrative expense, up to the amount of revenues recognized to date. Any incremental allowance is recorded as an offset to unearned revenue on the condensed consolidated balance sheets. Receivables are written off and charged against the recorded allowance when the Company has exhausted collection efforts without success.

No single customer accounted for ten percent or more of accounts receivable as of July 31, 2025 and January 31, 2025. No single customer accounted for ten percent or more of total revenue during the three and six months ended July 31, 2025 and 2024. As of July 31, 2025 and January 31, 2025, assets located outside the Americas were 15 percent and 17 percent of total assets, respectively. As of July 31, 2025 and January 31, 2025, assets located in the United States were 84 percent and 81 percent of total assets, respectively.

The Company is also exposed to concentrations of risk in its strategic investment portfolio, including within specific industries, as the Company primarily invests in enterprise cloud companies, technology st artups and system integrators. As of July 31, 2025, the Company held three investments, all privately held, with carrying values that were individually greater than five percent of its total strategic investments portfolio and represented approximately 18 percent o f the portfolio in the aggregate. As of January 31, 2025 , the Company held four investments, all privately held, with carrying values that were individually greater than five percent of its strategic investments portfolio and represented approximately 24 percent of the portfolio in the aggregate.

## Item 1 LEGAL PROCEEDINGS (blocks 338-341)

**Terms: data center (data centers)**

Leases

The Company has entered into operating and finance leases for corporate offices, data centers, and equipment. The Company determines if an arrangement is a lease at inception and classifies its leases at commencement. Operating leases are included in operating lease right-of-use (“ROU”) assets and current and noncurrent operating lease liabilities on the Company’s condensed consolidated balance sheets. Assets (also referred to as ROU assets) and liabilities recognized from finance leases are included in property and equipment, accrued expenses and other liabilities and other noncurrent liabilities, respectively, on the Company’s condensed consolidated balance sheets. ROU assets represent the Company's right to use an underlying asset for the lease term. The corresponding lease liabilities represent its obligation to make lease payments arising from the lease. The Company does not recognize ROU assets or lease liabilities for leases with a term of 12 months or less for any asset classes.

Lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement, net of any future tenant incentives. The Company has lease agreements which contain both lease and non-lease components, which it has elected to combine for all asset classes. As such, minimum lease payments include fixed payments for non-lease components within a lease agreement but exclude variable lease payments not dependent on an index or rate, such as common area maintenance, operating expenses, utilities, or other costs that are subject to fluctuation from period to period. The Company’s lease terms may include options to extend or terminate the lease. Periods beyond the noncancellable term of the lease are included in the measurement of the lease liability only when it is reasonably certain that the Company will exercise the associated extension option or waive the termination option. The Company reassesses the lease term if and when a significant event or change in circumstances occurs within the control of the Company. As most of the Company’s leases do not provide an implicit rate, the net present value of future minimum lease payments is determined using the Company’s incremental borrowing rate. The Company's incremental borrowing rate is an estimate of the interest rate the Company would have to pay to borrow on a collateralized basis with similar terms and payments, in the economic environment where the leased asset is located.

## Item 1 LEGAL PROCEEDINGS (blocks 426-428)

**Terms: sale-leaseback (Asset-backed securities)**

Mortgage-backed obligations | 145 | 0 | ( 4 ) | 141

Asset-backed securities | 1,190 | 3 | ( 1 ) | 1,192

Municipal securities | 68 | 0 | 0 | 68

## Item 1 LEGAL PROCEEDINGS (blocks 437-439)

**Terms: sale-leaseback (Asset-backed securities)**

Mortgage-backed obligations | 128 | 0 | ( 6 ) | 122

Asset-backed securities | 1,218 | 3 | ( 4 ) | 1,217

Municipal securities | 108 | 0 | ( 1 ) | 107

## Item 1 LEGAL PROCEEDINGS (blocks 491-493)

**Terms: sale-leaseback (Asset-backed securities)**

Mortgage-backed obligations | 0 | 141 | 0 | 141

Asset-backed securities | 0 | 1,192 | 0 | 1,192

Municipal securities | 0 | 68 | 0 | 68

## Item 1 LEGAL PROCEEDINGS (blocks 510-512)

**Terms: sale-leaseback (Asset-backed securities)**

Mortgage-backed obligations | 0 | 122 | 0 | 122

Asset-backed securities | 0 | 1,217 | 0 | 1,217

Municipal securities | 0 | 107 | 0 | 107

## Item 1 LEGAL PROCEEDINGS (blocks 524-526)

**Terms: data center (data centers)**

Leases

The Company has leases for corporate offices, data centers and equipment under noncancellable operating and finance leases with various expiration dates.

Total operating lease costs were $ 149 million and $ 193 million for the three months ended July 31, 2025 and 2024, respectively, and were $ 296 million and $ 351 million for the six months ended July 31, 2025 and 2024, respectively. Included in operating lease costs are amounts related to restructuring charges, which are discussed in Note 9 “Restructuring.”

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 727-730)

**Terms: data center (data center), data centre capacity (data center capacity)**

Cost of Revenues

Cost of subscription and support revenues primarily consists of expenses related to our employee-related costs, which includes salaries, benefits and stock-based compensation expense, delivering our service and providing support, including the costs of data center capacity, certain fees paid to various third parties for the use of their technology, services and data, and allocated overhead. Our cost of subscription and support revenues also includes amortization of certain acquisition-related intangible assets, such as the amortization of the cost associated with an acquired company’s research and development efforts.

Also included in the cost of subscription and support revenues are expenses incurred supporting the free user base of Slack, including third-party hosting costs and employee-related costs specific to customer experience and technical operations.

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 896-898)

**Terms: sale-leaseback (asset-backed securities)**

Liquidity and Capital Resources

At July 31, 2025, our principal sources of liquidity were cash, cash equivalents and marketable securities totaling $15.4 billion and accounts receivable of $5.6 billion. Our cash equivalents and marketable securities are comprised primarily of corporate notes and obligations, U.S. treasury securities, U.S. agency obligations, asset-backed securities, foreign government obligations, mortgage-backed obligations, covered bonds, time deposits, money market mutual funds and municipal securities. Our Revolving Loan Credit Agreement (as defined below), which provides the ability to borrow up to $5.0 billion in unsecured financing (the “Credit Facility”) as of July 31, 2025, also serves as a source of liquidity.

Net cash provided by operating activities could continue to be affected by various risks and uncertainties, including, but not limited to, the risks detailed in Part II, Item 1A, “Risk Factors.” We believe our existing cash, cash equivalents, marketable securities, cash provided by operating activities, unbilled amounts related to contracted noncancellable subscription agreements, which are not reflected on the balance sheet, and, if necessary, our borrowing capacity under our Credit Facility will be sufficient to meet our working capital, capital expenditure and debt maintenance needs over the next 12 months and thereafter.

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 922-923)

**Terms: sale-leaseback (off-balance sheet)**

In June 2025, we entered into a 364-Day Credit Agreement that provides us with the ability to borrow up to $4.0 billion and a three-year Credit Agreement that provides us with the ability to borrow up to $2.0 billion, both on an unsecured basis, to finance a portion of the cash consideration for the pending acquisition of Informatica, the repayment of certain debt of Informatica and the payment of fees, costs and expenses related thereto (collectively, the “Informatica Credit Agreements”). The availability and funding of each credit agreement is conditioned on the consummation of the acquisition of Informatica in accordance with the terms of the merger agreement and is subject to certain exceptions, qualifications and certain other conditions. There were no outstanding borrowings under the Informatica Credit Agreements as of July 31, 2025.

We do not have any special purpose entities and we do not engage in off-balance sheet financing arrangements.

## Item 3 DEFAULTS UPON SENIOR SECURITIES (blocks 956-957)

**Terms: data center (data center)**

Foreign Currency Exchange Risk

We primarily conduct our business in the following locations: the United States, Europe, Canada, Latin America, Asia Pacific and Japan. The expanding global scope of our business exposes us to the risk of fluctuations in foreign currency markets, including emerging markets. This exposure is the result of selling in multiple currencies, operating in countries where the functional currency is the local currency and growth in our international investments, including data center expansion, costs associated with third-party infrastructure providers and additional headcount in foreign countries. Specifically, our results of operations and cash flows are subject to fluctuations in the following currencies: the Euro, British Pound Sterling, Japanese Yen, Canadian Dollar, Australian Dollar and Brazilian Real against the United States Dollar (“USD”). These exposures may change over time as business practices evolve and economic conditions change. Changes in foreign currency exchange rates could have an adverse impact on our financial results and cash flows.

## Item 3 DEFAULTS UPON SENIOR SECURITIES (blocks 986-988)

**Terms: tenant credit risk (counterparty risk)**

Any borrowings under our Revolving Loan Credit Agreement bear interest, at our option, at a base rate plus a spread of 0.00% or an adjusted benchmark rate plus a spread of 0.50% to 0.85%, in each case with such spread being determined based on our credit rating. We are also obligated to pay an ongoing commitment fee on undrawn amounts. As of July 31, 2025, there was no outstanding borrowing amount under the Credit Facility.

The bank counterparties to our derivative contracts potentially expose us to credit-related losses in the event of their nonperformance. To mitigate that risk, we only contract with counterparties who meet the minimum requirements under our counterparty risk assessment process. We monitor ratings, credit spreads and potential downgrades on at least a quarterly basis. Based on our ongoing assessment of counterparty risk, we adjust our exposure to various counterparties. We generally enter into master netting arrangements, which reduce credit risk by permitting net settlement of transactions with the same counterparty. However, we do not have any master netting arrangements in place with collateral features.

Strategic Investments

## Item 1A RISK FACTORS (blocks 1017-1021)

**Terms: data center (data center)**

Operational and Execution Risks

Any breaches in our security measures or those of our third-party data center hosting facilities, cloud computing platform providers, customers or third-party service partners, or the underlying infrastructure of the Internet that cause unauthorized access to a customer’s data, our data or our IT systems, or the blockage or disablement of authorized access to our services.

Any defects or disruptions in our services that diminish demand for our services.

Any interruptions or delays in services from third parties, including data center hosting facilities, cloud computing platform providers and other hardware and software vendors, as well as internet availability, or from our inability to adequately plan for and manage service interruptions or infrastructure capacity requirements.

An inability to realize the expected business or financial benefits of company and technology acquisitions.

## Item 1A RISK FACTORS (blocks 1059-1061)

**Terms: data center (data center)**

Operational and Execution Risks

If our security measures or those of our third-party data center hosting facilities, cloud computing platform providers, customers or third-party service partners, or the underlying infrastructure of the Internet are breached, and unauthorized access is obtained to a customer’s data, our data or our IT systems, or authorized access is blocked or disabled, our services may be perceived as not being secure, customers may curtail or stop using our services, and we may incur significant reputational harm, legal exposure and liabilities, or a negative financial impact.

Our services involve the storage and transmission of our customers’ and our customers’ customers’ proprietary and other sensitive data, including financial, health and other personal information. Our services and underlying infrastructure may in the future be materially breached or compromised as a result of the following:

## Item 1A RISK FACTORS (blocks 1231-1233)

**Terms: data center (data center)**

Due to the unpredictability of future general economic and financial market conditions, including from the global economic impact of uncertainty regarding changes in trade policy, including the threat or imposition of tariffs or other trade restrictions, as well as retaliatory actions; ongoing conflicts, such as the war in Ukraine and the regional conflict in the Middle East; the pace of change and innovation in enterprise cloud computing services; the impact of foreign currency exchange rate fluctuations; changing interest rates and inflation; the growing complexity of our business, including the use of multiple pricing

and packaging models and fluctuations to the amount of revenue from term software license sales; and our increasing focus on enterprise cloud computing services, we may not be able to realize our projected revenue growth plans. We plan our expense and investment levels based on estimates of future revenue and future anticipated rate of growth. We may not be able to adjust our spending appropriately if the addition of new subscriptions or the renewals of existing subscriptions fall short of our expectations, and unanticipated events may cause us to incur expenses beyond what we anticipated. A portion of our expenses may also be fixed in nature for some minimum amount of time, such as with costs capitalized to obtain revenue contracts, data center and infrastructure service contracts or office leases, so it may not be possible to reduce costs in a timely manner, or at all, without the payment of fees to exit certain obligations early. Additionally, if sales through indirect channels or for consumption-based product offerings increase, this may lead to greater difficulty in forecasting revenue and anticipated rate of growth. As a result, our revenues, operating results and cash flows may fluctuate significantly on a quarterly basis and revenue growth rates may not be sustainable and may decline in the future. If we are not able to provide continued operating margin expansion, our business could be harmed and the market price of our common stock could decline.

## Item 1A RISK FACTORS (blocks 1278-1280)

**Terms: data center (data centers)**

the costs associated with acquiring and integrating new businesses and technologies;

expenses related to our real estate or changes in the nature or extent of our use of existing real estate, including our office leases and data centers;

timing of additional investments in our enterprise cloud computing application and platform services and in our consulting services;

## Item 1A RISK FACTORS (blocks 1302-1304)

**Terms: data center (data center)**

recruitment or departure of key personnel;

disruptions in our service due to computer hardware, software, network or data center problems;

uncertainty regarding changes in trade policies, including trade wars, the threat or imposition of tariffs or other trade restrictions, as well as any retaliatory actions;
