# CADENCE DESIGN SYSTEMS INC | 10-Q | fiscal year not provided by the data provider

- Report length: 20,345 words
- Direct AI mentions (classified): 2, of which about AI: 2, false candidates: 0, flagged for review: 0
- Context passages (not classified): 3; groups: euphemisms (3)
- Frames: business (1), risk_factor (1)
- Roles: offering (1), risk (1)
- Risk types: cybersecurity (1)
- MIT subdomains: ai_system_security_vulnerabilities_attacks (1), fraud_scams_targeted_manipulation (1)
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: unspecified (1), generative_llm (1)
- Substantiveness: specific (2)
- Disclosure traits: hedging (1)
- Trait activation rate: 0.5 (boilerplate (0.0), hedging (0.5), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 2 (1), Item 1A (1)
- Named entities: none

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 614-617)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> Cadence® is a global technology leader that develops computational, AI-driven software, accelerated hardware, and silicon intellectual property (“IP”) products and solutions.

> As our customers tackle the challenges of designing increasingly intricate systems, they rely on our advanced AI-driven computational software, hardware, IP, and services to manage this complexity without proportional cost increases.

<details><summary>Passage</summary>

Business Overview

Cadence® is a global technology leader that develops computational, AI-driven software, accelerated hardware, and silicon intellectual property (“IP”) products and solutions. Our customers include semiconductor companies that design and manufacture integrated circuits (“ICs”), as well as systems companies that design and manufacture electromechanical systems containing various types of semiconductor and other electronics. Our products and solutions empower our customers to design and verify and bring to life new and innovative products. Our mission is to empower the world’s most innovative companies to deliver extraordinary electronic products that drive the global economy and improve everyday life.

Our customers include semiconductor companies that design and manufacture semiconductor devices, as well as systems companies that design and manufacture products containing many different types of semiconductors. Semiconductors, also referred to as integrated circuits (“ICs”), or chips, are integral components in a wide range of products across multiple industries, including both industrial and consumer end markets. As our customers tackle the challenges of designing increasingly intricate systems, they rely on our advanced AI-driven computational software, hardware, IP, and services to manage this complexity without proportional cost increases. Our products and solutions are critical for optimizing the performance, power, and area (“PPA”) of semiconductors and electronic systems while accelerating time-to-market.

In alignment with our intelligent system design (“ISD”) strategy, we organize our offerings into three tightly integrated product categories: Core EDA, Semiconductor IP, and System Design and Analysis (“SD&A”). Core EDA encompasses the software, hardware, and services essential for the design and verification of a wide range of semiconductors. Our Semiconductor IP portfolio includes silicon subsystems, software, and related services that accelerate the semiconductor design process. The SD&A category provides solutions and services that enable the design and verification of complete electronic systems, from printed circuit boards to complex system assemblies. These offerings are tightly integrated to provide complete design solutions for our customers.

</details>

## Item 1A Risk Factors (blocks 895-899)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: cybersecurity | mit: ai_system_security_vulnerabilities_attacks, fraud_scams_targeted_manipulation | kinds: generative_llm | substantiveness: specific | traits: hedging**

> Additionally, advances in technology, an increased level of sophistication and expertise of hackers, widespread access to generative AI, and new discoveries in the field of cryptography increase the risk of significant compromises or breaches of our IT Systems or security measures implemented to protect our systems.

> Cyberattacks are expected to accelerate on a global basis in frequency and magnitude as threat actors are becoming increasingly sophisticated in using techniques and tools – including AI – that circumvent security controls, evade detection and remove forensic evidence.

<details><summary>Passage</summary>

Cyberattacks that compromise the confidentiality, integrity or availability of our or our third-party providers' information technology systems or confidential information could materially harm our reputation, business, financial condition and results of operations.

We rely on hardware, software, digital infrastructure and computing networks for both internal and customer-facing operations that are critical to our business (collectively, “IT Systems”). We own and manage certain IT Systems but also rely on third parties for IT Systems and related products and services, including cloud computing. In addition, we and certain third-party providers collect, maintain and process data about our customers, employees, business partners and others, including information that relates to individuals and/or constitutes “personal data,” “personal information,” "personally identifiable information" or similar terms under applicable data privacy laws (collectively “Personal Information”), as well as proprietary data such as trade secrets (together with Personal Information, “Confidential Information”).

We face numerous, evolving cybersecurity risks that threaten the confidentiality, integrity and availability of our IT Systems, Confidential Information, products and services, including from diverse threat actors, such as state-sponsored organizations, opportunistic hackers and malicious insiders, as well as through diverse attack vectors, such as social engineering (including phishing), malware (including ransomware) and denial-of-service attacks, and due to human or technological error, such as misconfigurations, “bugs” or other vulnerabilities in software or hardware. Additionally, advances in technology, an increased level of sophistication and expertise of hackers, widespread access to generative AI, and new discoveries in the field of cryptography increase the risk of significant compromises or breaches of our IT Systems or security measures implemented to protect our systems. From time to time, we and certain of our third-party service providers experience varying degrees of cyberattacks and other security incidents. Any such incidents could compromise our or our providers' IT Systems, which could cause system disruptions or slowdowns and lead to the Confidential Information stored on our or third-party systems being accessed, publicly disclosed, lost or stolen. Any actual or perceived unauthorized access or disclosure to our Confidential Information poses significant risk to our business as it could result in reputational and financial harm and further subject us to liability to our customers, suppliers, business partners and others. For example, we recently learned that a threat actor obtained a limited amount of Confidential Information from certain of our IT systems including a limited amount of test files, configuration setting files and source code files which are not material to our business. We notified law enforcement, and we believe that the incident was contained. There was no operational disruption, and customer environments were not impacted.

Cyberattacks are expected to accelerate on a global basis in frequency and magnitude as threat actors are becoming increasingly sophisticated in using techniques and tools – including AI – that circumvent security controls, evade detection and remove forensic evidence. Techniques used to obtain unauthorized access or to sabotage information systems change frequently and include zero-day software vulnerabilities that are unknown until exploited by threat actors. As a result, we may be unable to promptly or effectively detect, investigate, remediate or recover from future attacks or incidents, or to avoid a material adverse impact to our IT Systems, Confidential Information or business. Furthermore, state-supported and geopolitical-related cyberattacks against companies such as ours may increase due to geopolitical conditions. A cyberattack on our IT Systems or IT Systems of one of our third-party providers or customers could result in material adverse impacts due to any or all of the following: compromise to our Cadence Cloud portfolio, which includes both our managed and customer-managed environments, and our data centers and those of our customers and end users; corruption or stealing of Confidential Information such as proprietary information related to our (or our customers') business, products, services and infrastructure or Personal Information; manipulation or stealing of financial data and assets; and/or disruption of our systems and services and those of our customers and others. As a result, we could be exposed to a risk of loss or misuse of Confidential Information, loss of financial assets, business interruption, regulatory investigations, litigation and other liabilities and costs.

Because we make extensive use of third-party suppliers and service providers, such as cloud services that support our internal and customer-facing operations, successful cyberattacks that disrupt or result in unauthorized access to third party providers’ IT Systems, including those that store our Confidential Information, can materially impact our operations and financial results. Moreover, hardware, software or applications we develop or procure from third parties or through open source solutions may contain defects in design or manufacture or other vulnerabilities and are susceptible to compromise. In addition, we have acquired and continue to acquire companies with less sophisticated security measures, and it takes time to align their security practices to meet our information security policies, procedures and controls, which exposes us to increased cybersecurity and other integration risks. There can be no assurance that our cybersecurity risk management strategy, program, policies, processes and controls will be fully implemented, complied with or effective in protecting any systems or information.

</details>

# Context passages: implicit mentions, not classified

## Item 1 Legal Proceedings (blocks 244-246)

**Terms: smart technology (Smart Solutions)**

Acquisition of Hexagon Design and Engineering Business

On February 23, 2026, Cadence acquired all of the outstanding equity of the design and engineering (“D&E”) business of Hexagon Smart Solutions AB. The aggregate purchase consideration paid to Hexagon, net of cash acquired of $ 154.6 million, was $ 2.9 billion. The aggregate purchase consideration was comprised of $ 2.2 billion of cash and non-cash consideration of 3.2 million shares of Cadence common stock with an aggregate acquisition date fair value of $ 902.2 million. This acquisition is expected to expand Cadence’s System Design and Analysis (“SD&A”) portfolio, building upon its acquisition of BETA CAE in fiscal 2024.

The total purchase consideration was allocated to the assets acquired and liabilities assumed with Cadence’s acquisition of the D&E business based on their respective fair values on the acquisition date as follows:

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 621-622)

**Terms: smart technology (Smart Solutions)**

As part of our ISD strategy, we invest in and acquire complementary businesses, joint ventures, services and technologies and IP rights. The size and timing of these investments and acquisitions may affect comparability of revenue, expenses and cash flows between fiscal periods.

On February 23, 2026, we completed our acquisition of the design and engineering (“D&E”) business of Hexagon Smart Solutions AB. This acquisition is expected to accelerate our ISD strategy by expanding our SD&A portfolio, building upon our acquisition of BETA CAE in fiscal 2024. The acquisition includes substantially all of the subsidiaries and related assets comprising Hexagon's design and engineering business. For the three months ended March 31, 2026, revenue associated with contracts assumed with our acquisition of the D&E business was primarily classified as product and maintenance revenue in our SD&A product category, and cost of revenue associated with these contracts was primarily classified as cost of product and maintenance in our condensed consolidated income statements.

## Item 6 Exhibits (blocks 926-928)

**Terms: smart technology (Smart Solutions)**

Exhibit Number | Exhibit Title | Incorporated by Reference — Form | File No. | Exhibit No. | Filing Date | Provided Herewith

2.1 | # | Amendment No. 1 dated February 21, 2026 to Equity Purchase Agreement between Hexagon Smart Solutions AB and Cadence Design Systems, Inc. dated September 4, 2025. | X

3.1 | The Registrant’s Restated Certificate of Incorporation, as filed with the Secretary of State of the State of Delaware on May 3, 2024. | 8-K | 000-15867 | 3.1 | 5/6/2024
