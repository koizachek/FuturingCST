# BOSTON SCIENTIFIC CORP | 10-K | fiscal year 2025

- Report length: 67,243 words
- Direct AI mentions (classified): 4, of which about AI: 4, false candidates: 0, flagged for review: 0
- Context passages (not classified): 17; groups: industry (16), euphemisms (1), governance_regulation (1)
- Frames: risk_factor (2), governance (2)
- Roles: risk (2), governance (2), adoption (1)
- Risk types: strategic_competitive (1), cybersecurity (1)
- MIT subdomains: other (1), cyberattacks_weapons_mass_harm (1)
- Adoption stage: deployed (1)
- Business functions: it_cybersecurity (1)
- Governance responses: technical_controls (1), oversight_structure (1)
- Kinds of AI: unspecified (2), traditional_ml (1), generative_llm (1)
- Substantiveness: detailed (2), generic (1), specific (1)
- Disclosure traits: none
- Trait activation rate: 0.0 (boilerplate (0.0), hedging (0.0), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 1A (2), Item 1C (2)
- Named entities: none

## Item 1A RISK FACTORS (blocks 176-178)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: strategic_competitive | mit: other | kinds: traditional_ml | substantiveness: generic**

> Digital technologies, including artificial intelligence (AI) and machine learning capabilities, have and may continue to increase in their applicability and importance to various aspects of our business, operating and competitive environments, research and development (R&D) pipeline and product portfolio.

> We believe we will need to develop new and enhanced digital capabilities and competences in order to remain competitive.

<details><summary>Passage</summary>

We face intense competition and may not be able to keep pace with the rapid technological changes in the medical devices industry or low-cost competitive offerings, which could have an adverse effect on our business, financial condition or results of operations.

The medical device markets in which we participate are highly competitive. We encounter significant competition across our product lines and in each market in which our products are sold from various medical device companies. Some of our competitors may have greater financial and marketing resources than we do, including as a result of consolidation among companies in our industry. Our primary competitors include large manufacturers with multiple lines of business and competing products, as well as a wide range of medical device companies that sell a single or limited number of competitive products or which participate in only a specific market segment or segments. We also face competition from non-medical device companies, including pharmaceutical companies, biotech companies and providers of various diagnostic solutions, which may offer alternative therapies for disease states also amenable to diagnosis or treatment using our products. New competitors may emerge in the future, potentially including companies introducing new sales or distribution models to our industry or leveraging genomic, robotic, navigation, and/or other automation technologies. Digital technologies, including artificial intelligence (AI) and machine learning capabilities, have and may continue to increase in their applicability and importance to various aspects of our business, operating and competitive environments, research and development (R&D) pipeline and product portfolio. We believe we will need to develop new and enhanced digital capabilities and competences in order to remain competitive.

In addition, the medical device markets in which we participate are characterized by extensive research and development and rapid technological change. Developments by other companies of products and/or services, processes or technologies, including low-cost alternatives, may make our products or proposed products obsolete or less competitive and may negatively impact our net sales. It is necessary for us to devote continued efforts and financial resources to the development or acquisition of scientifically advanced technologies and products. In addition, we will need to apply our technologies cost-effectively across product lines and markets, obtain patent and other protection for our technologies and products, obtain required regulatory and reimbursement approvals and successfully manufacture and market our products consistent with our quality standards. If we fail to develop or acquire new products or enhance existing products, such failure could have a material adverse effect on our business, financial condition or results of operations. In addition, a delay in the timing of the launch of next-generation products and the overall performance of, and continued physician confidence in, those products may result in declines in our market share and have an adverse impact on our business, financial condition or results of operations.

</details>

## Item 1A RISK FACTORS (blocks 229-231)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: cybersecurity | mit: cyberattacks_weapons_mass_harm | kinds: generative_llm | substantiveness: specific**

> This includes opportunities as well as risks associated with the integration of AI into our or our suppliers' or customers' operations.

> While AI presents significant opportunities for innovation and efficiency, it could introduce new risks in managing information systems and in the cybersecurity threat landscape.

> This includes emerging technologies which increase our threat landscape, such as generative AI and quantum computing, which are evolving rapidly in their practicality and use for cyber-attacks including through enhanced social engineering, and for cyber-attacks on industry standard data protections through increased computing capabilities.

<details><summary>Passage</summary>

We rely on information technology (IT) and operational technology (OT) systems, including technology from third party vendors, to manufacture and ship our products, as well as to process, transmit and store electronic information in our day-to-day operations. Similar to other large multi-national companies, the size and complexity of our IT systems makes them vulnerable to a cyber-attack, malicious intrusion, breakdown, destruction, loss of data privacy, or other significant disruption. Various other factors may also cause system failures or security breaches, including power outages, natural disasters, inadequate or ineffective backups, issues with upgrading or creating new systems or platforms, vulnerabilities in third-party software or services, errors by our staff or third-party service providers, or breaches in the security of these technologies. We have faced, and may continue to face, operational interruptions as we continue to implement our global enterprise resource planning (ERP) system. Malicious actors may attempt to trick staff to disclose information to gain access to our systems and/or data. International conflicts have also heightened cybersecurity risks on a global basis. If our incident response, disaster recovery, and business continuity plans fail, such failure could result in adverse impacts to our business operations and our financial results.

Our information systems require an ongoing commitment of significant resources to maintain, protect and enhance existing systems and develop new systems to keep pace with continuing changes in information processing technology, evolving systems and regulatory standards, the increasing need to protect patient and customer information and changing customer patterns. This includes opportunities as well as risks associated with the integration of AI into our or our suppliers' or customers' operations. While AI presents significant opportunities for innovation and efficiency, it could introduce new risks in managing information systems and in the cybersecurity threat landscape. In addition, third parties have and may continue to attempt to hack into our products to obtain data relating to patients, or alter the intended functionality of our medical devices, or disrupt performance of our products, or access our proprietary information and the technology from third party vendors that we rely upon may have defects or vulnerabilities which, in turn, create vulnerabilities or disruptions in our system. Cyber-attacks continue to evolve in complexity and scope, and inherently may be difficult to detect. This includes emerging technologies which increase our threat landscape, such as generative AI and quantum computing, which are evolving rapidly in their practicality and use for cyber-attacks including through enhanced social engineering, and for cyber-attacks on industry standard data protections through increased computing capabilities. We have seen, and could continue to see, software and supply-chain vulnerabilities and malware, which could affect our systems and the systems of our third-party vendors and business partners . Some of our IT and OT systems contain legacy third-party software components for which we depend on a layered security

approach to protect against exploitation, and such layered security approach may not be effective. Any failure by us to maintain or protect our IT or OT systems, products and data integrity, including from cyber-attacks, intrusions or other breaches, could result in outages or unauthorized access to patient data and personally identifiable information, theft of intellectual property or other misappropriation of assets, or otherwise compromise our confidential or proprietary information and disrupt our operations, or, in the worst case, could result in harm to patients. In addition, such attackers may make demands for ransom, which could result in financial loss, or, if we determine not to pay such ransom, other harm, loss, or misappropriation of our data and assets. Such failure, or demonstration of vulnerability to such failure, may also result in additional regulatory scrutiny. We also grow our company through acquisitions and may face risks associated with defects and vulnerabilities in acquired systems as we work to integrate the acquisitions into our IT system.

</details>

## Item 1C CYBERSECURITY (blocks 285-288)

**AI reference: explicit | frame: governance | roles: adoption, governance | adoption: deployed | functions: it_cybersecurity | responses: technical_controls | kinds: unspecified | substantiveness: detailed**

> We also use a managed security service provider to enhance our security operations center with AI-enabled monitoring, analysis, and threat correlation capabilities.

<details><summary>Passage</summary>

We have established an enterprise cybersecurity program , which is administered by a cross-functional team of cybersecurity professionals that includes employees and third party contractors and vendors, that utilizes various tools, methodologies and processes to assess, identify and manage cybersecurity risks related to our information technology (IT) and operational technology (OT) systems. Our cybersecurity program is designed to monitor and continually enhance our enterprise security posture, including assessments to evaluate readiness and resilience with the goal of preventing incidents and mitigating the impact in the event an incident occurs. We have implemented cybersecurity policies mapped to industry and government standards and frameworks, such as U.S. National Institute of Standards and Technology (NIST) and International Standard of Organization, and our strategy is aligned to the NIST CyberSecurity Framework that provides us a structured approach to managing our cybersecurity risk through its five core functions. We regularly review our cybersecurity policies and require annual cybersecurity training for our employees. We also periodically conduct simulation exercises involving employees at various levels of the organization and provide annual cybersecurity briefings to our Board of Directors. Cybersecurity education has also been provided to our Board of Directors to support incident preparedness.

We have an established product cybersecurity program that ensures cybersecurity risk management is incorporated into the entire lifecycle for all of our products. Our product cybersecurity program applies various tools, methodologies and processes to each lifecycle stage and helps ensure that our products are designed, built, tested, deployed and maintained in accordance with medical device cybersecurity standards, best practices, and guidance documents. This serves to build appropriate cybersecurity controls into our medical device products while also meeting regulatory compliance objectives.

We engage third-party security partners for specialized services such as incident response, penetration testing, and on-demand cybersecurity support. We also use a managed security service provider to enhance our security operations center with AI-enabled monitoring, analysis, and threat correlation capabilities. All third parties undergo security due diligence and risk assessment prior to engagement, with additional reviews performed as needed based on risk. If a third party experiences a cybersecurity incident that could affect our business, we conduct a full assessment and implement appropriate safeguards. Our cybersecurity team also continually monitors third-party security posture to help mitigate risks to our systems.

Cybersecurity risks are also monitored within our enterprise risk management (ERM) program and included in the risk universe used to assess top risks to the Company on an annual basis. Risks are discussed with appropriate members of management, who oversee risk coverage, monitoring and reporting in the relevant risk function, including in our cybersecurity program, and incorporate those activities as part of developing our strategic plan.

</details>

## Item 1C CYBERSECURITY (blocks 292-293)

**AI reference: explicit | frame: governance | roles: governance | responses: oversight_structure | kinds: unspecified | substantiveness: detailed**

> Under our framework, cybersecurity issues, including vulnerabilities introduced through our IT and OT systems, the use of artificial intelligence technologies, and risks arising from third-party software and service providers, are analyzed by subject matter experts, including a crisis committee as needed in accordance with our incident response plans, for potential financial, operational, and reputational risks, based on, among other factors, the nature of the matter and breadth of impact.

<details><summary>Passage</summary>

Our Board of Directors (the Board) oversees an enterprise-wide approach to risk management, including cybersecurity risks. While the Board has ultimate responsibility for risk oversight, each committee of the Board also oversees risks to the extent they relate to the committee’s respective area of responsibility and provides reports to the Board as appropriate. The Board receives annual updates (or more frequently, as appropriate under the procedures described below) on cybersecurity matters, including our cybersecurity program, cybersecurity risks, and the evolving threat landscape. Separately, the Board receives cybersecurity risk updates through the ERM program's annual risk assessment presented to the Board.

We have established controls and procedures to escalate enterprise level issues, including cybersecurity matters, to the appropriate management levels within our organization and the Board, or members or committees thereof, as appropriate. Under our framework, cybersecurity issues, including vulnerabilities introduced through our IT and OT systems, the use of artificial intelligence technologies, and risks arising from third-party software and service providers, are analyzed by subject matter experts, including a crisis committee as needed in accordance with our incident response plans, for potential financial, operational, and reputational risks, based on, among other factors, the nature of the matter and breadth of impact. Matters determined to present potential material impacts to our financial results, operations, and/or reputation are immediately reported by management to the Board, or individual members or committees thereof, as appropriate, in accordance with our established escalation framework. In addition, we have established procedures to help ensure that members of management responsible for overseeing the effectiveness of disclosure controls are informed in a timely manner of known cybersecurity risks and incidents that may materially impact our operations and that timely public disclosure is made, as appropriate.

</details>

# Context passages: implicit mentions, not classified

## Item 1 BUSINESS (blocks 92-94)

**Terms: machine-assisted (Computer Assisted)**

In the second quarter of 2025, we completed our acquisition of the remaining shares of Bolt Medical, Inc. (Bolt Medical), the developer of an intravascular lithotripsy advanced laser-based platform for the treatment of coronary and peripheral artery disease. In addition, we completed the acquisition of the remaining shares of SoniVie Ltd. (SoniVie), a privately held medical device company that has developed the TIVUS™ Intravascular Ultrasound System. An investigational technology, the TIVUS System is designed to denervate nerves surrounding blood vessels to treat a variety of hypertensive disorders, including renal artery denervation for hypertension.

On January 15, 2026, we announced our entry into a definitive agreement to acquire 100 percent of Penumbra, Inc. (Penumbra), a publicly traded medical technology company primarily focused on innovative medical thrombectomy products for use in peripheral vascular procedures in the removal of blood clots and blockages. The Penumbra portfolio includes the Lightning Bolt™ and Lightning Flash™ Computer Assisted Vacuum Thrombectomy (CAVT™) Systems. The purchase price is valued at $374 per share, or approximately $14.500 billion. The transaction is expected to close during 2026, subject to customary closing conditions. We plan to fund the transaction consideration through a combination of cash on hand and newly issued debt in an aggregate amount equal to approximately $11.000 billion, and the remaining portion of the transaction consideration will be paid in shares of our common stock.

Watchman

## Item 1 BUSINESS (blocks 102-104)

**Terms: remote patient monitoring (remote monitoring)**

Cardiac Rhythm Management

Our Cardiac Rhythm Management (CRM) business unit develops and manufactures a variety of implantable devices that monitor the heart and deliver electricity to treat cardiac abnormalities. Our product offerings include implantable cardioverter defibrillators (ICD) (RESONATE™) and implantable cardiac resynchronization therapy defibrillators (CRT-D) (HeartLogic™ Heart Failure (HF) Diagnostic and SmartCRT™ Technology), subcutaneous implantable cardiac defibrillators (S-ICD) (EMBLEM™ MRI S-ICD System), which provide physicians the ability to treat patients who are at risk for sudden cardiac arrest without touching the heart, pacemakers and implantable cardiac resynchronization therapy pacemakers (CRT-P) (ACCOLADE™), remote patient management systems (LATITUDE™) and cardiac monitoring systems (BodyGuardian™ Remote Cardiac Monitoring Systems provide a full range of mobile health solutions and remote monitoring services), and our LUX-Dx II+™ Insertable Cardiac Monitor System, a long-term diagnostic device implanted in patients to detect arrhythmias associated with conditions such as AF, cryptogenic stroke and syncope.

Interventional Oncology and Embolization

## Item 1 BUSINESS (blocks 131-133)

**Terms: EU MDR (Medical Device Regulations)**

As a global company, we are governed by federal, state, local and international laws of general applicability relating to, among other things, employment, labor, privacy and data protection, governance and securities, anti-corruption, fraud and abuse (including anti-kickback and false claims laws), competition, trade and export controls. In general, the scope and complexity of regulations applicable to our business has increased over time. We anticipate that governmental authorities will continue to scrutinize our industry closely and that additional regulation may increase compliance and legal costs. Any adverse regulatory actions or exposure to litigation could have an adverse effect on our business, results of operations or financial condition.

Medical Device Regulations

The medical devices that we manufacture, market and commercialize are subject to regulation by numerous worldwide regulatory bodies, including the FDA in the United States, the European Medicines Agency (EMA) in Europe and other comparable international regulatory agencies. These agencies require manufacturers of medical devices to comply with applicable laws and regulations governing development, testing, manufacturing, labeling, marketing and distribution. Medical devices are also generally subject to varying levels of regulatory control based on risk level of the device.

## Item 1 BUSINESS (blocks 135-138)

**Terms: EU MDR (EU MDR, Medical Device Regulation, medical device regulations, notified body), conformity assessment (conformity assessment)**

modifications require a new marketing authorization is initially left to the manufacturer to assess using available guidance; however, regulators may review this determination to evaluate the regulatory status of the modified product at any time and may require the manufacturer to cease marketing and recall the modified device until a new marketing authorization is obtained.

In the European Union (EU), a CE Mark is required to sell medical devices, which represents that products meet required standards of performance, safety, and quality. A CE Mark is affixed following a conformity assessment and either approval from an appointed independent notified body or through self-certification by the manufacturer. In 2017, the EU enacted the Medical Device Regulation (MDR or EU MDR), which became effective in May 2021, and changed multiple aspects of the regulatory framework for CE marking, including increased compliance requirements for the medical device industry. Medical devices that have a valid CE Certificate issued before May 2021 can continue to be sold during the applicable transition period or until the CE Certificate expires, whichever comes first, provided there are no significant changes to the design or intended use. In 2023, the European Commission extended the transitional period to 2027 for certain high risk class devices and 2028 for lower risk class medical devices. The MDR has required significant investment and will continue to require ongoing investment over the next couple of years to transition all products. The CE mark continues to be a prerequisite for successful registration in many other global geographies. In addition, other EU countries continue to impose significant local registration requirements despite the implementation of MDR.

We are also required to comply with the regulations of every other country where we commercialize products before we can launch or maintain new products on the market, including NMPA regulations in China, Ministry of Health, Labour and Welfare (MHLW) and PMDA regulations in Japan, and regulations in many countries in the Middle East and Southeast Asia that previously did not have, or had minimal, medical device regulations.

The FDA and other worldwide regulatory agencies and competent authorities actively monitor compliance to local laws and regulations through review and inspection of design and manufacturing practices, record-keeping, reporting of adverse events, labeling and promotional practices. The FDA can ban certain medical devices, detain or seize adulterated or misbranded medical devices, order recall or market withdrawal of these devices and require notification of health professionals and others with regard to medical devices that present unreasonable risks of substantial harm to the public health. The FDA may also enjoin and restrain a company for certain violations of the Food, Drug and Cosmetic Act and the Safe Medical Devices Act, pertaining to medical devices, or initiate action for criminal prosecution of such violations. Regulatory agencies and authorities in the countries where we do business can halt production in or distribution within their respective country or otherwise take action in accordance with local laws and regulations.

## Item 1A RISK FACTORS (blocks 190-192)

**Terms: EU MDR (medical device regulations)**

International net sales accounted for 36 percent of our global net sales in 2025. An important part of our strategy is to continue pursuing growth opportunities in net sales and market share outside of the U.S. by expanding global presence, including in Emerging Markets. Our international operations are subject to a number of market, business and financial risks and uncertainties, including those related to our use of channel partners, go-to-market strategies, geopolitical and economic instability, foreign currency exchange and interest rate fluctuations, competitive product offerings, local changes in health care financing and payment systems and health care delivery systems, local product preferences and requirements, including preferences for local manufacturers, trade protection measures, including tariffs and other barriers to market participation, workforce instability, weaker intellectual property protection in certain countries than exists in the U.S. and longer accounts receivable cycles. Such risks and uncertainties may adversely impact our ability to implement our growth strategy in these markets and, as a result, our sales growth, market share and operating profits from our international operations may be adversely affected.

Our international operations are subject to established and developing legal and regulatory requirements for medical devices in each country in which our products are marketed and sold. Most foreign countries have medical device regulations. Further, most countries outside of the U.S. require product approvals be renewed or re-certified on a regular basis in order to continue to be marketed and sold there. In addition, several countries that previously did not have regulatory requirements for medical devices have established such requirements in recent years and other countries have expanded, or plan to expand, existing regulations, including requiring local clinical data in addition to global clinical data. These factors have caused or may cause us to experience more uncertainty, risk, expense and delay in obtaining approvals and commercializing products in certain jurisdictions, which could adversely impact our net sales, market share and operating profits from our international operations.

Further, international markets are affected by economic pressure to contain health care costs, which can lead to more rigorous evidence requirements and lower reimbursement rates for either our products directly or procedures in which our products are used. Governments and payers may also institute changes in health care delivery systems that may reduce funding for services, seek payback from market participants, or encourage greater scrutiny of health care costs. In addition, certain international markets may also be affected by foreign government efforts to reference reimbursement rates in other countries. All of these types of changes may ultimately reduce selling prices of our products and/or reduce the number of procedures in which our products are used, which may adversely impact our net sales, market share and operating profits from our international operations.

## Item 1A RISK FACTORS (blocks 242-251)

**Terms: EU MDR (Medical Device Regulation, medical device regulation, medical device regulations, notified body, post-market surveillance)**

We cannot predict the specific health care programs and regulations that will be ultimately implemented by various regional and national governments. However, any changes that lower reimbursements for either our products and/or procedures using our products reduce medical procedure volumes and/or increase cost containment pressures on us or others in the health care sector could adversely affect our business and results of operations.

We are subject to extensive and dynamic medical device regulation, which may impede or hinder the approval or sale of our products and, in some cases, may ultimately result in an inability to obtain approval of certain products or may result in the recall or seizure of previously approved products.

Our products, marketing, sales and development activities and manufacturing processes are subject to extensive and rigorous regulation by the FDA pursuant to the Federal Food, Drug and Cosmetic Act (FDC Act), by comparable agencies in foreign countries and by other regulatory agencies and governing bodies. Under the FDC Act, medical devices must receive FDA clearance or approval or an exemption from such clearance or approval before they can be commercially marketed in the U.S. In the EU, we are required to comply with the Medical Device Regulation (MDR), which became effective in May 2021 and changed multiple aspects of the regulatory framework for CE Marking, including increased compliance requirements for the medical device industry. Medical devices that have a valid CE Certificate issued before May 2021 can continue to be sold during the applicable transition period or until the CE Certificate expires, whichever comes first, provided there are no significant changes to the design or intended use. In 2023, the European Commission extended the transitional period to 2027 for certain high risk class devices and 2028 for lower risk class medical devices. The CE Mark is applied following approval from an independent notified body or declaration of conformity. The process of obtaining marketing approval or clearance from the FDA or by comparable agencies in foreign countries for new products, or with respect to enhancements or modifications to existing products, could:

take a significant period of time,

require the expenditure of substantial resources,

involve rigorous pre-clinical and clinical testing, as well as increased post-market surveillance,

require changes to products, and

result in limitations on the indicated uses of products.

In addition, exported devices are subject to the regulatory requirements of each country to which the device is exported. Some countries do not have medical device regulations, but in most countries, medical devices are regulated. Frequently, regulatory approval may first be obtained in a foreign country prior to application in the U.S. due to differing regulatory requirements; however, other countries, such as China for example, require approval in the country of origin or legal manufacturer first. Most countries outside of the U.S. require that product approvals be renewed or recertified on a regular basis, generally every four to five years. The renewal or recertification process requires that we evaluate any device changes and any new regulations or standards relevant to the device and conduct appropriate testing to document continued compliance. Where renewal or recertification applications are required, they may need to be renewed and/or approved in order to continue selling our products in those countries. There can be no assurance that we will receive the required approvals for new products or modifications to existing products on a timely basis or that any approval will not be subsequently withdrawn or conditioned upon extensive post-market study requirements.

Our global regulatory environment is becoming increasingly stringent and unpredictable, which could increase the time, cost and complexity of obtaining regulatory approvals, as well as the clinical and regulatory costs of supporting those approvals. Several countries that did not previously have regulatory requirements for medical devices have established such requirements in recent years and other countries have expanded on existing regulations. Certain regulators are exhibiting less flexibility and are requiring local preclinical and clinical data in addition to global data. While harmonization of global regulations has been pursued, requirements continue to differ significantly among countries. We expect this global regulatory environment will continue to evolve, which could impact our ability, or increase the time and cost, to obtain future approvals for our products.

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 398-400)

**Terms: EU MDR (EU MDR)**

compared to 2023 were inventory charges, including related to the POLARx™ cryoablation system given the strong commercial adoption of our Farapulse™ PFA System, strategic manufacturing capacity investments and other period expenses, partially offset by increased sales of higher margin products.

EU MDR Implementation Costs

We began our EU MDR implementation efforts in late 2019 and have incurred cumulative expenses of $464 million through December 31, 2025, which are primarily being recorded within Cost of product sold . We expect to incur total expenses of approximately $475 million to $525 million over the transition period.

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 573-575)

**Terms: EU MDR (EU MDR)**

To supplement our consolidated financial statements presented on a GAAP basis, we disclose certain non-GAAP financial measures, including adjusted net income (loss), adjusted net income (loss) attributable to Boston Scientific common stockholders and adjusted net income (loss) per share (EPS) that exclude certain charges (credits); operational net sales, which exclude the impact of foreign currency fluctuations; and organic net sales, which exclude the impact of foreign currency fluctuations as well as the impact of certain acquisitions and divestitures with less than a full period of comparable net sales. These non-GAAP financial measures are not in accordance with U.S. GAAP and should not be considered in isolation from or as a replacement for the most directly comparable GAAP financial measures. Further, other companies may calculate these non-GAAP financial measures differently than we do, which may limit the usefulness of those measures for comparative purposes.

To calculate adjusted net income (loss), adjusted net income (loss) attributable to Boston Scientific common stockholders and adjusted net income (loss) per share, we exclude certain charges (credits) from GAAP net income and GAAP net income attributable to Boston Scientific common stockholders, which include amortization expense, goodwill and other intangible asset impairment charges, acquisition/divestiture-related net charges (credits), investment portfolio net losses (gains) and impairments, restructuring and restructuring-related net charges (credits), certain litigation-related net charges (credits), EU MDR implementation costs, debt extinguishment net charges, deferred tax expenses (benefits) and certain discrete tax items. Amounts are presented after-tax using our effective tax rate, unless the amount is a significant unusual or infrequently occurring item in accordance with FASB ASC Topic 740-270-30, "General Methodology and Use of Estimated Annual Effective Tax Rate."

The GAAP financial measure most directly comparable to adjusted net income (loss), adjusted net income (loss) attributable to Boston Scientific common stockholders and adjusted net income (loss) per share are GAAP net income (loss), GAAP net income (loss) attributable to Boston Scientific common stockholders and GAAP net income (loss) per common share - diluted, respectively.

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 587-589)

**Terms: EU MDR (EU MDR)**

Litigation-related net charges (credits) - These adjustments include certain product liability and other litigation-related charges and credits. We record these charges and credits, which we consider to be unusual or infrequent and significant, within the litigation-related charges (credits) line in our consolidated statements of operations; all other legal charges, credits and costs are recorded within selling, general and administrative expenses. Certain litigation-related net charges (credits) are excluded from management's assessment of operating performance and from our operating segments' measures of profit and loss used for making operating decisions and assessing performance,

EU MDR implementation costs - These adjustments represent certain incremental costs specific to complying with new regulatory requirements in the EU. EU MDR replaced the existing MDD regulatory framework, and manufacturers of medical devices were required to comply with EU MDR beginning in May 2021 for new products and by May 2024 for medical devices which have a valid CE Certificate to the Directives issued before May 2021. In 2023, updates to the legislative text of the EU MDR were adopted by the European Parliament and the Council of the European Union, including an extension of the transitional period to 2027 for certain high risk class devices and 2028 for lower risk class medical devices that have a valid CE Certificate to the Directives issued before May 2021. We expect to incur significant expenditures in connection with the adoption of the EU MDR requirements and we consider the adoption of EU MDR to be a significant change to a regulatory framework, and therefore, these expenditures are not considered to be ordinary course expenditures in connection with regulatory matters. As such, certain of these costs are excluded from management's assessment of operating performance and from our operating segments' measures of profit and loss used for making operating decisions and assessing performance,

Debt extinguishment net charges - These amounts relate to the early extinguishment of certain outstanding principal amounts of our senior notes. Certain debt extinguishment net charges are excluded from management's assessment of operating performance used for making operating decisions and assessing performance,

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 606-608)

**Terms: EU MDR (Medical device regulation)**

Investment portfolio net losses (gains) and impairments | 26 | (0) | 26 | — | 26 | 0.02

European Union (EU) Medical device regulation (MDR) implementation costs | 46 | 6 | 39 | — | 39 | 0.03

Deferred tax expenses (benefits) | — | (206) | 206 | — | 206 | 0.14

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 619-621)

**Terms: EU MDR (EU MDR)**

Investment portfolio net losses (gains) and impairments | 20 | 1 | 19 | — | 19 | 0.01

EU MDR implementation costs | 52 | 7 | 45 | — | 45 | 0.03

Deferred tax expenses (benefits) | — | (165) | 165 | — | 165 | 0.11

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 632-634)

**Terms: EU MDR (EU MDR)**

Investment portfolio net losses (gains) and impairments | 21 | (3) | 24 | — | — | 24 | 0.02

EU MDR implementation costs | 69 | 10 | 59 | — | — | 59 | 0.04

Deferred tax expenses (benefits) | — | (155) | 155 | — | — | 155 | 0.11

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1637-1639)

**Terms: EU MDR (Medical Device Regulation)**

We aggregate our core businesses into two reportable segments: MedSurg and Cardiovascular, each of which generates revenues from the sale of medical devices. In accordance with FASB ASC Topic 280, Segment Reporting, we identified our reportable segments based on the nature of our products, production processes, type of customer, selling and distribution methods and regulatory environment, as well as the economic characteristics of each of our operating segments. In the fourth quarter of 2025, we reorganized our operating segments; this change had no impact on our reportable segments. Our chief operating decision maker (CODM) is our President and Chief Executive Officer.

We measure and evaluate our reportable segments based on their respective net sales, cost of goods sold, selling, general and administrative expenses, research and development expenses, operating income, excluding intersegment profits, and operating income as a percentage of net sales, all based on internally-derived standard currency exchange rates to exclude the impact of foreign currency, which may be updated from year to year. We exclude from segment expenses and segment operating income certain corporate-related expenses and certain transactions or adjustments that our CODM considers to be non-operational, such as amounts related to amortization expense, goodwill and other intangible asset impairment charges, acquisition/divestiture-related net charges (credits), restructuring and restructuring-related net charges (credits), certain litigation-related net charges (credits) and European Union (EU) Medical Device Regulation (MDR) implementation costs. Although we exclude these amounts from segment expenses and segment operating income, they are included in reported Income (loss) before income taxes within our consolidated statements of operations and are included in the reconciliation below. The CODM uses segment operating income in the strategic plan, annual operating plan and other forecasting cycles. During these forecasting cycles, the CODM compares budget versus actual results to evaluate both internal and external events and conditions, which are used in assessing the performance of the reportable segments and to allocate resources across our reportable segments. Refer to Note N – Revenue for net sales by reportable segment presented in accordance with GAAP.

A reconciliation of sales and operating income for the reportable segments to the applicable line items within our accompanying consolidated statements of operations is as follows (in millions, except percentages). Prior period amounts have been restated at constant currency to conform to the current year presentation.

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1651-1653)

**Terms: EU MDR (EU MDR)**

Corporate expenses, including hedging activities and impact of foreign currency fluctuations on operating income of reportable segments | ( 958 )

Goodwill and other intangible asset impairment charges, acquisition/divestiture-related net charges (credits), restructuring and restructuring-related net charges (credits), certain litigation-related net charges (credits) and EU MDR implementation costs | ( 1,102 )

Amortization expense | ( 897 )

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1668-1670)

**Terms: EU MDR (EU MDR)**

Corporate expenses, including hedging activities and impact of foreign currency fluctuations on operating income of reportable segments | ( 788 )

Goodwill and other intangible asset impairment charges, acquisition/divestiture-related net charges (credits), restructuring and restructuring-related net charges (credits), certain litigation-related net charges (credits) and EU MDR implementation costs | ( 1,070 )

Amortization expense | ( 856 )

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1685-1687)

**Terms: EU MDR (EU MDR)**

Corporate expenses, including hedging activities and impact of foreign currency fluctuations on operating income of reportable segments | ( 489 )

Goodwill and other intangible asset impairment charges, acquisition/divestiture-related net charges (credits), restructuring and restructuring-related net charges (credits), certain litigation-related net charges (credits) and EU MDR implementation costs | ( 567 )

Amortization expense | ( 828 )

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1741-1743)

**Terms: remote patient monitoring (Remote Monitoring)**

Contract liabilities are classified within Other current liabilities and Other long-term liabilities within our accompanying consolidated balance sheets. Our deferred revenue balance was $ 682 million as of December 31, 2025 and $ 635 million as of December 31, 2024. Our contract liabilities are primarily composed of deferred revenue related to the LATITUDE™ Patient Management System within our Cardiovascular business, for which revenue is recognized over the average service period based on device and patient longevity. Our contract liabilities also include deferred revenue related to the LUX-Dx II+™ Insertable Cardiac Monitor system, also within our Cardiovascular business, for which revenue is recognized over the average service period based on device longevity and usage. We recognized revenue of $ 264 million in 2025 that was included in the above contract liability balance as of December 31, 2024.

We capitalize sales force commissions related to contracts with customers when the associated revenue is expected to be earned over a period that exceeds one year. Deferred commissions are primarily related to the sale of devices enabled with our LATITUDE™ Patient Management System. We have elected to expense commission costs when incurred for contracts with an expected duration of one year or less. Capitalized commission fees are amortized over the period the associated products or services are transferred. Similarly, we capitalize certain recoverable costs related to the delivery of the LATITUDE™ Remote Monitoring Service. These fulfillment costs are amortized over the average service period.

Refer to Note A – Significant Accounting Policies for additional information on our accounting policies relating to revenue recognition.
