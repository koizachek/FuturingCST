# TEXAS INSTRUMENTS INC | 10-Q | fiscal year 2026

- Report length: 9,015 words
- Direct AI mentions (classified): 0, of which about AI: 0, false candidates: 0, flagged for review: 0
- Context passages (not classified): 11; groups: industry (8), compute_infrastructure (3)
- Frames: none
- Roles: none
- Risk types: none
- MIT subdomains: none
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: none
- Substantiveness: none
- Disclosure traits: none
- Trait activation rate: n/a
- Sections: none
- Named entities: none

# Context passages: implicit mentions, not classified

## Item 1 Legal proceedings (blocks 141-143)

**Terms: CHIPS Act (CHIPS Act, CHIPS and Science Act)**

Capital expenditures | ( 676 ) | ( 1,123 )

Proceeds from U.S. CHIPS and Science Act (CHIPS Act) incentives | 555 | 260

Proceeds from asset sales | 5 | —

## Item 1 Legal proceedings (blocks 159-162)

**Terms: CHIPS Act (CHIPS Act)**

Investment tax credit (ITC) used to reduce income taxes payable | $ — | $ —

Proceeds from CHIPS Act incentives | 555 | 260

Total cash benefit related to the CHIPS Act | $ 555 | $ 260

See accompanying notes.

## Item 1 Legal proceedings (blocks 367-369)

**Terms: CHIPS Act (CHIPS Act)**

2026 | 2025

CHIPS Act incentives | $ 1,404 | $ 1,709

Other | 349 | 393

## Item 1 Legal proceedings (blocks 372-374)

**Terms: CHIPS Act (CHIPS Act)**

2026 | 2025

CHIPS Act incentives | $ 1,493 | $ 1,639

Other | 1,012 | 1,017

## Item 2 Unregistered sales of equity securities and use of proceeds (blocks 412-414)

**Terms: data center (data center)**

Markets for our products

The markets for our products are industrial, automotive, data center, personal electronics and communications equipment. See our 2025 Form 10-K for more information.

Semiconductor cycle

## Item 2 Unregistered sales of equity securities and use of proceeds (blocks 436-438)

**Terms: data center (data center)**

Our first quarter revenue was $4.83 billion, net income was $1.55 billion and earnings per share (EPS) were $1.68.

Revenue increased 9% sequentially and 19% from the same quarter a year ago with growth led by industrial and data center.

Our cash flow from operations of $7.8 billion for the trailing 12 months again underscored the strength of our business model, the quality of our product portfolio and the benefit of 300mm production. Free cash flow for the same period was $4.4 billion.

## Item 2 Unregistered sales of equity securities and use of proceeds (blocks 440-442)

**Terms: data center (data center)**

Macroeconomic factors

In first quarter, the overall analog and embedded semiconductor market recovery continued. While uncertainty related to broader macroeconomic dynamics remains, growth of semiconductor content in electronics has continued to drive demand for our products, particularly in the industrial, automotive and data center markets. We believe we are well positioned with inventory and capacity to support our customers with competitive lead times through the semiconductor cycle.

Acquisition of Silicon Labs

## Item 2 Unregistered sales of equity securities and use of proceeds (blocks 480-483)

**Terms: CHIPS Act (CHIPS Act, CHIPS and Science Act)**

Our primary source of liquidity is cash flow from operations. Additional sources of liquidity are cash and cash equivalents, short-term investments and access to debt markets. We also have a variable-rate, revolving credit facility. As of March 31, 2026, our credit facility was undrawn, and we had no commercial paper outstanding. Cash flows from operating activities for the first three months of 2026 were $1.52 billion, an increase of $671 million from the year-ago period due to higher net income and non-cash items, as well as lower cash used for working capital.

Investing activities for the first three months of 2026 used $47 million compared with $1.25 billion of cash provided in the year-ago period. Capital expenditures were $676 million compared with $1.12 billion in the year-ago period and were primarily for semiconductor manufacturing equipment and facilities in both periods. U.S. CHIPS and Science Act (CHIPS Act) incentives provided cash proceeds of $555 million of direct funding compared with $260 million related to the investment tax credit (ITC) in the year-ago period. Short-term investments provided cash of $108 million compared with $2.16 billion in the year-ago period.

We are nearing the end of our six-year elevated capital expenditures cycle, and consistent with our capital management strategy, we are expecting to spend about $2 billion to $3 billion in 2026. Beyond 2026, capital expenditures will be dependent on revenue and growth expectations. We expect to continue benefiting from the CHIPS Act. This includes the 35% ITC on qualifying manufacturing investments as well as direct funding of up to $1.6 billion, of which we have received $630 million, for our three large-scale 300mm wafer fabs located in Sherman, Texas, and Lehi, Utah.

Financing activities for the first three months of 2026 used $1.15 billion compared with $2.54 billion in the year-ago period. We retired maturing debt of $750 million in the year-ago period. Dividends paid were $1.29 billion compared with $1.24 billion in the year-ago period, reflecting an increased dividend rate. We used $158 million to repurchase 0.8 million shares of our common stock compared with $653 million to repurchase 3.5 million shares in the year-ago period. Employee exercises of stock options provided cash proceeds of $309 million compared with $118 million in the year-ago period.

## Item 2 Unregistered sales of equity securities and use of proceeds (blocks 485-487)

**Terms: CHIPS Act (CHIPS Act)**

Non-GAAP financial information

This MD&A includes references to free cash flow and ratios based on that measure. These are financial measures that were not prepared in accordance with generally accepted accounting principles in the United States (GAAP). Free cash flow is calculated as cash flows from operating activities (also referred to as cash flow from operations) less capital expenditures, plus proceeds from CHIPS Act incentives.

We believe that free cash flow and the associated ratios provide insight into our liquidity, our cash-generating capability and the amount of cash potentially available to return to shareholders, as well as insight into our financial performance. These non-GAAP measures are supplemental to the comparable GAAP measures.

## Item 2 Unregistered sales of equity securities and use of proceeds (blocks 493-495)

**Terms: CHIPS Act (CHIPS Act)**

Capital expenditures | (4,103) | (4,695)

Proceeds from CHIPS Act incentives | 630 | 260

Free cash flow (non-GAAP) | $ 4,351 | $ 1,715 | 154 %

## Item 2 Unregistered sales of equity securities and use of proceeds (blocks 498-499)

**Terms: CHIPS Act (CHIPS Act)**

Free cash flow as a percentage of revenue (non-GAAP) | 23.6 % | 10.7 %

Includes cash benefits of $335 million and $588 million from the CHIPS Act ITC used to reduce income taxes payable for the twelve months ended March 31, 2026 and 2025, respectively.
