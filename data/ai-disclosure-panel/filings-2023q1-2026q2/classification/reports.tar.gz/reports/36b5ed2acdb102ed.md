# QUALCOMM INC | 10-Q | fiscal year 2025

- Report length: 32,203 words
- Direct AI mentions (classified): 8, of which about AI: 8, false candidates: 0, flagged for review: 0
- Context passages (not classified): 5; groups: industry (3), compute_infrastructure (3), workforce_society (1), products_vendors (1)
- Frames: business (5), risk_factor (3)
- Roles: offering (4), risk (3), market_driver (1)
- Risk types: cybersecurity (1), operational_reliability (1), regulatory_legal (1)
- MIT subdomains: cyberattacks_weapons_mass_harm (1), lack_of_capability_robustness (1), other (1)
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: unspecified (6), traditional_ml (1), computer_vision (1)
- Substantiveness: specific (6), generic (2)
- Disclosure traits: hedging (1)
- Trait activation rate: 0.125 (boilerplate (0.0), hedging (0.125), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 1A (5), Item 1 (2), Item 2 (1)
- Named entities: none

## Item 1 LEGAL PROCEEDINGS (blocks 257-259)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> Includes revenues from products sold for use in automobiles, including connectivity, digital cockpit and advanced driver assistance systems (ADAS) and automated driving (AD).

<details><summary>Passage</summary>

(1) Includes revenues from products sold for use in mobile handsets.

(2) Includes revenues from products sold for use in automobiles, including connectivity, digital cockpit and advanced driver assistance systems (ADAS) and automated driving (AD).

(3) Primarily includes products sold for use in the following industries and applications: consumer (including personal computers (PCs), tablets, voice and music and extended reality (XR)), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, tracking and logistics and utilities).

</details>

## Item 1 LEGAL PROCEEDINGS (blocks 315-317)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> QCT develops and supplies integrated circuits and system software with advanced connectivity and high-performance, low-power computing technologies for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices, industrial devices and edge networking products.

<details><summary>Passage</summary>

Note 6. Segment Information

We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software with advanced connectivity and high-performance, low-power computing technologies for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices, industrial devices and edge networking products. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our Data Center business (formerly referred to as our cloud computing processing initiative).

The table below presents revenues and earnings (loss) before income taxes (EBT) for reportable segments (in millions):

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 516-518)

**AI reference: explicit | frame: business | roles: market_driver | kinds: unspecified | substantiveness: generic**

> We believe that 5G combined with high-performance, low-power computing and on-device artificial intelligence will continue to drive adoption of certain technologies that are already commonly used in smartphones by industries and applications beyond mobile handsets, such as automotive and IoT.

<details><summary>Passage</summary>

Looking Forward

We believe that 5G combined with high-performance, low-power computing and on-device artificial intelligence will continue to drive adoption of certain technologies that are already commonly used in smartphones by industries and applications beyond mobile handsets, such as automotive and IoT. We believe it is important that we remain a leader in 5G technology development, standardization, intellectual property creation and licensing, and a leading developer and supplier of 5G integrated circuit products in order to sustain and grow our business long-term.

As we look forward to the next several quarters:

</details>

## Item 1A RISK FACTORS (blocks 625-627)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> While we continue to invest significant resources toward advancements of foundational technologies, including wireless connectivity, high-performance and low-power computing and on-device artificial intelligence (AI), we also invest in new and expanded product areas, and industries and applications beyond mobile handsets, by utilizing our existing technical and business expertise and through acquisitions or other strategic transactions.

<details><summary>Passage</summary>

Our growth depends in part on our ability to extend our technologies and products into new and expanded product areas, and industries and applications beyond mobile handsets. Our research, development and other investments in these new and expanded product areas, industries and applications, and related technologies and products, as well as in our existing technologies and products, and new technologies, may not generate operating income or contribute to future results of operations that meet our expectations.

While we continue to invest significant resources toward advancements of foundational technologies, including wireless connectivity, high-performance and low-power computing and on-device artificial intelligence (AI), we also invest in new and expanded product areas, and industries and applications beyond mobile handsets, by utilizing our existing technical and business expertise and through acquisitions or other strategic transactions.

In particular, our future growth depends in part on new and expanded product areas, and industries and applications beyond mobile handsets, such as automotive and IoT; our ability to develop leading and cost-effective technologies and products for these new and expanded product areas, industries and applications; and third parties incorporating our technologies and products into devices used in these product areas, industries and applications. Accordingly, we intend to

</details>

## Item 1A RISK FACTORS (blocks 673-676)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: cybersecurity | mit: cyberattacks_weapons_mass_harm | kinds: unspecified | substantiveness: specific | traits: hedging**

> For example, as AI continues to evolve, cyber-attackers could also use AI to develop malicious code and increasingly sophisticated phishing attempts.

<details><summary>Passage</summary>

The successful operation of various functions within our business, as well as the protection of our intellectual property and other proprietary or confidential information, depend in part on the security and functionality of our IT systems. Third parties regularly attempt to gain unauthorized access to our IT systems, and many such attacks are increasingly more sophisticated. These attacks, which might be related to industrial, corporate or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks, including those in our manufacturing operations, exploiting vulnerabilities in hardware, software or other IT infrastructure and impersonating authorized users, among others. We are also subject to ransom-style cyber-attacks, which could expose our confidential or proprietary information, demand payment of money and/or impact our IT systems and cause widespread disruption to our business, including our manufacturing operations. Third parties that store and/or process our confidential information, or that provide products, software or services used in our IT infrastructure, are subject to similar attacks, which could also result in malware being introduced into our IT infrastructure, e.g., through the third parties’ software and/or software updates. Such attacks could result in the misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our IT systems. Any damage to or disruptions in our IT systems as a result of cyber-attacks or for other reasons, such as issues related to third-party software or services used in our IT infrastructure, could significantly disrupt our business operations.

Although we maintain a cybersecurity program to manage cybersecurity risks, as described in the “Cybersecurity” section of our 2024 Annual Report on Form 10-K, we cannot anticipate, detect, repel or implement fully effective preventative measures against all cybersecurity threats, particularly because the techniques used are increasingly sophisticated and constantly evolving. For example, as AI continues to evolve, cyber-attackers could also use AI to develop malicious code and increasingly sophisticated phishing attempts. As part of our cybersecurity program, we seek to identify and remediate vulnerabilities in our IT systems and software (including third party software used in our IT systems) that could be exploited by hackers or other malicious actors. However, we may not be aware of all such vulnerabilities, and we may fail to identify and/or remediate such vulnerabilities before they are exploited. Attempts to gain unauthorized access to our IT systems or other attacks have in the past, in certain instances and to certain degrees, been successful (but have not caused significant harm), and may in the future be successful, and in some cases, we might be unaware of an incident or its magnitude and effects.

In addition, employees and former employees, in particular former employees who become employees of our competitors, customers, licensees or other third parties, including state actors, have in the past and may in the future misappropriate, wrongfully use, publish or provide to our competitors, customers, licensees or other third parties, including state actors, our technology, intellectual property or other proprietary or confidential information. This risk is exacerbated as competitors for talent, particularly engineering talent, increasingly attempt to hire our employees. See also the Risk Factor titled “We may not be able to attract or retain qualified employees.” Similarly, we provide access to certain of our technology, intellectual property and other proprietary or confidential information to our direct and indirect customers and licensees and certain of our consultants, who have in the past and may in the future wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. We also provide access to certain of our technology, intellectual property and other proprietary or confidential information to certain of our joint venture partners, including those affiliated with state actors and including in foreign jurisdictions where ownership restrictions may require us to take a minority ownership interest in the joint venture. Such joint venture partners may wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. Our technology, intellectual property and other proprietary or confidential information that we have provided to

customers, licensees or other business partners could also be wrongfully obtained by third parties through cyber-attacks on such customers’, licensees’ or other business partners’ IT systems.

</details>

## Item 1A RISK FACTORS (blocks 715-720)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> Competition in the semiconductor industry is affected by various factors that include, among others: OEM concentrations; vertical integration; competition in certain geographic regions; government intervention or support of national industries or competitors; the ability to maintain product differentiation in light of evolving industry standards and speed of technological change (including the transition to smaller geometry process technologies, the demand for always on, always connected capabilities, the increasing use of AI and machine learning technologies and the need to run complex AI-based applications on devices); access to capacity in the supply chain; and value-added features that drive selling prices and consumer demand for new devices.

> differentiate our integrated circuit products with innovative technologies across multiple products and features (e.g., modem, RFFE including millimeter wave (mmWave), graphics and other processors, camera, connectivity and on-device AI) and with smaller geometry process technologies that drive both performance and lower power consumption;

<details><summary>Passage</summary>

Our industry is subject to intense competition in an environment of rapid technological change. Our success depends in part on our ability to adapt to such change and compete effectively; and such change and competition could result in decreased demand for our products and technologies or declining average selling prices for our products or those of our customers or licensees.

Our products and technologies face significant competition. Competition may intensify as our current competitors expand their product offerings, improve their products or reduce the prices of their products as part of a strategy to maintain existing business and customers or attract new business and customers, as new opportunities develop, and as new competitors enter the industry. Competition in the semiconductor industry is affected by various factors that include, among others: OEM concentrations; vertical integration; competition in certain geographic regions; government intervention or support of national industries or competitors; the ability to maintain product differentiation in light of evolving industry standards and speed of technological change (including the transition to smaller geometry process technologies, the demand for always on, always connected capabilities, the increasing use of AI and machine learning technologies and the need to run complex AI-based applications on devices); access to capacity in the supply chain; and value-added features that drive selling prices and consumer demand for new devices.

We anticipate that additional competitors will introduce products as a result of growth opportunities in the industries in which we operate, the trend toward global expansion by foreign and domestic competitors, and technological and public policy changes. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape. For example, if any key supplier of technologies and intellectual property to the semiconductor industry was sold to one of our competitors, it could negatively affect our ability to procure or license such technologies and intellectual property in the future, at all or upon acceptable terms, which could have wide-ranging impacts on our business and operations.

We expect that our future success will depend on, among other factors, our ability to:

differentiate our integrated circuit products with innovative technologies across multiple products and features (e.g., modem, RFFE including millimeter wave (mmWave), graphics and other processors, camera, connectivity and on-device AI) and with smaller geometry process technologies that drive both performance and lower power consumption;

develop and offer integrated circuit products at competitive cost and price points and to effectively cover all geographic regions and all device tiers;

</details>

## Item 1A RISK FACTORS (blocks 741-743)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: operational_reliability | mit: lack_of_capability_robustness | kinds: computer_vision | substantiveness: specific**

> The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications such as: automobiles, including ADAS/AD functions; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and XR for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

<details><summary>Passage</summary>

In addition, the occurrence of defects, errors or security vulnerabilities may give rise to product liability or other commercial claims, particularly if such defects, errors or security vulnerabilities in our products or the technology we use, or the products into which they are integrated, result in personal injury or death, or customer field actions (for example, in the automotive industry, where such term means automotive product-related service actions or repairs for defects, whether

safety-related or not). If a product liability or other commercial claim is brought against us, the cost of defending the claim could be significant, and could divert the attention of our technical and management personnel and harm our business, even if we are successful. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. We may also be required to indemnify and/or defend our customers from product liability claims relating to our products. Further, our business liability insurance may be inadequate, may not cover the claims, and future coverage may be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications such as: automobiles, including ADAS/AD functions; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and XR for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

Accordingly, defects, errors or security vulnerabilities in our products or the technologies we use could have an adverse impact on us, on our customers and the end users of our customers’ products. If any of these risks materialize, there could be a material adverse effect on our business, results of operations and financial condition.

</details>

## Item 1A RISK FACTORS (blocks 770-772)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: other | kinds: unspecified | substantiveness: generic**

> These include, among others, Regulations related to: patent licensing practices; antitrust, competition and competitive business practices; protection of intellectual property; cybersecurity; privacy and data protection; AI technologies; imports and exports, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; trade and trade protection including tariffs; foreign policy and national security; the flow of funds out of certain countries (e.g., China); automotive industry safety, security and quality standards; environmental protection (including climate change), health and safety; supply chain, responsible sourcing (including the use of conflict minerals) and human rights; spectrum availability and license issuance; adoption of standards; taxation; labor, employment and human capital; corporate governance; public disclosure and reporting (including reporting of ESG-related data); and business conduct.

<details><summary>Passage</summary>

Our business and products, and those of our customers and licensees, are subject to various laws, rules and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies (collectively, Regulations). These include, among others, Regulations related to: patent licensing practices;

antitrust, competition and competitive business practices; protection of intellectual property; cybersecurity; privacy and data protection; AI technologies; imports and exports, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; trade and trade protection including tariffs; foreign policy and national security; the flow of funds out of certain countries (e.g., China); automotive industry safety, security and quality standards; environmental protection (including climate change), health and safety; supply chain, responsible sourcing (including the use of conflict minerals) and human rights; spectrum availability and license issuance; adoption of standards; taxation; labor, employment and human capital; corporate governance; public disclosure and reporting (including reporting of ESG-related data); and business conduct. Compliance with, or changes in the interpretation of, existing Regulations, the adoption of new Regulations, changes in the oversight of our activities by governments or standards bodies, or rulings in court, regulatory, administrative or other proceedings relating to such Regulations, among others, could have an adverse effect on our business and results of operations. See also the Risk Factors titled “ Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings,” “ Changes in our patent licensing practices, whether due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations,” “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions,” “ There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises, geopolitical conflicts and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues,” and “Tax liabilities could adversely affect our results of operations.”

Regulations are complex and changing (which may create uncertainty regarding compliance), are subject to varying interpretations, and their application in practice may evolve over time. In addition, and especially in developing regulatory areas (for example, AI, privacy and data protection, and ESG-related reporting), Regulations may differ by country or by state within the United States, and may be conflicting in certain cases. As a result, our efforts to comply with Regulations may fail, particularly if there is ambiguity as to how they should be applied in practice. Failure to comply with any Regulation may adversely affect our business, results of operations and cash flows. New Regulations, or evolving interpretations thereof, may cause us to incur higher costs as we revise current practices, policies or procedures; may divert management time and attention to compliance activities; and may negatively impact our ability to conduct business in certain jurisdictions.

</details>

# Context passages: implicit mentions, not classified

## Item 1 LEGAL PROCEEDINGS (blocks 383-385)

**Terms: advanced packaging (chiplets), custom silicon (custom silicon), data center (data centers)**

Note 8. Acquisitions

Pending. On June 9, 2025, we announced that we reached an agreement with Alphawave IP Group plc (Alphawave) regarding the terms and conditions of a recommended acquisition by Aqua Acquisition Sub LLC, an indirect wholly-owned subsidiary of Qualcomm Incorporated, for the entire issued and to be issued ordinary share capital of Alphawave at an implied enterprise value of approximately $ 2.4 billion (as of the announcement date). The purchase price will be paid in cash or, if validly elected by eligible shareholders of Alphawave, in shares of our common stock or securities exchangeable for shares of our common stock. Alphawave is a developer of high-speed wired connectivity and compute technologies delivering IP, custom silicon, connectivity products and chiplets. The acquisition aims to further accelerate, and provide key assets for, our expansion into data centers. This acquisition is expected to complete during the first calendar quarter of 2026, subject to certain conditions, including receipt of regulatory approvals and approval from the requisite majority of Alphawave’s shareholders. In connection with the pending acquisition, we agreed to restrict the use of $ 2.3 billion in cash, which is presented as restricted cash on our condensed consolidated balance sheets, for the purpose of satisfying payment of the consideration to effect the acquisition.

Completed. During the first nine months of fiscal 2025, we acquired seven businesses for a total accounting purchase price of $ 668 million. These acquisitions were primarily for the purpose of executing on certain products and technology that support our diversification strategy in QCT industrial IoT and automotive. The acquired assets primarily consisted of $ 120 million of intangible assets and $ 532 million of goodwill, which was allocated to our QCT segment and which is primarily attributable to assembled workforce and certain synergies expected to arise after the acquisition.

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 395-397)

**Terms: data center (Data Center)**

We develop and commercialize foundational technologies and products used in mobile devices and other wireless products. We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents and other rights.

We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our Data Center business (formerly referred to as our cloud computing processing initiative).

Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering and research and development functions are operated by Qualcomm Technologies, Inc. (QTI), a wholly-owned subsidiary of QUALCOMM Incorporated, and QTI’s subsidiaries. QTL is operated by QUALCOMM Incorporated, which owns the vast majority of our patent portfolio. Neither QTI nor any of its subsidiaries has any right, power or authority to grant any licenses or other rights under or to any patents owned by QUALCOMM Incorporated.

## Item 1A RISK FACTORS (blocks 620-623)

**Terms: Entity List (entity lists), export controls (export licenses)**

Due to various factors, including pressure, encouragement or incentives from, or policies of, the Chinese government (such as its Made in China 2025 campaign), concerns over losing access to our integrated circuit products as a result of actual, threatened or potential U.S. or Chinese government actions or policies, including trade protection or national security policies, or other reasons, some of our customers in China have developed, and others may in the future develop, their own integrated circuit products and use such integrated circuit products in their devices, or use our competitors’ integrated circuit products in their devices, rather than our products, which could materially harm our business, revenues, results of operations, cash flows and financial position. See also the Risk Factor titled “ Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

Political actions, including trade protection and national security policies of the U.S. and Chinese governments, such as tariffs, bans or placing companies on restricted entity lists, have in the past, currently are and could in the future limit or prevent us from transacting business with certain of our Chinese customers or suppliers, limit, prevent or discourage certain of our Chinese customers or suppliers from transacting business with us, or make it more expensive to do so. Given our revenue concentration in China, if, due to actual, threatened or potential U.S. or Chinese government actions or policies: we were further limited in, or prohibited from, selling our integrated circuit products to Chinese customers; our non-Chinese OEM customers were limited in, or prohibited from, selling devices that incorporate our integrated circuit products into China; Chinese OEMs develop and use their own integrated circuit products or use our competitors’ integrated circuit products in some or all of their devices rather than our integrated circuit products; Chinese tariffs on our integrated circuit products or on devices which incorporate our integrated circuit products made purchasing such products or devices more expensive to our Chinese customers or Chinese consumers; or our Chinese licensees delay or cease making payments of license fees they owe us, our business, revenues, results of operations, cash flows and financial position could be materially harmed. Similarly, if, due to U.S. or Chinese government actions or policies, we were limited in or prohibited from obtaining critical integrated circuit products from our suppliers in China, or we or our customers were limited in or prohibited from selling in the United States products containing technologies with Chinese-origin content, our business, revenues, results of operations, cash flows and financial position could be materially harmed. See also the Risk Factors titled “ We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium-tier handset devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected ” and “ Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

For example, we previously sold 4G and other integrated circuit products, including Wi-Fi products, but excluding 5G products, to Huawei under export licenses from the U.S. Department of Commerce. On May 7, 2024, the U.S. Department of Commerce informed us that it was revoking our license to export 4G and certain other integrated circuit products to Huawei, effective immediately, and we implemented procedures to immediately comply. Accordingly, we do not expect to receive any further product revenues from Huawei. Additionally, to the extent that Huawei’s devices take share from Chinese OEMs that utilize our products or from non-Chinese OEMs that utilize our products in devices they sell into China, our revenues, results of operations and cash flows could be further impacted.

Finally, government policies in China that regulate the amount and timing of funds that may flow out of the country have impacted and may continue to impact the timing of our receipt of, and/or ability to receive, payments from our customers and licensees in China, which may negatively impact our cash flows.

## Item 1A RISK FACTORS (blocks 680-682)

**Terms: digital talent (engineering talent)**

We may not be able to attract or retain qualified employees.

Our future success depends upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. In addition, in order to extend our business into certain new and expanded product areas and industries and applications beyond mobile handsets, we need to attract, retain and motivate engineering and other technical personnel with specialized skills in these areas, and these skills are in high demand among our competitors. The market for employees in our industry is extremely competitive, and competitors for talent, particularly engineering talent, increasingly attempt to hire, and to varying degrees have been successful in hiring, our employees or employment candidates, including by establishing or expanding local offices near our headquarters in San Diego, California. Further, the increased availability of remote working arrangements has expanded the pool of companies that can compete for our employees and employment candidates. A number of such competitors for talent are significantly larger than us and/or offer compensation in excess of what we offer or other benefits that we do not offer, including remote work policies that may be perceived as more favorable than ours. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller.

If we are unable to attract or retain qualified employees or fail to maintain employee productivity due to any of the factors described above or for other reasons, our business could be adversely impacted.

## Item 1A RISK FACTORS (blocks 730-732)

**Terms: Nvidia (Nvidia)**

continue to develop brand recognition to effectively compete against better known companies in computing and other consumer driven segments and to deepen our presence in significant emerging regions.

We compete with many different semiconductor companies, ranging from multinational companies with integrated research and development, manufacturing, sales and marketing organizations across a broad spectrum of product lines, to companies that are focused on a single application, industry or standard product, including those that produce products for mobile handsets, automotive or IoT, among others. Most of these competitors compete with us with respect to some, but not all, of our businesses or product lines. Companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Broadcom, HiSilicon, MediaTek, Mobileye, Nvidia, NXP Semiconductors, Qorvo, Samsung, Skyworks, Texas Instruments and UNISOC. Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to use our competitors’ integrated circuit products, to utilize their own internally-developed integrated circuit products and/or sell such products to others, or to utilize alternative technologies; lower cost structures or a willingness and ability to accept lower prices or lower margins for their products, particularly in China; foreign government support of other technologies, competitors or OEMs that sell devices that do not contain our integrated circuit products; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; the development and sale of infrastructure equipment for wireless networks, which may enable such competitors to better optimize their integrated circuit products for performance on those networks; more extensive relationships with local distribution companies and OEMs in certain geographic regions (such as China); more experience in industries and applications beyond mobile handsets (such as automotive and IoT); and a more established presence in certain regions.

In addition, certain of our largest customers have in the past utilized, currently utilize and may in the future utilize our competitors’ integrated circuit products in some or all of their devices, rather than our products. Further, certain of those customers, such as Apple and Samsung, have developed, are developing or may develop their own integrated circuit products (effectively making them competitors), which they have in the past utilized, currently utilize or may in the future utilize in some or all of their devices, rather than our products. See also the Risk Factor titled “ Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products) .”
