# PNC FINANCIAL SERVICES GROUP, INC. | 10-Q | fiscal year 2024

- Report length: 56,029 words
- Direct AI mentions (classified): 0, of which about AI: 0, false candidates: 0, flagged for review: 0
- Context passages (not classified): 1; groups: generative (1)
- Frames: none
- Roles: none
- Risk types: none
- MIT subdomains: none
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: none
- Substantiveness: none
- Disclosure traits: none
- Trait activation rate: n/a
- Sections: none
- Named entities: none

# Context passages: implicit mentions, not classified

## Item 3 Quantitative and Qualitative Disclosures about Market Risk. | 21-38, 49-50, 83-89 (blocks 2136-2138)

**Terms: model provider (third-party model)**

Sensitivity Analysis

The fair value of commercial and residential MSRs and significant inputs to the valuation models as of June 30, 2024 and December 31, 2023 are shown in Tables 55 and 56. The expected and actual rates of mortgage loan prepayments are significant factors driving the fair value. Management uses both internal proprietary models and a third-party model to estimate future commercial mortgage loan prepayments and a third-party model to estimate future residential mortgage loan prepayments. These models have been refined based on current market conditions and management judgment. Future interest rates are another important factor in the valuation of MSRs. Management utilizes market implied forward interest rates to estimate the future direction of mortgage and discount rates. The forward rates utilized are derived from the current yield curve for U.S. dollar interest rate swaps and are consistent with pricing of capital markets instruments. Changes in the shape and slope of the forward curve in future periods may result in volatility in the fair value estimate.

A sensitivity analysis of the hypothetical effect on the fair value of MSRs to adverse changes in key assumptions is presented in Tables 55 and 56. These sensitivities do not include the impact of the related hedging activities. Changes in fair value generally cannot be extrapolated because the relationship of the change in the assumption to the change in fair value may not be linear. Also, the effect of a variation in a particular assumption on the fair value of the MSRs is calculated independently without changing any other assumption. Changes in one factor may result in changes in another ( e.g. , changes in mortgage interest rates, which drive changes in prepayment rate estimates, could result in changes in the interest rate spread), which could either magnify or counteract the sensitivities.
