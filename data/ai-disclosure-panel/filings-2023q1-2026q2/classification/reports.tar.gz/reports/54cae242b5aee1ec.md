# GOLDMAN SACHS GROUP INC | 10-Q | fiscal year 2024

- Report length: 124,627 words
- Direct AI mentions (classified): 5, of which about AI: 4, false candidates: 1, flagged for review: 0
- Context passages (not classified): 6; groups: risks_failures (4), industry (1), generative (1), security_misuse (1)
- Frames: governance (2), risk_factor (1), business (1)
- Roles: governance (2), risk (1), general (1)
- Risk types: cybersecurity (1)
- MIT subdomains: cyberattacks_weapons_mass_harm (1)
- Adoption stage: none
- Business functions: none
- Governance responses: oversight_structure (2)
- Kinds of AI: unspecified (4)
- Substantiveness: detailed (2), generic (2)
- Disclosure traits: hedging (1)
- Trait activation rate: 0.25 (boilerplate (0.0), hedging (0.25), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 2 (4)
- Named entities: none

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 5261-5266)

**AI reference: explicit | frame: governance | roles: governance | responses: oversight_structure | kinds: unspecified | substantiveness: detailed**

> To assist the Firmwide Technology Risk Committee in carrying out its mandate, the Firmwide Artificial Intelligence Risk and Controls Committee, which oversees risks associated with the use of artificial intelligence (AI), reports to the Firmwide Technology Risk Committee .

<details><summary>Passage</summary>

• Firmwide New Activity Committee. The Firmwide New Activity Committee is responsible for reviewing new activities and may review previously approved activities that are significant and/or that have changed in complexity and/or structure or present different reputational and suitability concerns over time to consider whether these activities remain appropriate. This committee is chaired by our controller and chief accounting officer, who is appointed as chair by the chairs of the Firmwide Enterprise Risk Committee.

• Firmwide Technology Risk Committee. The Firmwide Technology Risk Committee is responsible for reviewing matters related to the design, development, deployment and use of technology. This committee oversees cybersecurity matters, as well as technology risk management frameworks and methodologies, and monitors their effectiveness. This committee is co-chaired by our CISO and our chief technology officer, who are appointed as chairs by the chairs of the Firmwide Enterprise Risk Committee. To assist the Firmwide Technology Risk Committee in carrying out its mandate, the Firmwide Artificial Intelligence Risk and Controls Committee, which oversees risks associated with the use of artificial intelligence (AI), reports to the Firmwide Technology Risk Committee .

• Firmwide Operational Risk and Resilience Committee. The Firmwide Operational Risk and Resilience Committee is responsible for overseeing operational risk, and seeks to ensure our business and operational resilience. This committee is co-chaired by our chief administrative officer for EMEA and our head of Operational Risk, who are appointed as chairs by the chairs of the Firmwide Enterprise Risk Committee.

• Firmwide Conduct Committee. The Firmwide Conduct Committee is responsible for the ongoing approval and monitoring of the frameworks and policies which govern our conduct risks. Conduct risk is the risk that our people fail to act in a manner consistent with our Business Principles and related core values, policies or codes, or applicable laws or regulations, thereby falling short in fulfilling their responsibilities to us, our clients, colleagues, other market participants or the broader community. This committee is chaired by our chief legal officer, who is appoin ted as chair by the chairs of the Firmwide Enterprise Risk Committee.

• Firmwide Risk Appetite Committee. The Firmwide Risk Appetite Committee (through delegated authority from the Firmwide Enterprise Risk Committee) is responsible for the ongoing approval and monitoring of risk frameworks, policies and parameters related to our core risk management processes, as well as limits, thresholds and alerts, at firmwide, business and product levels. In addition, this committee is responsible for overseeing our financial risks and reviews the results of stress tests and scenario analyses. To assist the Firmwide Risk Appetite Committee in carrying out its mandate, a number of other risk committees with dedicated oversight for stress testing, model risks, Volcker Rule compliance, as well as our investments or other capital commitments that may give rise to financial risk, report into the Firmwide Risk Appetite Committee. This committee is chaired by our chief risk officer, who is appointed as chair by the chairs of the Firmwide Enterprise Risk Committee. The Firmwide Capital Committee and Firmwide Commitments Committee report to the Firmwide Risk Appetite Committee.

THE GOLDMAN SACHS GROUP, INC. AND SUBSIDIARIES

</details>

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 6096-6097)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: cybersecurity | mit: cyberattacks_weapons_mass_harm | kinds: unspecified | substantiveness: generic | traits: hedging**

> In addition, new AI technologies may increase the frequency and severity of cybersecurity attacks.

<details><summary>Passage</summary>

Overview

Cybersecurity risk is the risk of compromising the confidentiality, integrity or availability of our data and systems, leading to an adverse impact to us, our reputation, our clients and/or the broader financial system. We seek to minimize the occurrence and impact of unauthorized access, disruption or use of information and/or information systems. We deploy and operate preventive and detective controls and processes to mitigate emerging and evolving information security and cybersecurity threats, including monitoring our network for known vulnerabilities and signs of unauthorized attempts to access our data and systems. There is increased information risk through diversification of our data across external service providers, including use of a variety of cloud-provided or -hosted services and applications. In addition, new AI technologies may increase the frequency and severity of cybersecurity attacks. See “Risk Factors” in Part I, Item 1A of the 2023 Form 10-K for further information about information and cybersecurity risk.

</details>

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 6117-6126)

**AI reference: explicit | frame: governance | roles: governance | responses: oversight_structure | kinds: unspecified | substantiveness: detailed**

> To assist the Firmwide Technology Risk Committee in carrying out its mandate, the Firmwide Artificial Intelligence Risk and Controls Committee, which oversees risks associated with the use of AI, reports to the Firmwide Technology Risk Committee .

<details><summary>Passage</summary>

In addition, we have a series of committees that oversee the implementation of our cybersecurity risk management strategy and framework. These committees are informed about cybersecurity incidents and risks by designated members of Technology Risk, who periodically report to these committees about the Cybersecurity Program, including the efforts of the Technology Risk teams to prevent, detect, mitigate and remediate incidents and threats. These committees enable formal escalation and reporting of risks, and our CISO and other members of Technology Risk provide regular briefings to these committees.

The Firmwide Technology Risk Committee is responsible for reviewing matters related to the design, development, deployment and use of technology. This committee oversees cybersecurity matters, as well as technology risk management frameworks and methodologies, and monitors their effectiveness. This committee is co-chaired by our CISO and our chief technology officer, and reports to the Firmwide Enterprise Risk Committee. To assist the Firmwide Technology Risk Committee in carrying out its mandate, the Firmwide Artificial Intelligence Risk and Controls Committee, which oversees risks associated with the use of AI, reports to the Firmwide Technology Risk Committee . See “Overview and Structure of Risk Management” for further information about this committee.

The Digital Risk Office Steering Group oversees Engineering risk decisions, monitors control performance and reviews approaches to comply with current and emerging regulation applicable to Engineering. This steering group is chaired by our CISO, and reports to the Firmwide Technology Risk Committee.

Our CISO, senior management within Technology Risk and Operational Risk, as well as management personnel overseeing the Cybersecurity Program, all have substantial relevant expertise in the areas of information security and cybersecurity risk management.

Model Risk Management

Overview

Model risk is the potential for adverse consequences from decisions made based on model outputs that may be incorrect or used inappropriately. We rely on quantitative models across our business activities primarily to value certain financial assets and liabilities, to monitor and manage our risk, and to measure and monitor our regulatory capital.

Model Risk, which is independent of our revenue-producing units, model developers, model owners and model users, and reports to our chief risk officer, has primary responsibility for assessing, monitoring and managing our model risk through firmwide oversight across our global businesses, and provides periodic updates to senior management, risk committees and the Risk Committee of the Board.

Our model risk management framework is managed through a governance structure and risk management controls, which encompass standards designed to ensure we maintain a comprehensive model inventory, including risk assessment and classification, sound model development practices, independent review and model-specific usage controls. The Firmwide Model Risk Control Committee oversees our model risk management framework.

THE GOLDMAN SACHS GROUP, INC. AND SUBSIDIARIES

</details>

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 6128-6134)

**AI reference: none**

- Note (gemini: The passage discusses model review and validation but does not explicitly link it to AI.)

<details><summary>Passage</summary>

Model Review and Validation Process

Model Risk consists of quantitative professionals who perform an independent review, validation and approval of our models. This review includes an analysis of the model documentation, independent testing, an assessment of the appropriateness of the methodology used, and verification of compliance with model development and implementation standards.

We regularly refine and enhance our models to reflect changes in market or economic conditions and our business mix. All models are reviewed on an annual basis, and new models or significant changes to existing models and their assumptions are approved prior to implementation.

The model validation process incorporates a review of models and trade and risk parameters across a broad range of scenarios (including extreme conditions) in order to critically evaluate and verify:

The model’s conceptual soundness, including the reasonableness of model assumptions, and suitability for intended use;

The testing strategy utilized by the model developers to ensure that the models function as intended;

The suitability of the calculation techniques incorporated in the model;

</details>

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 6173-6175)

**AI reference: explicit | frame: business | roles: general | kinds: unspecified | substantiveness: generic**

> the opportunities and challenges presented by artificial intelligence

<details><summary>Passage</summary>

Management’s Discussion and Analysis

These statements may relate to, among other things, (i) our future plans and results, including our target ROE, ROTE, efficiency ratio, CET1 capital ratio and total credit alternative assets, and how they can be achieved, (ii) trends in or growth opportunities for our businesses, including the timing, costs, profitability, benefits and other aspects of business and strategic initiatives and their impact on our efficiency ratio, as well as the opportunities and challenges presented by artificial intelligence, (iii) our level of future compensation expense, including as a percentage of both operating expenses and net revenues, net of provision for credit losses, (iv) our Investment banking fees backlog and future advisory and capital market results, (v) our expected interest income and interest expense, (vi) our expense savings and strategic locations initiatives, (vii) expenses we may incur, including future litigation expense, (viii) the projected growth of our deposits and other funding, asset liability management and funding strategies and related interest expense savings, (ix) our business initiatives, including transaction banking, (x) our planned 2024 and 2025 benchmark debt issuances, (xi) the amount, composition and location of GCLA we expect to hold, (xii) our credit exposures, (xiii) our expected provision for credit losses, (xiv) the adequacy of our allowance for credit losses, (xv) the narrowing of our consumer business, (xvi) the objectives and effectiveness of our BCP, information security program, risk management and liquidity policies, (xvii) our resolution plan and strategy and their implications for stakeholders, (xviii) the design and effectiveness of our resolution capital and liquidity models and triggers and alerts framework, (xix) the results of stress tests, the effect of changes to regulations, and our future status, activities or reporting under banking and financial regulation, (xx) our expected tax rate, (xxi) the future state of our liquidity and regulatory capital ratios, and our prospective capital distributions (including dividends and repurchases), (xxii) our expected SCB and G-SIB surcharge, (xxiii) legal proceedings, governmental investigations or other contingencies, (xxiv) the asset recovery guarantee and our remediation activities related to our 1Malaysia Development Berhad (1MDB) settlements, (xxv) the effectiveness of our management of our human capital, including our diversity goals, (xxvi) our sustainability and carbon neutrality targets and goals, (xxvii) future inflation, (xxviii) the impact of Russia’s invasion of Ukraine and related sanctions and other developments on our business, results and financial position, (xxix) our ability to sell, and the terms of any proposed sales of, Asset & Wealth Management historical principal investments, the pending sale of the seller financing loan portfolio and our ability to transition the GM credit card program to another issuer, (xxx) the impact of the conflicts in the Middle East, (xxxi) our ability to manage our commercial real estate exposures, (xxxii) the profitability of Platform Solutions and (xxxiii) the effectiveness of our cybersecurity risk management process.

Statements about our target ROE, ROTE, efficiency ratio and expense savings, and how they can be achieved, are based on our current expectations regarding our business prospects and are subject to the risk that we may be unable to achieve our targets due to, among other things, changes in our business mix, lower profitability of new business initiatives, increases in technology and other costs to launch and bring new business initiatives to scale, and increases in liquidity requirements.

</details>

# Context passages: implicit mentions, not classified

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 98-100)

**Terms: model risk (Model Risk, Model Risk Management)**

Cybersecurity Risk Management | 166

Model Risk Management | 167

Other Risk Management | 168

## Item 1 Legal Proceedings (blocks 3374-3376)

**Terms: IRB model (Internal Ratings-Based approach)**

The Standardized Capital Rules apply prescribed risk-weights, which depend largely on the type of counterparty. The exposure measures for derivatives and securities financing transactions are based on specific formulas which take certain factors into consideration.

Under the Advanced Capital Rules, the firm computes risk-weights for wholesale and retail credit exposures in accordance with the Advanced Internal Ratings-Based approach. The exposure measures for derivatives and securities financing transactions are computed utilizing internal models.

For both Standardized and Advanced credit RWAs, the risk-weights for securitizations and equities are based on specific required formulaic approaches.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 4088-4089)

**Terms: model provider (model developers), model risk (model risk, model risk management)**

Review of Net Revenues. Independent risk oversight and control functions ensure adherence to our pricing policy through a combination of daily procedures, including the explanation and attribution of net revenues based on the underlying factors. Through this process, we independently validate net revenues, identify and resolve potential fair value or trade booking issues on a timely basis and seek to ensure that risks are being properly categorized and quantified.

Review of Valuation Models. Our independent model risk management group (Model Risk), consisting of quantitative professionals who are separate from model developers, performs an independent model review and validation process of our valuation models. New or changed models are reviewed and approved prior to implementation. Models are reviewed annually to assess the impact of any changes in the product or market and any market developments in pricing theories. See “Risk Management — Model Risk Management” for further information about the review and validation of our valuation models.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 5225-5226)

**Terms: model risk (Model Risk, Model Risk Management)**

Risk Management

Risks are inherent in our businesses and include liquidity, market, credit, operational, cybersecurity, model, legal, compliance, conduct, regulatory and reputational risks. For further information about our risk management processes, see “Overview and Structure of Risk Management,” and for information about our areas of risk, see “Liquidity Risk Management,” “Market Risk Management,” “Credit Risk Management,” “Operational Risk Management,” “Cybersecurity Risk Management,” “Model Risk Management” and “Other Risk Management,” as well as “Risk Factors” in Part I, Item 1A of the 2023 Form 10-K.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 5230-5232)

**Terms: model risk (model risk)**

Governance. Risk management governance starts with the Board, which both directly and through its committees, including its Risk Committee, oversees our risk management policies and practices implemented through the enterprise risk management framework. The Board is also responsible for the annual review and approval of our risk appetite statement. The risk appetite statement describes the levels and types of risk we are willing to accept or to avoid in order to achieve our objectives included in our strategic business plan, while remaining in compliance with regulatory requirements. The Board reviews our strategic business plan and is ultimately responsible for overseeing and providing direction about our strategy and risk appetite.

The Board, including through its committees, receives regular briefings on firmwide risks, including liquidity risk, market risk, credit risk, operational risk, cybersecurity risk, model risk and climate risk, from our independent risk oversight and control functions, including our chief risk officer, on cybersecurity threats and risks from our chief information security officer (CISO), on compliance risk and conduct risk from our chief compliance officer, on legal and regulatory enforcement matters from our chief legal officer, and on other matters impacting our reputation from the chair and/or vice-chairs of our Firmwide Reputational Risk Committee. The chief risk officer reports to our chief executive officer and to the Risk Committee of the Board. As part of the review of the firmwide risk portfolio, the chief risk officer regularly advises the Risk Committee of the Board of relevant risk metrics and material exposures, including risk limits and thresholds established in our risk appetite statement.

The implementation of our risk governance structure and core risk management processes is overseen by Enterprise Risk, which reports to our chief risk officer, and is responsible for ensuring that our enterprise risk management framework provides the Board, our risk committees and senior management with a consistent and integrated approach to managing our various risks in a manner consistent with our risk appetite.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 6109-6111)

**Terms: red teaming (red team)**

Third-party risk management, including vendor management and governance, and cybersecurity and business resiliency on vendor assessments.

In conjunction with third-party vendors and consultants, we perform risk assessments to gauge the performance of the Cybersecurity Program, to estimate our risk profile and to assess compliance with relevant regulatory requirements. We perform periodic assessments of control efficacy through our internal risk and control self-assessment process, as well as a variety of external technical assessments, including external penetration tests and “red team” engagements where third parties test our defenses. The results of these risk assessments, together with control performance findings, are used to establish priorities, allocate resources, and identify and improve controls. We use third parties, such as outside forensics firms, to augment our cyber incident response capabilities. We have a vendor management program that documents a risk-based framework for managing third-party vendor relationships. Information security risk management is built into our vendor management process, which covers vendor selection, onboarding, performance monitoring and risk management. See “Third-Party Risk” for further information about vendor risk.

THE GOLDMAN SACHS GROUP, INC. AND SUBSIDIARIES
