# RTX Corp | 10-Q | fiscal year not provided by the data provider

- Report length: 24,067 words
- Direct AI mentions (classified): 0, of which about AI: 0, false candidates: 0, flagged for review: 0
- Context passages (not classified): 0; groups: none
- Frames: none
- Roles: none
- Risk types: none
- MIT subdomains: none
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: none
- Substantiveness: none
- Disclosure traits: none
- Trait activation rate: n/a
- Sections: none
- Named entities: none
