# BANK OF AMERICA CORP | 10-Q | fiscal year 2026

- Report length: 62,527 words
- Direct AI mentions (classified): 1, of which about AI: 1, false candidates: 0, flagged for review: 0
- Context passages (not classified): 0; groups: none
- Frames: risk_factor (1)
- Roles: risk (1)
- Risk types: operational_reliability (1), strategic_competitive (1)
- MIT subdomains: lack_of_capability_robustness (1), other (1)
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: unspecified (1)
- Substantiveness: generic (1)
- Disclosure traits: hedging (1), vagueness (1)
- Trait activation rate: 1.0 (boilerplate (0.0), hedging (1.0), externalisation (0.0), vagueness (1.0), safe_harbour (0.0))
- Sections: Item 2 (1)
- Named entities: none

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 150-152)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: operational_reliability, strategic_competitive | mit: lack_of_capability_robustness, other | kinds: unspecified | substantiveness: generic | traits: hedging, vagueness**

> the risks related to the development, implementation, use and management of emerging technologies, including artificial intelligence and the ability to achieve potential benefits, such as increased productivity and cost savings;

<details><summary>Passage</summary>

industries and geographies, and geopolitical instability; uncertainties about the financial stability and growth rates of non-U.S. jurisdictions, the risk that those jurisdictions may face difficulties servicing their sovereign debt, and related stresses on financial markets, currencies and trade, and the Corporation’s exposures to such risks, including direct, indirect and operational; the impact of the interest rate, inflationary, macroeconomic, banking and regulatory environment on the Corporation’s assets, business, financial condition and results of operations; the impact of adverse developments affecting the U.S. or global banking industry, including a deterioration in private credit markets, bank failures and liquidity concerns, resulting in worsening economic and market volatility, and regulatory responses thereto; the possibility that future credit losses may be higher than currently expected, including due to changes in economic assumptions, which may include unemployment rates, real estate prices, gross domestic product levels and corporate bond spreads, customer behavior, adverse developments with respect to U.S. or global economic conditions and other uncertainties, such as the impact of trade policies, supply chain disruptions, commodity prices, inflationary pressures and labor shortages on economic conditions and our business; potential losses related to the Corporation's concentration of credit risk; the Corporation’s ability to achieve its expense targets (including noninterest expense) and expectations regarding revenue, net interest income, operating leverage, other income, provision for credit losses, net charge-offs, effective tax rate, loan or deposit growth or other projections and targets; variances to the underlying assumptions and judgments used in estimating banking book net interest income sensitivity; adverse changes to the Corporation’s credit ratings from the major credit rating agencies; an inability to access capital markets or maintain deposits or borrowing costs; estimates of the fair value and other accounting values, subject to impairment assessments, of certain of the Corporation’s assets and liabilities; the estimated or actual impact of changes in accounting standards or assumptions in applying those standards; uncertainty regarding the content, timing and impact of regulatory capital and liquidity requirements; the impact of adverse changes to total loss-absorbing capacity requirements, stress capital buffer requirements and/or global systemically important bank surcharges; the potential impact of actions of the Board of Governors of the Federal Reserve System on the Corporation’s capital plans; the effect of changes in or interpretations of income tax laws and regulations, including impacts from the 2025 Budget Reconciliation Act; the impact of implementation and compliance with U.S. and international laws, regulations and regulatory interpretations, including recovery and resolution planning requirements, Federal Deposit Insurance Corporation assessments, fiduciary standards, derivatives regulations and potential changes to loss allocations between financial institutions and customers, including for losses incurred from the use of our products and services, including electronic payments and payment of checks, that were authorized by the customer but induced by fraud; the impact of failures or

disruptions in or breaches of the Corporation’s operations or information systems, or those of various third parties, including regulators and federal and state governments, such as from cybersecurity incidents; the risks related to the development, implementation, use and management of emerging technologies, including artificial intelligence and the ability to achieve potential benefits, such as increased productivity and cost savings; the risks related to the transition and physical impacts of climate change; our ability to achieve environmental goals or the impact of any changes in the Corporation’s sustainability or human capital management strategy or goals; the impact of uncertain or changing political conditions, federal government shutdowns, including partial shutdowns, and uncertainty regarding the federal government’s debt limit or changes in fiscal, monetary, trade or regulatory policy; the emergence of widespread health emergencies or pandemics; the impact of natural disasters, extreme weather events, military conflicts (including the Russia/Ukraine conflict, the conflicts in the Middle East, the possible expansion of such conflicts and potential geopolitical and economic consequences), civil unrest, terrorism or other geopolitical events; and other matters.

Forward-looking statements speak only as of the date they are made, and the Corporation undertakes no obligation to update any forward-looking statement to reflect the impact of circumstances or events that arise after the date the forward-looking statement was made.

</details>
