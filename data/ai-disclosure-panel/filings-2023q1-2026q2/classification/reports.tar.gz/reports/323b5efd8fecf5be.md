# VERIZON COMMUNICATIONS INC | 10-Q | fiscal year 2024

- Report length: 30,190 words
- Direct AI mentions (classified): 0, of which about AI: 0, false candidates: 0, flagged for review: 0
- Context passages (not classified): 12; groups: industry (13), compute_infrastructure (1)
- Frames: none
- Roles: none
- Risk types: none
- MIT subdomains: none
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: none
- Substantiveness: none
- Disclosure traits: none
- Trait activation rate: n/a
- Sections: none
- Named entities: none

# Context passages: implicit mentions, not classified

## Item 1 Legal Proceedings (blocks 819-822)

**Terms: fixed wireless access (FWA, fixed wireless access)**

Segment | Description

Verizon Consumer Group | Our Consumer segment provides consumer-focused wireless and wireline communications services and products. Our wireless services are provided across one of the most extensive wireless networks in the U.S. under the Verizon family of brands and through wholesale and other arrangements. We also provide fixed wireless access (FWA) broadband through our 5G or 4G LTE networks as an alternative to traditional landline internet access. Our wireline services are provided in nine states in the Mid-Atlantic and Northeastern U.S., as well as Washington D.C., over our 100% fiber-optic network through our Verizon Fios product portfolio and over a traditional copper-based network to customers who are not served by Fios.

Verizon Business Group | Our Business segment provides wireless and wireline communications services and products, including FWA broadband, data, video and conferencing services, corporate networking solutions, security and managed network services, local and long distance voice services and network access to deliver various Internet of Things services and products. We provide these products and services to businesses, government customers and wireless and wireline carriers across the U.S. and a subset of these products and services to customers around the world.

Our Consumer segment's wireless and wireline products and services are available to our retail customers, as well as resellers that purchase wireless network access from us on a wholesale basis. Our Business segment's wireless and wireline products and services are organized by the primary customer groups targeted by these offerings: Enterprise and Public Sector, Business Markets and Other, and Wholesale.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 919-924)

**Terms: IoT connectivity (connected devices), fixed wireless access (FWA, fixed wireless access)**

Verizon Consumer Group

Our Consumer segment provides consumer-focused wireless and wireline communications services and products. Our wireless services are provided across one of the most extensive wireless networks in the United States (U.S.) under the Verizon family of brands and through wholesale and other arrangements. We also provide fixed wireless access (FWA) broadband through our 5G or 4G LTE networks as an alternative to traditional landline internet access. Our wireline services are provided in nine states in the Mid-Atlantic and Northeastern U.S., as well as Washington D.C., over our 100% fiber-optic network through our Verizon Fios product portfolio and over a traditional copper-based network to customers who are not served by Fios. Our Consumer segment's wireless and wireline products and services are available to our retail customers, as well as resellers that purchase wireless network access from us on a wholesale basis.

Customers can obtain our wireless services on a postpaid or prepaid basis. Our postpaid service is generally billed one month in advance for a monthly access charge in return for access to and usage of network services. Our prepaid service is offered only to Consumer customers and enables individuals to obtain wireless services without credit verification by paying for all services in advance. The Consumer segment also offers several categories of wireless equipment to customers, including a variety of smartphones and other handsets, wireless-enabled internet devices, such as tablets, and other wireless-enabled connected devices, such as smart watches.

In addition to the wireless services and equipment discussed above, the Consumer segment sells residential fixed connectivity solutions, including internet, video and voice services, and wireless network access to resellers on a wholesale basis. The Consumer segment's operating revenues for the three and six months ended June 30, 2024 totaled $24.9 billion and $50.0 billion, respectively, representing an increase of 1.5% and 1.2%, respectively, compared to the similar periods in 2023. See "Segment Results of Operations" for additional information regarding our Consumer segment’s operating performance and selected operating statistics.

Verizon Business Group

Our Business segment provides wireless and wireline communications services and products, including FWA broadband, data, video and conferencing services, corporate networking solutions, security and managed network services, local and long distance voice services and network access to deliver various Internet of Things (IoT) services and products, including solutions that support mobile resource management. We provide these products and services to businesses, government customers and wireless and wireline carriers across the U.S. and a subset of these products and services to customers around the world. The Business segment's operating revenues for the three and six months ended June 30, 2024 totaled $7.3 billion and $14.7 billion, respectively, representing a decrease of 2.4% and 2.0%, respectively, compared to the similar periods in 2023. See "Segment Results of Operations" for additional information regarding our Business segment’s operating performance and selected operating statistics.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 931-934)

**Terms: IoT connectivity (connected devices), fixed wireless access (FWA)**

Global Network and Technology

Over the past several years, we have been leading the development of 5G wireless technology industry standards and the ecosystems for fixed and mobile 5G wireless services. 5G technology enables higher throughput and lower latency than 4G LTE technology and allows our networks to handle more traffic as the number of internet-connected devices grows.

We are focusing our capital investment on building our next generation 5G network, while also adding capacity and density to our 4G LTE network. We are densifying our networks by utilizing macro and small cell technology, in-building solutions and distributed antenna systems. Network densification enables us to add capacity to address increasing mobile video consumption and the growing demand for IoT products and services on our 5G and 4G LTE networks. We obtained full access to our C-Band spectrum in August 2023, and will continue deploying this spectrum across the continental U.S.

We continue to build fiber-based networks supporting data, video and advanced business services - areas where demand for reliable high-speed connections is growing. In addition, we leverage our 5G and 4G LTE networks for our FWA broadband service.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 973-975)

**Terms: call centre (call center)**

Selling, General and Administrative Expense

Selling, general and administrative expense includes salaries and wages and benefits not directly attributable to a service or product, the provision for credit losses, taxes other than income taxes, advertising and sales commission costs, call center and information technology costs, regulatory fees, professional service fees and rent and utilities for administrative space. Also included is a portion of the aggregate customer care costs as discussed above in "Cost of Services."

Selling, general and administrative expense decreased during the three months ended June 30, 2024 compared to the similar period in 2023. The decrease was primarily the result of:

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1054-1062)

**Terms: fixed wireless access (FWA)**

To aid in the understanding of segment performance as it relates to segment operating income, management uses the following operating statistics to evaluate the overall effectiveness of our segments. We believe these operating statistics are useful to investors and other users of our financial information because they provide additional insight into drivers of our segments’ operating results, key trends and performance relative to our peers. These operating statistics may be determined or calculated differently by other companies and may not be directly comparable to those statistics of other companies.

Wireless retail connections are retail customer device postpaid and prepaid connections as of the end of the period. Retail connections under an account may include those from smartphones and basic phones (collectively, phones), postpaid and prepaid FWA, as well as tablets and other internet devices, wearables and retail IoT devices. Wireless retail connections are calculated by adding total retail postpaid and prepaid new connections in the period to prior period retail connections, and subtracting total retail postpaid and prepaid disconnects in the period.

Wireless retail postpaid connections are retail postpaid customer device connections as of the end of the period. Retail postpaid connections under an account may include those from phones, postpaid FWA, as well as tablets and other internet devices, wearables and retail IoT devices. Wireless retail postpaid connections are calculated by adding retail postpaid new connections in the period to prior period retail postpaid connections, and subtracting retail postpaid disconnects in the period.

Wireless retail prepaid connections are retail prepaid customer device connections as of the end of the period. Retail prepaid connections may include those from phones, prepaid FWA, as well as tablets and other internet devices, and wearables. Wireless retail prepaid connections are calculated by adding retail prepaid new connections in the period to prior period retail prepaid connections, and subtracting retail prepaid disconnects in the period.

Fios internet connections are the total number of connections to the internet using Fios internet services as of the end of the period. Fios internet connections are calculated by adding Fios internet new connections in the period to prior period Fios internet connections, and subtracting Fios internet disconnects in the period.

Fios video connections are the total number of connections to traditional linear video programming using Fios video services as of the end of the period. Fios video connections are calculated by adding Fios video net additions in the period to prior period Fios video connections. Fios video net additions are calculated by subtracting the Fios video disconnects from the Fios video new connections.

Total broadband connections are the total number of connections to the internet using Fios internet services, Digital Subscriber Line, and postpaid, prepaid and IoT FWA as of the end of the period. Total broadband connections are calculated by adding total broadband connections, net additions in the period to prior period total broadband connections.

Wireless retail connections, net addition s are the total number of additional retail customer device postpaid and prepaid connections, less the number of device disconnects in the period. Wireless retail connections, net additions in each period presented are calculated by subtracting the total retail postpaid and prepaid disconnects, net of certain adjustments, from the total retail postpaid and prepaid new connections in the period.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1068-1070)

**Terms: IoT connectivity (connected devices)**

Wireless retail postpaid ARPA is the calculated average retail postpaid service revenue per account (ARPA) from retail postpaid accounts in the period. Wireless retail postpaid service revenue does not include recurring device payment plan billings related to the Verizon device payment program, plan billings related to device warranty and insurance or regulatory fees. Wireless retail postpaid ARPA in each period presented is calculated by dividing retail postpaid service revenue by the average retail postpaid accounts in the period.

Wireless retail postpaid accounts are wireless retail customers that are directly served and managed under the Verizon brand and use its services as of the end of the period. Accounts include unlimited plans, shared data plans and corporate accounts, as well as legacy single connection plans and multi-connection family plans. A single account may include monthly wireless services for a variety of connected devices. Wireless retail postpaid accounts are calculated by adding retail postpaid new accounts to the prior period retail postpaid accounts.

Wireless retail postpaid connections per account is the calculated average number of retail postpaid connections per retail postpaid account as of the end of the period. Wireless retail postpaid connections per account is calculated by dividing the total number of retail postpaid connections by the number of retail postpaid accounts as of the end of the period.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1075-1076)

**Terms: fixed wireless access (FWA)**

Verizon Consumer Group

Our Consumer segment provides consumer-focused wireless and wireline communications services and products. Our wireless services are provided across one of the most extensive wireless networks in the U.S. under the Verizon family of brands and through wholesale and other arrangements. We also provide FWA broadband through our 5G or 4G LTE networks as an alternative to traditional landline internet access. Our wireline services are provided in nine states in the Mid-Atlantic and Northeastern U.S., as well as Washington D.C., over our 100% fiber-optic network through our Verizon Fios product portfolio and over a traditional copper-based network to customers who are not served by Fios.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1115-1117)

**Terms: fixed wireless access (FWA)**

Wireless service revenue increased during the three months ended June 30, 2024 compared to the similar period in 2023 primarily as a result of:

an increase of $502 million in access revenues related to our postpaid plans primarily due to pricing actions, an increase in our FWA subscriber base, and an increase in subscriptions through MyPlan offerings. These increases were partially offset by the amortization of wireless equipment sales promotions;

an increase of $162 million related to growth in non-retail service revenue;

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1120-1122)

**Terms: fixed wireless access (FWA)**

Wireless service revenue increased during the six months ended June 30, 2024 compared to the similar period in 2023 primarily as a result of:

an increase of $911 million in access revenues related to our postpaid plans primarily due to pricing actions, an increase in our FWA subscriber base, and an increase in subscriptions through MyPlan offerings. These increases were partially offset by the amortization of wireless equipment sales promotions;

an increase of $311 million related to growth in non-retail service revenue;

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1180-1181)

**Terms: fixed wireless access (FWA)**

Verizon Business Group

Our Business segment provides wireless and wireline communications services and products, including FWA broadband, data, video and conferencing services, corporate networking solutions, security and managed network services, local and long distance voice services and network access to deliver various IoT services and products. We provide these products and services to businesses, government customers and wireless and wireline carriers across the U.S. and a subset of these products and services to customers around the world. The Business segment is organized in three customer groups: Enterprise and Public Sector, Business Markets and Other, and Wholesale.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1214-1215)

**Terms: fixed wireless access (FWA)**

Business Markets and Other offers wireless services and equipment, conferencing services, tailored voice and networking products, Fios services, advanced voice solutions and security services to our business customers that ordinarily do not meet the requirements to be categorized as Enterprise and Public Sector, as described above. Business Markets and Other also includes solutions that support mobile resource management.

Business Markets and Other revenues increased during both the three and six months ended June 30, 2024 compared to the similar periods in 2023 primarily due to an increase of $109 million and $223 million, respectively, in Wireless service revenue driven by an increase in our FWA subscriber base and our pricing actions.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1357-1359)

**Terms: gigawatt-scale (gigawatts of capacity)**

Other Future Obligations

As of June 30, 2024, Verizon had 27 renewable energy purchase agreements (REPAs) with third parties. See Note 12 to the condensed consolidated financial statements for additional information. Under the REPAs, we plan to purchase up to an aggregate of approximately 3.5 gigawatts of capacity across multiple states.

Market Risk
