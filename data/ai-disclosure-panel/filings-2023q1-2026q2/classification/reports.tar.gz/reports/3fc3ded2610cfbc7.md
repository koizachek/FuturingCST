# KKR & Co. Inc. | 10-K | fiscal year 2025

- Report length: 201,631 words
- Direct AI mentions (classified): 7, of which about AI: 7, false candidates: 0, flagged for review: 0
- Context passages (not classified): 7; groups: euphemisms (6), industry (1)
- Frames: risk_factor (7)
- Roles: risk (7), adoption (1)
- Risk types: regulatory_legal (5), strategic_competitive (2), other (1), operational_reliability (1), third_party (1)
- MIT subdomains: other (7), compromise_of_privacy (1), lack_of_capability_robustness (1)
- Adoption stage: deployed (1)
- Business functions: decision_analytics (1)
- Governance responses: none
- Kinds of AI: unspecified (6), traditional_ml (1)
- Substantiveness: boilerplate (4), detailed (2), generic (1)
- Disclosure traits: boilerplate (4), vagueness (4), hedging (2)
- Trait activation rate: 0.857 (boilerplate (0.571), hedging (0.286), externalisation (0.0), vagueness (0.571), safe_harbour (0.0))
- Sections: Item 1A (5), unknown (2)
- Named entities: European Union

## unknown section (blocks 236-238)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: other | mit: other | kinds: unspecified | substantiveness: boilerplate | traits: boilerplate, vagueness**

> impact of artificial intelligence

<details><summary>Passage</summary>

changes in tax laws;

impact of artificial intelligence;

cybersecurity failures and data security breaches; and

</details>

## unknown section (blocks 252-254)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: other | kinds: unspecified | substantiveness: boilerplate | traits: boilerplate, vagueness**

> privacy, data protection, cybersecurity, and artificial intelligence laws.

<details><summary>Passage</summary>

sustainability-related laws and disclosure requirements; and

privacy, data protection, cybersecurity, and artificial intelligence laws.

We are subject to risks related to our investment activities, including risks involving:

</details>

## Item 1A RISK FACTORS (blocks 2004-2034)

**AI reference: explicit | frame: risk_factor | roles: adoption, risk | risk: operational_reliability, regulatory_legal, strategic_competitive, third_party | mit: compromise_of_privacy, lack_of_capability_robustness, other | adoption: deployed | functions: decision_analytics | kinds: traditional_ml | substantiveness: detailed | traits: hedging**

> The use of artificial intelligence by us and others, and the overall adoption of artificial intelligence throughout the world, may exacerbate or create new and unpredictable competitive, operational, legal and regulatory risks to our businesses.

> We use artificial intelligence and other quantitative analysis tools and models, developed by us and third-party service providers.

> If the data we, or third parties whose services we rely on, use in connection with the development or deployment of artificial intelligence is incomplete, inadequate or biased in some way, the performance of our products, services, and businesses could suffer.

<details><summary>Passage</summary>

See Note 18 “Income Taxes” in our financial statements for further information regarding various tax matters.

Artificial intelligence may increase competitive, operational, legal and regulatory risks to our

businesses in ways that we cannot predict.

The use of artificial intelligence by us and others, and the overall adoption of artificial intelligence throughout the world,

may exacerbate or create new and unpredictable competitive, operational, legal and regulatory risks to our businesses. Any

changes from the use of artificial intelligence could potentially disrupt, among other things, our business models, investment

strategies, investment performance, operational processes, and our ability to identify and hire employees. Some of our

competitors may be more successful than us in the development and implementation of new technologies to address investor

demands, making investments or improve operations, including services and platforms based on artificial intelligence.

We use artificial intelligence and other quantitative analysis tools and models, developed by us and third-party service

providers. Such technology, analysis and modeling are highly complex and subject to limitations and risks that have the

potential to adversely impact us to the extent that we rely on artificial intelligence. If the data we, or third parties whose

services we rely on, use in connection with the development or deployment of artificial intelligence is incomplete, inadequate

or biased in some way, the performance of our products, services, and businesses could suffer. Data in technology that uses

artificial intelligence may contain a degree of inaccuracy and error, which could result in flawed algorithms in various models

used in our businesses. Our personnel or the personnel of our service providers could, without our knowledge, improperly

utilize or misappropriate artificial intelligence and machine-learning technology while carrying out their responsibilities,

including relating to the entry of confidential information into a technology platform that is or becomes accessible by third

parties. The misuse or misappropriation of our data, unavoidable deficiencies in the practices associated with data collection,

training artificial intelligence technology on large data sets, and big data analytics and difficulties validating data, could have

an adverse impact on us.

Regulators are also increasing scrutiny and considering, and in some cases enacting, regulation of the use of artificial

intelligence technologies, including regarding the use of big data, diligence of data sets and oversight of data vendors. The

use of artificial intelligence by us or others may require compliance with legal or regulatory frameworks that are not fully

developed or tested, and we may face increased costs, litigation and regulatory actions related to our use of artificial

intelligence. See also “—Risks Related to Regulatory Matters—Privacy, data protection, cybersecurity and artificial intelligence

laws may increase compliance costs and subject us to enforcement risks and reputational risks”.

In addition, artificial intelligence may materially disrupt the industries in which we invest, the businesses of our portfolio

companies and the valuations of our investments. See also “—Risks Related to Our Investment Activities—Various conditions

</details>

## Item 1A RISK FACTORS (blocks 2550-2553)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: other | kinds: unspecified | substantiveness: boilerplate | traits: boilerplate, vagueness**

> Privacy, data protection, cybersecurity and artificial intelligence laws may increase compliance costs

<details><summary>Passage</summary>

liabilities, operational restrictions, litigation, reputational harm and other material and adverse impacts to our business”.

Privacy, data protection, cybersecurity and artificial intelligence laws may increase compliance costs

</details>

## Item 1A RISK FACTORS (blocks 2555-2557)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: other | kinds: unspecified | substantiveness: boilerplate | traits: boilerplate, vagueness**

> rapidly evolving and changing laws and regulations, including with respect to artificial intelligence, may increase compliance and legal costs and expose us to enforcement risk, litigation, and reputational harm.

<details><summary>Passage</summary>

Data privacy, data protection and cybersecurity have become priorities for regulators around the world, and rapidly

evolving and changing laws and regulations, including with respect to artificial intelligence, may increase compliance and legal

costs and expose us to enforcement risk, litigation, and reputational harm. We and our portfolio companies are subject to U.S.

</details>

## Item 1A RISK FACTORS (blocks 2575-2580)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: other | kinds: unspecified | substantiveness: detailed**

> There is also increased regulatory attention about the use of artificial intelligence.

> For example, the European Union has adopted Regulation (EU) 2024/1689, which establishes a comprehensive, risk-based regulatory framework governing the development, marketing, deployment and use of artificial intelligence systems within the European Union.

<details><summary>Passage</summary>

obligations arising from contractual commitments with counterparties.

There is also increased regulatory attention about the use of artificial intelligence. For example, the European Union has

adopted Regulation (EU) 2024/1689, which establishes a comprehensive, risk-based regulatory framework governing the

development, marketing, deployment and use of artificial intelligence systems within the European Union.

Failure to comply with applicable data privacy, data protection, cybersecurity, or artificial intelligence laws or related

contractual obligations could result in regulatory investigations or enforcement actions, private litigation, fines, penalties,

</details>

## Item 1A RISK FACTORS (blocks 2677-2679)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: strategic_competitive | mit: other | kinds: unspecified | substantiveness: generic | traits: hedging**

> developments in and adoption of artificial intelligence technologies, which may render existing products, services, or business models of the companies in which we invest to become obsolete, less competitive, or require significant

<details><summary>Passage</summary>

impacts, business trends, and changes in consumer behavior related to climate change and technology; and

developments in and adoption of artificial intelligence technologies, which may render existing products, services, or

business models of the companies in which we invest to become obsolete, less competitive, or require significant

</details>

# Context passages: implicit mentions, not classified

## Item 1A RISK FACTORS (blocks 2054-2056)

**Terms: social engineering (social engineering)**

vulnerable to unauthorized access, theft, misuse, computer viruses or other malicious code, and other events that could have

a security impact (including the deployment of harmful malware, ransomware, denial-of-service attacks, social engineering,

and other means to affect service reliability and threaten the confidentiality, integrity, and availability of information). Our

## Item 7 Management's Discussion and Analysis of Financial Condition and Results of Operations — Critical Accounting Policies and Estimates — Asset (blocks 4751-4753)

**Terms: next-generation technology (Next Generation Technology)**

Core Private Equity Vehicles | 187,886 | 65,846 | 122,040

Next Generation Technology Growth Fund II | 162,679 | — | 162,679

European Fund V | 89,459 | 32,864 | 56,595

## Item 7 Management's Discussion and Analysis of Financial Condition and Results of Operations — Critical Accounting Policies and Estimates — Asset (blocks 4762-4764)

**Terms: next-generation technology (Next Generation Technology)**

primarily of (i) realized proceeds from the sale of our investments in Seiyu Group (consumer products sector) held by Asian

Fund IV, ReliaQuest, LLC (technology sector) held by Next Generation Technology Growth Fund II, Integrated Specialty

Services (financial services sector) held by Americas Fund XII, and The Citation Group (services sector) held by both European

## Item 7 Management's Discussion and Analysis of Financial Condition and Results of Operations — Critical Accounting Policies and Estimates — Asset (blocks 5169-5173)

**Terms: next-generation technology (Next Generation Technology)**

Asian Fund (5) | 7/2007 | 4/2013 | 3,983 | — | 3,974 | 8,728 | — | — | —

Next Generation Technology Growth Fund III | 11/2022 | 11/2028 | 2,740 | 734 | 2,006 | — | 2,006 | 2,297 | 1

Next Generation Technology Growth Fund II | 12/2019 | 5/2022 | 2,088 | 54 | 2,269 | 1,846 | 1,610 | 2,477 | 153

Next Generation Technology Growth Fund | 3/2016 | 12/2019 | 659 | 3 | 671 | 1,314 | 241 | 806 | 59

Health Care Strategic Growth Fund II | 5/2021 | 5/2027 | 3,789 | 1,657 | 2,132 | — | 2,132 | 3,022 | 111

## Item 7 Management's Discussion and Analysis of Financial Condition and Results of Operations — Critical Accounting Policies and Estimates — Asset (blocks 5281-5283)

**Terms: next-generation technology (Next Generation Technology)**

Real Estate Partners Europe (2015) | 710 | 694 | 806 | 125 | 931 | 9.9 % | 7.1 % | 1.3

Next Generation Technology Growth Fund (2016) | 659 | 671 | 1,314 | 806 | 2,120 | 27.6 % | 23.4 % | 3.2

Health Care Strategic Growth Fund (2016) | 1,331 | 1,397 | 1,021 | 1,737 | 2,758 | 17.7 % | 12.8 % | 2.0

## Item 7 Management's Discussion and Analysis of Financial Condition and Results of Operations — Critical Accounting Policies and Estimates — Asset (blocks 5293-5295)

**Terms: next-generation technology (Next Generation Technology)**

Asia Real Estate Partners (2019) | 1,682 | 1,371 | 559 | 991 | 1,550 | 4.5 % | 1.4 % | 1.1

Next Generation Technology Growth Fund II (2019) | 2,088 | 2,269 | 1,846 | 2,477 | 4,323 | 19.5 % | 15.4 % | 1.9

Real Estate Credit Opportunity Partners II (2019) | 950 | 976 | 469 | 869 | 1,338 | 10.0 % | 7.7 % | 1.4

## Item 7 Management's Discussion and Analysis of Financial Condition and Results of Operations — Critical Accounting Policies and Estimates — Asset (blocks 5305-5307)

**Terms: next-generation technology (Next Generation Technology)**

Ascendant Fund (2022) | 4,328 | 1,656 | — | 1,988 | 1,988 | 21.0 % | 9.2 % | 1.2

Next Generation Technology Growth Fund III (2022) | 2,740 | 2,006 | — | 2,297 | 2,297 | 13.9 % | 6.0 % | 1.1

European Fund VI (2022) | 7,549 | 4,981 | — | 5,298 | 5,298 | 4.7 % | 0.7 % | 1.1
