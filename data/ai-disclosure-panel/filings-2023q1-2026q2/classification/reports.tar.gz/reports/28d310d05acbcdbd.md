# T-Mobile US, Inc. | 10-K | fiscal year 2024

- Report length: 75,233 words
- Direct AI mentions (classified): 7, of which about AI: 7, false candidates: 0, flagged for review: 0
- Context passages (not classified): 28; groups: industry (30), compute_infrastructure (3), general (1)
- Frames: risk_factor (4), business (3)
- Roles: risk (4), adoption (3), general (1)
- Risk types: regulatory_legal (4), cybersecurity (1), operational_reliability (1), strategic_competitive (1), workforce (1)
- MIT subdomains: regulation_lagging_behind_ai (3), ai_system_security_vulnerabilities_attacks (1), cyberattacks_weapons_mass_harm (1), inequality_decline_employment_quality (1), lack_of_capability_robustness (1), other (1), unfair_discrimination_misrepresentation (1), devaluation_of_human_effort (1)
- Adoption stage: deployed (2), planned (1)
- Business functions: customer_service (1), decision_analytics (1), operations (1), hr_workforce (1), it_cybersecurity (1), rd_product (1)
- Governance responses: none
- Kinds of AI: unspecified (6), traditional_ml (1)
- Substantiveness: generic (3), detailed (2), specific (1), boilerplate (1)
- Disclosure traits: hedging (3)
- Trait activation rate: 0.429 (boilerplate (0.0), hedging (0.429), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 1A (3), Item 1 (2), unknown (1), Item 1C (1)
- Named entities: none

## unknown section (blocks 97-99)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: regulation_lagging_behind_ai | kinds: unspecified | substantiveness: generic**

> laws and regulations relating to the handling of privacy, data protection and artificial intelligence (“AI”);

<details><summary>Passage</summary>

any changes in regulations or in the regulatory framework under which we operate;

laws and regulations relating to the handling of privacy, data protection and artificial intelligence (“AI”);

unfavorable outcomes of and increased costs from existing or future regulatory or legal proceedings;

</details>

## Item 1 Business (blocks 119-120)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: customer_service, decision_analytics | kinds: unspecified | substantiveness: detailed**

> As part of our relentless, customer-first focus, we are transforming into an AI-enabled, data-informed, digital-first organization to continue delivering differentiated experiences to our customers.

> Leveraging the latest AI technology and digital capabilities, we are pioneering new approaches to serving customers with a platform to better anticipate and proactively solve their issues, offering personalized self-service options and taking authorized actions on their behalf, while simultaneously creating large-format customer experience stores for customers looking for an immersive experience, and increasing investment in domestic customer care.

<details><summary>Passage</summary>

We continue to expand the footprint and improve the quality of our network, enabling us to provide what we believe are outstanding wireless experiences for customers who should not have to compromise on quality and value. Our network allows us to deliver new, innovative products and services, such as our High Speed Internet fixed wireless product, with the same customer experience focus and industry-disrupting mindset that we have adopted in our attempt to redefine the wireless communications services industry in the United States in the customers’ favor.

As part of our relentless, customer-first focus, we are transforming into an AI-enabled, data-informed, digital-first organization to continue delivering differentiated experiences to our customers. Leveraging the latest AI technology and digital capabilities, we are pioneering new approaches to serving customers with a platform to better anticipate and proactively solve their issues, offering personalized self-service options and taking authorized actions on their behalf, while simultaneously creating large-format customer experience stores for customers looking for an immersive experience, and increasing investment in domestic customer care. Our comprehensive T-Life app will further allow us to tap into customer preferences and radically simplify customer experiences in the future.

</details>

## Item 1 Business (blocks 141-144)

**AI reference: explicit | frame: business | roles: adoption | adoption: planned | functions: operations | kinds: unspecified | substantiveness: specific**

> We are also part of an alliance working to bring Radio Access Network (“RAN”) and AI innovation closer together to deliver transformational network experiences in the future.

<details><summary>Passage</summary>

Utilizing our multilayer spectrum portfolio, our mission is to become “Famous for Network.” We have deployed low-band, mid-band and mmWave spectrum dedicated for 5G across our dense and broad network to create what we believe is America’s largest, fastest, most awarded and most advanced 5G network.

We believe our spectrum position and focus on technology leadership will continue to drive network differentiation. Our innovative Customer-Driven Coverage (“CDC”) approach to network investments, and leadership in deploying the latest network technologies including Massive Multiple-input/multiple-out (“Massive MIMO”), Voice over New Radio (“VoNR”), four-carrier and higher order aggregation, dynamic network slicing and the U.S.’s first broad deployment of 5G Advanced, are

enabled by our scaled nationwide 5G standalone network. We are also part of an alliance working to bring Radio Access Network (“RAN”) and AI innovation closer together to deliver transformational network experiences in the future.

</details>

## Item 1A Risk Factors (blocks 250-260)

**AI reference: explicit | frame: risk_factor | roles: adoption, risk | risk: cybersecurity, operational_reliability, regulatory_legal, strategic_competitive, workforce | mit: ai_system_security_vulnerabilities_attacks, cyberattacks_weapons_mass_harm, inequality_decline_employment_quality, lack_of_capability_robustness, other, regulation_lagging_behind_ai, unfair_discrimination_misrepresentation | adoption: deployed | functions: hr_workforce, it_cybersecurity, rd_product | kinds: traditional_ml | substantiveness: detailed | traits: hedging**

> We also expect that threat actors will continue to gain sophistication including in the use of tools and techniques (such as AI) that are specifically designed to circumvent security controls, evade detection, and obfuscate forensic evidence, making it more challenging for us to identify, investigate and recover from future cyberattacks in a timely and effective manner.

> If we fail to timely adopt and effectively deploy emerging network technologies, our competitive position could erode, which may adversely affect our business, financial condition, and operating results.

> We are engaged in complex digital transformation efforts intended to streamline operations, enhance customer experience, and improve our overall competitiveness. These initiatives involve integrating emerging and rapidly evolving technologies, reconfiguring internal processes, and implementing advanced data analytics and AI-driven tools, including those developed through our partnerships with a number of third-party providers.

<details><summary>Passage</summary>

In November 2024, it was publicly reported that a nation-state actor called “Salt Typhoon” successfully infiltrated the telecommunications networks of certain of our competitors to obtain information on their customers. While we have no evidence that any of our Systems or Confidential Information were impacted in any significant way, we may face similar attempts in the future.

Our procedures and safeguards to prevent unauthorized access to Confidential Information and to defend against cyberattacks seeking to disrupt our operations must be continually evaluated and enhanced to address the ever-evolving threat landscape and changing cybersecurity regulations, including while we adapt complex digital transformation efforts. These preventative actions require the investment of significant resources and management time and attention. Additionally, we do not have control of the cybersecurity systems, breach prevention, and response protocols of our third-party providers, including through our cybersecurity programs or policies. While T-Mobile may have contractual rights to assess the effectiveness of many of our providers’ systems and protocols, we do not have the means to always know or assess the effectiveness of all of our providers’ systems and controls. We cannot provide any assurances that actions taken by us, or our third-party providers, including through our cybersecurity programs or policies, will adequately repel a significant cyberattack or prevent or substantially mitigate the impacts of cybersecurity breaches or misuses of Confidential Information, unauthorized access to our networks or Systems or exploits against third-party environments, or that we, or our third-party providers, will be able to effectively identify, investigate, and remediate such incidents in a timely manner or at all. We expect to continue to be the target of cyberattacks, given the nature of our business, and we expect the same with respect to our third-party providers. We also expect that threat actors will continue to gain sophistication including in the use of tools and techniques (such as AI) that are specifically designed to circumvent security controls, evade detection, and obfuscate forensic evidence, making it more challenging for us to identify, investigate and recover from future cyberattacks in a timely and effective manner. In addition, we have acquired and continue to acquire companies with cybersecurity vulnerabilities or unsophisticated security measures, which exposes us to significant cybersecurity, operational, and financial risks. If we fail to protect Confidential Information or to prevent operational disruptions from future cyberattacks, there may be a material adverse effect on our business, reputation, financial condition, cash flows, and operating results.

If we fail to timely adopt and effectively deploy emerging network technologies, our competitive position could erode, which may adversely affect our business, financial condition, and operating results.

Our competitive advantage and reputation depend on our ability to provide industry-leading network coverage, speed, and reliability. While we have established a leadership position in 5G, the communications industry evolves rapidly, and emerging technologies – such as AI-driven Radio Access Networks (“AI-RAN”) and the potential transition to 6G – may redefine network standards and increase customer expectations. To stay ahead, we are investing in strategic collaborations with third parties, such as AI-RAN partnerships, to develop technologies that are intended to advance our network capabilities. Despite these efforts, we may encounter technical challenges, regulatory hurdles, supply chain constraints, or unexpected delays in developing and deploying new network technologies. If we fail to anticipate market trends, efficiently integrate innovative solutions into our network, or maintain the quality and reliability of our network, our market share and competitive standing could erode, adversely impacting our business and operating results.

If we fail to effectively execute our digital transformation and drive customer and employee adoption of emerging technologies, our competitive position and financial performance could be materially harmed.

We are engaged in complex digital transformation efforts intended to streamline operations, enhance customer experience, and improve our overall competitiveness. These initiatives involve integrating emerging and rapidly evolving technologies, reconfiguring internal processes, and implementing advanced data analytics and AI-driven tools, including those developed through our partnerships with a number of third-party providers. The successful execution of our planned transformation is

subject to significant uncertainties. For example, we may face challenges in harmonizing complex system architectures, integrating new platforms with legacy infrastructure, and managing large volumes of data from disparate sources. We must also maintain rigorous data security and privacy safeguards, ensure our AI-driven solutions comply with evolving regulatory standards, and mitigate potential issues such as algorithmic bias or unintended operational disruptions. Additionally, implementing these digital solutions often requires substantial capital and operational expenditures, extensive employee training, specialized skill sets that may be difficult to source, and close coordination with multiple third-party vendors and partners. If we fail to execute these initiatives effectively, our ability to realize the intended benefits of digital transformation may be compromised. Even if we successfully deploy these capabilities, customer adoption and employee acceptance may be slower than anticipated, diminishing the expected improvements to efficiency, service quality, or revenue generation. This could materially and adversely affect our competitive position, financial performance, and brand reputation.

We rely on highly skilled personnel throughout all levels of our business. Our business could be harmed if we are unable to retain or motivate key personnel, hire a sufficient number of qualified new personnel, or maintain our corporate culture.

Our future success depends in substantial part on our ability to attract, recruit, hire, motivate, develop, and retain talented personnel possessing the qualifications, experiences, capabilities and skills we need for all areas of our organization, including our CEO and members of our senior leadership team. Succession planning to ensure effective transfer of knowledge and a seamless transition when key personnel depart is also important to our long-term success. Additionally, as we continue to make significant investments in new technologies and new business areas, we are increasingly dependent on being able to hire and retain technically skilled employees, including those with expertise in AI and machine learning.

Both external factors, such as fluctuations in economic and industry conditions, changes in U.S. immigration policies, regulatory changes, political forces and the competitive landscape, and internal factors, such as employee tolerance for changes in our corporate culture, organizational changes, limited remote working opportunities, and our compensation programs, may impact our ability to effectively manage our workforce. Further, employee compensation and benefit costs may increase due to inflationary pressures, and if our compensation does not keep up with inflation or that of our competitors’, we may see increased employee dissatisfaction and departures or difficulty in recruiting new employees. If key employees depart or we are unable to recruit and integrate new employees successfully, our business could be negatively impacted.

</details>

## Item 1A Risk Factors (blocks 329-335)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: regulation_lagging_behind_ai | kinds: unspecified | substantiveness: generic | traits: hedging**

> AI-related laws and regulations continue to remain uncertain and may vary from jurisdiction to jurisdiction. Our obligations to comply with the evolving legal and regulatory landscape may require us to incur significant additional costs or limit our ability to incorporate certain AI capabilities into our business operations or product offerings.

> Failure to comply with these regulations could result in fines, penalties, or restrictions on our use of AI, which could adversely affect our business.

<details><summary>Passage</summary>

Failure to comply with applicable regulations could have a material adverse effect on our business, financial condition, and operating results. We could be subject to fines, forfeitures, and other penalties (including, in extreme cases, revocation of our spectrum licenses) for failure to comply with the FCC or other governmental regulations, even if any such noncompliance was unintentional. The loss of any licenses, or any related fines or forfeitures, could adversely affect our business, financial condition, and operating results.

Laws and regulations relating to the handling of privacy, data protection and AI may result in increased costs, legal claims, fines against us, or reputational damage.

Since 2020, more than a dozen states have enacted new, comprehensive privacy laws that create new data privacy rights for residents of those states and new compliance obligations for us and the industry in general, in addition to private rights of action for certain types of data breaches. These include the California Consumer Privacy Act (“CCPA”) and similar laws in other states. Pending legislation in a number of other states would create similar laws elsewhere. All of these new privacy laws and others that we expect to be developed and enacted going forward will impose additional data protection obligations and potential liability on companies such as ours doing business in those states. Further, privacy laws also limit our ability to collect and use personal information.

We have incurred and will continue to incur significant implementation costs to ensure compliance with the CCPA, new privacy laws in other states, and their related regulations, including managing the complexity of laws that vary from state to state. Both federal and state governments are considering additional privacy laws and regulations which, if passed, could further impact our business, strategies, offerings, and initiatives and cause us to incur further costs. Any actual or perceived failure to comply with the CCPA, other data privacy laws or regulations, or related contractual or other obligations, or any perceived privacy rights violation, could lead to investigations, claims, and proceedings by governmental entities and private parties, damages for contract breaches, and other significant costs, penalties, and other liabilities, as well as harm to our reputation and market position.

AI-related laws and regulations continue to remain uncertain and may vary from jurisdiction to jurisdiction. Our obligations to comply with the evolving legal and regulatory landscape may require us to incur significant additional costs or limit our ability to incorporate certain AI capabilities into our business operations or product offerings. As we integrate AI technologies into our

business, we must navigate varying regulations that could impact our operations and product development. Failure to comply with these regulations could result in fines, penalties, or restrictions on our use of AI, which could adversely affect our business.

</details>

## Item 1A Risk Factors (blocks 341-343)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: devaluation_of_human_effort | kinds: unspecified | substantiveness: generic | traits: hedging**

> Additionally, we have faced and will continue to face various litigations alleging that our products or services infringe patents or other intellectual property of third parties, including potential litigation arising from our use of AI.

<details><summary>Passage</summary>

We rely on a variety of intellectual property assets, including patents, copyrights, trademarks, and domains, to maintain our competitiveness. If we are unable to protect our intellectual property due to factors such as changes in US intellectual property laws, the value of our intellectual property may become impaired, which may adversely impact our business and financial results.

Additionally, we have faced and will continue to face various litigations alleging that our products or services infringe patents or other intellectual property of third parties, including potential litigation arising from our use of AI. If successful, these litigations could result in an award of financial compensation, including damages or royalties, business disruptions, reputational harm, or an order requiring that we cease offering, selling, and using the relevant products, equipment, services, and network functions. Defending against such litigation is not only costly and time-consuming, but it may also be disruptive to our business operations and divert resources and attention. Furthermore, the outcomes of these litigations are inherently uncertain.

Our suppliers and vendors also have and will continue to face intellectual property litigation related to the technology used in the products, equipment, and services they provide to us. If successful, such litigation against our suppliers and vendors might impact their ability to continue to provide the relevant products, equipment, and services to us.

</details>

## Item 1C Cybersecurity (blocks 397-398)

**AI reference: explicit | frame: business | roles: general | kinds: unspecified | substantiveness: boilerplate**

> Mr. Simon received his Master of Science in Computer Science, Software Engineering & Artificial Intelligence from the Johns Hopkins Whiting School of Engineering and Bachelor of Science in Business Administration and Applied Economics from Marquette University.

<details><summary>Passage</summary>

As the Company’s Executive Vice President, Transformation and Chief Information & Digital Officer, Néstor Cano has served in several leadership positions at both the Company and Sprint, including as Sprint’s Chief Operating Officer, overseeing, among other things, Sprint’s digital architecture and delivery. Mr. Cano studied industrial engineering at Barcelona Polytechnic University, attended the Executive Distribution Academy by INSEAD Business School in Fontainebleau, France, and also completed his post-graduate degree in executive management at IESE Business School in Barcelona, Spain.

As the Company’s CSO, Jeff Simon has extensive experience in risk management and information security, including serving as the Chief Information Security Officer at Fidelity National Information Services, Inc. Mr. Simon received his Master of Science in Computer Science, Software Engineering & Artificial Intelligence from the Johns Hopkins Whiting School of Engineering and Bachelor of Science in Business Administration and Applied Economics from Marquette University. Mr. Simon is a Certified Information Systems Security Professional.

</details>

# Context passages: implicit mentions, not classified

## unknown section (blocks 84-86)

**Terms: emerging technologies (emerging technologies)**

our inability to timely adopt and effectively deploy network technology developments;

our inability to effectively execute our digital transformation and drive customer and employee adoption of emerging technologies;

our inability to retain or motivate key personnel, hire qualified personnel or maintain our corporate culture;

## Item 1 Business (blocks 131-133)

**Terms: IoT connectivity (connected devices)**

We provide wireless communications services to a variety of customers needing connectivity, but focus primarily on two categories of customers:

Postpaid customers generally are qualified to pay after receiving wireless communications services utilizing phones, High Speed Internet modems, mobile internet devices (including tablets and hotspots), wearables, DIGITS and other connected devices (including SyncUP and internet of things (“IoT”)). We serve consumers as well as business customers, who are provided services under the T-Mobile for Business brand.

Prepaid customers generally pay for wireless communications services in advance. We serve prepaid customers under the T-Mobile, Metro by T-Mobile, Mint Mobile and Ultra Mobile brands.

## Item 1 Business (blocks 158-161)

**Terms: network capex (network investment), tower infrastructure (cell sites)**

We plan to evaluate future spectrum purchases in future auctions and secondary market opportunities to further augment or refine our current spectrum position.

As of December 31, 2024, we had equipment deployed on approximately 82,000 macro cell sites and 52,000 small cell/distributed antenna system sites across our network.

Competition

The wireless communications services industry remains competitive. We are the second largest provider of wireless communications services in the U.S. as measured by our total postpaid and prepaid customers. Our wireless communications services competitors include other carriers, such as AT&T Inc. (“AT&T”), Verizon Communications, Inc. (“Verizon”), and DISH Network Corporation (“DISH”) as it continues to grow its network. In addition, our competitors include numerous smaller and regional providers, including Comcast Corporation, Charter Communications, Inc., Cox Communications, Inc., and Altice USA, Inc., many of which offer no-contract, postpaid and prepaid service plans. Competitors also include providers who offer similar communication services, such as voice, messaging and data services, using alternative technologies. In addition to our wireless communications services, our High Speed Internet service competes against other broadband providers, including traditional wireline solutions, such as Cable, DSL and Fiber broadband providers, and fixed wireless solutions, including AT&T and Verizon’s fixed wireless products, and Satellite Internet providers. Competitive factors within the wireless communications services and broadband industries include pricing, market saturation, service and product offerings, customer experience, network investment and quality, development and deployment of technologies and regulatory changes. Some of our competitors have shown a willingness to use discounted pricing or offer bundled services as a potential source of differentiation.

## Item 1 Business (blocks 210-212)

**Terms: data center (data centers), tower infrastructure (cell sites)**

Investing in renewable energy, meeting our RE100 pledge since 2021, through initiatives such as Virtual Power Purchasing Agreements and clean energy projects producing over 3.4 million megawatt hours annually;

Enhancing energy efficiency in our facilities, including retail stores, data centers, and cell sites; and

Promoting a circular economy through a robust device reuse and recycling program.

## Item 1A Risk Factors (blocks 298-299)

**Terms: 5G standalone (5G advanced), network slicing (network slicing)**

If we do not successfully deliver new products and services, we may not realize our intended growth targets or generate the expected returns from our business, adversely affecting our financial condition, and operating results.

We continue to expand our offerings beyond traditional wireless services to include High Speed Internet (including fiber broadband), advertising technology and services, and specialized network solutions, such as network slicing for first responders (T-Priority) and 5G advanced network solutions (ANS) for enterprises. These new ventures require significant capital, expertise, and operational support, and their success depends on factors we cannot fully control or predict. Increased competition, technical challenges, security concerns, operational complexities, or shifting regulatory landscapes could delay product rollouts, inflate costs, or limit adoption rates. Additionally, entering new markets or lines of business may expose us to unfamiliar regulatory requirements, compliance challenges, or damage existing customer relationships. Should these new products and services fail to gain traction, generate expected returns, or deliver value to customers, we could incur substantial expenses without offsetting revenue gains, adversely affecting our business, financial condition, and operating results.

## Item 2 Properties (blocks 414-418)

**Terms: call centre (call centers), data center (data centers), tower infrastructure (cell sites)**

Total | 100 % | 100 %

Wireless communications systems primarily consist of assets used to operate our wireless network and information technology data centers, including switching equipment, radio frequency equipment, tower assets, High Speed Internet routers, construction in progress and leasehold improvements related to the wireless network and asset retirement costs.

Land, buildings and building equipment primarily consist of land and land improvements, central office buildings or any other buildings that house network equipment, buildings used for administrative and other purposes, related construction in progress and certain network service equipment.

Data processing equipment and other primarily consist of data processing equipment, office equipment, capitalized software, leased wireless devices, construction in progress and leasehold improvements.

We also lease distributed antenna systems and small cell sites, as well as properties throughout the United States that contain data and switching centers, customer call centers, retail locations, warehouses and administrative spaces.

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 472-475)

**Terms: workforce reduction (Workforce Reduction)**

Net cash payments for Merger-related costs | $ 767 | $ 1,973 | $ 3,364 | $ (1,206) | (61) % | $ (1,391) | (41) %

2023 Workforce Reduction

In August 2023, we implemented an initiative to reduce the size of our workforce by approximately 5,000 positions, just under 7% of our total employee base, primarily in corporate and back-office functions, and some technology roles.

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 477-480)

**Terms: fibre rollout (fiber-to-the-home)**

Joint Ventures

On April 24, 2024, we entered into a definitive agreement with a fund operated by EQT, Infrastructure VI fund (“Fund VI”), to establish a joint venture between us and Fund VI to acquire Lumos (“Lumos”), a fiber-to-the-home platform, from EQT’s predecessor fund, EQT Infrastructure III. The arrangement is expected to close in the first half of 2025, subject to customary closing conditions and regulatory approvals. At closing, we expect to invest approximately $950 million in the joint venture to acquire a 50% equity interest and all existing Lumos fiber customers. The funds invested by us will be used to fund future fiber builds. In addition, pursuant to the definitive agreement, we expect to make an additional capital contribution of approximately $500 million in 2027 or 2028 under the existing business plan.

On July 18, 2024, we entered into a definitive agreement with KKR & Co. Inc. (“KKR”) to establish a joint venture to acquire Metronet Holdings, LLC and certain of its affiliates (collectively, “Metronet”), a fiber-to-the-home platform. This arrangement is expected to close in 2025, subject to customary closing conditions and regulatory approvals. At closing, we expect to invest approximately $4.9 billion in the joint venture to acquire a 50% equity interest and all existing residential fiber customers, as well as funding the joint venture. We do not anticipate making further capital contributions following the closing under the existing business plan.

The joint ventures will focus on market identification and selection, build plans, network engineering and design, network deployment, and customer installation, with us owning customer relationships and selling fiber service under the T-Mobile brand. Upon closing of the transactions, we expect to account for the Lumos and Metronet joint ventures under the equity method of accounting and recognize service revenues for the acquired Lumos and Metronet fiber customers and wholesale costs paid to the joint ventures for network access within Cost of services on our Consolidated Statements of Comprehensive Income.

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 561-563)

**Terms: workforce reduction (workforce reduction)**

Lower employee costs, primarily due to reduced headcount;

$141 million of severance and related costs associated with the August 2023 workforce reduction recognized in the prior year; and

Higher Merger synergies; partially offset by

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 572-574)

**Terms: workforce reduction (workforce reduction)**

A decrease of $453 million in Merger-related costs, including the $100 million gain recognized during the year ended December 31, 2024, for the extension fee previously paid by DISH associated with the DISH License Purchase Agreement;

$321 million of severance and related costs associated with the August 2023 workforce reduction recognized in the prior year;

$202 million of gains associated with the closing of certain spectrum exchange transactions and $105 million of legal-related insurance recoveries recognized during the year ended December 31, 2024; and

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 593-594)

**Terms: workforce reduction (workforce reduction)**

Merger-related costs, net of Merger-related gain and tax, of $91 million for the year ended December 31, 2024, compared to Merger-related costs, net of tax, of $775 million for the year ended December 31, 2023.

Severance and related costs associated with the August 2023 workforce reduction of $347 million, net of tax, for the year ended December 31, 2023.

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 650-653)

**Terms: IoT connectivity (connected devices)**

Postpaid Accounts

A postpaid account is generally defined as a billing account number that generates revenue. Postpaid accounts generally consist of customers that are qualified for postpaid service utilizing phones, High Speed Internet modems, mobile internet devices (including tablets and hotspots), wearables, DIGITS and other connected devices (including SyncUP and IoT), where they generally pay after receiving service.

The following table sets forth the number of ending postpaid accounts:

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 662-664)

**Terms: IoT connectivity (connected devices)**

Customers

A customer is generally defined as a SIM number with a unique T-Mobile identifier which is associated with an account that generates revenue. Customers are qualified either for postpaid service utilizing phones, High Speed Internet modems, mobile internet devices (including tablets and hotspots), wearables, DIGITS and other connected devices (including SyncUP and IoT), where they generally pay after receiving service, or prepaid service, where they generally pay in advance of receiving service.

The following table sets forth the number of ending customers:

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 693-695)

**Terms: IoT connectivity (connected devices)**

Higher net additions from mobile internet devices, primarily due to higher prior year deactivations of lower ARPU mobile internet devices in the educational sector that were activated during the COVID-19 pandemic and no longer needed; and

Higher net additions from other connected devices; partially offset by

Lower net additions from wearables; and

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 708-710)

**Terms: IoT connectivity (connected devices)**

Postpaid Average Revenue Per Account

Postpaid Average Revenue per Account (“ARPA”) represents the average monthly postpaid service revenue earned per account. Postpaid ARPA is calculated as Postpaid revenues for the specified period divided by the average number of postpaid accounts during the period, further divided by the number of months in the period. We believe postpaid ARPA provides management, investors and analysts with useful information to assess and evaluate our postpaid service revenue realization and assists in forecasting our future postpaid service revenues on a per account basis. We consider postpaid ARPA to be indicative of our revenue growth potential given the increase in the average number of postpaid phone customers per account and increases in postpaid other customers, including High Speed Internet, mobile internet devices (including tablets and hotspots), wearables, DIGITS and other connected devices (including SyncUP and IoT).

The following table sets forth our operating measure ARPA:

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 719-721)

**Terms: IoT connectivity (connected devices)**

Average Revenue Per User

Average Revenue per User (“ARPU”) represents the average monthly service revenue earned per customer. ARPU is calculated as service revenues for the specified period divided by the average number of customers during the period, further divided by the number of months in the period. We believe ARPU provides management, investors and analysts with useful information to assess and evaluate our service revenue per customer and assist in forecasting our future service revenues generated from our customer base. Postpaid phone ARPU excludes postpaid other customers and related revenues, which include High Speed Internet, mobile internet devices (including tablets and hotspots), wearables, DIGITS and other connected devices (including SyncUP and IoT).

The following table sets forth our operating measure ARPU:

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 760-762)

**Terms: workforce reduction (workforce reduction)**

(3) Legal-related (recoveries) expenses, net, consists of the settlement of certain litigation associated with the August 2021 cyberattack and is presented net of insurance recoveries.

(4) Other, net, primarily consists of certain severance, restructuring and other expenses, gains and losses, not directly attributable to the Merger, which are not reflective of T-Mobile’s core business activities and are, therefore, excluded from Adjusted EBITDA and Core Adjusted EBITDA. Other, net, for the year ended December 31, 2023, includes $462 million of severance and related costs associated with the August 2023 workforce reduction.

NM - Not meaningful

## Item 8 Financial Statements (blocks 966-968)

**Terms: lawful interception (subscriber data)**

We tested internal controls in the revenue accounting processes, including those in place to (a) establish revenue recognition accounting policies for promotional offers, (b) record revenue and the related promotional offers in accordance with the established accounting policies and (c) reconcile the various systems to the Company’s general ledger.

We created data visualizations to evaluate recorded service and equipment revenue and trends in the related subscriber data.

For a selection of wholesale service revenue and equipment revenue transactions, we compared the amounts recognized to contractual agreements or other source documents and tested the mathematical accuracy of the recorded revenue.

## Item 8 Financial Statements (blocks 1205-1207)

**Terms: data center (data centers)**

Property and Equipment

Property and equipment consists of buildings and equipment, including certain network server equipment, wireless communications systems, leasehold improvements, capitalized software, leased wireless devices and construction in progress. Wireless communications systems include assets to operate our wireless network and information technology data centers, including tower assets, leasehold improvements and asset retirement costs. Leasehold improvements include asset improvements other than those related to the wireless network.

Index for Notes to the Consolidated Financial Statements

## Item 8 Financial Statements (blocks 1283-1285)

**Terms: dark fibre (long-haul fiber)**

Wireline Business

On September 6, 2022, Sprint Communications LLC, a Kansas limited liability company and wholly owned subsidiary of the Company (“Sprint Communications”), Sprint LLC, a Delaware limited liability company and wholly owned subsidiary of the Company, and Cogent Infrastructure, Inc., a Delaware corporation (the “Buyer”) and a wholly owned subsidiary of Cogent Communications Holdings, Inc., entered into a Membership Interest Purchase Agreement (the “Wireline Sale Agreement”), pursuant to which Cogent Infrastructure, Inc. agreed to acquire the U.S. long-haul fiber network and operations (including the non-U.S. extensions thereof) of Sprint Communications and its subsidiaries (the “Wireline Business”). Such transactions contemplated by the Wireline Sale Agreement are collectively referred to as the “Wireline Transaction.” On May 1, 2023, Cogent Infrastructure, Inc. and the Company completed the Wireline Transaction.

Under the terms of the Wireline Sale Agreement, the Company agreed to make payments pursuant to an IP transit services agreement totaling $ 700 million, consisting of (i) $ 350 million in equal monthly installments during the first year after the closing and (ii) $ 350 million in equal monthly installments over the subsequent 42 months.

## Item 8 Financial Statements (blocks 1289-1292)

**Terms: tower infrastructure (Cell Site, cell sites)**

Leases

Cell Site, Retail Store and Office Facility Leases

We are a lessee for non-cancelable operating and financing leases for cell sites, switch sites, retail stores, network equipment and office facilities. We recognize a right-of-use asset and lease liability for operating leases based on the net present value of future minimum lease payments. The right-of-use asset for an operating lease is based on the lease liability. Lease expense is recognized on a straight-line basis over the non-cancelable lease term and renewal periods that are considered reasonably certain.

In addition, we have financing leases for certain network equipment. We recognize a right-of-use asset and lease liability for financing leases based on the net present value of future minimum lease payments. The right-of-use asset for a finance lease is based on the lease liability. Expense for our financing leases is comprised of the amortization expense associated with the right-of-use asset and interest expense recognized based on the effective interest method.

## Item 8 Financial Statements (blocks 1395-1398)

**Terms: fibre rollout (fiber-to-the-home)**

Lumos and Metronet Joint Ventures

On April 24, 2024, we entered into a definitive agreement with a fund operated by EQT, Infrastructure VI fund (“Fund VI”), to establish a joint venture between us and Fund VI to acquire Lumos (“Lumos”), a fiber-to-the-home platform, from EQT’s predecessor fund, EQT Infrastructure III. The arrangement is expected to close in the first half of 2025, subject to customary closing conditions and regulatory approvals. At closing, we expect to invest approximately $ 950 million in the joint venture to acquire a 50 % equity interest and all existing Lumos fiber customers. The funds invested by us will be used by the joint venture to fund future fiber builds. In addition, pursuant to the definitive agreement, we expect to make an additional capital contribution of approximately $ 500 million in 2027 or 2028 under the existing business plan.

On July 18, 2024, we entered into a definitive agreement with KKR & Co. Inc. (“KKR”) to establish a joint venture to acquire Metronet Holdings, LLC and certain of its affiliates (collectively, “Metronet”), a fiber-to-the-home platform. This arrangement is expected to close in 2025, subject to customary closing conditions and regulatory approvals. At closing, we expect to invest approximately $ 4.9 billion in the joint venture to acquire a 50 % equity interest and all existing residential fiber customers, as well as funding the joint venture. We do not anticipate making further capital contributions following the closing under the existing business plan.

Upon closing of the transactions, we expect to account for the Lumos and Metronet joint ventures under the equity method of accounting and recognize service revenues for the acquired Lumos and Metronet fiber customers and wholesale costs paid to the joint ventures for network access within Cost of services on our Consolidated Statements of Comprehensive Income.

## Item 8 Financial Statements (blocks 1810-1812)

**Terms: IoT connectivity (connected devices)**

We provide wireless communications services to three primary categories of customers:

Postpaid customers generally include customers who are qualified to pay after receiving wireless communications services utilizing phones, High Speed Internet, mobile internet devices (including tablets and hotspots), wearables, DIGITS and other connected devices (including SyncUP and IoT);

Prepaid customers generally include customers who pay for wireless communications services in advance; and

## Item 8 Financial Statements (blocks 2026-2028)

**Terms: tower infrastructure (cell sites)**

Lessee

We are a lessee for non-cancelable operating and financing leases for cell sites, switch sites, retail stores, network equipment and office facilities with contractual terms that generally extend through 2035. The majority of cell site leases have a non-cancelable term of five to 15 years with several renewal options that can extend the lease term for five to 50 years. In addition, we have financing leases for network equipment that generally have a non-cancelable lease term of three to five years . The financing leases do not have renewal options and contain a bargain purchase option at the end of the lease.

The components of lease expense were as follows:

## Item 8 Financial Statements (blocks 2064-2069)

**Terms: fibre rollout (fiber-to-the-home)**

Such purchase commitments are approximately $ 4.6 billion for the 12-month period ending December 31, 2025, $ 5.1 billion in total for both of the 12-month periods ending December 31, 2026 and 2027, $ 2.2 billion in total for both of the 12-month periods ending December 31, 2028 and 2029, and $ 2.3 billion in total thereafter. These amounts are not reflective of our entire anticipated purchases under the related agreements but are determined based on the non-cancelable quantities or termination amounts to which we are contractually obligated.

On April 24, 2024, we entered into a definitive agreement with a fund operated by EQT, Fund VI, to establish a joint venture between us and Fund VI to acquire Lumos, a fiber-to-the-home platform, from EQT’s predecessor fund, EQT Infrastructure III. At closing, we expect to invest approximately $ 950 million in the joint venture to acquire a 50 % equity interest and all existing Lumos fiber customers. The funds invested by us will be used by the joint venture to fund future fiber builds. In addition, pursuant to the definitive agreement, we expect to make an additional capital contribution of approximately $ 500 million in 2027 or 2028 under the existing business plan. The agreement remains subject to regulatory approval, and the estimated purchase price is excluded from our reported purchase commitments above. See Note 3 – Joint Ventures for additional details.

On May 24, 2024, we entered into a securities purchase agreement with UScellular, Telephone and Data Systems, Inc., and USCC Wireless Holdings, LLC, pursuant to which, among other things, we will acquire substantially all of UScellular’s wireless operations and select spectrum assets for an aggregate purchase price of approximately $ 4.4 billion, payable in cash and the assumption of up to $ 2.0 billion of debt through an exchange offer to be made to certain UScellular debtholders prior to closing. To the extent any debtholders do not participate in the exchange, their bonds will continue as obligations of UScellular, and the cash portion of the purchase price will be correspondingly increased. Following the closing of the transaction, we will enter into a 15-year master license agreement and estimate the incremental future minimum lease payments will be $ 1.4 billion over 15 years post-closing. The securities purchase agreement remains subject to regulatory approval. The estimated purchase price and incremental minimum lease payments are excluded from our reported purchase commitments above. See Note 2 – Business Combinations for additional details.

Index for Notes to the Consolidated Financial Statements

On July 18, 2024, we entered into a definitive agreement with KKR to establish a joint venture to acquire Metronet, a fiber-to-the-home platform. At closing, we expect to invest approximately $ 4.9 billion in the joint venture to acquire a 50 % equity interest and all existing residential fiber customers, as well as funding the joint venture. The agreement remains subject to regulatory approval, and the estimated purchase price is excluded from our reported purchase commitments above. See Note 3 – Joint Ventures for additional details.

On December 20, 2024, we entered into an agreement and plan of merger for the acquisition of 100 % of the outstanding capital stock of Vistar Media Inc., for a purchase price of approximately $ 625 million. The agreement remains subject to certain regulatory approvals, and the estimated purchase price is excluded from our reported purchase commitments above. See Note 2 – Business Combinations for additional details.

## Item 8 Financial Statements (blocks 2098-2100)

**Terms: tower infrastructure (cell sites)**

Merger Restructuring Initiatives

Upon closing the Merger in April 2020, we began implementing restructuring initiatives to realize cost efficiencies and reduce redundancies. The major activities associated with the Merger restructuring initiatives included contract termination costs associated with the rationalization of retail stores, distribution channels, duplicative network and backhaul services and other agreements, severance costs associated with the integration of redundant processes and functions and the decommissioning of certain small cell sites and distributed antenna systems to achieve Merger synergies in network costs.

As of June 30, 2024, we have incurred substantially all restructuring and integration costs associated with the Merger and, accordingly, no longer separately disclose Merger-related costs. The cash payments for the Merger-related costs incurred extend beyond 2024.

## Item 8 Financial Statements (blocks 2107-2112)

**Terms: tower infrastructure (cell sites), workforce reduction (Workforce Reduction, workforce reduction)**

The expenses associated with our Merger restructuring initiatives are included in Cost of services and Selling, general and administrative expenses on our Consolidated Statements of Comprehensive Income.

Our Merger restructuring initiatives also included the acceleration or termination of certain of our operating and financing leases for cell sites, switch sites, retail stores, network equipment and office facilities. Incremental expenses associated with terminated leases and leases for which we have recognized accelerated lease expense were $ 91 million, $ 390 million and $ 1.7 billion for the years ended December 31, 2024, 2023 and 2022, respectively, and are included in Cost of services and Selling, general and administrative expenses on our Consolidated Statements of Comprehensive Income.

2023 Workforce Reduction

In August 2023, we implemented an initiative to reduce the size of our workforce by approximately 5,000 positions, just under 7 % of our total employee base, primarily in corporate and back-office functions, and some technology roles.

The following table summarizes the expenses incurred in connection with our workforce reduction initiative:

(in millions) | Year Ended December 31, 2023 | Year Ended December 31, 2024 | Incurred to Date

## Item 8 Financial Statements (blocks 2114-2115)

**Terms: workforce reduction (workforce reduction)**

Index for Notes to the Consolidated Financial Statements

The expenses associated with our workforce reduction initiative are included in Cost of services and Selling, general and administrative expenses on our Consolidated Statements of Comprehensive Income.
