# JPMORGAN CHASE & CO | 10-Q | fiscal year 2023

- Report length: 89,816 words
- Direct AI mentions (classified): 0, of which about AI: 0, false candidates: 0, flagged for review: 0
- Context passages (not classified): 6; groups: risks_failures (3), governance_regulation (2), industry (1)
- Frames: none
- Roles: none
- Risk types: none
- MIT subdomains: none
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: none
- Substantiveness: none
- Disclosure traits: none
- Trait activation rate: n/a
- Sections: none
- Named entities: none

# Context passages: implicit mentions, not classified

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1216-1218)

**Terms: model risk (Model Risk)**

Legal Risk | 147

Estimations and Model Risk | 148

CAPITAL RISK MANAGEMENT

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 2046-2048)

**Terms: model risk (Model Risk, Model Risk Management, model uncertainty)**

Market risk is the risk associated with the effect of changes in market factors such as interest and foreign exchange rates, equity and commodity prices, credit spreads or implied volatilities, on the value of assets and liabilities held for both the short and long term. Refer to Market Risk Management on pages 131-138 of JPMorgan Chase’s 2022 Form 10-K for a discussion of the Firm’s Market Risk Management organization, market risk measurement, risk monitoring and control, and predominant business activities that give rise to market risk.

Models used to measure market risk are inherently imprecise and are limited in their ability to measure certain risks or to predict losses. This imprecision may be heightened when sudden or severe shifts in market conditions occur. For additional discussion on model uncertainty refer to Estimations and Model Risk Management on page 148 of JPMorgan Chase’s 2022 Form 10-K.

Market Risk Management periodically reviews the Firm’s existing market risk measures to identify opportunities for enhancement, and to the extent appropriate, will calibrate those measures accordingly over time.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 2051-2053)

**Terms: model risk (Model Risk, Model Risk Management)**

The Firm’s Risk Management VaR is calculated assuming a one-day holding period and an expected tail-loss methodology which approximates a 95% confidence level. For risk management purposes, the Firm believes this methodology provides a daily measure of risk that is closely aligned to risk management decisions made by the LOBs and Corporate and, along with other market risk measures, provides the appropriate information needed to respond to risk events. The Firm calculates separately a daily aggregated VaR in accordance with regulatory rules (“Regulatory VaR”), which is used to derive the Firm’s regulatory VaR-based capital requirements under Basel III.

The Firm’s VaR model calculations are periodically evaluated and enhanced in response to changes in the composition of the Firm’s portfolios, changes in market conditions, improvements in the Firm’s modeling techniques and measurements, and other factors. Such changes may affect historical comparisons of VaR results. Refer to Estimations and Model Risk Management on page 148 of JPMorgan Chase’s 2022 Form 10-K for information regarding model reviews and approvals.

Refer to page 133 of JPMorgan Chase’s 2022 Form 10-K for further information regarding VaR, including the inherent limitations, and the key differences between Risk Management VaR and Regulatory VaR. Refer to JPMorgan Chase’s Basel III Pillar 3 Regulatory Capital Disclosures reports, which are available on the Firm’s website, f or additional information on Regulatory VaR and the other components of market risk regulatory capital for the Firm (e.g., VaR-based measure, stressed VaR-based measure and the respective backtesting) . Refer to Other risk measures on pages 136-138 of JPMorgan Chase’s 2022 Form 10-K for further information regarding nonstatistical market risk measures used by the Firm.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 2075-2077)

**Terms: model governance (model governance)**

(a) Diversification benefit represents the difference between the portfolio VaR and the sum of its individual components. This reflects the non-additive nature of VaR due to imperfect correlation across LOBs, Corporate, and risk types.

(b) Credit portfolio VaR includes the derivative CVA, hedges of the CVA and hedges of the retained loan portfolio, which are reported in principal transactions revenue. This VaR does not include the retained loan portfolio, which is not reported at fair value. In the first quarter of 2022, in line with the Firm's internal model governance, the credit risk component of CVA related to certain counterparties was removed from Credit Portfolio VaR due to the widening of the credit spreads for those counterparties to elevated levels. The related hedges were also removed to maintain consistency. This exposure is now reflected in other sensitivity-based measures.

(c) For the three months ended March 31, 2022, the effects of nickel price increases and the associated volatility in the nickel market resulted in elevated average and maximum Credit Portfolio VaR. For the three months ended March 31, 2023, average and maximum Credit Portfolio VaR have decreased driven by a reduction in nickel-related exposure when compared to the same period in the prior year.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 2143-2145)

**Terms: model governance (model governance)**

(a) Excludes equity securities without readily determinable fair values that are measured under the measurement alternative. Refer to Note 2 for additional information.

(b) In the first quarter of 2022, in line with the Firm's internal model governance, the credit risk component of CVA related to certain counterparties was removed from Credit Portfolio VaR due to the widening of the credit spreads for those counterparties to elevated levels. The related hedges were also removed to maintain consistency. This exposure is now reflected in other sensitivity-based measures.

(c) Impact recognized through net revenue.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 2852-2853)

**Terms: automated valuation model (automated valuation, automated valuation models)**

(a) Primarily includes equity securities without readily determinable fair values that were adjusted based on observable price changes in orderly transactions from an identical or similar investment of the same issuer (measurement alternative). Of the $ 179 million in level 3 assets measured at fair value on a nonrecurring basis as of March 31, 2023, $ 158 million related to equity securities adjusted based on the measurement alternative. These equity securities are classified as level 3 due to the infrequency of the observable prices and/or the restrictions on the shares.

(b) Of the $ 833 million in level 3 assets measured at fair value on a nonrecurring basis as of March 31, 2023, $ 14 million related to residential real estate loans carried at the net realizable value of the underlying collateral (e.g., collateral-dependent loans). These amounts are classified as level 3 as they are valued using information from broker’s price opinions, appraisals and automated valuation models and discounted based upon the Firm’s experience with actual liquidation values. These discounts ranged from 13 % to 48 % with a weighted average of 25 %.
