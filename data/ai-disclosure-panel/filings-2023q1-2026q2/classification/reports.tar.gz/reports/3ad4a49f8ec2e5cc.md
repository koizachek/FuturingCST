# VERIZON COMMUNICATIONS INC | 10-Q | fiscal year 2025

- Report length: 30,443 words
- Direct AI mentions (classified): 1, of which about AI: 1, false candidates: 0, flagged for review: 0
- Context passages (not classified): 17; groups: industry (18)
- Frames: risk_factor (1)
- Roles: risk (1)
- Risk types: strategic_competitive (1)
- MIT subdomains: other (1)
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: unspecified (1)
- Substantiveness: generic (1)
- Disclosure traits: none
- Trait activation rate: 0.0 (boilerplate (0.0), hedging (0.0), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 2 (1)
- Named entities: none

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1407-1409)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: strategic_competitive | mit: other | kinds: unspecified | substantiveness: generic**

> failure to take advantage of, or respond to competitors' use of, developments in technology, including artificial intelligence, and address changes in consumer demand

<details><summary>Passage</summary>

the effects of competition in the markets in which we operate, including the inability to successfully respond to competitive factors such as prices, promotional incentives and evolving consumer preferences;

failure to take advantage of, or respond to competitors' use of, developments in technology, including artificial intelligence, and address changes in consumer demand;

performance issues or delays in the deployment of our 5G network resulting in significant costs or a reduction in the anticipated benefits of the enhancement to our networks;

</details>

# Context passages: implicit mentions, not classified

## Item 1 Legal Proceedings (blocks 836-839)

**Terms: fixed wireless access (FWA, fixed wireless access)**

Segment | Description

Verizon Consumer Group | Our Consumer segment provides consumer-focused wireless and wireline communications services and products. Our wireless services are provided across one of the most extensive wireless networks in the U.S. under the Verizon family of brands and through wholesale and other arrangements. We also provide fixed wireless access (FWA) broadband through our 5G or 4G LTE networks as an alternative to traditional landline internet access. Our wireline services are provided in nine states in the Mid-Atlantic and Northeastern U.S., as well as Washington D.C., over our 100% fiber-optic network through our Verizon Fios product portfolio and over a traditional copper-based network to customers who are not served by Fios.

Verizon Business Group | Our Business segment provides wireless and wireline communications services and products, including FWA broadband, data, video and advanced communication services, corporate networking solutions, security and managed network services, local and long distance voice services and network access to deliver various Internet of Things services and products. We provide these products and services to businesses, public sector customers and wireless and wireline carriers across the U.S. and a subset of these products and services to customers around the world.

Our Consumer segment's wireless and wireline products and services are available to our retail customers, as well as resellers that purchase wireless network access from us on a wholesale basis. Our Business segment's wireless and wireline products and services are organized by the primary customer groups for these offerings: Enterprise and Public Sector, Business Markets and Other, and Wholesale.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 957-960)

**Terms: IoT connectivity (connected devices), fixed wireless access (FWA, fixed wireless access)**

Verizon Consumer Group

Our Consumer segment provides consumer-focused wireless and wireline communications services and products. Our wireless services are provided across one of the most extensive wireless networks in the United States (U.S.) under the Verizon family of brands and through wholesale and other arrangements. We also provide fixed wireless access (FWA) broadband through our 5G or 4G LTE networks as an alternative to traditional landline internet access. Our wireline services are provided in nine states in the Mid-Atlantic and Northeastern U.S., as well as Washington D.C., over our 100% fiber-optic network through our Verizon Fios product portfolio and over a traditional copper-based network to customers who are not served by Fios.

Customers can obtain our wireless services on a postpaid or prepaid basis. Our postpaid service is generally billed one month in advance for a monthly access charge in return for access to and usage of network services. Our prepaid service is offered only to Consumer customers and enables individuals to obtain wireless services without credit verification by paying for all services in advance. The Consumer segment also offers several categories of wireless equipment to customers, including a variety of smartphones and other handsets, wireless-enabled internet devices, such as tablets, and other wireless-enabled connected devices, such as smart watches.

In addition to wireless services and equipment for retail customers, the Consumer segment sells residential fixed connectivity solutions, including internet, video and voice services, and wireless network access to resellers on a wholesale basis.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 963-965)

**Terms: fixed wireless access (FWA)**

Verizon Business Group

Our Business segment provides wireless and wireline communications services and products, including FWA broadband, data, video and advanced communication services, corporate networking solutions, security and managed network services, local and long distance voice services and network access to deliver various Internet of Things (IoT) services and products. We provide these products and services to businesses, public sector customers and wireless and wireline carriers across the U.S. and a subset of these products and services to customers around the world.

The Business segment's operating revenues for the three and six months ended June 30, 2025 totaled $7.3 billion and $14.6 billion, respectively, representing a decrease of 0.3% and 0.8%, respectively, compared to the similar periods in 2024. See "Segment Results of Operations" for additional information regarding our Business segment’s operating performance and selected operating statistics.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 972-973)

**Terms: fixed wireless access (FWA)**

While we continue to improve our 5G wireless service coverage, we are also adding capacity and density to our networks. Network densification enables us to increase coverage, improve quality of service and add capacity to accommodate an increasing number of users.

In addition to enhancing our wireless service, our wireless mobility investments provide the foundation for our growing FWA broadband business. We are also continuing to expand our fiber-based networks, as customers increasingly value the ability to obtain wireless and wireline broadband services from the same provider. In September 2024, we entered into an agreement to acquire Frontier Communications Parent, Inc. (Frontier), a U.S. provider of broadband internet and other communication services, as part of our fiber expansion strategy, and we expect to increase the capital expenditures we devote to our fiber networks in 2025.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1010-1012)

**Terms: call centre (call center)**

Selling, General and Administrative Expense

Selling, general and administrative expense includes salaries and wages and benefits not directly attributable to a service or product, the provision for credit losses, taxes other than income taxes, advertising and sales commission costs, call center and information technology costs, regulatory fees, professional service fees, rent and utilities for administrative space and device insurance program costs. Also included is a portion of the aggregate customer care costs as discussed above in "Cost of Services."

Selling, general and administrative expense decreased during both the three and six months ended June 30, 2025 compared to the similar periods in 2024.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1022-1023)

**Terms: fixed wireless access (FWA)**

Depreciation and Amortization Expense

Depreciation and amortization expense increased during both the three and six months ended June 30, 2025 compared to the similar periods in 2024 primarily due to the change in the mix of net depreciable and amortizable assets, including the amortization period of certain acquisition-related intangible assets, and the continued deployment of C-Band and FWA network assets.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1088-1098)

**Terms: fixed wireless access (FWA)**

To aid in the understanding of segment performance as it relates to segment operating income, management uses the following operating statistics to evaluate the overall effectiveness of our segments. We believe these operating statistics are useful to investors and other users of our financial information because they provide additional insight into drivers of our segments' operating results, key trends and performance relative to our peers. These operating statistics may be determined or calculated differently by other companies and may not be directly comparable to those statistics of other companies.

Wireless retail connections are retail customer device postpaid and prepaid connections as of the end of the period. Retail connections under an account may include those from smartphones and basic phones (collectively, phones), postpaid and prepaid FWA, as well as tablets and other internet devices, wearables and retail IoT devices. Wireless retail connections are calculated by adding total retail postpaid and prepaid new connections in the period to prior period retail connections, and subtracting total retail postpaid and prepaid disconnects in the period.

Wireless retail postpaid connections are retail postpaid customer device connections as of the end of the period. Retail postpaid connections under an account may include those from phones, postpaid FWA, as well as tablets and other internet devices, wearables and retail IoT devices. Wireless retail postpaid connections are calculated by adding retail postpaid new connections in the period to prior period retail postpaid connections, and subtracting retail postpaid disconnects in the period.

Wireless retail prepaid connections are retail prepaid customer device connections as of the end of the period. Retail prepaid connections may include those from phones, prepaid FWA, as well as tablets and other internet devices, and wearables. Wireless retail prepaid connections are calculated by adding retail prepaid new connections in the period to prior period retail prepaid connections, and subtracting retail prepaid disconnects in the period.

Wireless retail core prepaid connections are wireless retail prepaid customer device connections, excluding our SafeLink brand, as of the end of the period. Retail core prepaid connections may include those from phones, prepaid FWA, as well as tablets and other internet devices, and wearables. Wireless retail core prepaid connections are calculated by adding retail core prepaid new connections in the period to prior period retail core prepaid connections, and subtracting retail core prepaid disconnects in the period.

Fios internet connections are the total number of connections to the internet using Fios internet services as of the end of the period. Fios internet connections are calculated by adding Fios internet new connections in the period to prior period Fios internet connections, and subtracting Fios internet disconnects in the period.

Fios video connections are the total number of connections to traditional linear video programming using Fios video services as of the end of the period. Fios video connections are calculated by adding Fios video net additions in the period to prior period Fios video connections. Fios video net additions are calculated by subtracting the Fios video disconnects from the Fios video new connections.

Total broadband connections are the total number of connections to the internet using Fios internet services, Digital Subscriber Line (DSL), and postpaid, prepaid and IoT FWA as of the end of the period. Total broadband connections are calculated by adding total broadband connections, net additions in the period to prior period total broadband connections.

FWA broadband connections are the total number of postpaid and prepaid connections to the internet through our 5G or 4G LTE wireless networks as of the end of the period. FWA broadband connections are calculated by adding FWA broadband connections, net additions in the period to prior period FWA broadband connections.

Wireline broadband connections are the total number of connections to the internet using DSL and Fios internet services as of the end of the period. Wireline broadband connections are calculated by adding wireline broadband connections, net additions in the period to prior period wireline broadband connections.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1104-1107)

**Terms: fixed wireless access (FWA)**

Total broadband connections, net additions are the total number of additional total broadband connections, less the number of total broadband disconnects in the period. Total broadband connections, net additions in each period presented are calculated by subtracting the total broadband disconnects, net of certain adjustments, from the total broadband new connections in the period.

FWA broadband connections , net additions are the total number of additional FWA broadband connections, less the number of FWA broadband disconnects in the period. FWA broadband connections, net additions in each period presented are calculated by subtracting the FWA broadband disconnects, net of certain adjustments, from the FWA broadband new connections in the period.

Wireline broadband connections, net additions are the total number of additional wireline broadband connections, less the number of wireline broadband disconnects in the period. Wireline broadband connections, net additions in each period presented are calculated by subtracting the wireline broadband disconnects, net of certain adjustments, from the wireline broadband new connections in the period.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1109-1111)

**Terms: IoT connectivity (connected devices)**

Wireless retail postpaid ARPA is the calculated average retail postpaid service revenue per account (ARPA) from retail postpaid accounts in the period. Wireless retail postpaid service revenue does not include recurring device payment plan billings related to the Verizon device payment program, insurance premiums or regulatory fees. Wireless retail postpaid ARPA in each period presented is calculated by dividing retail postpaid service revenue by the average retail postpaid accounts in the period.

Wireless retail postpaid accounts are wireless retail customers that are directly served and managed under the Verizon brand and use its services as of the end of the period. Accounts include unlimited plans, shared data plans and corporate accounts, as well as legacy single connection plans and multi-connection family plans. A single account may include monthly wireless services for a variety of connected devices. Wireless retail postpaid accounts are calculated by adding retail postpaid new accounts to the prior period retail postpaid accounts.

Wireless retail postpaid connections per account is the calculated average number of retail postpaid connections per retail postpaid account as of the end of the period. Wireless retail postpaid connections per account is calculated by dividing the total number of retail postpaid connections by the number of retail postpaid accounts as of the end of the period.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1115-1116)

**Terms: fixed wireless access (FWA)**

Verizon Consumer Group

Our Consumer segment provides consumer-focused wireless and wireline communications services and products. Our wireless services are provided across one of the most extensive wireless networks in the U.S. under the Verizon family of brands and through wholesale and other arrangements. We also provide FWA broadband through our 5G or 4G LTE networks as an alternative to traditional landline internet access. Our wireline services are provided in nine states in the Mid-Atlantic and Northeastern U.S., as well as Washington D.C., over our 100% fiber-optic network through our Verizon Fios product portfolio and over a traditional copper-based network to customers who are not served by Fios.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1133-1135)

**Terms: fixed wireless access (FWA)**

Fios video | 2,564 | 2,818 | (254) | (9.0)

FWA broadband | 3,077 | 2,292 | 785 | 34.2

Wireline broadband | 7,348 | 7,238 | 110 | 1.5

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1141-1143)

**Terms: fixed wireless access (FWA)**

Wireless retail core prepaid (3) | 50 | (12) | 62 | nm | 187 | (143) | 330 | nm

FWA broadband | 164 | 218 | (54) | (24.8) | 363 | 421 | (58) | (13.8)

Wireline broadband | 17 | 13 | 4 | 30.8 | 48 | 49 | (1) | (2.0)

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1162-1167)

**Terms: fixed wireless access (FWA)**

Wireless service revenue increased during the three months ended June 30, 2025 compared to the similar period in 2024 primarily due to:

an increase of $220 million in postpaid revenue primarily related to pricing actions, higher adoption of perks and premium MyPlan offerings, and a 34% increase in our FWA subscriber base. These increases were partially offset by the amortization of wireless equipment sales promotions; and

an increase of $176 million related to growth in non-retail service revenue.

Wireless service revenue increased during the six months ended June 30, 2025 compared to the similar period in 2024 primarily as a result of:

an increase of $627 million in postpaid revenue primarily related to pricing actions, higher adoption of perks and premium MyPlan offerings, and a 34% increase in our FWA subscriber base. These increases were partially offset by the amortization of wireless equipment sales promotions;

an increase of $319 million related to growth in non-retail service revenue; and

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1207-1208)

**Terms: fixed wireless access (FWA)**

Verizon Business Group

Our Business segment provides wireless and wireline communications services and products, including FWA broadband, data, video and advanced communication services, corporate networking solutions, security and managed network services, local and long distance voice services and network access to deliver various IoT services and products. We provide these products and services to businesses, public sector customers and wireless and wireline carriers across the U.S. and a subset of these products and services to customers around the world. The Business segment is organized in three customer groups: Enterprise and Public Sector, Business Markets and Other, and Wholesale.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1223-1225)

**Terms: fixed wireless access (FWA)**

Fios video | 51 | 58 | (7) | (12.1)

FWA broadband | 2,035 | 1,523 | 512 | 33.6

Wireline broadband | 458 | 458 | — | —

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1229-1231)

**Terms: fixed wireless access (FWA)**

Wireless retail postpaid phone | 42 | 135 | (93) | (68.9) | 109 | 215 | (106) | (49.3)

FWA broadband | 114 | 160 | (46) | (28.8) | 223 | 311 | (88) | (28.3)

Wireline broadband | (2) | — | (2) | nm | (2) | (1) | (1) | nm

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1248-1250)

**Terms: fixed wireless access (FWA)**

Business Markets and Other

Business Markets and Other offers wireless services (including FWA broadband), wireless equipment, advanced communication services, tailored voice and networking products, Fios services, advanced voice solutions and security services to businesses that ordinarily do not meet the requirements to be categorized as Enterprise and Public Sector, as described above. Business Markets and Other also includes solutions that support mobile resource management.

Business Markets and Other revenues increased during both the three and six months ended June 30, 2025 compared to the similar periods in 2024 primarily due to an increase of $90 million and $219 million, respectively, in Wireless service revenue driven by pricing actions and an increase in our FWA subscriber base partially offset by the amortization of wireless equipment sales promotions.
