# Tesla, Inc. | 10-Q | fiscal year 2023

- Report length: 17,892 words
- Direct AI mentions (classified): 8, of which about AI: 8, false candidates: 0, flagged for review: 0
- Context passages (not classified): 0; groups: none
- Frames: business (6), risk_factor (2)
- Roles: offering (3), adoption (3), risk (2)
- Risk types: regulatory_legal (2), reputational_ethical (1)
- MIT subdomains: false_or_misleading_information (1), overreliance_unsafe_use (1), regulation_lagging_behind_ai (1)
- Adoption stage: deployed (3)
- Business functions: rd_product (3)
- Governance responses: none
- Kinds of AI: unspecified (8)
- Substantiveness: specific (8)
- Disclosure traits: none
- Trait activation rate: 0.0 (boilerplate (0.0), hedging (0.0), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 2 (5), Item 1 (3)
- Named entities: DOJ, Elon Musk, Tesla, Inc.

## Item 1 LEGAL PROCEEDINGS (blocks 302-304)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> Deferred revenue is related to the access to our Full Self Driving (“FSD”) features and ongoing maintenance, internet connectivity, free Supercharging programs and over-the-air software updates primarily on automotive sales, which amounted to $ 3.17 billion and $ 2.91 billion as of June 30, 2023 and December 31, 2022, respectively.

<details><summary>Passage</summary>

Automotive Sales Revenue

Deferred revenue is related to the access to our Full Self Driving (“FSD”) features and ongoing maintenance, internet connectivity, free Supercharging programs and over-the-air software updates primarily on automotive sales, which amounted to $ 3.17 billion and $ 2.91 billion as of June 30, 2023 and December 31, 2022, respectively.

Deferred revenue is equivalent to the total transaction price allocated to the performance obligations that are unsatisfied, or partially unsatisfied, as of the balance sheet date. Revenue recognized from the deferred revenue balance as of December 31, 2022 and 2021 was $ 256 million and $ 121 million for six months ended June 30, 2023 and 2022, respectively. Of the total deferred revenue balance as of June 30, 2023, we expect to recognize $ 747 million of revenue in the next 12 months. The remaining balance will be recognized at the time of transfer of control of the product or over the performance period.

</details>

## Item 1 LEGAL PROCEEDINGS (blocks 552-555)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal, reputational_ethical | mit: false_or_misleading_information, overreliance_unsafe_use | kinds: unspecified | substantiveness: specific**

> For example, on September 14, 2022, a proposed class action was filed against Tesla, Inc. and related entities in the U.S. District Court for the Northern District of California, alleging various claims about the Company’s driver assistance technology systems under state and federal law.

> On February 27, 2023, a proposed class action was filed in the U.S. District Court for the Northern District of California against Tesla, Inc., Elon Musk and certain current and former Company executives. The complaint alleges that the defendants made material misrepresentations and omissions about the Company’s Autopilot and FSDC technologies and seeks money damages and other relief on behalf of persons who purchased Tesla stock between February 19, 2019 and February 17, 2023.

<details><summary>Passage</summary>

Other Litigation Related to Our Products and Services

We are also subject to various lawsuits, including proposed class actions, that seek monetary and other injunctive relief. For example, on September 14, 2022, a proposed class action was filed against Tesla, Inc. and related entities in the U.S. District Court for the Northern District of California, alleging various claims about the Company’s driver assistance technology systems under state and federal law. This case was later consolidated with several other proposed class actions, and a Consolidated Amended Complaint was filed on October 28, 2022, which seeks damages and other relief on behalf of all persons who purchased or leased from Tesla between January 1, 2016 to the present. On October 5, 2022 a proposed class action complaint was filed in the U.S. District Court for the Eastern District of New York asserting similar state and federal law claims against the same defendants. On March 22, 2023, the plaintiffs in the California consolidated action filed a motion for a preliminary injunction to order Tesla to (1) cease using the term “Full Self-Driving Capability” (FSDC), (2) cease the sale and activation of FSDC and deactivate FSDC on Tesla vehicles, and (3) provide certain notices to consumers about proposed court-findings about the accuracy of the use of the terms Autopilot and FSDC. Tesla opposed the motion.

On February 27, 2023, a proposed class action was filed in the U.S. District Court for the Northern District of California against Tesla, Inc., Elon Musk and certain current and former Company executives. The complaint alleges that the defendants made material misrepresentations and omissions about the Company’s Autopilot and FSDC technologies and seeks money damages and other relief on behalf of persons who purchased Tesla stock between February 19, 2019 and February 17, 2023. On April 13, 2023, a putative Tesla shareholder filed a related shareholder derivative complaint against the members of Tesla’s board of directors and certain current and former executives, alleging contribution for violations of the federal securities law, breach of fiduciary duties, waste, and unjust enrichment. The complaint asserts derivative claims and seeks, among other relief, unspecified monetary damages, attorneys’ fees and costs.

On March 14, 2023 a proposed class action was filed in the U.S. District Court for the Northern District of California. Several similar complaints have also been filed in the same court and these cases have now all been consolidated. These complaints allege that Tesla violates federal antitrust and warranty laws through its repair, service, and maintenance practices and seeks, among other relief, damages for persons who paid Tesla for repairs services or Tesla compatible replacement parts from March 2019 to March 2023. On July 17, 2023, these plaintiffs filed a consolidated amended complaint.

</details>

## Item 1 LEGAL PROCEEDINGS (blocks 557-561)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: regulation_lagging_behind_ai | kinds: unspecified | substantiveness: specific**

> Separately, the company has received requests from the DOJ for documents related to Tesla’s Autopilot and FSD features. To our knowledge no government agency in any ongoing investigation has concluded that any wrongdoing occurred. We cannot predict the outcome or impact of any ongoing matters. Should the government decide to pursue an enforcement action, there exists the possibility of a material adverse impact on our business, results of operation, prospects, cash flows and financial position.

<details><summary>Passage</summary>

Certain Investigations and Other Matters

We receive requests for information from regulators and governmental authorities, such as the National Highway Traffic Safety Administration, the National Transportation Safety Board, the SEC, the Department of Justice (“DOJ”) and various state, federal, and international agencies. We routinely cooperate with such regulatory and governmental requests, including subpoenas, formal and informal requests and other investigations and inquiries.

For example, the SEC had issued subpoenas to Tesla in connection with Elon Musk’s prior statement that he was considering taking Tesla private. The take-private investigation was resolved and closed with a settlement entered into with the SEC in September 2018 and as further clarified in April 2019 in an amendment. The SEC also has periodically issued subpoenas to us seeking information on our governance processes around compliance with the SEC settlement, as amended.

Separately, the company has received requests from the DOJ for documents related to Tesla’s Autopilot and FSD features. To our knowledge no government agency in any ongoing investigation has concluded that any wrongdoing occurred. We cannot predict the outcome or impact of any ongoing matters. Should the government decide to pursue an enforcement action, there exists the possibility of a material adverse impact on our business, results of operation, prospects, cash flows and financial position.

We are also subject to various other legal proceedings, risks and claims that arise from the normal course of business activities. For example, during the second quarter of 2023, a foreign news outlet reported that it obtained certain misappropriated data including, purportedly, among other things, non-public Tesla business and personal information. While Tesla’s investigation remains ongoing, we are working with certain law enforcement and other authorities. If an unfavorable ruling or development were to occur in this or other possible legal proceedings, risks and claims, there exists the possibility of a material adverse impact on our business, results of operations, prospects, cash flows, financial position or brand.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 619-622)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> Additionally, we are increasingly focused on products and services based on artificial intelligence, robotics and automation.

> We are currently focused on increasing vehicle production, capacity and delivery capabilities, reducing costs, improving and developing our vehicles and battery technologies, improving and further deploying our FSD capabilities, increasing the affordability and efficiency of our vehicles, bringing new products to market and expanding our global infrastructure.

<details><summary>Passage</summary>

Overview

Our mission is to accelerate the world’s transition to sustainable energy. We design, develop, manufacture, lease and sell high-performance fully electric vehicles, solar energy generation systems and energy storage products. We also offer maintenance, installation, operation, financial and other services related to our products. Additionally, we are increasingly focused on products and services based on artificial intelligence, robotics and automation.

In 2023, we produced 920,508 consumer vehicles and delivered 889,015 consumer vehicles through the second quarter. We are currently focused on increasing vehicle production, capacity and delivery capabilities, reducing costs, improving and developing our vehicles and battery technologies, improving and further deploying our FSD capabilities, increasing the affordability and efficiency of our vehicles, bringing new products to market and expanding our global infrastructure.

In 2023, we deployed 7.54 GWh of energy storage products and 133 megawatts of solar energy systems through the second quarter. We are currently focused on ramping production of energy storage products, improving our Solar Roof installation capability and efficiency, and increasing market share of retrofit solar energy systems.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 642-644)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> We will also continue to generate demand and brand awareness by improving our vehicles’ performance and functionality, including through products based on artificial intelligence such as Autopilot and FSD, and other software features, and delivering new vehicles, such as our upcoming Cybertruck.

<details><summary>Passage</summary>

Automotive—Demand, Sales, Deliveries and Infrastructure

Our cost reduction efforts, cost innovation strategies, and additional localized procurement and manufacturing are key to our vehicles’ affordability and have allowed us to competitively price our vehicles. We will also continue to generate demand and brand awareness by improving our vehicles’ performance and functionality, including through products based on artificial intelligence such as Autopilot and FSD, and other software features, and delivering new vehicles, such as our upcoming Cybertruck. Moreover, we expect to continue to benefit from ongoing electrification of the automotive sector and increasing environmental regulations and initiatives.

However, we operate in a cyclical industry that is sensitive to political and regulatory uncertainty, including with respect to trade and the environment, all of which can be compounded by inflationary pressures, rising energy prices, increases in interest rates and the liquidity of enterprise customers. For example, inflationary pressures have increased across the markets in which we operate. In an effort to curb this trend, central banks in developed countries raised interest rates rapidly and substantially, impacting the affordability of vehicle lease and finance arrangements. Further, sales of vehicles in the automotive industry also tend to be cyclical in many markets, which may expose us to increased volatility as we expand and adjust our operations. Moreover, as additional competitors enter the marketplace and help bring the world closer to sustainable transportation, we will have to adjust and continue to execute well to maintain our momentum. These macroeconomic and industry trends have had, and will likely continue to have, an impact on the pricing of, and order rate for our vehicles, and in turn our operating margin. We will continue to adjust accordingly to such developments, and we believe our ongoing cost reduction, including improved production innovation and efficiency at our newest factories and lower logistics costs, and focus on operating leverage will continue to benefit us in relation to our competitors, while our new products will help enable future growth.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 649-651)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: rd_product | kinds: unspecified | substantiveness: specific**

> We are simultaneously ramping new products, building or ramping manufacturing facilities on three continents, piloting the development and manufacture of new battery cell technologies, expanding our Supercharger network and investing in autonomy and other artificial intelligence enabled training and products, and the pace of our capital spend may vary depending on overall priority among projects, the pace at which we meet milestones, production adjustments to and among our various products, increased capital efficiencies and the addition of new projects.

<details><summary>Passage</summary>

Cash Flow and Capital Expenditure Trends

Our capital expenditures are typically difficult to project beyond the short-term given the number and breadth of our core projects at any given time, and may further be impacted by uncertainties in future global market conditions. We are simultaneously ramping new products, building or ramping manufacturing facilities on three continents, piloting the development and manufacture of new battery cell technologies, expanding our Supercharger network and investing in autonomy and other artificial intelligence enabled training and products, and the pace of our capital spend may vary depending on overall priority among projects, the pace at which we meet milestones, production adjustments to and among our various products, increased capital efficiencies and the addition of new projects. Owing and subject to the foregoing as well as the pipeline of announced projects under development, all other continuing infrastructure growth and varying levels of inflation, we currently expect our capital expenditures to be between $7.00 to $9.00 billion in 2023 and in each of the following two fiscal years.

Our business has recently been consistently generating cash flow from operations in excess of our level of capital spend, and with better working capital management resulting in shorter days sales outstanding than days payable outstanding, our sales growth is also facilitating positive cash generation. We have and will continue to utilize such cash flows, among other things, to do more vertical integration, expand our product roadmap and provide financing options to our customers. At the same time, we are likely to see heightened levels of capital expenditures during certain periods depending on the specific pace of our capital-intensive projects and other potential variables such as rising material prices and increases in supply chain and labor expenses resulting from changes in global trade conditions and labor availability. Overall, we expect our ability to be self-funding to continue as long as macroeconomic factors support current trends in our sales.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 708-710)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: rd_product | kinds: unspecified | substantiveness: specific**

> The overall increases were primarily driven by additional costs in the current period related to the pre-production phase for Cybertruck, AI and other programs.

<details><summary>Passage</summary>

As a percentage of revenues | 4 % | 4 % | 4 % | 4 %

Research and development (“R&D”) expenses increased $276 million, or 41%, in the three months ended June 30, 2023 as compared to the three months ended June 30, 2022. R&D expenses increased $182 million, or 12%, in the six months ended June 30, 2023 as compared to the six months ended June 30, 2022. The overall increases were primarily driven by additional costs in the current period related to the pre-production phase for Cybertruck, AI and other programs.

R&D expenses as a percentage of revenue stayed consistent at 4% in the three and six months ended June 30, 2023 compared to the same periods in the prior year. Our R&D expenses have increased proportionately with total revenues as we continue to expand our product roadmap and technologies.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 738-740)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: rd_product | kinds: unspecified | substantiveness: specific**

> The cash we generate from our core operations enables us to fund ongoing operations and production, our research and development projects for new products and technologies including our proprietary battery cells, additional manufacturing ramps at existing manufacturing facilities such as the Fremont Factory, Gigafactory Nevada, Gigafactory Shanghai and Gigafactory New York, the ramp of Gigafactory Berlin-Brandenburg and Gigafactory Texas, the construction of future factories, and the continued expansion of our retail and service locations, body shops, Mobile Service fleet, Supercharger, including to support NACS, energy product installation capabilities and autonomy and other artificial intelligence enabled products.

<details><summary>Passage</summary>

Liquidity and Capital Resources

We expect to continue to generate net positive operating cash flow as we have done in the last four fiscal years. The cash we generate from our core operations enables us to fund ongoing operations and production, our research and development projects for new products and technologies including our proprietary battery cells, additional manufacturing ramps at existing manufacturing facilities such as the Fremont Factory, Gigafactory Nevada, Gigafactory Shanghai and Gigafactory New York, the ramp of Gigafactory Berlin-Brandenburg and Gigafactory Texas, the construction of future factories, and the continued expansion of our retail and service locations, body shops, Mobile Service fleet, Supercharger, including to support NACS, energy product installation capabilities and autonomy and other artificial intelligence enabled products.

In addition, because a large portion of our future expenditures will be to fund our growth, we expect that if needed we will be able to adjust our capital and operating expenditures by operating segment. For example, if our near-term manufacturing operations decrease in scale or ramp more slowly than expected, including due to global economic or business conditions, we may choose to correspondingly slow the pace of our capital expenditures. Finally, we continually evaluate our cash needs and may decide it is best to raise additional capital or seek alternative financing sources to fund the rapid growth of our business, including through drawdowns on existing or new debt facilities or financing funds. Conversely, we may also from time to time determine that it is in our best interests to voluntarily repay certain indebtedness early.

</details>
