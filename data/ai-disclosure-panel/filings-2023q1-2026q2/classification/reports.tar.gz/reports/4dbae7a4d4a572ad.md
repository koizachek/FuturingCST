# AMERICAN TOWER CORP | 10-Q | fiscal year 2024

- Report length: 36,507 words
- Direct AI mentions (classified): 6, of which about AI: 0, false candidates: 6, flagged for review: 0
- Context passages (not classified): 47; groups: compute_infrastructure (36), industry (15)
- Frames: none
- Roles: none
- Risk types: none
- MIT subdomains: none
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: none
- Substantiveness: none
- Disclosure traits: none
- Trait activation rate: n/a
- Sections: none
- Named entities: none

## Item 1 LEGAL PROCEEDINGS (blocks 475-477)

**AI reference: none**

- Note (gemini: GPU-backed financing is a false positive.)

<details><summary>Passage</summary>

2021 Credit Facility (1) | 1,068.0 | 1,603.4 | July 1, 2028

2021 EUR Three Year Delayed Draw Term Loan (1) (2) (3) | — | 910.7 | N/A

0.600 % senior notes (4) | — | 500.0 | N/A

</details>

## Item 1 LEGAL PROCEEDINGS (blocks 578-580)

**AI reference: none**

- Note (gemini: GPU-backed financing is a false positive.)

<details><summary>Passage</summary>

Bank Facilities

2021 Multicurrency Credit Facility— During the nine months ended September 30, 2024, the Company borrowed an aggregate of $ 4.6 billion, including 0.9 billion EUR ($ 1.0 billion as of the borrowing date) and repaid an aggregate of $ 5.2 billion, including 1.1 billion EUR ($ 1.2 billion as of the repayment date), of revolving indebtedness under the Company’s $ 6.0 billion senior unsecured multicurrency revolving credit facility, as amended and restated in December 2021, as further amended (the “2021 Multicurrency Credit Facility”). The Company used the borrowings to repay outstanding indebtedness, including the 0.600 % Notes, the 5.00 % Notes and the 2021 EUR Three Year Delayed Draw Term Loan (as defined below), and for general corporate purposes. The Company used the proceeds from the ATC TIPL Transaction to repay existing indebtedness under the 2021 Multicurrency Credit Facility. As of September 30, 2024, there are no EUR borrowings outstanding under the 2021 Multicurrency Credit Facility.

2021 Credit Facility— During the nine months ended September 30, 2024, the Company borrowed an aggregate of $ 1.5 billion and repaid an aggregate of $ 2.1 billion of revolving indebtedness under the Company’s $ 4.0 billion senior unsecured revolving credit facility, as amended and restated in December 2021, as further amended (the “2021 Credit Facility”). The Company used the borrowings to repay outstanding indebtedness, including the 3.375 % Notes, and for general corporate purposes.

</details>

## Item 1 LEGAL PROCEEDINGS (blocks 583-585)

**AI reference: none**

- Note (gemini: GPU-backed financing is a false positive.)

<details><summary>Passage</summary>

(tabular amounts in millions, unless otherwise noted)

Repayment of 2021 EUR Three Year Delayed Draw Term Loan— On May 21, 2024, the Company repaid all amounts outstanding under its 825 million EUR ($ 895.5 million as of the repayment date) unsecured term loan, as amended in December 2021 (the “2021 EUR Three Year Delayed Draw Term Loan”) using borrowings under the 2021 Multicurrency Credit Facility.

As of September 30, 2024, the key terms under the 2021 Multicurrency Credit Facility, the 2021 Credit Facility and the Company’s $ 1.0 billion unsecured term loan, as amended and restated in December 2021, as further amended (the “2021 Term Loan”) were as follows:

</details>

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1303-1305)

**AI reference: none**

- Note (gemini: GPU-backed financing is a false positive.)

<details><summary>Passage</summary>

Registered public offering in an aggregate principal amount of $2.4 billion, including 1.0 billion EUR, of senior unsecured notes with maturities ranging from 2029 to 2034;

Repayment of 825.0 million EUR ($895.5 million as of the repayment date) unsecured term loan, as amended in December 2021 (the “2021 EUR Three Year Delayed Draw Term Loan”); and

Repayment of indebtedness under the 2021 Multicurrency Credit Facility using proceeds from the ATC TIPL Transaction.

</details>

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1368-1370)

**AI reference: none**

- Note (gemini: GPU-backed financing is a false positive.)

<details><summary>Passage</summary>

Distributions paid on common stock | (2,316.9) | (2,193.2)

(1) For the nine months ended September 30, 2024, includes the repayments of the 2021 EUR Three Year Delayed Draw Term Loan and the India Term Loan (as defined below).

Repayments of Senior Notes

</details>

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1389-1393)

**AI reference: none**

- Note (gemini: GPU-backed financing is a false positive.)

<details><summary>Passage</summary>

Bank Facilities

2021 Multicurrency Credit Facility— During the nine months ended September 30, 2024, we borrowed an aggregate of $4.6 billion, including 0.9 billion EUR ($1.0 billion as of the borrowing date) and repaid an aggregate of $5.2 billion, including 1.1 billion EUR ($1.2 billion as of the repayment date), of revolving indebtedness under the 2021 Multicurrency Credit Facility. We used the borrowings to repay outstanding indebtedness, including the 0.600% Notes, the 5.00% Notes and the 2021 EUR Three Year Delayed Draw Term Loan, and for general corporate purposes. As of September 30, 2024, there are no EUR borrowings outstanding under the 2021 Multicurrency Credit Facility. We used the proceeds from the ATC TIPL Transaction to repay existing indebtedness under the 2021 Multicurrency Credit Facility. We currently have $5.2 million of undrawn letters of credit and maintain the ability to draw down and repay amounts under the 2021 Multicurrency Credit Facility in the ordinary course.

2021 Credit Facility— During the nine months ended September 30, 2024, we borrowed an aggregate of $1.5 billion and repaid an aggregate of $2.1 billion of revolving indebtedness under our $4.0 billion senior unsecured revolving credit facility, as amended and restated in December 2021, as further amended (the “2021 Credit Facility”). We used the borrowings to repay outstanding indebtedness, including the 3.375% Notes, and for general corporate purposes. We currently have $30.4 million of undrawn letters of credit and maintain the ability to draw down and repay amounts under the 2021 Credit Facility in the ordinary course.

Repayment of 2021 EUR Three Year Delayed Draw Term Loan— On May 21, 2024, we repaid all amounts outstanding under the 2021 EUR Three Year Delayed Draw Term Loan using borrowings under the 2021 Multicurrency Credit Facility.

As of September 30, 2024, the key terms under the 2021 Multicurrency Credit Facility, the 2021 Credit Facility and our $1.0 billion unsecured term loan, as amended and restated in December 2021, as further amended (the “2021 Term Loan”), were as follows:

</details>

# Context passages: implicit mentions, not classified

## Item 1 LEGAL PROCEEDINGS (blocks 271-276)

**Terms: data center (Data Centers, data center)**

Principles of Consolidation and Basis of Presentation —The accompanying consolidated and condensed consolidated financial statements include the accounts of the Company and those entities in which it has a controlling interest. Investments in entities that the Company does not control are accounted for using the equity method or as investments in equity securities, depending upon the Company’s ability to exercise significant influence over operating and financial policies. All intercompany accounts and transactions have been eliminated.

As of September 30, 2024, the Company holds (i) a 52 % controlling interest in subsidiaries whose holdings consist of the Company’s operations in France, Germany and Spain (such subsidiaries collectively, “ATC Europe”) (Allianz and CDPQ (each as defined in note 11) hold the noncontrolling interests), (ii) a 51 % controlling interest in a joint venture whose holdings consist of the Company’s operations in Bangladesh (Confidence Tower Holdings Ltd. (“Confidence Group”) holds the noncontrolling interest) and (iii) a controlling common equity interest of approximately 72 % in the Company’s U.S. data center business (Stonepeak (as defined and further discussed in note 11) holds approximately 28 % of the outstanding common equity and 100 % of the outstanding mandatorily convertible preferred equity). As of September 30, 2024, ATC Europe holds an 87 % and an 83 % controlling interest in subsidiaries that consist of the Company’s operations in Germany and Spain, respectively (PGGM holds the noncontrolling interests). See note 11 for a discussion of changes to the Company’s noncontrolling interests during the nine months ended September 30, 2024 and 2023.

ATC TIPL Transaction —On September 12, 2024, the Company completed the sale of its subsidiary ATC Telecom Infrastructure Private Limited (“ATC TIPL”), which held the Company’s operations in India. The divestiture qualified for presentation as discontinued operations. See note 15 for further discussion. Prior to the divestiture and classification as discontinued operations, ATC TIPL’s operating results were included within the Asia-Pacific property segment. Historical financial information included in this Quarterly Report on Form 10-Q has been adjusted to reflect the operating results of ATC TIPL as discontinued operations for all periods presented.

Australia & New Zealand —During the three months ended September 30, 2024, the Company, through its subsidiary, ATC Asia Pacific Pte. Ltd., entered into agreements pursuant to which it expects to sell 100 % of the ownership interests in its subsidiaries in Australia (“ATC Australia”) and New Zealand (“ATC New Zealand”) for total aggregate consideration of approximately $ 78.2 million as of the dates of signing, subject to certain adjustments. ATC Australia and ATC New Zealand’s operating results are included within the Asia-Pacific property segment. The divestitures will not qualify for presentation as discontinued operations.

Reportable Segments —The Company reports its results in seven segments – U.S. & Canada property, Asia-Pacific property, Africa property, Europe property, Latin America property, Data Centers and Services, which are discussed further in note 14.

Significant Accounting Policies —The Company’s significant accounting policies are described in note 1 to the Company’s consolidated financial statements included in the 2023 Form 10-K. There have been no material changes to the Company’s significant accounting policies during the nine months ended September 30, 2024, other than those noted below.

## Item 1 LEGAL PROCEEDINGS (blocks 298-304)

**Terms: data center (Data Centers, data center), interconnection (interconnection)**

Total cash, cash equivalents and restricted cash | $ 2,282.2 | $ 2,231.6

Revenue —The Company’s revenue is derived from leasing the right to use its communications sites, the land on which the sites are located, the land underlying its customers’ sites and the space in its data center facilities (the “lease component”) and from the reimbursement of costs incurred by the Company in operating the communications sites and data center facilities and supporting its customers’ equipment as well as other services and contractual rights (the “non-lease component”). Most of the Company’s revenue is derived from leasing arrangements and is accounted for as lease revenue unless the timing and pattern of revenue recognition of the non-lease component differs from the lease component. If the timing and pattern of the non-lease component revenue recognition differs from that of the lease component, the Company separately determines the stand-alone selling prices and pattern of revenue recognition for each performance obligation. Revenue related to distributed antenna system (“DAS”) networks and fiber and other related assets results from agreements with customers that are generally not accounted for as leases.

Non-lease property revenue —Non-lease property revenue consists primarily of revenue generated from DAS networks, fiber and other property related revenue. DAS networks and fiber arrangements generally require that the Company provide the tenant the right to use available capacity on the applicable communications infrastructure. Performance obligations are satisfied over time for the duration of the arrangements. Non-lease property revenue also includes revenue generated from interconnection offerings in the Company’s data center facilities. Interconnection offerings are generally contracted on a month-to-month basis and are cancellable by the Company or the data center customer at any time. Performance obligations are satisfied over time for the duration of the arrangements. Other property related revenue streams, which include site inspections, are not material on either an individual or consolidated basis. There were no material changes in the receivables, contract assets and contract liabilities from contracts with customers for the three and nine months ended September 30, 2024.

Services revenue —The Company offers tower-related services in the United States. These services include site application, zoning and permitting (“AZP”), structural and mount analyses, and construction management. There is a single performance obligation related to AZP and construction management, and revenue is recognized over time based on milestones achieved, which are determined based on costs expected to be incurred. Structural and mount analyses services may have more than one performance obligation, contingent upon the number of contracted services. Revenue is recognized at the point in time the services are completed.

A summary of revenue disaggregated by source and geography is as follows:

Three Months Ended September 30, 2024 | U.S. & Canada | Asia-Pacific (1) | Africa | Europe | Latin America | Data Centers | Total

Non-lease property revenue | $ 67.6 | $ — | $ 6.4 | $ 4.4 | $ 25.6 | $ 34.0 | $ 138.0

## Item 1 LEGAL PROCEEDINGS (blocks 312-314)

**Terms: data center (Data Centers)**

(1) Excludes the operating results of ATC TIPL, which are reported as discontinued operations. See note 15 for further discussion.

Three Months Ended September 30, 2023 | U.S. & Canada | Asia-Pacific (1) | Africa | Europe | Latin America | Data Centers | Total

Non-lease property revenue | $ 91.3 | $ — | $ 5.8 | $ 3.0 | $ 29.8 | $ 29.6 | $ 159.5

## Item 1 LEGAL PROCEEDINGS (blocks 319-321)

**Terms: data center (Data Centers)**

(1) Excludes the operating results of ATC TIPL, which are reported as discontinued operations. See note 15 for further discussion.

Nine Months Ended September 30, 2024 | U.S. & Canada | Asia-Pacific (1) | Africa | Europe | Latin America | Data Centers | Total

Non-lease property revenue | $ 217.7 | $ — | $ 18.7 | $ 13.1 | $ 81.9 | $ 98.4 | $ 429.8

## Item 1 LEGAL PROCEEDINGS (blocks 326-328)

**Terms: data center (Data Centers)**

(1) Excludes the operating results of ATC TIPL, which are reported as discontinued operations. See note 15 for further discussion.

Nine Months Ended September 30, 2023 | U.S. & Canada | Asia-Pacific (1) | Africa | Europe | Latin America | Data Centers | Total

Non-lease property revenue | $ 246.2 | $ — | $ 18.4 | $ 10.5 | $ 99.6 | $ 86.2 | $ 460.9

## Item 1 LEGAL PROCEEDINGS (blocks 339-343)

**Terms: data center (data center), renewable energy (renewable energy)**

(tabular amounts in millions, unless otherwise noted)

Stonepeak Development Partnership — During the nine months ended September 30, 2024, the Company entered into an agreement with Stonepeak (as defined in note 11) to form a joint venture to construct a new data center in Denver, CO (the “Stonepeak Development Partnership”). At formation, the Company contributed assets with a value of $ 14.6 million to the Stonepeak Development Partnership and acquired a minority ownership interest (Stonepeak holds the controlling interests). The Company accounts for the Stonepeak Development Partnership as an equity method investment. Under this method, investments are recorded at cost, and are adjusted for the Company’s share of the entities’ income or loss and for distributions and contributions. The investment is recorded in Other non-current assets in the consolidated balance sheets.

Accounting Standards Updates —In November 2023, the Financial Accounting Standards Board (“FASB”) issued guidance, which is intended to improve reportable segment disclosure requirements, primarily through additional disclosures about significant segment expenses. The standard is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the impact of this guidance on its consolidated financial statements and related disclosures.

In December 2023, the FASB issued guidance which requires public entities to provide enhanced income tax disclosures on an annual basis. The new guidance requires an expanded rate reconciliation and the disaggregation of cash taxes paid by U.S. federal, U.S. state and foreign jurisdictions. The updated guidance is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently evaluating the impact of this guidance on its consolidated financial statements and related disclosures.

SEC Rule Changes — In March 2024, the SEC issued Final Rule No. 33-11275, “The Enhancement and Standardization of Climate-Related Disclosures for Investors.” If such rule remains in effect, the rule will require registrants to provide certain climate-related information in their registration statements and annual reports. The rule requires registrants to provide climate related disclosures, including, but not limited to, (i) material Scope 1 and Scope 2 greenhouse gas emissions, (ii) governance and oversight of material climate-related risks, (iii) the material impact of climate risks on the registrant’s strategy, business model and outlook, (iv) risk management processes for material climate-related risks and (v) material climate targets and goals. The rule also requires disclosure of (x) financial statement effects of severe weather events and other natural conditions, (y) carbon offset and renewable energy credit information and (z) the impact of severe weather events and other natural conditions on estimates and assumptions. Disclosure requirements will begin phasing in for fiscal years beginning on or after January 1, 2025. In April 2024, the SEC issued an order staying implementation of such rule pending the resolution of certain challenges. The outcome of ongoing litigation is currently unknown. The Company is currently evaluating the potential impact of such rule on its consolidated financial statements and disclosures.

## Item 1 LEGAL PROCEEDINGS (blocks 426-428)

**Terms: data center (Data Centers)**

The changes in the carrying value of goodwill for each of the Company’s business segments were as follows:

Property — U.S. & Canada | Asia-Pacific (1) | Africa | Europe | Latin America | Data Centers | Services | Total (1)

Balance as of January 1, 2024 | $ 4,638.6 | $ 7.2 | $ 497.7 | $ 3,051.9 | $ 966.1 | $ 2,920.0 | $ 2.0 | $ 12,083.5

## Item 1 LEGAL PROCEEDINGS (blocks 446-448)

**Terms: data center (data center)**

(tabular amounts in millions, unless otherwise noted)

fair value of costs avoided in securing data center customers, including vacancy periods, legal costs and commissions. In place lease value also includes assumptions on similar costs avoided upon the renewal or extension of existing leases on a basis consistent with occupancy assumptions used in the fair value of other assets.

The Company amortizes its acquired intangible assets on a straight-line basis over their estimated useful lives. As of September 30, 2024, the remaining weighted average amortization period of the Company’s intangible assets was 20 years. Amortization of intangible assets for the three and nine months ended September 30, 2024 was $ 221.4 million and $ 675.0 million, respectively. Amortization of intangible assets for the three and nine months ended September 30, 2023 was $ 338.8 million and $ 1.0 billion, respectively. Based on current exchange rates, the Company expects to record amortization expense as follows over the remainder of the current year and the five subsequent years:

## Item 1 LEGAL PROCEEDINGS (blocks 703-704)

**Terms: data center (data center)**

Bangladesh Partnership —In 2021 , the Company acquired a 51 % controlling interest in Kirtonkhola Tower Bangladesh Limited (“KTBL”) for 900 million Bangladeshi Taka (approximately $ 10.6 million at the date of closing). Confidence Group holds a 49 % noncontrolling interest in KTBL.

Stonepeak Transaction —In 2022, the Company entered into agreements pursuant to which certain investment vehicles affiliated with Stonepeak Partners LP (such investment vehicles, collectively, “Stonepeak”) acquired a noncontrolling ownership interest in the Company’s U.S. data center business for total aggregate consideration of $ 3.1 billion, through an investment in common equity and mandatorily convertible preferred equity (the “Stonepeak Transaction”).

## Item 1 LEGAL PROCEEDINGS (blocks 707-711)

**Terms: data center (data center)**

(tabular amounts in millions, unless otherwise noted)

As of September 30, 2024, the Company holds a common equity interest of approximately 72 % in its U.S. data center business, with Stonepeak holding approximately 28 % of the outstanding common equity and 100 % of the outstanding mandatorily convertible preferred equity. On a fully converted basis, which is expected to occur four years from August 2022, and on the basis of the currently outstanding equity, the Company will hold a controlling ownership interest of approximately 64 %, with Stonepeak holding approximately 36 %. The mandatorily convertible preferred equity, which accrues dividends at 5.0 %, will convert into common equity on a one for one basis, subject to adjustment that will be measured upon conversion.

Dividends to noncontrolling interests— Certain of the Company’s subsidiaries may, from time to time, declare dividends. During the nine months ended September 30, 2024, the Company’s U.S. data center business declared distributions of $ 34.6 million related to the outstanding Stonepeak mandatorily convertible preferred equity (the “Stonepeak Preferred Distributions”). As of September 30, 2024, the amount accrued for Stonepeak Preferred Distributions was $ 11.6 million.

Beginning in January 2024, pursuant to the terms of the ownership agreement with Stonepeak, on a quarterly basis, the Company’s U.S. data center business will distribute common dividends to the Company and to Stonepeak in proportion to their respective equity interests in the Company’s U.S. data center business (the “Stonepeak Common Dividend”). During the nine months ended September 30, 2024, the Company’s U.S. data center business made distributions of $ 91.7 million related to the Stonepeak Common Dividend for the period from the initial closing of the Stonepeak Transaction in August 2022 through December 31, 2023, which was accrued for as of December 31, 2023. The $ 91.7 million distribution during the nine months ended September 30, 2024 included a noncash distribution of $ 37.5 million made in lieu of a common equity contribution from Stonepeak. Additionally, during the nine months ended September 30, 2024, the Company’s U.S. data center business declared and paid distributions of $ 30.1 million, related to the Stonepeak Common Dividend.

During the nine months ended September 30, 2024, pursuant to the terms of the ownership agreements, ATC Europe C.V., one of the Company’s subsidiaries in the Netherlands, declared and paid dividends of an aggregate of 422.5 million EUR (approximately $ 465.1 million at the dates of payment), pursuant to the terms of the ownership agreements, to the Company, CDPQ and Allianz in proportion to their respective equity interests in ATC Europe C.V.

## Item 1 LEGAL PROCEEDINGS (blocks 754-756)

**Terms: data center (Data Centers)**

Communications Sites and Related Communications Infrastructure —The Company’s primary business is leasing space on multitenant communications sites to wireless service providers, radio and television broadcast companies, wireless data providers, government agencies and municipalities and tenants in a number of other industries. The Company has historically reported these operations on a geographic basis.

Data Centers —The Company’s Data Centers segment relates to data center facilities and related assets that the Company owns and operates in the United States. The Data Centers segment offers different types of leased land and related services from, and requires different resources, skill sets and marketing strategies than the existing property operating segment in the U.S. & Canada.

During the three months ended September 30, 2024, the Company completed the sale of ATC TIPL. The divestiture qualified for presentation as discontinued operations. See note 15 for further discussion. Prior to the divestiture and classification as discontinued operations, ATC TIPL’s operating results were included within the Asia-Pacific property segment. Historical financial information included in this Quarterly Report on Form 10-Q has been adjusted to reflect the operating results of ATC TIPL as discontinued operations for all periods presented.

## Item 1 LEGAL PROCEEDINGS (blocks 762-763)

**Terms: data center (Data Centers)**

Latin America: property operations in Argentina, Brazil, Chile, Colombia, Costa Rica, Mexico, Paraguay and Peru; and

Data Centers: data center property operations in the United States.

## Item 1 LEGAL PROCEEDINGS (blocks 770-772)

**Terms: data center (Data Centers)**

Summarized financial information concerning the Company’s reportable segments for the three and nine months ended September 30, 2024 and 2023 is shown in the following tables. The “Other” column (i) represents amounts excluded from specific segments, such as business development operations, stock-based compensation expense and corporate expenses included in Selling, general, administrative and development expense; Other operating expenses; Interest income; Interest expense; Gain (loss) on retirement of long-term obligations; and Other income (expense), and (ii) reconciles segment operating profit to Income from continuing operations before income taxes.

Three Months Ended September 30, 2024 | Property — U.S. & Canada | Asia-Pacific (1) | Africa | Europe | Latin America | Data Centers | Total Property | Services | Other | Total

Segment revenues | $ 1,318.0 | $ 5.7 | $ 296.9 | $ 212.8 | $ 402.8 | $ 233.7 | $ 2,469.9 | $ 52.4 | $ 2,522.3

## Item 1 LEGAL PROCEEDINGS (blocks 788-790)

**Terms: data center (Data Centers)**

(3) Primarily includes interest expense and losses from foreign currency exchange rate fluctuations, partially offset by an unrealized gain from equity securities of $ 67.9 million.

Three Months Ended September 30, 2023 | Property — U.S. & Canada | Asia-Pacific (1) | Africa | Europe | Latin America | Data Centers | Total Property | Services | Other (4) | Total

Segment revenues | $ 1,324.5 | $ 4.8 | $ 293.7 | $ 200.4 | $ 459.6 | $ 211.9 | $ 2,494.9 | $ 26.2 | $ 2,521.1

## Item 1 LEGAL PROCEEDINGS (blocks 807-809)

**Terms: data center (Data Centers)**

(tabular amounts in millions, unless otherwise noted)

Nine Months Ended September 30, 2024 | Property — U.S. & Canada | Asia-Pacific (1) | Africa | Europe | Latin America | Data Centers | Total Property | Services | Total

Segment revenues | $ 3,944.1 | $ 16.1 | $ 882.8 | $ 620.5 | $ 1,297.0 | $ 689.1 | $ 7,449.6 | $ 130.0 | $ 7,579.6

## Item 1 LEGAL PROCEEDINGS (blocks 824-826)

**Terms: data center (Data Centers)**

(tabular amounts in millions, unless otherwise noted)

Nine Months Ended September 30, 2023 | Property — U.S. & Canada | Asia-Pacific (1) | Africa | Europe | Latin America | Data Centers | Total Property | Services | Total

Segment revenues | $ 3,915.3 | $ 13.7 | $ 931.9 | $ 590.3 | $ 1,363.1 | $ 619.8 | $ 7,434.1 | $ 122.0 | $ 7,556.1

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 936-938)

**Terms: data center (data center)**

Overview

We are one of the largest global real estate investment trusts and a leading independent owner, operator and developer of multitenant communications real estate. Our primary business is the leasing of space on communications sites to wireless service providers, radio and television broadcast companies, wireless data providers, government agencies and municipalities and tenants in a number of other industries. In addition to the communications sites in our portfolio, we manage rooftop and tower sites for property owners under various contractual arrangements. We also hold other telecommunications infrastructure and property interests that we lease primarily to communications service providers and third-party tower operators, and, as discussed further below, we hold a portfolio of highly interconnected data center facilities and related assets in the United States. Our customers include our tenants, licensees and other payers. We refer to the business encompassing the above as our property operations, which accounted for 98% of our total revenues for each of the three and nine months ended September 30, 2024 and includes our U.S. & Canada property, Asia-Pacific property, Africa property, Europe property and Latin America property segments and Data Centers segment.

We also offer tower-related services in the United States, including site application, zoning and permitting, structural and mount analyses, and construction management, which primarily support our site leasing business, including the addition of new tenants and equipment on our sites.

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 975-978)

**Terms: data center (Data Centers, data center)**

Australia & New Zealand —During the three months ended September 30, 2024, we, through our subsidiary, ATC Asia Pacific Pte. Ltd., entered into agreements pursuant to which we expect to sell 100% of the ownership interests in our subsidiaries in Australia (“ATC Australia”) and New Zealand (“ATC New Zealand”) for total aggregate consideration of approximately $78.2 million as of the dates of signing, subject to certain adjustments.

As of September 30, 2024, our property portfolio included 28 operating data center facilities across ten markets in the United States that collectively comprise approximately 3.2 million net rentable square feet (“NRSF”) of data center space, as follows:

Number of Data Centers | Total NRSF (1)

(in thousands)

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 990-992)

**Terms: data center (Data Centers)**

(1) Excludes approximately 0.4 million of office and light industrial NRSF.

We operate in seven reportable segments: U.S. & Canada property, Asia-Pacific property, Africa property, Europe property, Latin America property, Data Centers and Services. In evaluating operating performance in each business segment, management uses, among other factors, segment gross margin and segment operating profit (see note 14 to our consolidated and condensed consolidated financial statements included in this Quarterly Report).

The 2023 Form 10-K contains information regarding management’s expectations of long-term drivers of demand for our communications sites, as well as key trends, which management believes provide valuable insight into our operating and financial resource allocation decisions. The discussion below should be read in conjunction with the 2023 Form 10-K and, in particular, the information set forth therein under Item 7 “Management’s Discussion and Analysis of Financial Condition and Results of Operations—Executive Overview.”

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1018-1020)

**Terms: data center (Data Centers)**

Latin America | 402.8 | 459.6 | (12) % | 1,297.0 | 1,363.1 | (5) %

Data Centers | 233.7 | 211.9 | 10 % | 689.1 | 619.8 | 11 %

Total property | 2,469.9 | 2,494.9 | (1) % | 7,449.6 | 7,434.1 | 0 %

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1027-1029)

**Terms: colocation (colocations)**

Partially offset by tenant billings growth of $57.0 million, which was driven by:

$44.9 million due to leasing additional space on our sites (“colocations”) and amendments; and

$16.0 million resulting from contractual escalations, net of churn;

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1034-1036)

**Terms: colocation (colocations)**

$0.6 million generated from sites acquired or constructed since the beginning of the prior-year period (“newly acquired or constructed sites”);

$0.2 million due to colocations and amendments; and

$0.2 million resulting from contractual escalations, net of churn; and

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1041-1043)

**Terms: colocation (colocations)**

$11.6 million resulting from contractual escalations, net of churn;

$10.2 million due to colocations and amendments;

$10.0 million generated from newly acquired or constructed sites; and

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1050-1052)

**Terms: colocation (colocations)**

• Tenant billings growth of $10.5 million, which was driven by:

$5.6 million due to colocations and amendments;

$3.0 million resulting from contractual escalations, net of churn; and

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1062-1064)

**Terms: colocation (colocations)**

Tenant billings growth of $5.7 million, which was driven by:

$7.5 million due to colocations and amendments; and

$0.5 million generated from newly acquired or constructed sites;

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1068-1073)

**Terms: data center (Data Centers), interconnection (interconnection)**

An increase of $2.9 million in pass-through revenue.

Data Centers segment revenue growth of $21.8 million was attributable to:

An increase of $13.7 million in rental, related and other revenue, primarily due to new lease commencements, customer expansions and rent increases upon customer renewals;

An increase of $7.7 million in power revenue from new lease commencements, increased power consumption and pricing increases from existing customers; and

An increase of $2.8 million in interconnection revenue, primarily due to customer interconnection net additions and set-up fees;

Partially offset by a decrease of $2.4 million in straight-line revenue.

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1077-1079)

**Terms: colocation (colocations)**

Tenant billings growth of $167.6 million, which was driven by:

$135.5 million due to colocations and amendments; and

$42.2 million resulting from contractual escalations, net of churn;

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1085-1087)

**Terms: colocation (colocations)**

$1.7 million generated from newly acquired or constructed sites;

$0.6 million due to colocations and amendments; and

$0.4 million resulting from contractual escalations, net of churn; and

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1095-1097)

**Terms: colocation (colocations)**

Tenant billings growth of $115.5 million, which was driven by:

$39.2 million due to colocations and amendments;

$37.9 million generated from newly acquired or constructed sites;

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1102-1104)

**Terms: colocation (colocations)**

• Tenant billings growth of $28.7 million, which was driven by:

$15.1 million due to colocations and amendments;

$8.5 million resulting from contractual escalations, net of churn; and

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1114-1116)

**Terms: colocation (colocations)**

Tenant billings growth of $21.2 million, which was driven by:

$24.3 million due to colocations and amendments; and

$1.5 million generated from newly acquired or constructed sites;

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1120-1125)

**Terms: data center (Data Centers), interconnection (interconnection)**

An increase of $10.5 million in pass-through revenue.

Data Centers segment revenue growth of $69.3 million was attributable to:

An increase of $43.1 million in rental, related and other revenue, primarily due to new lease commencements, customer expansions and rent increases upon customer renewals;

An increase of $24.6 million in power revenue from new lease commencements, increased power consumption and pricing increases from existing customers; and

An increase of $8.4 million in interconnection revenue, primarily due to customer interconnection net additions and set-up fees;

Partially offset by a decrease of $6.8 million in straight-line revenue.

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1134-1136)

**Terms: data center (Data Centers)**

Latin America | 274.6 | 315.3 | (13) % | 892.1 | 941.1 | (5) %

Data Centers | 133.5 | 121.8 | 10 % | 396.7 | 362.2 | 10 %

Total property | 1,843.0 | 1,869.4 | (1) % | 5,590.4 | 5,557.1 | 1 %

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1144-1146)

**Terms: data center (Data Centers)**

The decrease in Latin America property segment gross margin was primarily attributable to the decrease in revenue described above, partially offset by a decrease in direct expenses of $3.3 million. Direct expenses also benefited by $12.8 million from the impact of foreign currency translation.

The increase in Data Centers segment gross margin was primarily attributable to the increase in revenue described above, partially offset by an increase in direct expenses of $10.1 million, primarily due to an increase in costs associated with power revenue, including utility costs.

• The increase in Services segment gross margin was primarily attributable to the increase in revenue described above, partially offset by an increase in direct expenses of $12.4 million.

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1152-1154)

**Terms: data center (Data Centers)**

The decrease in Latin America property segment gross margin was primarily attributable to the decrease in revenue described above, partially offset by a decrease in direct expenses of $9.5 million, including a decrease due to the sale of Mexico Fiber in the prior year period, as well as land rent costs. Direct expenses also benefited by $7.6 million from the impact of foreign currency translation.

The increase in Data Centers segment gross margin was primarily attributable to the increase in revenue described above, partially offset by an increase in direct expenses of $34.8 million, primarily due to an increase in costs associated with power revenue, including utility costs.

• The decrease in Services segment gross margin was primarily attributable to an increase in direct expenses of $12.0 million, partially offset by the increase in revenue described above.

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1162-1164)

**Terms: data center (Data Centers)**

Latin America | 28.6 | 28.9 | (1) | 78.1 | 82.1 | (5)

Data Centers | 20.5 | 17.9 | 15 | 56.6 | 54.0 | 5

Total property | 122.2 | 117.1 | 4 | 350.5 | 362.4 | (3)

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1174-1176)

**Terms: data center (Data Centers)**

• The decrease in our Latin America property segment SG&A was primarily driven by decreased professional services costs and personnel and related costs and a benefit from the impact of foreign currency translation, partially offset by a net increase in bad debt expense of $4.9 million.

• The increase in our Data Centers property segment SG&A was primarily driven by increased personnel and related costs to support our business and increased professional services costs.

• The decrease in our Services segment SG&A was primarily driven by decreased personnel and related costs.

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1179-1181)

**Terms: data center (Data Centers)**

• The decreases in our U.S. & Canada property segment SG&A and our Services segment SG&A were primarily driven by decreased personnel and related costs.

The increases in our Asia-Pacific property segment SG&A and our Data Centers segment SG&A were primarily driven by increased personnel and related costs to support our business.

• The decrease in our Africa property segment SG&A was primarily driven by a benefit from the impact of foreign currency translation of $10.2 million, partially offset by increased personnel and related costs to support our business and a net increase in bad debt expense.

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1192-1194)

**Terms: data center (Data Centers)**

Latin America | 246.0 | 286.4 | (14) | 814.0 | 859.0 | (5)

Data Centers | 113.0 | 103.9 | 9 | 340.1 | 308.2 | 10

Total property | 1,720.8 | 1,752.3 | (2) | 5,239.9 | 5,194.7 | 1

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1201-1203)

**Terms: data center (Data Centers)**

• The decreases in operating profit for the three and nine months ended September 30, 2024 for our Latin America property segment were primarily attributable to decreases in our segment gross margin, partially offset by decreases in our segment SG&A.

• The increases in operating profit for the three and nine months ended September 30, 2024 for our Data Centers segment were primarily attributable to increases in our segment gross margin, partially offset by increases in our segment SG&A.

• The increase in operating profit for the three months ended September 30, 2024 for our Services segment was primarily attributable to an increase in our segment gross margin and a decrease in our segment SG&A. The decrease in operating profit for the nine months ended September 30, 2024 for our Services segment was primarily attributable to a decrease in our segment gross margin, partially offset by a decrease in our segment SG&A.

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1295-1297)

**Terms: data center (Data Centers)**

The decrease in Adjusted EBITDA for the three months ended September 30, 2024 was primarily attributable to a decrease in our gross margin and an increase in SG&A, excluding the impact of stock-based compensation expense of $3.1 million. The increase in Adjusted EBITDA for the nine months ended September 30, 2024 was primarily attributable to an increase in our gross margin and a decrease in SG&A, excluding the impact of stock-based compensation expense of $12.3 million.

The increase in AFFO attributable to American Tower Corporation common stockholders for the three months ended September 30, 2024 was primarily attributable to (i) an increase in our operating profit, excluding the impact of straight-line accounting and (ii) decreases in cash paid for income taxes and capital improvement capital expenditures, partially offset by (i) distributions and adjustments for noncontrolling interests, including distributions to noncontrolling interest holders in our Europe property segment and Data Centers segment and (ii) a decrease in AFFO attributable to American Tower Corporation common stockholders from discontinued operations.

The increase in AFFO attributable to American Tower Corporation common stockholders for the nine months ended September 30, 2024 was primarily attributable to (i) an increase in our operating profit, excluding the impact of straight-line accounting, (ii) an increase in AFFO attributable to American Tower Corporation common stockholders from discontinued operations and (iii) decreases in cash paid for income taxes and capital improvement capital expenditures, partially offset by (x) distributions and adjustments for noncontrolling interests, including distributions to noncontrolling interest holders in our Europe property segment and Data Centers segment and (y) increases in net cash paid for interest.

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1324-1326)

**Terms: data center (data center)**

(1) For the nine months ended September 30, 2024, includes $2.2 billion of proceeds from the ATC TIPL Transaction.

We use our cash flows to fund our operations and investments in our business, including maintenance and improvements, communications site and data center construction, managed network installations and acquisitions. Additionally, we use our cash flows to make distributions, including distributions of our REIT taxable income to maintain our qualification for taxation as a REIT under the Internal Revenue Code of 1986, as amended (the “Code”). We may also periodically repay or repurchase our existing indebtedness or equity. We typically fund our international expansion efforts primarily through a combination of cash on hand, intercompany debt and equity contributions.

As of September 30, 2024, we had total outstanding indebtedness of $37.4 billion, with a current portion of $3.7 billion. During the nine months ended September 30, 2024, we generated sufficient cash flow from operations, together with borrowings under our credit facilities, proceeds from our debt issuance and cash on hand, to fund our acquisitions, capital

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1330-1331)

**Terms: data center (Data Centers)**

Cash Flows from Operating Activities

The increase in cash provided by operating activities for the nine months ended September 30, 2024 was primarily attributable to (i) an increase in the operating profits of our U.S. & Canada, Asia-Pacific, Africa, and Europe property segments, our Data Centers segment, and in India, excluding the loss on sale of ATC TIPL, (ii) a decrease in the impact of straight-line revenue and (iii) a decrease in cash required for working capital, partially offset by increases in cash paid for interest and cash paid for taxes.

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1343-1345)

**Terms: data center (data center)**

Total capital expenditures (4) | $ 1,162.9

(1) Includes the construction of 1,423 communications sites globally, the construction of 90 communications sites in India, which are reported as discontinued operations, and approximately $382.3 million of spend related to data center assets.

(2) Includes $24.0 million of perpetual land easement payments reported in Deferred financing costs and other financing activities in the cash flows from financing activities in our condensed consolidated statements of cash flows.

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1347-1349)

**Terms: data center (data center)**

(4) Net of purchase credits of $11.6 million on certain assets, which are recorded in investing activities in our condensed consolidated statements of cash flows.

We plan to continue to allocate our available capital, after satisfying our distribution requirements, among investment alternatives that meet our return on investment criteria, while maintaining our commitment to our long-term financial policies. Accordingly, we expect to continue to deploy capital through our annual capital expenditure program, including land purchases and new site and data center facility construction, and through acquisitions. We also regularly review our portfolios as to capital expenditures required to upgrade our infrastructure to our structural standards or address capacity, structural or permitting issues.

We expect that our 2024 total capital expenditures will be as follows (in millions):

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1355-1356)

**Terms: data center (data center)**

Total capital expenditures | $ 1,500 | to | $ 1,610

(1) Includes the construction of approximately 1,800 to 2,600 communications sites globally and approximately $480 million of anticipated spend related to data center assets.

## Item 2 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 1443-1445)

**Terms: customer concentration (significant customer)**

rising interest rates and supply chain disruptions may impact our ability to raise additional capital through debt financing activities or our ability to repay or refinance maturing liabilities, or impact the terms of any new obligations. If we are unable to raise capital when our needs arise, we may not be able to fund capital expenditures, future growth and expansion initiatives, satisfy our REIT distribution requirements and debt service obligations, or refinance our existing indebtedness.

In addition, our liquidity depends on our ability to generate cash flow from operating activities. As set forth under the caption “Risk Factors” in Item 1A of the 2023 Form 10-K, we derive a substantial portion of our revenues from a small number of customers and, consequently, a failure by a significant customer to perform its contractual obligations to us could adversely affect our cash flow and liquidity.

For more information regarding the terms of our outstanding indebtedness, please see note 8 to our consolidated financial statements included in the 2023 Form 10-K.
