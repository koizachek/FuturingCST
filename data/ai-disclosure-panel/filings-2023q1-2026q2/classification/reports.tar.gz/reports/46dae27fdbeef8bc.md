# US BANCORP \DE\ | 10-Q | fiscal year 2024

- Report length: 50,846 words
- Direct AI mentions (classified): 0, of which about AI: 0, false candidates: 0, flagged for review: 0
- Context passages (not classified): 4; groups: deployment_operations (4), industry (1)
- Frames: none
- Roles: none
- Risk types: none
- MIT subdomains: none
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: none
- Substantiveness: none
- Disclosure traits: none
- Trait activation rate: n/a
- Sections: none
- Named entities: none

# Context passages: implicit mentions, not classified

## unknown section (blocks 279-281)

**Terms: automated valuation model (automated valuation, automated valuation model)**

Residential mortgage originations are generally limited to prime borrowers and are performed through the Company’s branches, loan production offices, mobile and online services, and a wholesale network of originators. The Company may retain residential mortgage loans it originates on its balance sheet or sell the loans into the secondary market while retaining the servicing rights and customer relationships. Utilizing the secondary markets enables the Company to effectively reduce its credit and other asset/liability risks. For residential mortgages that are retained in the Company’s portfolio and for home equity and second mortgages, credit risk is managed by adherence to LTV and borrower credit criteria during the underwriting process.

The Company estimates updated LTV information on its outstanding residential mortgages quarterly, based on a method that combines automated valuation model updates and relevant home price indices. LTV is the ratio of the loan’s outstanding principal balance to the current estimate of property value. For home equity and second mortgages, combined loan-to-value (“CLTV”) is the combination of the first mortgage original principal balance and the second lien outstanding principal balance, relative to the current estimate of property value. Certain loans do not have an LTV or CLTV, primarily due to lack of availability of relevant automated valuation model and/or home price indices values, or lack of necessary valuation data on acquired loans.

The following tables provide summary information of residential mortgages and home equity and second mortgages by LTV at June 30, 2024:

## unknown section (blocks 470-472)

**Terms: model performance (model performance)**

When a loan portfolio is purchased, the acquired loans are divided into those considered purchased with more than insignificant credit deterioration (“PCD”) and those not considered PCD. An allowance is established for each population and considers product mix, risk characteristics of the portfolio and delinquency status and refreshed LTV ratios when possible. PCD loans also consider whether the loan has experienced a charge-off, bankruptcy or significant deterioration since origination. The allowance established for purchased loans not considered PCD is recognized through provision expense upon acquisition, whereas the allowance established for loans considered PCD at acquisition is offset by an increase in the basis of the acquired loans. Any subsequent increases and decreases in the allowance related to purchased loans, regardless of PCD status, are recognized through provision expense, with charge-offs charged to the allowance. The Company had a total net book balance of $2.9 billion of PCD loans, primarily related to the MUB acquisition, included in its loan portfolio at June 30, 2024.

The Company’s methodology for determining the appropriate allowance for credit losses also considers the imprecision inherent in the methodologies used and allocated to the various loan portfolios. As a result, amounts determined under the methodologies described above are adjusted by management to consider the potential impact of other qualitative factors not captured in quantitative model adjustments which include, but are not limited to, the following: model imprecision, imprecision in economic scenario assumptions, and emerging risks related to either changes in the economic environment that are affecting specific portfolios, or changes in portfolio concentrations over time that may affect model performance. The consideration of these items results in adjustments to allowance amounts included in the Company’s allowance for credit losses for each loan portfolio.

Although the Company determined the amount of each element of the allowance separately and considers this process to be an important credit management tool, the entire allowance for credit losses is available for the entire loan portfolio. The actual amount of losses can vary significantly from the estimated amounts.

## unknown section (blocks 589-591)

**Terms: model performance (model performance), model validation (model validations)**

Market Risk Management In addition to interest rate risk, the Company is exposed to other forms of market risk, principally related to trading activities which support customers’ strategies to manage their own foreign currency, interest rate risk, commodities risk and funding activities. For purposes of its internal capital adequacy assessment process, the Company considers risk arising from its trading activities, as well as the remeasurement volatility of foreign currency denominated balances included on its Consolidated Balance Sheet (collectively, “Covered Positions”), employing methodologies consistent with the requirements of regulatory rules for market risk. The Company’s Market Risk Committee (“MRC”), within the framework of the ALCO, oversees market risk management. The MRC monitors and reviews the Company’s Covered Positions and establishes policies for market risk management, including exposure limits for each portfolio. The Company uses a VaR approach to measure general market risk. Theoretically, VaR represents the statistical risk of loss the Company has to adverse market movements over a one-day time horizon. The Company uses the Historical Simulation method to calculate VaR for its Covered Positions measured at the ninety-ninth percentile using a one-year look-back period for distributions derived from past market data. The market factors used in the calculations include those pertinent to market risks inherent in the underlying trading portfolios, principally those that affect the Company’s corporate bond trading business, foreign currency transaction business, client derivatives business, loan trading business and municipal securities business, as well as those inherent in the Company’s foreign denominated balances and the derivatives used to mitigate the related measurement volatility. On average, the Company expects the

one-day VaR to be exceeded by actual losses two to three times per year related to these positions. The Company monitors the accuracy of internal VaR models and modeling processes by back-testing model performance, regularly updating the historical data used by the VaR models and regular model validations to assess the accuracy of the models’ input, processing, and reporting components. All models are required to be independently reviewed and approved prior to being placed in use. If the Company were to experience market losses in excess of the estimated VaR more often than expected, the VaR models and associated assumptions would be analyzed and adjusted.

The average, high, low and period-end one-day VaR amounts for the Company’s Covered Positions were as follows:

## unknown section (blocks 1185-1187)

**Terms: model performance (model performance)**

The allowance recorded for credit losses utilizes forward-looking expected loss models to consider a variety of factors affecting lifetime credit losses. These factors include, but are not limited to, macroeconomic variables such as unemployment rates, real estate prices, gross domestic product levels, inflation, interest rates and corporate bonds spreads, as well as loan and borrower characteristics, such as internal risk ratings on commercial loans and consumer credit scores, delinquency status, collateral type and available valuation information, consideration of end-of-term losses on lease residuals, and the remaining term of the loan, adjusted for expected prepayments. For each loan portfolio, including those loans modified under various loan modification programs, model estimates are adjusted as necessary to consider any relevant changes in portfolio composition, lending policies, underwriting standards, risk management practices, economic conditions or other factors that would affect the accuracy of the model. Expected credit loss estimates also include consideration of expected cash recoveries on loans previously charged-off or expected recoveries on collateral dependent loans where recovery is expected through sale of the collateral at fair value less selling costs. Where loans do not exhibit similar risk characteristics, an individual analysis is performed to consider expected credit losses. The allowance recorded for individually evaluated loans greater than $ 5 million in the commercial lending segment is based on an analysis utilizing expected cash flows discounted using the original effective interest rate, the observable market price of the loan, or the fair value of the collateral, less selling costs, for collateral-dependent loans as appropriate. For smaller commercial loans collectively evaluated for impairment, historical loss experience is also incorporated into the allowance methodology applied to this category of loans.

The Company’s methodology for determining the appropriate allowance for credit losses also considers the imprecision inherent in the methodologies used and allocated to the various loan portfolios. As a result, amounts determined under the methodologies described above are adjusted by management to consider the potential impact of other qualitative factors not captured in the quantitative model adjustments which include, but are not limited to, the following: model imprecision, imprecision in economic scenario assumptions, and emerging risks related to either changes in the environment that are affecting specific portfolios, or changes in portfolio concentrations over time that may affect model performance. The consideration of these items results in adjustments to allowance amounts included in the Company’s allowance for credit losses for each loan portfolio.

The Company also assesses the credit risk associated with off-balance sheet loan commitments, letters of credit, investment securities and derivatives. Credit risk associated with derivatives is reflected in the fair values recorded for those positions. The liability for off-balance sheet credit exposure related to loan commitments and other credit guarantees is included in other liabilities. Because business processes and credit risks associated with unfunded credit commitments are essentially the same as for loans, the Company utilizes similar processes to estimate its liability for unfunded credit commitments.
