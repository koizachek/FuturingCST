# Philip Morris International Inc. | 10-Q | fiscal year 2024

- Report length: 66,613 words
- Direct AI mentions (classified): 3, of which about AI: 1, false candidates: 2, flagged for review: 0
- Context passages (not classified): 5; groups: industry (4), governance_regulation (1)
- Frames: risk_factor (1)
- Roles: risk (1)
- Risk types: cybersecurity (1), regulatory_legal (1)
- MIT subdomains: ai_system_security_vulnerabilities_attacks (1), regulation_lagging_behind_ai (1)
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: unspecified (1)
- Substantiveness: specific (1)
- Disclosure traits: hedging (1)
- Trait activation rate: 1.0 (boilerplate (0.0), hedging (1.0), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 2 (1)
- Named entities: European Union

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1091-1093)

**AI reference: none**

- Note (gemini: The term 'in silico toxicology' is a false positive for AI, referring to computational toxicology methods rather than AI specifically.)

<details><summary>Passage</summary>

Description of Our Company

We are a leading international tobacco company, actively delivering a smoke-free future. We are evolving our portfolio for the long term to include products outside of the tobacco and nicotine sector. Our current product portfolio primarily consists of cigarettes and smoke-free products. Since 2008, we have invested over $12.5 billion to develop, scientifically substantiate and commercialize innovative smoke-free products for adults who would otherwise continue to smoke, with the goal of completely ending the sale of cigarettes. This investment includes the building of world-class scientific assessment capabilities, notably in the areas of pre-clinical systems toxicology, clinical and behavioral research, as well as post-market studies. In November 2022, we acquired Swedish Match AB ("Swedish Match") – a leader in oral nicotine delivery – creating a global smoke-free combination led by the companies’ IQOS and ZYN brands. The U.S. Food and Drug Administration (the "FDA") has authorized versions of our IQOS devices and consumables and Swedish Match's General snus as Modified Risk Tobacco Products ("MRTPs") and renewal applications for these products are presently pending before the FDA. We describe the MRTP orders in more detail in the "Business Environment" section of this Item 2. Management's Discussion and Analysis of Financial Condition and Results of Operations ("MD&A").

Following the combination and the progress in 2023 toward the integration of the Swedish Match business into PMI's existing regional structure, PMI updated in January 2024 its segment reporting by including the former Swedish Match segment results into the four existing geographical segments. Our four geographical segments are as follows:

</details>

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1556-1559)

**AI reference: none**

- Note (gemini: The term 'in silico toxicology' is a false positive for AI, referring to computational toxicology methods rather than AI specifically.)

<details><summary>Passage</summary>

Premarket tobacco applications for certain ZYN products, which are currently marketed in the U.S., were submitted in March 2020. In the same month, these applications were filed for scientific review and in July 2020 the FDA issued a deficiency letter which Swedish Match USA, Inc. addressed in September 2020. The FDA has not completed its review of such applications but, consistent with its practice concerning products with respect to which applications were filed prior to a September 9, 2020 deadline, the FDA has not taken enforcement action to prevent these ZYN products from being marketed or indicated that it intends to do so. After the September 9, 2020 deadline, we also submitted additional applications for authorization to market other ZYN products. We are unable to market these products until the FDA authorizes such applications. In April 2024, we submitted MRTPAs for ZYN products currently marketed in the U.S. and requested authorization of the modified risk claim. As these applications proceed through the review process, the FDA may request additional information or conduct subsequent inspections to verify the submitted information.

On April 29, 2024, we submitted the Annual Report for the IQOS Tobacco Heating System ("THS") to the FDA. The report included a systematic review of the literature covering publications related to the IQOS THS between March 1, 2023 and February 29, 2024. The report included publications in various scientific fields including aerosol chemistry and physics, standard and systems toxicology, clinical studies on exposure reduction to HPHCs, and observational studies. Overall, the review continues to support the finding that IQOS THS is "appropriate for the promotion of public health."

Some states and municipalities in the U.S. have introduced stringent restrictions on the sale of certain SFPs, including those authorized by the FDA. We believe that many of those restrictions on FDA-authorized products are unlikely to advance public health and instead are likely to limit adult consumer access to products that are shown to be a better alternative to continued cigarette smoking.

</details>

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 2007-2014)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: cybersecurity, regulatory_legal | mit: ai_system_security_vulnerabilities_attacks, regulation_lagging_behind_ai | kinds: unspecified | substantiveness: specific | traits: hedging**

> Cyberattacks, security incidents and vulnerabilities, including through artificial intelligence-driven techniques, impacting PMI, newly acquired companies, our business partners, or our third-party providers, continue to dynamically evolve in sophistication and volume, making it difficult for us to predict probability, frequency, and impact severity of security incidents.

> Our or our business partners’ failure or inability to adhere to privacy, data, artificial intelligence and information security laws could result in business disruption, loss of reputation and consumer trust, litigation, regulatory action including significant fines or penalties, financial impact, and loss of revenue, assets or personal, confidential, or sensitive data.

> comply with artificial intelligence regulations including, but not limited to, the EU Artificial Intelligence Act; and others, could have a material adverse effect on us, subject us to substantial fines and/or legal challenges, and/or harm our business, reputation, financial condition, or operating results.

<details><summary>Passage</summary>

We and our business partners heavily rely on information technology networks and systems, including those connected to the Internet, to help manage business processes and operations, including the collection, storage, interpretation, and processing of confidential, sensitive, personal and other data; internal and external communications; marketing and e-commerce activities; the manufacture, sale, and distribution of our products; management of third-party business relationships; engagement with governmental authorities; innovation through research and development; and other activities necessary for business operations. Some of these information systems and networks are developed, supplied, or managed by third-party service providers that may make us vulnerable to “supply chain” style cyberattacks. The failure or disruption of our information technology networks and systems, or those managed by third-party service providers or owned by our business partners and used in furtherance of PMI’s business, due to cybersecurity attacks; unauthorized attempts to access, corrupt or extract data; security vulnerabilities; misconfigurations; human error; or failure or inability by us, third-parties, or our business partners to adhere to cybersecurity industry best practices, could place us at a competitive disadvantage, cause reputational damage, impact our operations, result in data breaches, significant business disruption, litigation, regulatory action including significant fines or penalties, financial impact, loss of revenue or assets including our intellectual property, personal, confidential, or sensitive data.

Cyberattacks, security incidents and vulnerabilities, including through artificial intelligence-driven techniques, impacting PMI, newly acquired companies, our business partners, or our third-party providers, continue to dynamically evolve in sophistication and volume, making it difficult for us to predict probability, frequency, and impact severity of security incidents. Further, it may be inherently difficult to detect vulnerabilities during due diligence, for long periods of time, or soon enough to mitigate exploitation. There can be no assurance that such security incidents or vulnerabilities will not have a material adverse effect on us in the future. While PMI works to mitigate these risks by implementing a cybersecurity risk program and a third-party cybersecurity risk management program, there can be no assurance that these programs are comprehensive or accurately identify and sufficiently mitigate all cybersecurity risks.

We continue to make investments in administrative, technical, and physical safeguards to maintain information security protections in line with industry standards and best practices. We evaluate the adequacy of preventative actions to reduce security incidents on an ongoing basis.

Our safeguards may not, however, be effective in mitigating the impact of service disruptions or other failures of these information technology networks and systems. Failure to timely respond and mitigate security incidents, could result in wide-ranging business interruptions. Such security incidents could place us at a competitive disadvantage; result in financial impacts, a loss of revenue, assets, including our intellectual property, personal or other sensitive data; result in litigation and regulatory action including significant fines or penalties; impact our operations; cause damage to our reputation and that of our brands; and result in significant remediation and other costs. See Item 1C. Cybersecurity of our Annual Report on Form 10-K for the fiscal year ended December 31, 2023 for a description of our cybersecurity risk management and strategy and governance.

Our or our business partners’ failure or inability to adhere to privacy, data, artificial intelligence and information security laws could result in business disruption, loss of reputation and consumer trust, litigation, regulatory action including significant fines or penalties, financial impact, and loss of revenue, assets or personal, confidential, or sensitive data.

An actual or alleged failure to comply with complex and changing privacy, data, artificial intelligence and information security laws and regulations under the EU General Data Protection Regulation, various U.S. state and federal laws, and other similar privacy and information security laws across the jurisdictions in which PMI operates, such as the failure to protect personal data; implement appropriate technological and reasonable security measures; implement and maintain appropriate safeguards for personal data being transferred internationally; respect the privacy rights of data subjects; provide sufficient detailed notices of personal data processing; retrieve consent and provide opt-outs; meet stringent timeframe requirements for incident reporting to regulatory authorities; comply with artificial intelligence regulations including, but not limited to, the EU Artificial Intelligence Act; and others, could have a material adverse effect on us, subject us to substantial fines and/or legal challenges, and/or harm our business, reputation, financial condition, or operating results. Such laws and regulations across the jurisdictions in which PMI operates may vary, resulting in inconsistent or conflicting legal obligations.

Risks Related to Acquisitions and Divestitures

</details>

# Context passages: implicit mentions, not classified

## Item 1 Legal Proceedings (blocks 790-793)

**Terms: age verification (age-verification)**

In the fifth case, a putative class action, Norris v. Philip Morris International Inc., et al ., filed July 30, 2024, before United States District Court for the District of Connecticut, plaintiff alleges, among other things, addiction to nicotine resulting from the use of ZYN nicotine pouches. The named defendants are PMI and Swedish Match North America LLC. Plaintiff purports to represent classes comprised of (i) all persons who used ZYN products in the United States, (ii) all persons who used ZYN products in the United States while under the age of 18, (iii) all residents of Florida who used ZYN products, and (iv) all residents of Florida who used ZYN products while under the age of 18. Plaintiff alleges, among other things, that defendants made misrepresentations about ZYN products in their advertising and marketing, marketed ZYN products to minors, and misrepresented or failed to disclose to consumers information about ZYN products, including information about health risks associated with these products. Plaintiff asserts unjust enrichment, and breach of consumer protection, unfair trade and advertising statutes claims and is seeking compensatory and punitive damages, disgorgement of profits, attorney’s fees and expenses, interest and other applicable injunctive relief. On September 24, PMI and Swedish Match North America LLC filed motions to dismiss the complaint with prejudice. On October 2, 2024, Plaintiff filed a notice of voluntary dismissal without prejudice as to Swedish Match, which the Court ordered on October 3, 2024 At this time, no estimated loss has been accrued in the consolidated financial statements for this proceeding and we cannot determine the likelihood of loss, or reasonably estimate a range of loss, if any, from this proceeding.

District of Columbia Attorney General Investigation : On June 11, 2024, Swedish Match North America LLC ("SMNA") received a subpoena from the office of the Attorney General of the District of Columbia (“D.C.”). The subpoena requests, among other things, information concerning SMNA’s compliance with D.C.’s licensing regulations, age-verification requirements, and prohibition on the sale of flavored tobacco products, including with respect to ZYN nicotine pouches. SMNA is cooperating with the investigation. It is too early to assess the timeline on which such investigation will conclude or its outcome.

Philip Morris International Inc. and Subsidiaries

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1523-1525)

**Terms: precision marketing (digital consumer engagement)**

We aim to expand our brand portfolio and market positions with additional SFPs. In addition, we continue to use our expertise, technology and capabilities to explore new growth opportunities beyond our current business, including products that do not contain nicotine or tobacco.

Commercialization of SFPs: We are continuing to develop a multiplatform approach and tailoring our commercialization strategy to the characteristics of each specific market. We focus our commercialization efforts on consumer retail experience, guided consumer trials and customer care, and increasingly, digital communication programs and e-commerce. In order to accelerate switching to our Platform 1 products, our initial market introductions typically entail one-on-one consumer engagement (in person or by digital means) and device discounts. These initial commercialization efforts require substantial investment, which we believe will moderate over time and further benefit from the increased use of digital engagement capabilities. PMI has, and continues to, invest in digital consumer engagement.

In 2014, we introduced our Platform 1 product in pilot city launches in Nagoya, Japan, and in Milan, Italy. Since then, we have continuously expanded our commercialization activities.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1576-1578)

**Terms: technology committee (Technology Committee)**

In June 2018, the Korean Food and Drug Administration (“KFDA”) issued a statement on products that heat rather than burn tobacco. The KFDA tested three heat-not-burn products, one of which was our Platform 1 product. The KFDA confirmed that the levels of the nine HPHCs tested in the aerosol of these products were on average approximately 90% lower compared to those measured in the cigarette smoke of the top five cigarette brands in South Korea. However, the KFDA stated that it could not establish that the tested heat-not-burn products are less harmful than cigarettes. In October 2018, our Korean subsidiary filed a request with a local court seeking information underlying KFDA’s analysis, conclusions and public statements. In May 2020, the court ordered KFDA to produce certain records. Subsequent to that decision, and after exchanges between the parties, the case was closed.

In August 2018, the Science & Technology Committee of the U.K. House of Commons published a report of its inquiry into e-cigarettes and heat-not-burn products. The report concluded that e-cigarettes are significantly less harmful to health than smoking tobacco. The report also observed that for those smokers who do not accept e-cigarettes, heat-not-burn products may offer a public health benefit despite their relative risk. The report called for a risk-proportionate regulatory environment for both e-cigarettes and heat-not-burn products and noted that e-cigarettes should remain the least taxed, cigarettes the most taxed, with heat-not-burn products falling between the two. The U.K. Committee on Advertising Practice announced the removal of a prohibition of health claims in the advertising of e-cigarettes in the U.K., effective November 2018.

In November 2018, the Eurasian Economic Commission (regulatory body of the Eurasian Union consisting of Armenia, Belarus, Kazakhstan, Kyrgyzstan and Russia) published the results of its commissioned study on novel nicotine-containing

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1588-1591)

**Terms: age verification (age-verification)**

Legal Challenges to SFPs: We face various administrative and legal challenges related to certain SFP activities, including allegations concerning product classification; advertising, distribution and sales restrictions; corporate communications; product coach activities; scientific substantiation; product liability; and unfair competition. While we design our programs to comply with relevant regulations, we expect these or similar challenges to continue as we expand our efforts to commercialize SFPs and to communicate with the public. The outcomes of these matters may affect our SFP commercialization and public communication activities and performance in one or more markets.

On June 11, 2024, Swedish Match North America LLC ("SMNA") received a subpoena from the office of the Attorney General of the District of Columbia (“D.C.”). The subpoena requests, among other things, information concerning SMNA’s compliance with D.C.’s licensing regulations, age-verification requirements, and prohibition on the sale of flavored tobacco products, including with respect to ZYN nicotine pouches. SMNA is cooperating with the investigation and is conducting a full review of its sales and supply chain arrangements in D.C. and other U.S. localities where flavor bans may apply.

As part of its sales and supply chain review, SMNA has discontinued sales through the e-commerce shop associated with ZYN.com and direct sales to dedicated online retailers in the United States indefinitely. U.S. e-commerce has represented a small fraction of sales of SMNA in the United States, and the current network of approximately 170,000 brick-and-mortar retailers will remain SMNA’s focus.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 1881-1883)

**Terms: youth access prevention (youth access prevention)**

Additionally, any claims, regardless of merit, challenging our research and clinical data available to date, may impact the development of science-based regulatory frameworks for the commercialization of the SFP category and the commercialization of the SFP category in general.

Our SFPs and commercial activities for these products are designed for, and directed toward, current adult smokers and users of nicotine-containing products. We put significant effort to restrict access of our products from non-smokers and youth. Despite our efforts, technological, operational, regulatory and/or commercial developments might impact the implementation or effectiveness of youth access prevention mechanisms and surrounding infrastructure. If there is significant usage, whether actual or perceived, of our products or competitive products among youth or non-smokers, even in situations over which we have no control, our reputation and credibility may suffer, the regulatory approach to our products may become more restrictive, and our efforts to advocate for the development of science-based regulatory frameworks for the development and commercialization of SFPs may be significantly impacted.

Moreover, the FDA’s premarket tobacco product and modified risk tobacco product authorizations of two versions of our Platform 1 product are subject to strict marketing, reporting and other requirements. Although we have received these authorizations from the FDA, there is no guarantee that the product will remain authorized for sale in the U.S., or that new versions of the product (Platform 1 or other smoke-free platforms) will receive necessary authorizations, particularly if there is a significant uptake in youth or non-smoker initiation.
