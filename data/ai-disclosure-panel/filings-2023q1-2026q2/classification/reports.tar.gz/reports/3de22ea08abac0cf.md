# Blackstone Inc. | 10-K | fiscal year 2025

- Report length: 149,445 words
- Direct AI mentions (classified): 20, of which about AI: 12, false candidates: 8, flagged for review: 0
- Context passages (not classified): 2; groups: compute_infrastructure (1), governance_regulation (1)
- Frames: risk_factor (6), market (4), business (2)
- Roles: risk (6), market_driver (4), general (2), adoption (1)
- Risk types: strategic_competitive (4), regulatory_legal (2), cybersecurity (2), third_party (2), operational_reliability (1), reputational_ethical (1), market_demand (1)
- MIT subdomains: other (5), ai_system_security_vulnerabilities_attacks (2), cyberattacks_weapons_mass_harm (1), compromise_of_privacy (1), false_or_misleading_information (1), regulation_lagging_behind_ai (1)
- Adoption stage: deployed (1)
- Business functions: decision_analytics (1)
- Governance responses: none
- Kinds of AI: unspecified (11), generative_llm (1), traditional_ml (1)
- Substantiveness: generic (9), specific (2), detailed (1)
- Disclosure traits: hedging (1)
- Trait activation rate: 0.083 (boilerplate (0.0), hedging (0.083), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 1A (5), Item 7 (4), Item 10 (2), unknown (1)
- Named entities: Breyer Capital, MIT, Stanford Institute for Human-Assisted Artificial Intelligence, University of Oxford

## unknown section (blocks 82-86)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal, strategic_competitive | mit: other | kinds: unspecified | substantiveness: generic**

> Technological developments in artificial intelligence could disrupt the markets in which we and our portfolio companies operate and subject us to increased competition, legal and regulatory risks and compliance costs.

<details><summary>Passage</summary>

Cybersecurity or other operational risks could result in the loss of data, interruptions in our business and damage to our reputation, and subject us to regulatory actions, increased costs and financial losses.

Technological developments in artificial intelligence could disrupt the markets in which we and our portfolio companies operate and subject us to increased competition, legal and regulatory risks and compliance costs.

Extensive regulation of our businesses affects our activities, creates the potential for significant liabilities and penalties, may make it more difficult for us to deploy capital in certain jurisdictions or sell assets to certain buyers, and could result in additional burdens on our business.

</details>

## unknown section (blocks 113-115)

**AI reference: none**

- Note (gemini: AI is part of a company name.)

<details><summary>Passage</summary>

“Series II Preferred Stockholder” refers to Blackstone Group Management L.L.C., the holder of the sole outstanding share of our Series II preferred stock.

“Blackstone Holdings,” “Blackstone Holdings Partnerships” or “Holdings Partnerships” refer to Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P. and Blackstone Holdings IV L.P., collectively.

“Blackstone Funds,” “our funds” and “our investment funds” refer to the funds and other vehicles that are managed by Blackstone. “Our carry funds” refers to funds managed by Blackstone that have commitment-based multi-year drawdown structures that pay carry on the realization of an investment.

</details>

## Item 1A Risk Factors (blocks 356-358)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: strategic_competitive | mit: other | kinds: unspecified | substantiveness: generic**

> Additionally, technological innovation, including the use of artificial intelligence, has the potential to disrupt the financial industry and change the way financial institutions, including asset managers, do business.

> Some of our competitors may be more successful than we are in the development and implementation of new technologies, including services and platforms based on artificial intelligence, to address investor demand or improve operations.

> If we are unable to adequately advance our capabilities in these areas, or do so at a slower pace than others in our industry, we may be at a competitive disadvantage.

<details><summary>Passage</summary>

other industry participants will from time to time seek to recruit our investment professionals and other employees away from us.

Additionally, technological innovation, including the use of artificial intelligence, has the potential to disrupt the financial industry and change the way financial institutions, including asset managers, do business. Some of our competitors may be more successful than we are in the development and implementation of new technologies, including services and platforms based on artificial intelligence, to address investor demand or improve operations. If we are unable to adequately advance our capabilities in these areas, or do so at a slower pace than others in our industry, we may be at a competitive disadvantage.

We may lose investment opportunities if we do not match investment prices, structures and terms offered by competitors. Alternatively, we may experience decreased rates of return and increased risks of loss if we match investment prices, structures and terms offered by competitors. Moreover, if we are forced to compete with other

</details>

## Item 1A Risk Factors (blocks 388-395)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: cybersecurity, third_party | mit: ai_system_security_vulnerabilities_attacks, cyberattacks_weapons_mass_harm | kinds: unspecified | substantiveness: generic**

> In addition, the risk of cyber and data security threats to us is exacerbated with the advancement of artificial intelligence, which malicious third parties are using to create new, sophisticated and more frequent attacks.

> These cybersecurity threats and compromises could occur as a result of threat actors impersonating Blackstone or its employees, including through the use of artificial intelligence technologies.

> Such technologies could make such impersonation more likely to occur or appear more credible.

<details><summary>Passage</summary>

Cybersecurity and data protection risks could result in the loss of data, interruptions in our business, and damage to our reputation, and subject us to regulatory actions, increased costs and financial losses, each of which could have a material adverse effect on our business and results of operations.

Our operations are highly dependent on our technology platforms and we rely heavily on our analytical, financial, accounting, communications and other data processing systems. Our systems face ongoing cybersecurity threats and attacks, which could result in the loss of confidentiality, integrity or availability of such systems and the data held by such systems. Attacks on our systems could involve, and in some instances have in the past involved, attempts intended to obtain unauthorized access to our proprietary information, destroy data or disable, degrade or sabotage our systems, or divert or otherwise steal funds, including through the introduction of computer viruses, “phishing” attempts and other forms of social engineering. Attacks on our systems could also involve ransomware or other forms of cyber extortion. Cyberattacks and other data security threats could originate from a wide variety of external sources, including cyber criminals, nation state hackers, hacktivists and other outside parties. Cyberattacks and other security threats could also originate from the malicious or accidental acts of insiders, such as employees, consultants, independent contractors or other service providers.

There has been an increase in the frequency and sophistication of the cyber and data security threats we face, with attacks ranging from those common to businesses generally to those that are more advanced and persistent. In addition, the risk of cyber and data security threats to us is exacerbated with the advancement of artificial intelligence, which malicious third parties are using to create new, sophisticated and more frequent attacks. As an alternative asset management firm, we face a heightened risk of such an attack because we hold a significant amount of confidential and sensitive information about our investors, our funds’ portfolio companies and potential

investments. Measures we take to ensure the integrity of our systems may not provide adequate protection, especially because cyberattack techniques are continually evolving, may persist undetected over extended periods of time, and may not be mitigated in a timely manner to prevent or minimize the impact of an attack on Blackstone, our investors, our portfolio companies or potential investments. If our systems or those of third-party service providers are compromised either as a result of malicious activity or through inadvertent transmittal or other loss of data, do not operate properly or are disabled, or we fail to provide the appropriate regulatory or other notifications in a timely manner, we could suffer financial loss, increased costs, a disruption of our businesses, liability to our counterparties, investment funds or fund investors, regulatory intervention or reputational damage. The costs related to cyber or other data security threats or disruptions may not be fully insured or indemnified by other means.

We are reliant on third-party service providers for certain aspects of our business, including the administration of certain funds, as well as for certain technology platforms, including cloud-based services. These third-party service providers also face ongoing cybersecurity threats and compromises of their systems. These cybersecurity threats and compromises could occur as a result of threat actors impersonating Blackstone or its employees, including through the use of artificial intelligence technologies. Such technologies could make such impersonation more likely to occur or appear more credible. As a result, unauthorized individuals could gain, and in some past instances have gained, access to certain confidential data through third-party service providers. In addition, we could also suffer losses in connection with updates to, or the failure to timely update, the third-party technology platforms on which we rely.

Cybersecurity, privacy and data protection have become top priorities for regulators in the United States and around the world. Many jurisdictions in which we operate have laws and regulations relating to privacy, data protection and cybersecurity, including the Gramm-Leach-Bliley Act (“GLBA”) (including recent amendments to Regulation S-P), the General Data Protection Regulation (“GDPR”), the U.K. Data Protection Act, and the California Privacy Rights Act (“CPRA”). Some jurisdictions have also enacted or proposed laws requiring companies to notify individuals and/or government agencies of data security breaches involving certain types of personal data or involving certain thresholds of potential harm to impacted individuals. In light of the focus of federal regulators on cybersecurity, SEC enforcement and examination activity has increased in recent years and may increase further. Although we maintain cybersecurity controls designed to prevent cyber incidents from occurring, no security is impenetrable to cyberattacks. It is possible that current and future cyber enforcement activity will target practices that we believe are compliant, but our regulator deem otherwise. See “—Rapidly developing and changing global data security and privacy laws and regulations could increase compliance costs and subject us to enforcement risks and reputational damage.”

</details>

## Item 1A Risk Factors (blocks 407-415)

**AI reference: explicit | frame: risk_factor | roles: adoption, risk | risk: cybersecurity, operational_reliability, regulatory_legal, reputational_ethical, strategic_competitive, third_party | mit: ai_system_security_vulnerabilities_attacks, compromise_of_privacy, false_or_misleading_information, other, regulation_lagging_behind_ai | adoption: deployed | functions: decision_analytics | kinds: generative_llm, traditional_ml | substantiveness: detailed | traits: hedging**

> Technological developments in artificial intelligence, including machine learning technology and generative artificial intelligence (“AI Technology” and, collectively, “AI Technologies”) and their current and potential future applications, including in the private investment and financial sectors as well as across sectors in which our portfolio companies operate, are rapidly changing.

> Through our use of AI Technologies, we avail ourselves of the potential benefits, insights and efficiencies resulting from these technologies. For example, our employees can utilize internal generative AI-powered applications to help summarize, search or translate documents or gather information on a wide variety of topics.

> If the data we, or third parties whose services we rely on, use in connection with the possible development or deployment of AI Technologies is incomplete, inadequate or biased in some way, the performance of our products, services, and businesses could suffer.

<details><summary>Passage</summary>

Any inability, or perceived inability, by us or our funds’ portfolio companies to adequately address data protection or privacy concerns, or comply with applicable laws, regulations, policies, industry standards and guidance, contractual obligations, or other legal obligations, even if unfounded, could result in significant legal, regulatory and third-party liability, increased costs, disruption of our and our funds’ portfolio companies’ business and operations, and a loss of client (including investor) confidence and other reputational damage. Many regulators have indicated an intention to take more aggressive enforcement actions regarding data security and privacy matters, and private litigation resulting from such matters is increasing and resulting in progressively larger judgments and settlements. Specifically, the SEC’s stated 2026 examination priorities include an intended focus on adviser’s policies and practices as it relates to the prevention of interruptions to mission-critical services and protection of investor information, records and assets. Furthermore, as new data protection and privacy-related laws and regulations are implemented, the time and resources needed for us and our funds’ portfolio companies to comply with such laws and regulations continues to increase and become a significant compliance workstream.

Technological developments in artificial intelligence could disrupt the markets in which we and our portfolio companies operate and subject us and our portfolio companies to increased competition, legal and regulatory risks and compliance costs.

Technological developments in artificial intelligence, including machine learning technology and generative artificial intelligence (“AI Technology” and, collectively, “AI Technologies”) and their current and potential future applications, including in the private investment and financial sectors as well as across sectors in which our portfolio companies operate, are rapidly changing. The legal and regulatory frameworks related to such current and potential future applications are also evolving. The full extent of current or future risks related thereto is not possible to predict and we and our portfolio companies may not be able to anticipate, prevent, mitigate or remediate all of the potential risks, challenges or impacts of such changes. AI Technologies could significantly disrupt the business models, investment strategies, operational processes, and markets in which we operate. Similarly, AI Technologies could significantly disrupt our portfolio companies’ businesses and markets. This could subject us and our portfolio companies to increased competition, legal and regulatory risks and compliance costs, and adversely impact our or our portfolio companies’ growth prospects. These impacts could have a material adverse effect on our business, financial condition and results of operations. Advancements in computing and AI Technologies, including efficiency improvements, without related increases in the adoption and development of such technologies, could also negatively impact demand for, and the valuation of, digital infrastructure assets, a sector to which certain of our investment strategies have significant exposure.

Through our use of AI Technologies, we avail ourselves of the potential benefits, insights and efficiencies resulting from these technologies. For example, our employees can utilize internal generative AI-powered applications to help summarize, search or translate documents or gather information on a wide variety of topics. However, these technologies also present a number of potential risks that cannot be fully mitigated. If the data we, or third parties whose services we rely on, use in connection with the possible development or deployment of AI Technologies is incomplete, inadequate or biased in some way, the performance of our products, services, and businesses could suffer. Data in models that AI Technologies utilize are likely to contain a degree of inaccuracy and error, which could result in flawed algorithms. This could reduce the effectiveness of AI Technologies and adversely impact us and our operations to the extent we rely on the work product of such AI Technologies in such operations. The volume and reliance on data and algorithms also make AI Technologies, and in turn us and our portfolio companies and investments, more susceptible to cybersecurity threats, including the compromise of underlying models, training data, or other intellectual property. We, our funds, our portfolio companies and our funds’ investments could be exposed to risks to the extent third-party service providers or any counterparties use AI Technologies in their business activities. There is also a risk that AI Technologies may be misused or misappropriated by our employees and/or third parties engaged by us. For example, a user may input confidential information, including material non-public information or personal identifiable information, into AI Technology applications, resulting in such information becoming part of a dataset that is accessible by third-party AI Technology applications and users, including our competitors. Such actions could subject us to legal and regulatory

investigations and/or actions. In addition, we may not be able to control how third-party AI Technologies that we choose to use are developed or maintained, or how data we input is used or disclosed, even where we have sought contractual protections with respect to these matters. We may be subject to legal and regulatory investigations and/or actions related to our use of AI Technologies, including as related to alleged misuse or misappropriation of our data. This could also have an adverse impact on our reputation. We may also communicate externally regarding AI Technology-related initiatives, including our development and use of AI Technologies, which subjects us to the risk of being accused of making inaccurate or misleading statements regarding our ability to avail ourselves of the potential benefits of AI Technology.

Regulations related to AI Technologies may also impose on us certain obligations and costs related to monitoring and compliance. Regulators are increasing scrutiny of, and enacting or considering enacting regulations regarding, the use of AI Technologies, including the use of “big data,” diligence of data sets and oversight of data vendors. The use of AI Technologies by us and our vendors may require compliance with legal and regulatory frameworks that are not fully developed or tested, and we may face litigation and regulatory actions related to our use of, or our engagement of vendors that use, AI Technologies. In April 2023, the Federal Trade Commission, U.S. Department of Justice, Consumer Financial Protection Bureau, and U.S. Equal Employment Opportunity Commission released a joint statement on artificial intelligence demonstrating interest in monitoring the development and use of automated systems and enforcement of their respective laws and regulations. In October 2023, an executive order established new standards for AI safety and security. In addition to the U.S. regulatory framework, the EU adopted the Artificial Intelligence Act in 2024, which applies to certain AI Technologies and the data used to train, test and deploy them, which may create additional compliance burdens, higher administrative costs and significant penalties should we fail to comply or be perceived to fail to comply.

Extensive regulation of our businesses affects our activities and creates the potential for significant liabilities and penalties. The possibility of increased regulatory focus could result in additional burdens on our business.

</details>

## Item 1A Risk Factors (blocks 562-564)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: strategic_competitive | mit: other | kinds: unspecified | substantiveness: generic**

> The due diligence investigation that we will carry out with respect to any investment opportunity may not reveal or highlight all relevant facts (including fraud) or risks that may be necessary or helpful in evaluating such investment opportunity.

> In addition, we may not identify or foresee future developments that could have a material adverse effect on an investment, including, for example, rapidly changing fundamentals in a certain sector, geography or asset class, or technological disruption of a specific company or asset, or an entire industry, including as a result of the rapid development and implementation of AI Technologies.

<details><summary>Passage</summary>

The due diligence process that we undertake in connection with investments by our funds may not reveal all facts and issues that may be relevant in connection with an investment.

When evaluating a potential business or asset for investment, we conduct due diligence that we deem reasonable and appropriate based on the facts and circumstances applicable to such investment. When conducting due diligence, we may be required to evaluate important and complex issues, including but not limited to those related to business, financial, credit risk, tax, accounting, sustainability, legal and regulatory and macroeconomic trends. Selecting and evaluating such factors is subjective by nature, and there is no guarantee that the criteria utilized or judgment exercised by Blackstone or a third-party specialist (if any) will reflect the policies or preferred practices of any particular investor or align with the practices of other asset managers or with market trends. The materiality of various risks and impact of such risks on an individual potential investment or portfolio as a whole depend on many factors, including the relevant industry, geography and asset class and the nature of the investment. The due diligence investigation that we will carry out with respect to any investment opportunity may not reveal or highlight all relevant facts (including fraud) or risks that may be necessary or helpful in evaluating such investment opportunity. In addition, we may not identify or foresee future developments that could have a material adverse effect on an investment, including, for example, rapidly changing fundamentals in a certain sector, geography or asset class, or technological disruption of a specific company or asset, or an entire industry, including as a result of the rapid development and implementation of AI Technologies.

We may be unable to consummate or successfully integrate development opportunities, acquisitions or joint ventures that we pursue.

</details>

## Item 1A Risk Factors (blocks 635-637)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: market_demand | mit: other | kinds: unspecified | substantiveness: generic**

> In addition, advancements in computing and AI Technologies, including efficiency improvements (without related increases in the adoption and development of such technologies), as well as technological changes that render existing data center designs less competitive or require significant redevelopment, could negatively impact demand for, and the valuation of, our digital infrastructure assets.

<details><summary>Passage</summary>

foreign government or regulatory agencies. The nature of these obligations exposes us to a higher level of regulatory control than typically imposed on other businesses and may require us to rely on complex government licenses, concessions, leases or contracts, which may be difficult to obtain or maintain. Such licenses, concessions, leases or contracts may also be terminated for convenience without adequate compensation. Further, many of our funds’ infrastructure investments are in critical infrastructure sectors, such as transportation systems, energy and digital infrastructure, which are generally subject to heightened regulatory scrutiny at the time of investment and ongoing compliance requirements. Such requirements are likely to expand our compliance burdens, costs and enforcement risks.

Our real estate and infrastructure funds have in recent years substantially increased their exposure to digital infrastructure investments, which, in addition to being subject to many of the risks outlined above, are subject to additional risks. The increase in exposure to digital infrastructure has supported strong performance for our real estate and infrastructure funds. Such performance would be difficult to replicate if demand for digital infrastructure were substantially reduced, including as a result of economic slowdown, regulatory impediments or changes in the needs or strategies of a relatively small number of key customers on behalf of which our funds have undertaken development. Digital infrastructure demand is highly concentrated in a small number of large counterparties. Such concentration makes the value of digital infrastructure assets particularly susceptible to the risk of financial distress, consolidation or change in capital and expenditure trends of a single or small number of tenants. Digital infrastructure requires significant upfront and ongoing capital expenditure for land, power, construction and equipment, as well as access to reliable power sources, which may be constrained in key markets. An increase in the price of such inputs can increase build and operating costs and reduce the profitability of such investments. The inability to access sufficient power could constrain our ability to develop land acquired for digital infrastructure or to deliver the levels of power required by tenants, each of which could negatively impact the value of our funds’ investments. Given the long-term nature of many of the tenant leases at our funds’ digital infrastructure assets, a prolonged period of high interest rates could also negatively impact the valuation of such assets to the extent the contractual rent escalators in such leases are insufficient to offset increased costs. In addition, advancements in computing and AI Technologies, including efficiency improvements (without related increases in the adoption and development of such technologies), as well as technological changes that render existing data center designs less competitive or require significant redevelopment, could negatively impact demand for, and the valuation of, our digital infrastructure assets. The digital infrastructure sector is also highly competitive, with pressure from various data center operators and hyperscalers building their own facilities. In addition, digital infrastructure assets have recently faced and continue to face increasing opposition from local communities and organizations. These factors may make it more difficult to deploy additional capital and continue to grow our investments in the sector.

Our funds’ investments in the life sciences industry may expose us to increased risks.

</details>

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 813-815)

**AI reference: explicit | frame: market | roles: market_driver | kinds: unspecified | substantiveness: generic**

> At the beginning of 2026, however, concerns regarding impact of artificial intelligence-driven disruption weighed on equity capital markets.

<details><summary>Passage</summary>

Blackstone’s businesses are materially aﬀected by conditions in the financial markets and economic conditions in the U.S., Europe, Asia and, to a lesser extent, elsewhere in the world.

Most major equity markets appreciated in the fourth quarter of 2025, driven by positive economic data and accommodative central bank actions. The total return of the S&P 500 Index was 2.7% in the fourth quarter, led by the healthcare and telecommunications sectors, which gained 11.7% and 7.3%, respectively. The real estate and utilities sectors underperformed, declining 2.9% and 1.4%, respectively. Equity market volatility decreased, with the CBOE Volatility Index (VIX) declining 8.2% at the end of the fourth quarter compared to the third quarter. In credit markets, the S&P Leveraged Loan Index generated a total return of 1.2% and the ICE Bank of America High Yield Bond Index returned 1.3%. At the beginning of 2026, however, concerns regarding impact of artificial intelligence-driven disruption weighed on equity capital markets. By mid-February 2026, the Dow Jones and S&P 500 Index had experienced declines for four out of five weeks, while the Nasdaq recorded its fifth straight negative week.

Capital markets activity levels in the U.S. expanded considerably in 2025, with U.S. initial public oﬀering volumes and announced merger and acquisition volumes up approximately 73% and 60%, respectively, compared to 2024. In particular, the fourth quarter saw a two-and-a-half year-over-year increase in merger and acquisition and initial public oﬀerings activity. High-yield spreads tightened by 21 basis points in 2025, while issuance increased 16.8% year-over-year.

</details>

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 819-821)

**AI reference: explicit | frame: market | roles: market_driver | kinds: unspecified | substantiveness: generic**

> Uncertainty regarding the trajectory of inflation and interest rates in the U.S., continued geopolitical turbulence and concerns regarding the potential impact of artificial intelligence-related disruptions across a number of industries, however, have more recently adversely impacted investor sentiment and the market environment.

<details><summary>Passage</summary>

Outside of the U.S., most major central banks reduced interest rates in 2025 as inflation around the world continued to show signs of moderation. Inflation in the U.K. increased slightly to 3.4% in December 2025 compared to 3.0% in January 2025, but remained well below prior year peaks, and The Bank of England lowered its rate by 100 points over four reductions in 2025, ending the year at 3.75%. The European Central Bank lowered its deposit facility by 100 basis points during the year, with inflation in the Eurozone falling to 1.9% in December 2025 compared to 2.5% in January 2025. In China, the People’s Bank also lowered the required reserve ratio by 50 basis points in 2025 to 9%, continuing a rate-cutting cycle that began in 2021. By contrast, the Bank of Japan further increased its policy rate twice in 2025 to 0.75% by year end, the highest level since 1995.

An overall resilient economic backdrop, alongside moderating interest rates in several major economies, supported a gradual improvement in capital markets and transaction activity in the latter part of 2025. Uncertainty regarding the trajectory of inflation and interest rates in the U.S., continued geopolitical turbulence and concerns regarding the potential impact of artificial intelligence-related disruptions across a number of industries, however, have more recently adversely impacted investor sentiment and the market environment.

For additional information on the potential impact on each of our business segments of the conditions described above see “—Segment Analysis.”

</details>

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 1411-1413)

**AI reference: explicit | frame: market | roles: market_driver | kinds: unspecified | substantiveness: generic**

> Despite an overall strong capital markets environment, the potential for artificial intelligence-driven disruption has recently weighed on equity capital markets and equity values of companies in certain sectors, such as software.

<details><summary>Passage</summary>

Segment Distributable Earnings were $2.9 billion for the year ended December 31, 2025, an increase of $268.0 million, compared to $2.6 billion for the year ended December 31, 2024. The increase in Segment Distributable Earnings was attributable to an increase of $47.7 million in Fee Related Earnings, and an increase of $220.4 million in Net Realizations.

Our Private Equity segment generated strong performance across all strategies in 2025, with particular strength in Infrastructure. In Corporate Private Equity, our operating companies exhibited solid revenue growth and resilient margins. A more favorable capital markets environment supported an acceleration in transaction activity, particularly initial public offerings, in our Private Equity segment funds in the second half of 2025. A continuation of a favorable capital markets environment should contribute to a further increase in transaction activity, including realizations, in our Private Equity segment. Despite an overall strong capital markets environment, the potential for artificial intelligence-driven disruption has recently weighed on equity capital markets and equity values of companies in certain sectors, such as software. We believe the ultimate impact of such disruption will vary significantly across companies based on multiple factors, with a number of companies well-positioned to be protected or benefit from such disruption. We believe such factors, which include large company size, depth of resources and high customer switching costs, are generally evident across our portfolio.

Fee Related Earnings

</details>

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 1493-1497)

**AI reference: explicit | frame: market | roles: market_driver | kinds: unspecified | substantiveness: generic**

> Nevertheless, despite an overall strong capital markets environment, the potential for artificial intelligence-driven disruption has recently weighed on the equity capital markets and on equity values of companies in certain sectors, such as software.

<details><summary>Passage</summary>

Segment Distributable Earnings were $2.0 billion for the year ended December 31, 2025, an increase of $533.4 million, compared to $1.4 billion for the year ended December 31, 2024. The increase in Segment Distributable Earnings was attributable to increases of $195.4 million in Fee Related Earnings and $338.0 million in Net Realizations.

Our Credit & Insurance segment demonstrated strong performance in 2025. While lower interest rates will likely reduce returns in our floating rate strategies, we believe we will continue to generate excess returns relative to liquid markets in our private credit strategies. We also continue to see long-term structural shifts toward private credit in the credit market. This has contributed to robust momentum in our non-investment grade and investment grade private credit strategies. Opportunities for corporate and bank partnerships should also support momentum in investment grade private credit strategies. While we would expect defaults to rise from a historically low level as the credit cycle progresses, our Credit & Insurance segment funds’ holdings are predominantly in senior secured credit with significant equity subordination from institutional borrowers. We believe this should position our Credit & Insurance segment well. A favorable capital markets environment has supported, and should continue to support, overall transaction activity in our Credit & Insurance segment. Nevertheless, despite an overall strong capital markets environment, the potential for artificial intelligence-driven disruption has recently weighed on the equity capital markets and on equity values of companies in certain sectors, such as software. We believe the ultimate impact of such disruption will vary significantly across companies based on multiple factors, and that companies that are larger, have depth of resources and whose customers face high switching costs, are well-positioned to be protected or benefit from such disruption. Notwithstanding the potential for artificial-intelligence disruption, we believe our overall portfolio is relatively well-protected given the extent of our equity cushion and the prevalence of such factors at companies in our portfolio.

In our perpetual capital strategies, BCRED maintained healthy demand with over $14 billion raised in 2025. While heightened market attention around private credit has and could continue to adversely aﬀect net flows, we believe that strong investment performance should drive flows over the long-term.

</details>

## Item 8 Financial Statements and Supplementary Data (blocks 2343-2345)

**AI reference: none**

- Note (gemini: AI is part of a company name.)

<details><summary>Passage</summary>

Blackstone Inc. was initially formed as The Blackstone Group L.P., a Delaware limited partnership, on March 12 , 2007 . Prior to its conversion on July 1 , 2019 to a Delaware corporation, Blackstone Inc. was managed and operated by Blackstone Group Management L.L.C., which is wholly owned by Blackstone’s senior managing directors and controlled by one of Blackstone’s founders, Stephen A. Schwarzman (the “Founder”).

The activities of Blackstone are conducted through its holding partnerships: Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P. and Blackstone Holdings IV L.P. (collectively, “Blackstone Holdings,” “Blackstone Holdings Partnerships” or the “Holding Partnerships”). Blackstone, through its wholly owned subsidiaries, is the sole general partner of each of the Holding Partnerships. Generally, holders of the limited partner interests in the Holding Partnerships may, four times each year, exchange their limited partnership interests (“Partnership Units”) for Blackstone common stock, on a one-to-one basis, exchanging one Partnership Unit from each of the Holding Partnerships for one share of Blackstone common stock.

Summary of Significant Accounting Policies

</details>

## Item 8 Financial Statements and Supplementary Data (blocks 3050-3052)

**AI reference: none**

- Note (gemini: AI is part of a company name.)

<details><summary>Passage</summary>

Borrowings

On October 16, 2025, Blackstone Holdings Finance Co. L.L.C., as borrower, and Blackstone Holdings AI L.P., Blackstone Holdings I L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P. and Blackstone Holdings IV L.P., as guarantors, entered into an amended and restated $ 4.325 billion revolving credit facility (the “Revolving Credit Facility”) with Citibank, N.A., as administrative agent, and the lenders party thereto. The Revolving Credit Facility amends and restates Blackstone’s existing revolving credit facility to, among other things, extend the maturity date from December 15, 2028 to October 16, 2030 and increase the aggregate required minimum amount of fee generating assets under management.

On November 3, 2025, Blackstone, through its subsidiary Blackstone Reg Finance Co. L.L.C., issued $ 600 million aggregate principal amount of senior notes due November 3, 2030 (the “Registered 2030 Notes”), and $ 600 million aggregate principal amount of senior notes due February 15, 2036 (the “Registered 2036 Notes” and, together with the Registered 2030 Notes, the “Registered Notes”), pursuant to a Registration Statement on Form S-3. The Registered 2030 Notes have an interest rate of 4.300 % per annum, and the Registered 2036 Notes have an interest rate of 4.950 %. The Registered Notes accrue interest from November 3, 2025. Interest on the Registered 2030 Notes is payable semi-annually in arrears on May 3 and November 3 of each year commencing on May 3, 2026. Interest on the Registered 2036 Notes is payable semi-annually in arrears on February 15 and August 15 of each year commencing on February 15, 2026.

</details>

## Item 8 Financial Statements and Supplementary Data (blocks 3057-3059)

**AI reference: none**

- Note (gemini: AI is part of a company name.)

<details><summary>Passage</summary>

(All Dollars are in Thousands, Except Share and Per Share Data, Except Where Noted)

All of Blackstone’s outstanding senior notes as of December 31, 2025 are unsecured and unsubordinated obligations of Blackstone Holdings Finance Co. L.L.C. or Blackstone Reg Finance Co. L.L.C. (together, the “Issuers”), as applicable, both indirect subsidiaries of Blackstone, that are fully and unconditionally guaranteed by Blackstone Inc. and its indirect subsidiaries, Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P. and Blackstone Holdings IV L.P. (the “Guarantors”). The guarantees are unsecured and unsubordinated obligations of the Guarantors. Transaction costs related to senior note issuances have been capitalized and are amortized over the life of each respective note issuance.

Blackstone borrows and enters into credit agreements for its general operating and investment purposes and certain Blackstone Funds borrow to meet financing needs of their operating and investing activities. Borrowing facilities have been established for the benefit of selected Blackstone Funds. When a Blackstone Fund borrows from the facility in which it participates, the proceeds from the borrowing are strictly limited for its intended use by the borrowing fund and not available for other Blackstone purposes. Blackstone’s credit facilities consist of the following:

</details>

## Item 10 Directors, Executive Officers and Corporate Governance (blocks 3891-3895)

**AI reference: explicit | frame: business | roles: general | kinds: unspecified | substantiveness: specific**

> In October 2018, he announced a foundational $350 million gift to establish the MIT Schwarzman College of Computing, an interdisciplinary hub which will reorient MIT to address the opportunities and challenges presented by the rise of artificial intelligence, including critical ethical and policy considerations to ensure that the technologies are employed for the common good.

<details><summary>Passage</summary>

Ruth Porat | 68 | Director

Stephen A. Schwarzman is the Chairman, Chief Executive Officer and Co-Founder of Blackstone and the Chairman of our board of directors. Mr. Schwarzman was elected Chairman of the board of directors effective March 20, 2007. He also sits on the firm’s Management Committee. Mr. Schwarzman has been involved in all phases of the firm’s development since its founding in 1985. Mr. Schwarzman is an active philanthropist with a history of supporting education, as well as culture and the arts, among other things. In 2020, he signed The Giving Pledge, committing to give the majority of his wealth to philanthropic causes. In both business and philanthropy, Mr. Schwarzman has dedicated himself to tackling big problems with transformative solutions. In June 2019, he donated £150 million to the University of Oxford to help redefine the study of the humanities for the 21st century. His gift – the largest single donation to Oxford since the renaissance – will create a new Centre for the Humanities which unites all humanities faculties under one roof for the first time in Oxford’s history and will offer new performing arts and exhibition venues as well as a new Institute for Ethics in AI. In October 2018, he announced a foundational $350 million gift to establish the MIT Schwarzman College of Computing, an interdisciplinary hub which will reorient MIT to address the opportunities and challenges presented by the rise of artificial intelligence, including critical ethical and policy considerations to ensure that the technologies are employed for the common good. In 2015, Mr. Schwarzman donated $150 million to Yale University to establish the Schwarzman Center, a first-of-its-kind campus center in Yale’s historic “Commons” building, and also gave a founding gift of $40 million to the Inner-City Scholarship Fund, which provides tuition assistance to underprivileged children attending Catholic schools in the Archdiocese of New York. In 2013, he founded an international scholarship program, “Schwarzman Scholars,” at Tsinghua University in Beijing to educate future leaders about China. At over $575 million, the program is modeled on the Rhodes Scholarship and is the single largest philanthropic effort in China’s history coming largely from international donors. Mr. Schwarzman is Co-Chair of the board of trustees of Schwarzman Scholars. In 2007, Mr. Schwarzman donated $100 million to the New York Public Library on whose board he serves. In 2019, Mr. Schwarzman published his first book, What It Takes: Lessons in the Pursuit of Excellence , a New York Times Best Seller which draws from his experiences in business, philanthropy and public service. Mr. Schwarzman is a member of The Council on Foreign Relations, The Business Council, The Business Roundtable, and The International Business Council of the World Economic Forum. He is a former Co-Chair of the Partnership for New York City and serves on the boards of The Asia Society and New York Presbyterian Hospital, as well as on The Advisory Board of the School of Economics and Management at Tsinghua University, Beijing. He is a Trustee of The Frick Collection in New York City and Chairman Emeritus of the board of directors of The John F. Kennedy Center for the Performing Arts. In 2007, Mr. Schwarzman was included in TIME’s “100 Most Influential People.” In 2016, he topped Forbes Magazine’s list of the most influential people in finance and in 2018 was ranked in the Top 50 on Forbes’ list of the “World’s Most Powerful People.” In 2019, he was named one of Barron’s “World’s Best CEOS.” The Republic of France has awarded Mr. Schwarzman both the Légion d’Honneur and the Ordre des Arts et des Lettres at the Commandeur level. Mr. Schwarzman is one of the only Americans to receive both awards recognizing significant contributions to France. He was also awarded the Order of the Aztec Eagle, Mexico’s highest honor for foreigners, for his work on behalf of the U.S. in support of the U.S.-Mexico-Canada Agreement in 2018. Also, at the University of Oxford, Mr. Schwarzman was elected a Wykeham Fellow at New College in 2021 and a Waynflete Fellow at Magdalen College in 2023. In 2024, Mr. Schwarzman was appointed as an Honorary Knight of the Most Excellent Order of the British Empire (KBE) in recognition of his services to philanthropy. He is a recipient of the Arthur Ross Award for Patronage from the Institute of Classical Architecture and Art. Mr. Schwarzman holds a BA from Yale University and an MBA from Harvard Business School. He has served as an adjunct professor at the Yale School of Management and on the Harvard Business School Board of Dean’s Advisors.

Jonathan D. Gray is President and Chief Operating Officer of Blackstone and has been a member of our board of directors since February 2012. He sits on the firm’s Management Committee and nearly all of its investment committees. Mr. Gray was appointed to his current role in 2018. Mr. Gray previously served as Global Head of Real Estate, helping build that business into the largest commercial real estate platform in the world. He joined Blackstone in 1992 in the mergers and acquisitions and private equity areas. Mr. Gray has served as chairman of the board of directors of Hilton Worldwide Holdings Inc. since 2007 and is also on the board of directors of XRG. He previously served on the board of directors of Corebridge Financial. Mr. Gray and his wife, Mindy, established the Basser Center for BRCA at the University of Pennsylvania School of Medicine in 2012 focused on the prevention and treatment of BRCA-related cancers. They have also established numerous programs for low-income children in New York, including creating NYC Kids RISE, a college savings initiative provided to every NYC public school kindergartner. The Grays have been named to The Chronicle of Philanthropy’s list of the largest donors in the U.S. Mr. Gray received a BS in Economics from the Wharton School, as well as a BA in English from the College of Arts and Sciences at the University of Pennsylvania.

</details>

## Item 10 Directors, Executive Officers and Corporate Governance (blocks 3901-3903)

**AI reference: explicit | frame: business | roles: general | kinds: unspecified | substantiveness: specific**

> Over the past several years, Mr. Breyer has developed a deep personal and investment interest in long-term oriented entrepreneurs and teams working in artificial/augmented intelligence and human-assisted intelligence and has made numerous investments in this space.

<details><summary>Passage</summary>

Joseph P. Baratta is Global Head of Private Equity Strategies at Blackstone and a member of the board of directors. Mr. Baratta joined the board of directors in March 2020 and has served as Blackstone’s Global Head of Private Equity Strategies since July 2012. He also sits on the firm’s Management Committee. Mr. Baratta joined Blackstone in 1998, and in 2001 he moved to London to help establish Blackstone’s corporate private equity business in Europe. Before joining Blackstone, Mr. Baratta was with Tinicum Incorporated and McCown De Leeuw & Company. Mr. Baratta also worked at Morgan Stanley in its mergers and acquisitions department. Mr. Baratta has served on the boards of a number of Blackstone portfolio companies and currently serves as a member or observer on the boards of directors of SESAC, Ancestry, Candle Media and Merlin Entertainments Group. He also previously served on the boards of directors of First Eagle Investment Management and Refinitiv. He is a Trustee of the Tate Foundation and serves on the board of Year Up, an organization focused on youth employment. Mr. Baratta graduated magna cum laude from Georgetown University.

James W. Breyer is a member of our board of directors. Mr. Breyer joined the board of directors in July 2016. Since 2006, Mr. Breyer has been the Founder and Chief Executive Officer of Breyer Capital, a premier venture capital firm based in Austin, Texas and Menlo Park, California. Mr. Breyer has been an early investor in over 40 technology companies that have completed successful public offerings or mergers. He served as Partner at Accel Partners from 1990 to 2016 and Managing Partner from 1995 to 2011. Over the past several years, Mr. Breyer has developed a deep personal and investment interest in long-term oriented entrepreneurs and teams working in artificial/augmented intelligence and human-assisted intelligence and has made numerous investments in this space. Mr. Breyer previously served on the board of directors of Twenty-First Century Fox, Inc. from 2011 to 2019, Facebook, Inc. from 2005 to 2013, Etsy, Inc. from 2008 to 2016, Dell, Inc. from 2009 to 2013 and Wal-Mart Stores, Inc. from 2001 to 2013, as well as a number of other technology companies. Mr. Breyer is a member of Harvard Business School’s Board of Dean’s Advisors, a member of Harvard University’s Global Advisory Council, a founding member of the Dean’s Advisory Board of Stanford University’s School of Engineering, Chairman of the Stanford Engineering Venture Fund and founding member of the Stanford Institute for Human-Assisted Artificial Intelligence Advisory Board. In addition, Mr. Breyer is a long-time active volunteer as a Trustee of the San Francisco Museum of Modern Art, the Metropolitan Museum of Art, the American Film Institute and Stanford’s Center for Philanthropy and Civil Society.

Reginald J. Brown is a member of the board of directors of Blackstone. Mr. Brown joined the board of directors in September 2020. Since December 2020, Mr. Brown has been a partner in the Washington, D.C. office of Kirkland & Ellis LLP. Prior to joining Kirkland, Mr. Brown was a partner at WilmerHale from 2005 to 2020, where he served as Chairman of the firm’s Financial Institutions Group and led the firm’s congressional investigations practice as Vice Chair of the Crisis Management and Strategic Response Group. From 2003 to 2005, Mr. Brown served as Associate White House Counsel and Special Assistant to the President, and prior to serving in government, he worked as Assistant to the CEO and Vice President for Corporate Strategy at Nationwide Mutual Insurance Company. Mr. Brown holds a BA from Yale University and a JD from Harvard Law School.

</details>

## Item 15 Exhibits and Financial Statement Schedules (blocks 4315-4362)

**AI reference: none**

- Note (gemini: AI is part of a company name.)

<details><summary>Passage</summary>

4.12 | Form of 2.000% Senior Note due 2025 (included in Exhibit 4.11 hereto).

4.13 | Guarantor Joinder Agreement dated as of October 1, 2015 among Blackstone Holdings Finance Co. L.L.C., Blackstone Holdings I L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P., Blackstone Holdings AI L.P. and Citibank, N.A., as administrative agent (incorporated herein by reference to Exhibit 4.16 to the Registrant’s Annual Report on Form 10-K for the year ended December 31, 2015 filed with the SEC on February 26, 2016).

4.14 | Eighth Supplemental Indenture dated as of October 1, 2015 among Blackstone Holdings Finance Co. L.L.C., The Blackstone Group L.P., Blackstone Holdings I L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P., Blackstone Holdings AI L.P. and The Bank of New York Mellon, as Trustee (incorporated herein by reference to Exhibit 4.17 to the Registrant’s Annual Report on Form 10-K for the year ended December 31, 2015 filed with the SEC on February 26, 2016).

4.15 | Ninth Supplemental Indenture dated as of October 5, 2016 among Blackstone Holdings Finance Co. L.L.C., The Blackstone Group L.P., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P., The Bank of New York Mellon, as trustee, and The Bank of New York Mellon, London Branch, as paying agent (incorporated herein by reference to Exhibit 4.2 to the Registrant’s Current Report on Form 8-K filed with the SEC on October 5, 2016).

4.16 | Form of 1.000% Senior Note due 2026 (included in Exhibit 4.15 hereto).

4.17 | Tenth Supplemental Indenture dated as of October 2, 2017 among Blackstone Holdings Finance Co. L.L.C., The Blackstone Group L.P., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.2 to the Registrant’s Current Report on Form 8-K filed with the SEC on October 2, 2017).

4.18 | Form of 3.150% Senior Note due 2027 (included in Exhibit 4.17 hereto).

4.19 | Eleventh Supplemental Indenture dated as of October 2, 2017 among Blackstone Holdings Finance Co. L.L.C., The Blackstone Group L.P., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.4 to the Registrant’s Current Report on Form 8-K filed with the SEC October 2, 2017).

4.20 | Form of 4.000% Senior Note due 2047 (included in Exhibit 4.19 hereto).

4.21 | Twelfth Supplemental Indenture dated as of April 10, 2019 among Blackstone Holdings Finance Co. L.L.C., The Blackstone Group L.P., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P., The Bank of New York Mellon, as trustee, and The Bank of New York Mellon, London Branch, as paying agent (incorporated herein by reference to Exhibit 4.2 to the Registrant’s Current Report on Form 8-K filed with the SEC on April 11, 2019).

4.22 | Form of 1.500% Senior Notes due 2029 (included in Exhibit 4.21 hereto).

4.23 | Thirteenth Supplemental Indenture dated as of September 10, 2019 among Blackstone Holdings Finance Co. L.L.C., The Blackstone Group Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.2 to the Registrant’s Current Report on Form 8-K filed with the SEC on September 10, 2019).

4.24 | Form of 2.500% Senior Note due 2030 (included in Exhibit 4.23 hereto).

4.25 | Fourteenth Supplemental Indenture dated as of September 10, 2019 among Blackstone Holdings Finance Co. L.L.C., The Blackstone Group Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.4 to the Registrant’s Current Report on Form 8-K filed with the SEC on September 10, 2019).

4.26 | Form of 3.500% Senior Note due 2049 (included in Exhibit 4.25 hereto).

4.27 | Fifteenth Supplemental Indenture dated as of September 29, 2020 among Blackstone Holdings Finance Co. L.L.C., The Blackstone Group Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.2 to the Registrant’s Current Report on Form 8-K filed with the SEC on September 29, 2020).

4.28 | Form of 1.600% Senior Note due 2031 (included in Exhibit 4.27 hereto).

4.29 | Sixteenth Supplemental Indenture dated as of September 29, 2020 among Blackstone Holdings Finance Co. L.L.C., The Blackstone Group Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.4 to the Registrant’s Current Report on Form 8-K filed with the SEC on September 29, 2020).

4.30 | Form of 2.800% Senior Note due 2050 (included in Exhibit 4.29 hereto).

4.31 | Seventeenth Supplemental Indenture dated as of August 5, 2021 among Blackstone Holdings Finance Co. L.L.C., The Blackstone Group Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.2 to the Registrant’s Current Report on Form 8-K filed with the SEC on August 5, 2021).

4.32 | Form of 1.625% Senior Note due 2028 (included in Exhibit 4.31 hereto).

4.33 | Eighteenth Supplemental Indenture dated as of August 5, 2021 among Blackstone Holdings Finance Co. L.L.C., The Blackstone Group Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.4 to the Registrant’s Current Report on Form 8-K filed with the SEC on August 5, 2021).

4.34 | Form of 2.000% Senior Note due 2032 (included in Exhibit 4.33 hereto).

4.35 | Nineteenth Supplemental Indenture dated as of August 5, 2021 among Blackstone Holdings Finance Co. L.L.C., The Blackstone Group Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.6 to the Registrant’s Current Report on Form 8-K filed with the SEC on August 5, 2021).

4.36 | Form of 2.850% Senior Note due 2051 (included in Exhibit 4.35 hereto).

4.37 | Twentieth Supplemental Indenture dated as of January 10, 2022 among Blackstone Holdings Finance Co. L.L.C., Blackstone Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.2 to the Registrant’s Current Report on Form 8-K filed with the SEC on January 10, 2022).

4.38 | Form of 2.550% Senior Note due 2032 (included in Exhibit 4.37 hereto).

4.39 | Twenty-First Supplemental Indenture dated as of January 10, 2022 among Blackstone Holdings Finance Co. L.L.C., Blackstone Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.4 to the Registrant’s Current report on Form 8-K filed with the SEC on January 10, 2022).

4.40 | Form of 3.200% Senior Note due 2052 (included in Exhibit 4.39 hereto).

4.41 | Twenty-Second Supplemental Indenture dated as of June 1, 2022 among Blackstone Holdings Finance Co. L.L.C., Blackstone Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.2 to the Registrant’s Current Report on Form 8-K filed with the SEC on June 1, 2022).

4.42 | Form of 3.500% Senior Note due 2034 (included in Exhibit 4.41 hereto).

4.43 | Twenty-Third Supplemental Indenture dated as of November 3, 2022 among Blackstone Holdings Finance Co. L.L.C., Blackstone Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.2 to the Registrant’s Current Report on Form 8-K filed with the SEC on November 3, 2022).

4.44 | Form of 5.900% Senior Note due 2027 (included in Exhibit 4.43 hereto).

4.45 | Twenty-Fourth Supplemental Indenture dated as of November 3, 2022 among Blackstone Holdings Finance Co. L.L.C., Blackstone Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and The Bank of New York Mellon, as trustee (incorporated herein by reference to Exhibit 4.4 to the Registrant’s Current Report on Form 8-K filed with the SEC on November 3, 2022).

4.46 | Form of 6.200% Senior Note due 2033 (included in Exhibit 4.45 hereto).

4.47 | Indenture dated as of December 6, 2024 among Blackstone Reg Finance Co. L.L.C., Blackstone Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P. and Blackstone Holdings IV L.P. and The Bank of New York Mellon Trust Company, N.A., as trustee (incorporated herein by reference to Exhibit 4.1 to the Registrant’s Current Report on Form 8-K filed with the SEC on December 6, 2024).

4.48 | First Supplemental Indenture dated as of December 6, 2024 among Blackstone Reg Finance Co. L.L.C., Blackstone Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P. and Blackstone Holdings IV L.P. and The Bank of New York Mellon Trust Company, N.A., as trustee (incorporated herein by reference to Exhibit 4.2 to the Registrant’s Current Report on Form 8-K filed with the SEC on December 6, 2024).

4.49 | Form of 5.000% Senior Note due 2034 (included in Exhibit 4.48 hereto).

4.50 | Second Supplemental Indenture dated as of November 3, 2025 among Blackstone Reg Finance Co. L.L.C., Blackstone Inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P. and Blackstone Holdings IV L.P. and The Bank of New York Mellon Trust Company, N.A., as trustee (incorporated herein by reference to Exhibit 4.2 to the Registrant’s Current Report on Form 8-K filed with the SEC on November 3, 2025).

4.51 | Form of 4.300% Senior Note due 2030 (included in Exhibit 4.50 hereto).

4.52 | Third Supplemental Indenture dated as of November 3, 2025 among Blackstone Reg Finance Co L.L.C., Blackstone inc., Blackstone Holdings I L.P., Blackstone Holdings AI L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P. and Blackstone Holdings IV L.P. and the Bank of New York Mellon Trust Company, N.A., as trustee (incorporated herein by reference to Exhibit 4.3 to the Registrant’s Current Report on Form 8-K filed with the SEC on November 3, 2025).

4.53 | Form of 4.950% Senior Note due 2036 (included in Exhibit 4.52 hereto).

</details>

## Item 15 Exhibits and Financial Statement Schedules (blocks 4368-4372)

**AI reference: none**

- Note (gemini: AI is part of a company name.)

<details><summary>Passage</summary>

10.4 | Fifth Amended and Restated Limited Partnership Agreement of Blackstone Holdings IV L.P., dated as of May 7, 2021, by and among Blackstone Holdings IV GP L.P. and the limited partners of Blackstone Holdings IV L.P. party thereto (incorporated herein by reference to Exhibit 10.4 to the Registrant’s Quarterly Report on Form 10-Q for the quarter ended March 31, 2021 filed with the SEC on May 7, 2021).

10.5 | Fourth Amended and Restated Limited Partnership Agreement of Blackstone Holdings AI L.P., dated as of May 7, 2021, by and among Blackstone Holdings I/II GP L.L.C. and the limited partners of Blackstone Holdings AI L.P. party thereto (incorporated herein by reference to Exhibit 10.5 to the Registrant’s Quarterly Report on Form 10-Q for the quarter ended March 31, 2021 filed with the SEC on May 7, 2021).

10.6 | Amended and Restated Tax Receivable Agreement, dated as of May 7, 2021, by and among Blackstone Holdings I/II GP L.L.C., Blackstone Holdings I L.P., Blackstone Holdings II L.P. and the limited partners of Blackstone Holdings I L.P. and Blackstone Holdings II L.P. party thereto (incorporated herein by reference to Exhibit 10.6 to the Registrant’s Quarterly Report on Form 10-Q for the quarter ended March 31, 2021 filed with the SEC on May 7, 2021).

10.7+ | Sixth Amended and Restated Exchange Agreement, dated as of February 7, 2022, among Blackstone Inc., Blackstone Holdings AI L.P., Blackstone Holdings I L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P., Blackstone Holdings IV L.P. and the Blackstone Holdings Limited Partners from time to time party thereto (incorporated herein by reference to Exhibit 10.7 to the Registrant’s Annual Report on Form 10-K for the year ended December 31, 2021 filed with the SEC on February 25, 2022)

10.8 | Amended and Restated Registration Rights Agreement, dated as of May 7, 2021 (incorporated herein by reference to Exhibit 10.8 to the Registrant’s Quarterly Report on Form 10-Q for the quarter ended March 31, 2021 filed with the SEC on May 7, 2021).

</details>

## Item 15 Exhibits and Financial Statement Schedules (blocks 4462-4464)

**AI reference: none**

- Note (gemini: AI is part of a company name.)

<details><summary>Passage</summary>

10.84 | Form of Aircraft Dry Lease Agreement (N776BT) between Hilltop Asset Holdings LLC and Blackstone Administrative Services Partnership L.P. (incorporated herein by reference to Exhibit 10.84 to the Registrant’s Annual Report on Form 10-K for the year ended December 31, 2019 filed with the SEC on February 28, 2020).

10.85 | Amended and Restated Credit Agreement dated as of March 23, 2010, as amended and restated as of May 29, 2014, as further amended and restated as of August 31, 2016, as further amended and restated as of September 21, 2018, as further amended and restated as of November 24, 2020, as further amended and restated as of June 3, 2022, and as further amended and restated as of December 15, 2023, among Blackstone Holdings Finance Co. L.L.C., as borrower, Blackstone Holdings AI L.P., Blackstone Holdings I L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P. and Blackstone Holdings IV L.P., as guarantors, Citibank, N.A., as administrative agent and the lenders party thereto (incorporated herein by reference to Exhibit 10.1 to the Registrant’s Current Report on Form 8-K filed with the SEC on December 20, 2023).

10.86+ | Amended and Restated Limited Partnership Agreement of BTOA III L.P., dated as of February 27, 2019 and deemed effective as of May 24, 2018 (incorporated herein by reference to Exhibit 10.92 to the Registrant’s Annual Report on Form 10-K for the year ended December 31, 2018 filed with the SEC on March 1, 2019).

</details>

## Item 15 Exhibits and Financial Statement Schedules (blocks 4536-4538)

**AI reference: none**

- Note (gemini: AI is part of a company name.)

<details><summary>Passage</summary>

10.146+ | Amended and Restated Limited Partnership Agreement of BXGA II GP L.P., dated as of August 8, 2025 and deemed effective as of February 19, 2025 (incorporated herein by reference to Exhibit 10.1 to the Registrant’s Quarterly Report on Form 10-Q for the quarter ended June 30, 2025 file with the SEC on August 8, 2025).

10.147 | Amended and Restated Credit Agreement, dated as of October 16, 2025, among Blackstone Holdings Finance Co. L.L.C., as borrower, Blackstone Holdings AI L.P., Blackstone Holdings I L.P., Blackstone Holdings II L.P., Blackstone Holdings III L.P. and Blackstone Holdings IV L.P., as guarantors, Citibank, N.A., as administrative agent, and the lenders party thereto (incorporated herein by reference to Exhibit 10.1 to the Registrant’s Current Report on Form 8-K filed with the SEC on October 17, 2025).

10.148+ | Amended and Restated Limited Partnership Agreement of BREDS V L.P., dated as of November 7, 2025 and deemed effective as of November 1, 2022 (incorporated herein by reference to Exhibit 10.2 to the Registrant’s Quarterly Report on Form 10-Q for the quarter ended September 30, 2025).

</details>

# Context passages: implicit mentions, not classified

## Item 1 Business (blocks 147-151)

**Terms: data center (data centers)**

Our Real Estate business is a global leader in real estate investing, with $319.3 billion of Total Assets Under Management as of December 31, 2025. Our Real Estate business operates as one globally integrated business with approximately 785 employees and has investments across the globe, including in the Americas, Europe and Asia. Our real estate investment teams seek to utilize our global expertise and presence to generate attractive risk-adjusted returns for our investors.

Our Blackstone Real Estate Partners (“BREP”) business is geographically diversified and targets a broad range of opportunistic real estate and real estate-related investments. The BREP platform includes global funds as well as funds focused specifically on Europe or Asia investments. BREP seeks to invest thematically in high-quality, well-located assets where we see outsized growth potential driven by global economic and demographic trends. BREP has made significant investments in logistics, data centers, rental housing, hospitality, office and retail properties around the world, as well as in a variety of real estate operating companies.

Our Core+ real estate strategy invests in substantially stabilized real estate globally, primarily through perpetual capital vehicles. The strategy includes our (a) Blackstone Property Partners (“BPP”) funds, which are focused on high-quality assets in the Americas, Europe and Asia and (b) a non-listed real estate investment trust (“REIT”), Blackstone Real Estate Income Trust, Inc. (“BREIT”), and Blackstone European Property Income Fund (“BEPIF”) vehicles, which provide income-focused individual investors access to institutional quality real estate primarily in the Americas and Europe, respectively.

## Item 1 Business (blocks 265-267)

**Terms: data protection impact assessment (privacy impact assessments)**

Data Privacy and Security

Blackstone is committed to data privacy. We provide data privacy training at onboarding to new employees and at least annually to existing employees. Data privacy is typically addressed in the Global Head of Compliance’s annual update to our board of directors. Blackstone’s approach to data privacy is set out in our privacy notices, including our Online Privacy Notice and Investor Data Privacy Notice. Our privacy function, which involves activities including conducting privacy impact assessments, implementing privacy-by-design initiatives and aligning global privacy programs with local privacy requirements, is led by our Data and Policy Strategy Officer and overseen by the Data Protection Operating Committee, Blackstone’s global privacy compliance steering committee. Please see “—Item 1C. Cybersecurity” for a discussion of our cybersecurity risk management, strategy and governance.

Regulatory and Compliance Matters
