# Intercontinental Exchange, Inc. | 10-Q | fiscal year 2025

- Report length: 30,037 words
- Direct AI mentions (classified): 2, of which about AI: 2, false candidates: 0, flagged for review: 0
- Context passages (not classified): 2; groups: industry (1), compute_infrastructure (1)
- Frames: business (2)
- Roles: adoption (2)
- Risk types: none
- MIT subdomains: none
- Adoption stage: deployed (2)
- Business functions: decision_analytics (2)
- Governance responses: none
- Kinds of AI: unspecified (1), traditional_ml (1)
- Substantiveness: specific (2)
- Disclosure traits: none
- Trait activation rate: 0.0 (boilerplate (0.0), hedging (0.0), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 2 (2)
- Named entities: none

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 710-712)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: decision_analytics | kinds: unspecified | substantiveness: specific**

> our ability to keep pace with technological developments and client preferences, including with regard to our emerging technology initiatives and the use of artificial intelligence in certain of our existing products;

<details><summary>Passage</summary>

the impacts of computer and communications systems failures and delays, inclusive of the performance and reliability of our trading, clearing, data services and mortgage technologies and those of third-party service providers;

our ability to keep pace with technological developments and client preferences, including with regard to our emerging technology initiatives and the use of artificial intelligence in certain of our existing products;

our ability to ensure that the technology we utilize is not vulnerable to cyberattacks, hacking and other cybersecurity risks or other disruptive events or to minimize the impact of any such events;

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 785-787)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: decision_analytics | kinds: traditional_ml | substantiveness: specific**

> emerging technology initiatives and offerings in our markets, including the use of artificial intelligence and machine learning;

<details><summary>Passage</summary>

the evolution of existing products and new product innovation to serve emerging customer needs and changing industry agreements;

emerging technology initiatives and offerings in our markets, including the use of artificial intelligence and machine learning;

rising demand for speed, data, data capacity and connectivity by market participants, necessitating increased investment in technology; and

</details>

# Context passages: implicit mentions, not classified

## Item 1 LEGAL PROCEEDINGS (blocks 565-567)

**Terms: margin model (margin model)**

Each ICE Clearing House bears financial counterparty credit risk and provides a central counterparty guarantee, or performance guarantee, to its Members. In its guarantor role, each ICE Clearing House has equal and offsetting claims to and from Members on opposite sides of each contract, standing as an intermediary on every contract cleared. To reduce their exposure, the ICE Clearing Houses have a risk management program with both initial and ongoing membership standards. The ICE Clearing Houses mark all outstanding contracts to market and, with the exception of ICE NGX, pay and collect variation margin at least once daily.

Excluding the effects of original and variation margin, guaranty fund and collateral requirements and default insurance, the ICE Clearing Houses’ maximum estimated exposure for this guarantee would be the intra-day or full day change in fair value if all Members who have open positions with unrealized losses simultaneously defaulted, which is an extremely unlikely scenario. The levels of original margin are calibrated such that a portfolio the ICE Clearing House may be required to liquidate post Member default can be closed or auctioned without recourse to resources other than those deposited by the defaulting Member, assuming an appropriate risk confidence level and liquidation period. In addition to the base margin model, each ICE Clearing House, depending on its products, employs a number of margin add-ons related to position concentration, clearing member capital, volatility, spread responses, recovery rate sensitivity, jump-to-default, and wrong-way risk.

We also performed calculations to determine the fair value of our counterparty performance guarantee taking into consideration factors such as daily settlement of contracts, margining and collateral requirements, other elements of our risk management program, historical evidence of default payments, and estimated probability of potential default payouts by the ICE Clearing Houses. Based on these analyses, the estimated counterparty performance guarantee liability was determined to be nominal, and no liability was recorded as of March 31, 2025. The ICE Clearing Houses have never experienced an incident of a clearing member default which has required the use of the guaranty funds of non-defaulting clearing members or the assets of the ICE Clearing Houses.

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 1001-1003)

**Terms: data center (data centers)**

Technology and Communication Expenses

Technology support services consist of costs for running our wholly-owned data centers, hosting costs paid to third-party data centers and maintenance of our computer hardware and software required to support our technology and cybersecurity. These costs are driven by system capacity, functionality and redundancy requirements. Communication expenses consist of costs for network connections for our electronic platforms and telecommunications costs.

Technology and communications expense also includes fees paid for access to external market data, licensing and other fee agreement expenses. Technology and communications expenses may be impacted by growth in electronic contract volume, our capacity requirements, changes in the number of telecommunications hubs and connections with customers to access our electronic platforms directly.
