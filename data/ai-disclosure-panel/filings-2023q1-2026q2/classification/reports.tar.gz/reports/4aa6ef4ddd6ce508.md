# QUALCOMM INC | 10-Q | fiscal year 2026

- Report length: 32,179 words
- Direct AI mentions (classified): 12, of which about AI: 9, false candidates: 3, flagged for review: 0
- Context passages (not classified): 8; groups: compute_infrastructure (6), industry (2), workforce_society (1), euphemisms (1)
- Frames: business (5), risk_factor (4)
- Roles: offering (6), risk (4), market_driver (1)
- Risk types: regulatory_legal (2), cybersecurity (1), operational_reliability (1)
- MIT subdomains: other (2), ai_system_security_vulnerabilities_attacks (1), cyberattacks_weapons_mass_harm (1), lack_of_capability_robustness (1), devaluation_of_human_effort (1), regulation_lagging_behind_ai (1)
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: unspecified (8), traditional_ml (1)
- Substantiveness: generic (8), specific (1)
- Disclosure traits: hedging (3)
- Trait activation rate: 0.333 (boilerplate (0.0), hedging (0.333), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 1A (7), Item 1 (1), Item 2 (1)
- Named entities: Broadcom, HiSilicon, MediaTek, Mobileye, NXP Semiconductors, Nvidia, Qorvo, Samsung, Skyworks, Texas Instruments, UNISOC

## Item 1 LEGAL PROCEEDINGS (blocks 244-246)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> Includes revenues from products sold for use in automobiles, including connectivity, digital cockpit and advanced driver assistance systems (ADAS) and automated driving (AD).

<details><summary>Passage</summary>

(1) Includes revenues from products sold for use in mobile handsets.

(2) Includes revenues from products sold for use in automobiles, including connectivity, digital cockpit and advanced driver assistance systems (ADAS) and automated driving (AD).

(3) Primarily includes products sold for use in the following industries and applications: consumer (including personal computers (PCs), extended reality (XR) and other personal computing devices), edge networking (including mobile broadband and wireless access points) and industrial (including handhelds, retail, tracking and logistics and utilities).

</details>

## Item 1 LEGAL PROCEEDINGS (blocks 307-309)

**AI reference: none**

<details><summary>Passage</summary>

(Unaudited)

production processes and customer base. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuit platforms and system software with advanced connectivity and high-performance, low-power computing technologies for use in mobile devices; automotive systems for connectivity, digital cockpit and ADAS/AD; and IoT including consumer electronic devices, industrial devices and edge networking products. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our Data Center business.

Our CODM uses revenues and earnings (loss) before income taxes (EBT) to evaluate performance and allocate resources for our segments primarily through our budget and forecasting process. Our CODM primarily uses these metrics by comparing actual results to forecasted and prior period results. Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense (as presented on the condensed consolidated statements of cash flows, the majority of which is allocated to QCT). Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense, certain net investment income, share-based compensation, gains and losses on our deferred compensation plan liabilities and related assets, certain research and development (R&D) expenses, certain selling, general and administrative (SG&A) expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, asset impairment charges and awards, settlements and/or damages arising from legal or regulatory matters and recognition of the step-up of inventories and property, plant and equipment to fair value. Our CODM does not evaluate our operating segments using discrete asset information.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 514-516)

**AI reference: none**

<details><summary>Passage</summary>

- lower handsets revenues, primarily due to lower chipset shipments to certain major OEMs (primarily driven by customers adjusting build plans to reduce their inventory levels as a result of the negative effects of recent memory supply constraints and related price increases)

+ higher automotive revenues, due to $191 million in higher shipments primarily from new vehicle launches with our Snapdragon digital cockpit and advanced driver assistance and automated driving (ADAS/AD) products and a $176 million increase in revenues per unit driven by favorable mix and higher average selling prices

+ higher IoT revenues, primarily due to an increase in revenues per unit primarily driven by favorable mix

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 522-524)

**AI reference: none**

<details><summary>Passage</summary>

The increase in QCT revenues in the first six months of fiscal 2026 was primarily due to:

+ higher automotive revenues, due to $328 million in higher shipments primarily from new vehicle launches with our Snapdragon digital cockpit and ADAS/AD products and a $179 million increase in revenues per unit driven by favorable mix and higher average selling prices

+ higher IoT revenues, primarily due to an increase in revenues per unit primarily driven by favorable mix

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 548-550)

**AI reference: explicit | frame: business | roles: market_driver, offering | kinds: unspecified | substantiveness: generic**

> We believe that on-device AI and high-performance, low-power computing combined with cellular technology (such as 5G) will continue to drive adoption of certain technologies that are already commonly used in smartphones by industries and applications beyond mobile handsets, such as automotive and IoT.

> We believe it is important that we remain a leader in such technology development, standardization, intellectual property creation and licensing, and a leading developer and supplier of integrated circuit products in order to sustain and grow our business long-term.

<details><summary>Passage</summary>

Looking Forward

We believe that on-device AI and high-performance, low-power computing combined with cellular technology (such as 5G) will continue to drive adoption of certain technologies that are already commonly used in smartphones by industries and applications beyond mobile handsets, such as automotive and IoT. We believe it is important that we remain a leader in such technology development, standardization, intellectual property creation and licensing, and a leading developer and supplier of integrated circuit products in order to sustain and grow our business long-term.

As we look forward to the next several quarters:

</details>

## Item 1A RISK FACTORS (blocks 656-659)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: generic**

> While we continue to invest significant resources toward advancements of foundational technologies, including wireless connectivity, high-performance and low-power computing and on-device AI, we also invest in new and expanded product areas, and industries and applications beyond mobile handsets, by utilizing our existing technical and business expertise and through acquisitions or other strategic transactions.

<details><summary>Passage</summary>

Our growth depends in part on our ability to extend our technologies and products into new and expanded product areas, and industries and applications beyond mobile handsets. Our research, development and other investments in these new and expanded product areas, industries and applications, and related technologies and products, as well as in our existing technologies and products, and new technologies, may not generate operating income or contribute to future results of operations that meet our expectations.

While we continue to invest significant resources toward advancements of foundational technologies, including wireless connectivity, high-performance and low-power computing and on-device AI, we also invest in new and expanded product areas, and industries and applications beyond mobile handsets, by utilizing our existing technical and business expertise and through acquisitions or other strategic transactions.

In particular, our future growth depends in part on our ability to succeed in new and expanded product areas, and industries and applications beyond mobile handsets, including in automotive, IoT and data center; our ability to develop leading and cost-effective technologies and products for these new and expanded product areas, industries and applications; and third parties incorporating our technologies and products into devices used in these product areas, industries and applications. Accordingly, we intend to continue to make substantial investments in these new and expanded product areas, industries and applications, and in developing related products and technologies.

However, our research, development and other investments in these new and expanded product areas, industries and applications, and corresponding technologies and products, as well as in our existing technologies and products and new technologies in mobile handsets, may not succeed because, among other reasons: we may not be issued patents on the technologies we develop; the technologies we develop may not be incorporated into relevant standards; new and expanded product areas, industries and applications beyond mobile handsets, and consumer demand therein, may not develop or grow as anticipated; we may be unable to attract or retain employees with the necessary skills in such new and expanded product areas, industries and applications; our strategies or the strategies of our customers, licensees or partners may not be successful; alternate technologies or products may be better or may reduce the advantages we anticipate from our investments; competitors’ technologies or products may be more cost effective, have more capabilities or fewer limitations or be brought to market faster than our new technologies or products; we may not be able to develop, or our competitors may have more established and/or stronger customer, vendor, distributor or other channel relationships; and competitors may have

</details>

## Item 1A RISK FACTORS (blocks 704-707)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: cybersecurity | mit: ai_system_security_vulnerabilities_attacks, cyberattacks_weapons_mass_harm | kinds: unspecified | substantiveness: generic | traits: hedging**

> For example, as AI continues to evolve, cyber-attackers could also use AI to develop malicious code and increasingly sophisticated phishing attempts.

> Additionally, increasing use of AI by our employees and in our internal systems may create new attack surfaces or methods for malicious actors, and may increase the risk of unintended or inadvertent transmission of our proprietary or confidential information.

<details><summary>Passage</summary>

The successful operation of various functions within our business, as well as the protection of our intellectual property and other proprietary or confidential information, depend in part on the security and functionality of our IT systems. Third parties regularly attempt to gain unauthorized access to our IT systems, and many such attacks are increasingly more sophisticated. These attacks, which might be related to industrial, corporate or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks, including those in our manufacturing operations, exploiting vulnerabilities in hardware, software or other IT infrastructure and impersonating authorized users, among others. We are also subject to ransom-style cyber-attacks, which could expose our confidential or proprietary information, demand payment of money and/or impact our IT systems and cause widespread disruption to our business, including our manufacturing operations. Third parties that store and/or process our confidential information, or that provide products, software or services used in our IT infrastructure, are subject to similar attacks, which could also result in malware being introduced into our IT infrastructure, e.g., through the third parties’ software and/or software updates. Such attacks could result in the misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our IT systems. Any damage to or disruptions in our IT systems as a result of cyber-attacks or for other reasons, such as issues related to third-party software or services used in our IT infrastructure, could significantly disrupt our business operations.

Although we maintain a cybersecurity program to manage cybersecurity risks, as described in the “Cybersecurity” section of our 2025 Annual Report on Form 10-K, we cannot anticipate, detect, repel or guarantee the effectiveness of our preventative measures against all cybersecurity threats, particularly because the techniques used are increasingly sophisticated and constantly evolving. For example, as AI continues to evolve, cyber-attackers could also use AI to develop malicious code and increasingly sophisticated phishing attempts. Like many companies, we have encountered, and may continue to encounter, intrusions and attempts to gain unauthorized access to our IT systems or other attacks and incidents, and we have had third-party service providers who have encountered intrusions and may continue to encounter intrusions. In some cases, we might be unaware of an incident or its magnitude and effects. As part of our cybersecurity program, we seek to identify and remediate vulnerabilities in our IT systems and software (including third party software used in our IT systems) that could be exploited by hackers or other malicious actors. However, we may not be aware of all such vulnerabilities, and we may fail to identify and/or remediate such vulnerabilities before they are exploited.

In addition, employees and former employees, in particular former employees who become employees of our competitors, customers, licensees or other third parties, including state actors, have in the past and may in the future misappropriate, wrongfully use, publish or provide to our competitors, customers, licensees or other third parties, including state actors, our technology, intellectual property or other proprietary or confidential information. This risk is exacerbated as competitors for talent, particularly engineering talent, increasingly attempt to hire our employees. See also the Risk Factor titled “We may not be able to attract or retain qualified employees.” Similarly, we provide access to certain of our technology, intellectual property and other proprietary or confidential information to our direct and indirect customers and licensees and certain of our consultants, who have in the past and may in the future wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. We have also provided and may continue to provide access to certain of our technology, intellectual property and other proprietary or confidential information to certain joint venture partners, including those affiliated with state actors in foreign jurisdictions. Such joint venture partners may wrongfully use such technology, intellectual property or information, or wrongfully disclose such technology, intellectual property or information to third parties, including our competitors or state actors. Our technology, intellectual property and other proprietary or confidential information that we have provided to customers, licensees or other business partners could also be wrongfully obtained by third parties through cyber-attacks on such customers’, licensees’ or other business partners’ IT systems. Additionally, increasing use of AI by our employees and in our internal systems may create new attack surfaces or methods for malicious actors, and may increase the risk of unintended or inadvertent transmission of our proprietary or confidential information.

The misappropriation, theft, misuse, disclosure, loss or destruction of the technology, intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, could harm our competitive position, reduce the value of our investment in research and development and other strategic initiatives, cause us to lose business, damage our reputation, subject us to legal or regulatory proceedings, cause us to incur other loss or liability and otherwise adversely affect our business. We expect to continue to devote resources to the security of our IT systems, and our technology, intellectual property and proprietary and confidential information.

</details>

## Item 1A RISK FACTORS (blocks 743-748)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: generic**

> Competition in the semiconductor industry is affected by various factors that include, among others: OEM concentrations; vertical integration; competition in certain geographic regions; government intervention or support of national industries or competitors; geopolitical tensions, which may drive customer preference toward local suppliers; the ability to maintain product differentiation in light of evolving industry standards and speed of technological change (including the transition to smaller geometry process technologies, the demand for always on, always connected capabilities, the increasing use of AI and machine learning technologies and the need to run complex AI-based applications on devices); access to capacity in the supply chain; and value-added features that drive selling prices and consumer demand for new devices.

> differentiate our products with innovative technologies across multiple products and features (e.g., modem, on-device AI, graphics and other processors, camera and connectivity) and with smaller geometry process technologies that drive both performance and lower power consumption;

<details><summary>Passage</summary>

Our industry is subject to intense competition in an environment of rapid technological change. Our success depends in part on our ability to adapt to such change and compete effectively; and such change and competition could result in decreased demand for our products and technologies or declining average selling prices for our products or those of our customers or licensees.

Our products and technologies face significant competition. We expect this competition to intensify as our current competitors expand their product offerings, improve their products or reduce the prices of their products as part of a strategy to maintain existing business and customers or attract new business and customers, as new opportunities develop, and as new competitors enter the industry. Competition in the semiconductor industry is affected by various factors that include, among others: OEM concentrations; vertical integration; competition in certain geographic regions; government intervention or support of national industries or competitors; geopolitical tensions, which may drive customer preference toward local suppliers; the ability to maintain product differentiation in light of evolving industry standards and speed of technological change (including the transition to smaller geometry process technologies, the demand for always on, always connected capabilities, the increasing use of AI and machine learning technologies and the need to run complex AI-based applications on devices); access to capacity in the supply chain; and value-added features that drive selling prices and consumer demand for new devices.

We anticipate that additional competitors will introduce products as a result of growth opportunities in the industries in which we operate, the trend toward global expansion by foreign and domestic competitors, and technological and public policy changes. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape. For example, if any key supplier of technologies and intellectual property to the semiconductor industry was sold to one of our competitors, it could negatively affect our ability to procure or license such technologies and intellectual property in the future, at all or upon acceptable terms, which could have wide-ranging impacts on our business and operations.

We expect that our future success will depend on, among other factors, our ability to:

differentiate our products with innovative technologies across multiple products and features (e.g., modem, on-device AI, graphics and other processors, camera and connectivity) and with smaller geometry process technologies that drive both performance and lower power consumption;

develop and offer products at competitive cost and price points and to effectively cover all geographic regions and all device tiers;

</details>

## Item 1A RISK FACTORS (blocks 758-760)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: generic**

> Companies that provide on-device AI, high-performance and low-power computing and wireless connectivity-based integrated circuit products and/or software are generally competitors or potential competitors.

<details><summary>Passage</summary>

continue to develop brand recognition to effectively compete against better known companies in computing and other consumer driven segments and to deepen our presence in significant emerging regions.

We compete with many different semiconductor companies, ranging from multinational companies with integrated research and development, manufacturing, sales and marketing organizations across a broad spectrum of product lines, to companies that are focused on a single application, industry or standard product, including those that produce products for mobile handsets, automotive or IoT, among others. Most of these competitors compete with us with respect to some, but not all, of our businesses or product lines. Companies that provide on-device AI, high-performance and low-power computing and wireless connectivity-based integrated circuit products and/or software are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Broadcom, HiSilicon, MediaTek, Mobileye, Nvidia, NXP Semiconductors, Qorvo, Samsung, Skyworks, Texas Instruments and UNISOC. Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to use our competitors’ integrated circuit products, to utilize their own internally-developed integrated circuit products and/or sell such products to others, or to utilize alternative technologies; lower cost structures or a willingness and ability to accept lower prices or lower margins for their products, particularly in China; foreign government support of other technologies, competitors or OEMs that sell devices that do not contain our products; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; the development and sale of infrastructure equipment for wireless networks, which may enable such competitors to better optimize their integrated circuit products for performance on those networks; more extensive relationships with local distribution companies and OEMs in certain geographic regions (such as China); longer operating histories in industries and applications beyond mobile handsets (such as automotive, IoT and data center), including more established and/or stronger customer, vendor, distributor or other channel relationships in such industries; and a more established presence in certain regions.

In addition, certain of our largest customers have in the past utilized, currently utilize and may in the future utilize our competitors’ integrated circuit products in some or all of their devices, rather than our products. Further, certain of those customers have developed, are developing or may develop their own integrated circuit products (effectively making them competitors), which they have in the past utilized, currently utilize or may in the future utilize in some or all of their devices, rather than our products. See also the Risk Factor titled “ Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products) .”

</details>

## Item 1A RISK FACTORS (blocks 768-770)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: operational_reliability | mit: lack_of_capability_robustness | kinds: unspecified | substantiveness: generic**

> The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications, including but not limited to: automobiles, including ADAS/AD functions; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and XR for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

<details><summary>Passage</summary>

The occurrence of defects, errors or security vulnerabilities may also give rise to product liability or other commercial claims, particularly if such defects, errors or security vulnerabilities in our products or the technology we use, or the products into which they are integrated, result in personal injury or death, or customer field actions (for example, in the automotive industry, where such term means automotive product-related service actions or repairs for defects, whether safety-related or not). If a product liability or other commercial claim is brought against us, the cost of defending the claim could be significant, and could divert the attention of our technical and management personnel and harm our business, even if we are successful. We may be named in product liability claims even if there is no evidence that our products caused the damage in question, and even though we may have indemnity from our customers, and such claims could result in significant costs and expenses. We may also be required to indemnify and/or defend our customers from product liability claims relating to our products. Further, our business liability insurance may be inadequate or may not cover the claims, and future coverage may

be unavailable on acceptable terms, which could adversely impact our financial results. The above is exacerbated by the fact that our products may be used, and perform critical functions, in various high-risk applications, including but not limited to: automobiles, including ADAS/AD functions; cameras and artificial intelligence, including home and enterprise security; home automation, including smoke and noxious gas detectors; medical condition monitoring; location and asset tracking and management, including wearables for child safety and elderly health; robotics, including public safety drones and autonomous municipality vehicles; and XR for treatment of phobias or PTSD, early detection of disorders or special needs, among others.

Accordingly, defects, errors or security vulnerabilities in our products or the technologies we use could have an adverse impact on us, on our customers and the end users of our customers’ products. If any of these risks materialize, there could be a material adverse effect on our business, results of operations and financial condition.

</details>

## Item 1A RISK FACTORS (blocks 779-784)

**AI reference: explicit | frame: risk_factor | roles: offering, risk | risk: regulatory_legal | mit: devaluation_of_human_effort, other | kinds: unspecified | substantiveness: generic | traits: hedging**

> Finally, the intellectual property ownership and license rights, including copyrights and patents, surrounding AI technologies, which we are increasingly building into our product offerings, have not been fully addressed by U.S. or foreign courts, laws or regulations, and the use of AI in the development of our products and services could result in our loss of, or failure to obtain, intellectual property rights, as well as subject us to risks related to intellectual property infringement or misappropriation.

> Additionally, our increasing use of AI technologies for productivity and in our products and services may expose us to copyright infringement or other intellectual property misappropriation claims.

<details><summary>Passage</summary>

comply with the obligation to provide full access to their books and records. To the extent we do not aggressively enforce our rights under our license agreements, licensees may not comply with their existing license agreements, and to the extent we do not aggressively pursue unlicensed companies to enter into license agreements with us for their use of our intellectual property, other unlicensed companies may not enter into license agreements.

Finally, the intellectual property ownership and license rights, including copyrights and patents, surrounding AI technologies, which we are increasingly building into our product offerings, have not been fully addressed by U.S. or foreign courts, laws or regulations, and the use of AI in the development of our products and services could result in our loss of, or failure to obtain, intellectual property rights, as well as subject us to risks related to intellectual property infringement or misappropriation.

See also the Risk Factors titled “Our business and operations could suffer in the event of security breaches of our IT systems, or other misappropriation of our technology, intellectual property or other proprietary or confidential information,” “ Efforts by some OEMs to avoid paying fair and reasonable royalties for the use of our intellectual property may require the investment of substantial management time and financial resources and may result in legal decisions or actions by governments, courts, regulators or agencies, Standards Development Organizations (SDOs) or other industry organizations that harm our business, ” and “ Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings .”

Claims by third parties that we infringe their intellectual property could adversely affect our business.

From time to time, third parties have asserted, and may again assert, patent, copyright, trademark or other intellectual property claims against us relating to our technologies or products, including those we have acquired from other companies. These claims have resulted and may again result in our involvement in litigation, and we are currently involved in such litigation, including certain matters described in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Commitments and Contingencies.” We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. Additionally, our increasing use of AI technologies for productivity and in our products and services may expose us to copyright infringement or other intellectual property misappropriation claims. If any of our products were found to infringe another party’s intellectual property, we could be subject to an injunction or be required to redesign our products, or to license such intellectual property or pay damages or other compensation to such other party (any of which could be costly). If we are unable to redesign our products, license such intellectual property used in our products or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling our products. Similarly, our suppliers could be found to infringe another party’s intellectual property, and such suppliers could then be enjoined from providing products or services to us.

In any potential dispute involving us and another party’s patents, copyrights, trademarks or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and damages arising from qualifying claims of patent infringement by products sold by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and cash flows. Furthermore, litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could harm our relationships with them and could result in a decline in our chipset sales or a reduction in our licensees’ sales, causing a corresponding decline in our chipset or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel, cause product release or shipment delays and/or cause damage to our customer relationships, any of which could have an adverse effect on our results of operations and cash flows.

</details>

## Item 1A RISK FACTORS (blocks 797-800)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: other, regulation_lagging_behind_ai | kinds: unspecified | substantiveness: generic | traits: hedging**

> These include, among others, Regulations related to: patent licensing practices; antitrust, competition and competitive business practices; protection of intellectual property; cybersecurity; privacy and data protection; AI technologies; imports and exports, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; trade and trade protection including tariffs; foreign policy and national security; the flow of funds out of certain countries (e.g., China); automotive industry safety, security and quality standards; environmental protection (including climate change), health and safety; supply chain, responsible sourcing (including the use of conflict minerals) and human rights; spectrum availability and license issuance; adoption of standards; taxation; labor, employment and human capital; corporate governance; public disclosure and reporting (including reporting of sustainability-related data); and business conduct.

> In addition, and especially in developing regulatory areas (for example, AI, privacy and data protection, and sustainability-related reporting), Regulations may differ by country or by state within the United States and may be conflicting in certain cases.

<details><summary>Passage</summary>

Our business may suffer due to the impact of, or our failure to comply with, the various existing, new or amended laws, regulations, policies or standards to which we are subject.

Our business and products, and those of our customers and licensees, are subject to various laws, rules and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies (collectively, Regulations). These include, among others, Regulations related to: patent licensing practices; antitrust, competition and competitive business practices; protection of intellectual property; cybersecurity; privacy and data protection; AI technologies; imports and exports, such as the U.S. Export Administration Regulations administered by the U.S. Department of Commerce; trade and trade protection including tariffs; foreign policy and national security; the flow of funds out of certain countries (e.g., China); automotive industry safety, security and quality standards; environmental protection (including climate change), health and safety; supply chain, responsible sourcing (including the use of conflict minerals) and human rights; spectrum availability and license issuance; adoption of standards; taxation; labor, employment and human capital; corporate governance; public disclosure and reporting (including reporting of sustainability-related data); and business conduct. Compliance with, or changes in the interpretation of, existing Regulations, the adoption of new Regulations, changes in the oversight of our activities by governments or standards bodies, or rulings in court, regulatory, administrative or other proceedings relating to such Regulations, among others, could have an adverse effect on our business and results of operations. See also the Risk Factors titled “ Our business may suffer as a result of adverse rulings in governmental investigations or proceedings or other legal proceedings,” “ Changes in our patent licensing practices, whether

due to governmental investigations, legal challenges or otherwise, could adversely impact our business and results of operations,” “A significant portion of our business is concentrated in China, and the risks of such concentration are exacerbated by U.S./China trade and national security tensions,” “ There are numerous risks associated with the operation and control of our manufacturing facilities, including a higher portion of fixed costs relative to a fabless model; environmental compliance and liability; impacts related to climate change; exposure to natural disasters, health crises, geopolitical conflicts and cyber-attacks; timely supply of equipment and materials; and various manufacturing issues,” and “Tax liabilities could adversely affect our results of operations.”

Regulations are complex and changing (which may create uncertainty regarding compliance), are subject to varying interpretations, and their application in practice may evolve over time. In addition, and especially in developing regulatory areas (for example, AI, privacy and data protection, and sustainability-related reporting), Regulations may differ by country or by state within the United States and may be conflicting in certain cases. As a result, our efforts to comply with Regulations may fail, particularly if there is ambiguity as to how they should be applied in practice. Failure to comply with any Regulation may adversely affect our business, results of operations and cash flows. New Regulations, or evolving interpretations thereof, may cause us to incur higher costs as we revise current practices, policies or procedures; may divert management time and attention to compliance activities; and may negatively impact our ability to conduct business in certain jurisdictions.

</details>

# Context passages: implicit mentions, not classified

## Item 1 LEGAL PROCEEDINGS (blocks 382-384)

**Terms: custom silicon (custom silicon), data center (data centers)**

Note 8. Acquisitions

Alphawave. On December 18, 2025 (the Closing Date), we completed the acquisition of Alphawave IP Group plc (Alphawave) for $ 2.3 billion, which primarily consisted of $ 1.8 billion of equity consideration from the issuance of 11 million shares of our common stock, which includes certain securities exchangeable for shares of our common stock (Exchangeable Shares), and $ 301 million of cash consideration. Alphawave develops high-speed wired connectivity technologies delivering IP, custom silicon and connectivity products. The acquisition is intended to further accelerate, and provide key assets for, our expansion into data centers.

In connection with the acquisition, we issued Exchangeable Shares of Aqua ExchangeCo ULC, an indirect, wholly-owned subsidiary of QUALCOMM Incorporated, to certain Alphawave executives in exchange for their outstanding capital stock. The Exchangeable Shares ( no par value; unlimited shares authorized; 4 million shares issued and outstanding as of March 29, 2026) are exchangeable for our common stock on a one-for-one basis and are substantially the economic equivalent of our common stock. The issued and outstanding Exchangeable Shares have been presented together with our common stock in our condensed consolidated financial statements. The Exchangeable Shares had an estimated fair value of $ 746 million, of which $ 453 million is included within the $ 2.3 billion purchase price and the remainder is subject to a four-year service requirement post-acquisition and will be recognized as compensation expense.

## Item 1 LEGAL PROCEEDINGS (blocks 399-402)

**Terms: data center (Data Center)**

(Unaudited)

Goodwill related to this transaction was allocated to our Data Center operating segment and is not deductible for tax purposes. Goodwill is primarily attributable to assembled workforce which we expect will help accelerate our expansion into data centers, and certain revenue synergies expected to arise after the acquisition such as anticipated growth from new product sales. Acquired intangible assets subject to amortization primarily consists of completed technology that will be amortized on a straight-line basis over the weighted-average useful life of five years . We valued the completed technology and IPR&D using an income approach based on significant unobservable inputs.

Pro forma results of operations have not been presented because the effects of this acquisition were not material to our consolidated results of operations.

Other. During the first six months of fiscal 2026, we acquired six other businesses for a total accounting purchase price of $ 985 million. These acquisitions were primarily for the purpose of executing on certain products and technology that support our QCT business, including our diversification strategy. The acquired assets primarily consisted of $ 272 million of intangible assets and $ 698 million of goodwill, with $ 622 million allocated to our QCT segment and $ 76 million allocated to our Data Center operating segment, all of which is primarily attributable to assembled workforce and certain synergies expected to arise after the acquisitions.

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 413-415)

**Terms: data center (Data Center)**

We develop and commercialize foundational technologies and products used across industries and applications from mobile devices to other areas including automotive and the internet of things (IoT). We derive revenues principally from sales of integrated circuit products and licensing our intellectual property, including patents and other rights.

We are organized on the basis of products and services and have three reportable segments. We conduct business primarily through our QCT (Qualcomm CDMA Technologies) semiconductor business and our QTL (Qualcomm Technology Licensing) licensing business. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies) and our Data Center business.

Our reportable segments are operated by QUALCOMM Incorporated and its direct and indirect subsidiaries. Substantially all of our products and services businesses, including QCT, and substantially all of our engineering and research

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 428-430)

**Terms: data center (Data Center)**

- $143 million in licensing revenues from a settlement of a licensing dispute in the second quarter of fiscal 2025, which was not allocated to our segment results

+ $97 million in higher equipment and services revenues from our Data Center segment, primarily driven by our acquisition of Alphawave in the first quarter of fiscal 2026

+ $63 million in higher licensing revenues from our QTL segment

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 434-436)

**Terms: data center (Data Center)**

+ $120 million in higher licensing revenues from our QTL segment

+ $94 million in higher equipment and services revenues from our Data Center segment, primarily driven by our acquisition of Alphawave in the first quarter of fiscal 2026

- $143 million in licensing revenues from a settlement of a licensing dispute in the second quarter of fiscal 2025, which was not allocated to our segment results

## Item 1A RISK FACTORS (blocks 649-653)

**Terms: Entity List (entity lists), export controls (export license)**

Due to various factors, including pressure, encouragement or incentives from, or policies of, the Chinese government (which has prioritized semiconductor self-sufficiency), concerns over losing access to our products as a result of actual, threatened or potential U.S. or Chinese government actions or policies, including trade protection or national security policies, or other reasons, some of our customers in China have developed, and others may in the future develop, their own integrated circuit products and use such integrated circuit products in their devices, or use our competitors’ integrated circuit products in their devices, rather than our products, which could materially harm our business, results of operations, cash flows and financial condition. See also the Risk Factor titled “Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products).”

Political actions, including trade protection and national security policies of the U.S. and Chinese governments, such as tariffs, bans or placing companies on restricted entity lists, have in the past, currently are and could in the future limit or

prevent us from transacting business with certain of our Chinese or Chinese-affiliated customers or suppliers, limit, prevent or discourage such customers or suppliers from transacting business with us, or make it more expensive to do so. Given our revenue concentration in China, if, due to actual, threatened or potential U.S. or Chinese government actions or policies: we were further limited in, or prohibited from, selling our integrated circuit products to Chinese or Chinese-affiliated customers; our non-Chinese OEM customers were limited in, or prohibited from, selling devices that incorporate our integrated circuit products into China; Chinese OEMs develop and use their own integrated circuit products or use our competitors’ integrated circuit products in some or all of their devices rather than our integrated circuit products; Chinese tariffs on our integrated circuit products or on devices which incorporate our integrated circuit products made purchasing such products or devices more expensive to our Chinese customers or Chinese consumers; or our Chinese licensees delay or cease making payments of royalties they owe us, our business, results of operations, cash flows and financial condition could be materially harmed.

For example, in May 2024, the U.S. Department of Commerce revoked the export license under which we previously sold 4G and certain other integrated circuit products to Huawei, which is one of the largest smartphone OEMs in China. Accordingly, we do not expect to receive any further product revenues from Huawei, and to the extent that Huawei’s devices take share from OEMs that utilize our products (in China or elsewhere), our results of operations and cash flows could be further impacted. See also the Risk Factors titled “ We derive a significant portion of our revenues from a small number of customers and licensees, and particularly from their sale of premium-tier handset devices. If revenues derived from these customers or licensees decrease or the timing of such revenues fluctuates, our business and results of operations could be negatively affected ” and “ Our business, particularly our semiconductor business, may suffer as a result of our customers vertically integrating (i.e., developing their own integrated circuit products). ”

Similarly, if, due to U.S. or Chinese government actions or policies, we were limited in or prohibited from obtaining critical integrated circuit products or manufacturing, assembly or test services from Chinese or Chinese-affiliated suppliers, or we or our customers were limited in or prohibited from selling in the United States products containing technologies with Chinese-origin content, our business, results of operations, cash flows and financial condition could be materially harmed.

## Item 1A RISK FACTORS (blocks 710-712)

**Terms: digital talent (engineering talent)**

We may not be able to attract or retain qualified employees.

Our future success depends upon the continued service of our executive officers and other key management and technical personnel, and on our ability to continue to identify, attract, retain and motivate them. Implementing our business strategy requires specialized engineering and other talent, as our revenues are highly dependent on technological and product innovations. In addition, in order to extend our business into certain new and expanded product areas and industries and applications beyond mobile handsets, we need to attract, retain and motivate engineering and other technical personnel with specialized skills in these areas, and these skills are in high demand among our competitors. The market for employees in our industry is extremely competitive, and competitors for talent, particularly engineering talent, increasingly attempt to hire, and to varying degrees have been successful in hiring, our employees or employment candidates, including by establishing or expanding local offices near our headquarters in San Diego, California. Further, the increased availability of remote working arrangements has expanded the pool of companies that can compete for our employees and employment candidates. A number of such competitors for talent are significantly larger than us and/or offer compensation in excess of what we offer or other benefits that we do not offer, including remote work policies that may be perceived as more favorable than ours. Further, existing immigration laws make it more difficult for us to recruit and retain highly skilled foreign national graduates of universities in the United States, making the pool of available talent even smaller.

If we are unable to attract or retain qualified employees due to any of the factors described above or for other reasons, our business could be adversely impacted.

## Item 1A RISK FACTORS (blocks 751-753)

**Terms: next-generation technology (next-generation technology)**

maintain or accelerate demand for our products at the premium device tier, while also driving the adoption of our products into high, mid- and low-tier devices across all regions;

remain a leader in 5G and next-generation technology development, standardization, intellectual property creation and licensing, and develop, commercialize and remain a leading supplier of integrated circuit products based on such technologies, including RFFE products;

maintain access to sufficient capacity in the supply chain relative to our competitors to meet customer demand;
