# PFIZER INC | 10-Q | fiscal year 2025

- Report length: 37,420 words
- Direct AI mentions (classified): 6, of which about AI: 6, false candidates: 0, flagged for review: 0
- Context passages (not classified): 1; groups: industry (1)
- Frames: business (5), risk_factor (1)
- Roles: adoption (4), general (1), risk (1)
- Risk types: cybersecurity (1), operational_reliability (1)
- MIT subdomains: ai_system_security_vulnerabilities_attacks (1), lack_of_capability_robustness (1)
- Adoption stage: deployed (3), planned (1)
- Business functions: operations (2), rd_product (2), not_stated (1)
- Governance responses: none
- Kinds of AI: unspecified (6)
- Substantiveness: specific (3), generic (2), boilerplate (1)
- Disclosure traits: vagueness (1)
- Trait activation rate: 0.167 (boilerplate (0.0), hedging (0.0), externalisation (0.0), vagueness (0.167), safe_harbour (0.0))
- Sections: Item 2 (3), Item 1 (2), Item 6 (1)
- Named entities: none

## Item 6 EXHIBITS (blocks 78-80)

**AI reference: explicit | frame: business | roles: general | kinds: unspecified | substantiveness: boilerplate**

> AI | artificial intelligence

<details><summary>Passage</summary>

ACIP | Advisory Committee on Immunization Practices

AI | artificial intelligence

ALK | anaplastic lymphoma kinase

</details>

## Item 1 LEGAL PROCEEDINGS (blocks 401-403)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: operations | kinds: unspecified | substantiveness: specific**

> In the second quarter of 2025, we identified additional productivity opportunities to further reduce costs primarily in SI&A, driven in large part by enhanced digital enablement, including automation and AI, and simplification of business processes.

<details><summary>Passage</summary>

A. Realigning Our Cost Base Program

In the fourth quarter of 2023, we announced that we launched a multi-year, enterprise-wide cost realignment program that aims to realign our costs with our longer-term revenue expectations. In the second quarter of 2025, we identified additional productivity opportunities to further reduce costs primarily in SI&A, driven in large part by enhanced digital enablement, including automation and AI, and simplification of business processes.

We expect costs associated with these components of the program to be incurred through 2027 and to total approximately $ 4.7 billion, representing primarily cash expenditures for severance, implementation, exit, and digital enablement costs, as well as non-cash asset write downs of which $ 3.1 billion is associated with our Biopharma segment.

</details>

## Item 1 LEGAL PROCEEDINGS (blocks 406-408)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: rd_product | kinds: unspecified | substantiveness: specific**

> Additionally, in connection with our efforts to simplify the structure and sharpen the focus of our R&D organization, in the first quarter of 2025, we expanded this program after having identified additional opportunities to drive improvements in productivity and operational efficiencies through enhanced digital enablement, including automation and AI, and simplification of business processes.

<details><summary>Passage</summary>

(UNAUDITED)

Additionally, in connection with our efforts to simplify the structure and sharpen the focus of our R&D organization, in the first quarter of 2025, we expanded this program after having identified additional opportunities to drive improvements in productivity and operational efficiencies through enhanced digital enablement, including automation and AI, and simplification of business processes. We expect costs to implement these initiatives to be incurred through 2026 and to total approximately $ 600 million, primarily representing cash expenditures for severance, digital enablement and implementation, all of which is associated with our Biopharma segment. The majority of these costs were recorded in the first quarter of 2025, with cash outlays expected primarily in 2025 and 2026.

We expect costs associated with all the components of this program to total approximately $ 5.3 billion of which $ 3.7 billion is associated with the Biopharma segment.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 1077-1079)

**AI reference: explicit | frame: business | roles: adoption | adoption: planned | functions: not_stated | kinds: unspecified | substantiveness: generic**

> One way we believe we will be more efficient, effective and able to execute on these strategic priorities is through digital enablement, including automation and AI.

<details><summary>Passage</summary>

4. Optimize capital allocation.

One way we believe we will be more efficient, effective and able to execute on these strategic priorities is through digital enablement, including automation and AI.

Segments ––We manage our commercial operations through a global structure consisting of three operating segments: Biopharma, PC1 and Pfizer Ignite. Biopharma is the only reportable segment. See Note 13A .

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 1081-1084)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: operations, rd_product | kinds: unspecified | substantiveness: specific**

> In the second quarter of 2025, we identified additional productivity opportunities to further reduce costs primarily in SI&A, driven in large part by enhanced digital enablement, including automation and AI, and simplification of business processes.

> In connection with our efforts to simplify the structure and sharpen the focus of our R&D organization, in the first quarter of 2025, we expanded this program after having identified additional opportunities to drive improvements in productivity and operational efficiencies through enhanced digital enablement, including automation and AI, and simplification of business processes.

<details><summary>Passage</summary>

Realigning Our Cost Base Program

In the fourth quarter of 2023, we announced that we launched a multi-year, enterprise-wide cost realignment program that aims to realign our costs with our longer-term revenue expectations. In the second quarter of 2025, we identified additional productivity opportunities to further reduce costs primarily in SI&A, driven in large part by enhanced digital enablement, including automation and AI, and simplification of business processes.

In connection with our efforts to simplify the structure and sharpen the focus of our R&D organization, in the first quarter of 2025, we expanded this program after having identified additional opportunities to drive improvements in productivity and operational efficiencies through enhanced digital enablement, including automation and AI, and simplification of business processes.

Manufacturing Optimization Program ––In the second quarter of 2024, we announced that we launched a multi-year, multi-phased program to reduce our costs of goods sold, which is expected to include primarily operational efficiencies, network structure changes, and product portfolio enhancements.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 1544-1546)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: cybersecurity, operational_reliability | mit: ai_system_security_vulnerabilities_attacks, lack_of_capability_robustness | kinds: unspecified | substantiveness: generic | traits: vagueness**

> any business disruption, theft of confidential or proprietary information, security threats on facilities or infrastructure, extortion or integrity compromise resulting from a cyber-attack, which may include those using adversarial AI techniques, or other malfeasance by, but not limited to, nation states, employees, business partners or others; and

> risks and challenges related to the use of software and services that include AI-based functionality and other emerging technologies.

<details><summary>Passage</summary>

any significant breakdown or interruption of our information technology systems and infrastructure (including cloud services);

any business disruption, theft of confidential or proprietary information, security threats on facilities or infrastructure, extortion or integrity compromise resulting from a cyber-attack, which may include those using adversarial AI techniques, or other malfeasance by, but not limited to, nation states, employees, business partners or others; and

risks and challenges related to the use of software and services that include AI-based functionality and other emerging technologies.

</details>

# Context passages: implicit mentions, not classified

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 1073-1075)

**Terms: R&D productivity (R&D productivity)**

Our Business and Strategy ––Pfizer Inc. is a research-based, global biopharmaceutical company. We apply science and our global resources to bring therapies to people that extend and significantly improve their lives. Our 2025 key priorities are to:

1. Improve R&D productivity with sharpened focus

2. Expand margins and maximize operational efficiency
