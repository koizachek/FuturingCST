# NVIDIA CORP | 10-Q | fiscal year 2025

- Report length: 21,284 words
- Direct AI mentions (classified): 8, of which about AI: 8, false candidates: 0, flagged for review: 0
- Context passages (not classified): 38; groups: products_vendors (33), compute_infrastructure (6)
- Frames: business (6), risk_factor (2)
- Roles: offering (7), risk (3), governance (1)
- Risk types: national_security (2), market_demand (1), strategic_competitive (1), regulatory_legal (1)
- MIT subdomains: power_centralization_unfair_benefits (2), other (1), regulation_lagging_behind_ai (1)
- Adoption stage: none
- Business functions: none
- Governance responses: policies_processes (1)
- Kinds of AI: generative_llm (5), unspecified (3), recommendation (2)
- Substantiveness: detailed (5), specific (3)
- Disclosure traits: hedging (3)
- Trait activation rate: 0.375 (boilerplate (0.0), hedging (0.375), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 2 (4), Item 1 (2), Item 1A (2)
- Named entities: DGX Cloud, EU AI Act, Grace Hopper Superchips, Mellanox, NVIDIA ACE, NVIDIA AI Enterprise, NVIDIA AI Enterprise 5.0, NVIDIA AI Foundations, NVIDIA Blackwell, NVIDIA DGX, NVIDIA DGX Cloud, NVIDIA DRIVE Orin, NVIDIA DRIVE Thor, NVIDIA Hopper GPU, NVIDIA NIM Inference Microservices, NVIDIA Omniverse Cloud APIs, NVIDIA Quantum InfiniBand, NVIDIA RTX, Omniverse, Spectrum Ethernet

## Item 1 Legal Proceedings (blocks 521-523)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> We expect our cloud service agreements to be used to support our research and development efforts and our DGX Cloud offerings.

<details><summary>Passage</summary>

Our purchase obligations reflect our commitment to purchase components used to manufacture our products, including long-term supply and capacity agreements, certain software and technology licenses, other goods and services and long-lived assets.

As of April 28, 2024, we had outstanding inventory purchases and long-term supply and capacity obligations totaling $ 18.8 billion. We enter into agreements with contract manufacturers that allow them to procure inventory based upon our defined criteria, and in certain instances, these agreements are cancellable, able to be rescheduled, and adjustable for our business needs prior to placing firm orders. These changes may result in costs incurred through the date of cancellation. Other non-inventory purchase obligations were $ 10.6 billion, including $ 8.8 billion of multi-year cloud service agreements. We expect our cloud service agreements to be used to support our research and development efforts and our DGX Cloud offerings.

Total future purchase commitments as of April 28, 2024 are as follows:

</details>

## Item 1 Legal Proceedings (blocks 564-567)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> The Compute & Networking segment includes our Data Center accelerated computing platform; networking; automotive artificial intelligence, or AI, Cockpit, autonomous driving development agreements, and autonomous vehicle solutions; electric vehicle computing platforms; Jetson for robotics and other embedded platforms; NVIDIA AI Enterprise and other software; and DGX Cloud.

<details><summary>Passage</summary>

Our Chief Executive Officer is our chief operating decision maker, or CODM, and reviews financial information presented on an operating segment basis for purposes of making decisions and assessing financial performance.

The Compute & Networking segment includes our Data Center accelerated computing platform; networking; automotive artificial intelligence, or AI, Cockpit, autonomous driving development agreements, and autonomous vehicle solutions; electric vehicle computing platforms; Jetson for robotics and other embedded platforms; NVIDIA AI Enterprise and other software; and DGX Cloud.

The Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro/NVIDIA RTX GPUs for enterprise workstation graphics; virtual GPU software for cloud-based visual and virtual computing; automotive platforms for infotainment systems; and Omniverse Enterprise software for building and operating 3D internet applications.

Operating results by segment include costs or expenses directly attributable to each segment, and costs or expenses that are leveraged across our unified architecture and therefore allocated between our two segments.

</details>

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 641-643)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, autonomous vehicles, robotics, metaverse and 3D internet applications.

<details><summary>Passage</summary>

Our Company and Our Businesses

NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Since our original focus on PC graphics, we have expanded to several other large and important computationally intensive fields. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, autonomous vehicles, robotics, metaverse and 3D internet applications. Our two operating segments are "Compute & Networking" and "Graphics," as described in Note 14 of the Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q.

Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

</details>

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 645-656)

**AI reference: explicit | frame: business | roles: offering, risk | risk: national_security | mit: power_centralization_unfair_benefits | kinds: generative_llm | substantiveness: detailed | traits: hedging**

> We build technology and introduce products for new and innovative use cases and applications such as our NVIDIA DGX Cloud services, our Omniverse platform, LLMs, and generative AI models.

> Our competitive position has been harmed, and our competitive position and future results may be further harmed in the long term, if there are further changes in the USG’s export controls.

<details><summary>Passage</summary>

Demand and Supply, Product Transitions, and New Products and Business Models

Our overall revenue, driven by data center compute, continued to grow through the first quarter of fiscal year 2025. We continue to gather customer demand indications across several product transitions. We have demand visibility for our data center products, including the recently announced Blackwell GPU architecture. We have previously increased our supply and capacity purchases with existing suppliers with planned receipts later this year. We continue to add new vendors and have entered and may continue to enter into prepaid manufacturing and capacity agreements to supply both current and future products. The increased purchase volumes and number of suppliers and integration of new vendors into our supply chain may create more complexity and execution risk. Our purchase commitments and obligations for inventory and manufacturing capacity at the end of the first quarter of fiscal year 2025 continued to be impacted by shortening lead times for certain components. We may incur inventory provisions or impairments if our inventory or supply or capacity commitments exceed demand for our products or demand declines. While supply for H100 continued to improve, we are still constrained on H200. Our next generation data center architecture, Blackwell, is in production, and we plan on shipping customer samples in the second quarter. We expect to ramp customer shipments of Blackwell in the second half of the fiscal year. We believe the initial demand for Blackwell is well ahead of the projected supply for this fiscal year. We expect supply constraints for our Blackwell offerings will continue into next year.

Product transitions are complex as we often ship both new and prior architecture products simultaneously and we and our channel partners prepare to ship and support new products. Due to our product introduction cycles, we are almost always in various stages of transitioning the architectures of our Data Center, Gaming, and Professional Visualization products. We have begun a broader and faster Data Center product launch cadence to meet a growing and diverse set of

AI opportunities. The increased frequency of these transitions may magnify the challenges associated with managing our supply and demand due to manufacturing lead times. Qualification time for new products, customers anticipating product transitions and channel partners reducing channel inventory of prior architectures ahead of new product introductions can reduce or create volatility in our revenue. The increasing frequency and complexity of newly introduced products could result in quality or production issues that could increase inventory provisions, warranty, or other costs or result in product delays. Deployment of new products to customers creates additional challenges due to the complexity of our technologies, which has impacted and may in the future impact the timing of customer purchases or otherwise impact our demand. While we have managed prior product transitions and have sold multiple product architectures at the same time, these transitions are difficult, may impair our ability to predict demand and impact our supply mix, and may cause us to incur additional costs.

We build technology and introduce products for new and innovative use cases and applications such as our NVIDIA DGX Cloud services, our Omniverse platform, LLMs, and generative AI models. Our demand estimates for new use cases, applications, and services can be incorrect and create volatility in our revenue or supply levels, and we may not be able to generate significant revenue from these use cases, applications, and services. Recent technologies, such as generative AI models, have emerged, and while they have driven increased demand for Data Center, the long-term trajectory is unknown.

Global Trade

In August 2022, the U.S. government, or the USG, announced licensing requirements that, with certain exceptions, impact exports to China (including Hong Kong and Macau) and Russia of our A100 and H100 integrated circuits, DGX or any other systems or boards which incorporate A100 or H100 integrated circuits.

In July 2023, the USG informed us of an additional licensing requirement for a subset of A100 and H100 products destined to certain customers and other regions, including some countries in the Middle East.

In October 2023, the USG announced new and updated licensing requirements that became effective in our fourth quarter of fiscal year 2024 for exports to China and Country Groups D1, D4, and D5 (including but not limited to Saudi Arabia, the United Arab Emirates, and Vietnam, but excluding Israel) of our products exceeding certain performance thresholds, including A100, A800, H100, H800, L4, L40, L40S and RTX 4090. The licensing requirements also apply to the export of products exceeding certain performance thresholds to a party headquartered in, or with an ultimate parent headquartered in, Country Group D5, including China. On October 23, 2023, the USG informed us the licensing requirements were effective immediately for shipments of our A100, A800, H100, H800, and L40S products. We have not received licenses to ship these restricted products to China.

We expanded our Data Center product portfolio to offer new solutions, including those for which the USG does not require a license or advance notice before each shipment. We ramped new products designed specifically for China that do not require an export control license. Our Data Center revenue in China is down significantly from the level prior to the imposition of new export control restrictions in October 2023. To the extent that a customer requires products covered by the licensing requirements, we may seek a license for the customer but have no assurance that the USG will grant such a license, or that the USG will act on the license application in a timely manner or at all.

Our competitive position has been harmed, and our competitive position and future results may be further harmed in the long term, if there are further changes in the USG’s export controls. Given the increasing strategic importance of AI and rising geopolitical tensions, the USG has changed and may again change the export control rules at any time and further subject a wider range of our products to export restrictions and licensing requirements, negatively impacting our business and financial results. In the event of such change, we may be unable to sell our inventory of such products and may be unable to develop replacement products not subject to the licensing requirements, effectively excluding us from all or part of the China market, as well as other impacted markets, including the Middle East.

While we work to enhance the resiliency and redundancy of our supply chain, which is currently concentrated in the Asia-Pacific region, new and existing export controls or changes to existing export controls could limit alternative manufacturing locations and negatively impact our business. Refer to “Item 1A. Risk Factors” for a discussion of this potential impact.

</details>

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 669-682)

**AI reference: explicit | frame: business | roles: offering | kinds: generative_llm, recommendation | substantiveness: detailed**

> These increases reflect higher shipments of the NVIDIA Hopper GPU computing platform used for training and inferencing with large language models, recommendation engines, and generative AI applications.

> We unveiled the NVIDIA Blackwell platform, our next-generation GPU architecture for the new era of AI computing at trillion-parameter scale and the Blackwell-powered DGX SuperPOD for generative AI supercomputing.

> We introduced generative AI for digital humans, NVIDIA ACE for speech and animation, and new RTX technologies; and added support for new models.

<details><summary>Passage</summary>

Net income per diluted share | $ 5.98 | $ 4.93 | $ 0.82 | 21 % | 629 %

We specialize in markets where our computing platforms can provide tremendous acceleration for applications. These platforms incorporate processors, interconnects, software, algorithms, systems, and services to deliver unique value. Our platforms address four large markets where our expertise is critical: Data Center, Gaming, Professional Visualization, and Automotive.

Revenue was $26.0 billion, up 262% from a year ago and up 18% sequentially.

Data Center revenue was up 427% from a year ago and up 23% sequentially. Data Center compute revenue was $19.4 billion, up 478% from a year ago and up 29% sequentially. These increases reflect higher shipments of the NVIDIA Hopper GPU computing platform used for training and inferencing with large language models, recommendation engines, and generative AI applications. Networking revenue was $3.2 billion, up 242% from a year ago on strong growth of InfiniBand end-to-end solutions, and down 5% sequentially due to the timing of supply. Strong sequential Data Center growth was driven by all customer types, led by Enterprise and Consumer Internet companies. Large cloud providers continued to drive strong growth as they deploy and ramp NVIDIA AI infrastructure at scale, representing mid-40% of our Data Center revenue.

Gaming revenue was up 18% from a year ago and down 8% sequentially. The year-on-year increase primarily reflects higher demand. The sequential decrease reflects seasonally lower GPU sales for laptops.

Professional Visualization revenue was up 45% from a year ago and down 8% sequentially. The year-on-year increase primarily reflects higher sell-in to partners following the normalization of channel inventory levels. The sequential decrease was primarily due to desktop workstation GPUs.

Automotive revenue was up 11% from a year ago and up 17% sequentially. The year-on-year increase was driven primarily by self-driving platforms. The sequential increase was driven by AI Cockpit solutions and self-driving platforms.

Gross margin for the first quarter increased significantly from a year ago on strong Data Center revenue growth primarily driven by our Hopper GPU computing platform. Sequentially, gross margin benefited from lower inventory charges.

Operating expenses were up 39% from a year ago and up 10% sequentially. The increases were primarily driven by compensation and benefits, reflecting growth in employees and compensation.

Market Platform Highlights

Data Center revenue for the first quarter of fiscal year 2025 was $22.6 billion, up 427% from a year ago and up 23% from the previous quarter. In our trailing 4 quarters, we estimate that inference drove about 40% of our Data Center revenue. We unveiled the NVIDIA Blackwell platform, our next-generation GPU architecture for the new era of AI computing at trillion-parameter scale and the Blackwell-powered DGX SuperPOD for generative AI supercomputing. Joining Blackwell will be NVIDIA Quantum InfiniBand and Spectrum Ethernet switches designed for massive-scale AI. We also announced NVIDIA AI Enterprise 5.0 with NVIDIA NIM Inference Microservices — to speed enterprise app development. We announced that nine new supercomputers worldwide are using Grace Hopper Superchips to ignite a new era of AI supercomputing.

Gaming revenue for the first quarter of fiscal year 2025 was $2.6 billion, up 18% from a year ago and down 8% from the previous quarter. We introduced generative AI for digital humans, NVIDIA ACE for speech and animation, and new RTX technologies; and added support for new models.

Professional Visualization revenue for the first quarter of fiscal year 2025 was $427 million, up 45% from a year ago and down 8% from the previous quarter. We introduced NVIDIA RTX 500 and 1000 professional Ada generation laptop GPUs; unveiled NVIDIA RTX A400 and A1000 GPUs for desktop workstations, based on the NVIDIA Ampere architecture; and introduced NVIDIA Omniverse Cloud APIs to power industrial digital twin software tools.

Automotive revenue for the first quarter of fiscal year 2025 was $329 million, up 11% from a year ago and up 17% from the previous quarter. We revealed U.S. and China electric vehicle makers Lucid and IM Motors are using the NVIDIA DRIVE Orin platform; and announced BYD, XPENG, GAC's AION Hyper, Nuro and others will adopt its successor, NVIDIA DRIVE Thor.

</details>

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 718-720)

**AI reference: explicit | frame: business | roles: offering | kinds: generative_llm, recommendation | substantiveness: detailed**

> Compute GPU grew 497%, due to higher shipments of the NVIDIA Hopper GPU computing platform used for training and inferencing with large language models, recommendation engines, and generative AI applications.

<details><summary>Passage</summary>

Total | $ 16,909 | $ 2,140 | $ 14,769 | 690 %

Compute & Networking revenue – The year-on-year increase was due to higher Data Center revenue. Compute GPU grew 497%, due to higher shipments of the NVIDIA Hopper GPU computing platform used for training and inferencing with large language models, recommendation engines, and generative AI applications. Networking was up 242% on strong growth of InfiniBand end-to-end solutions.

Graphics revenue – The year-on-year increase of 18% was led by higher demand for Gaming.

</details>

## Item 1A Risk Factors (blocks 841-857)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: market_demand, strategic_competitive | mit: other | kinds: generative_llm | substantiveness: detailed | traits: hedging**

> the demand for accelerated computing or AI-related cloud services;

> We build technology and introduce products for new and innovative use cases and applications, such as NVIDIA DGX Cloud services, NVIDIA AI Foundations, Omniverse platform, LLMs, and generative AI models.

> Recent technologies, such as generative AI models, have emerged, and while they have driven increased demand for Data Center, the long-term trajectory is unknown.

<details><summary>Passage</summary>

business decisions made by third parties;

the demand for accelerated computing or AI-related cloud services;

changes that impact the ecosystem for the architectures underlying our products and technologies;

the demand for our products; or

government actions or changes in governmental policies, such as export controls or increased restrictions on gaming usage.

Our overall revenue, driven by data center compute, continued to grow through the first quarter of fiscal year 2025. We continue to gather customer demand indications across several product transitions. We have demand visibility for our data center products, including the recently announced Blackwell GPU architecture. We have previously increased our supply and capacity purchases with existing suppliers with planned receipts later this year. We continue to add new vendors and have entered and may continue to enter into prepaid manufacturing and capacity agreements to supply both current and future products. The increased purchase volumes and number of suppliers and integration of new vendors into our supply chain may create more complexity and execution risk. Our purchase commitments and obligations for inventory and manufacturing capacity at the end of the first quarter of fiscal year 2025 continued to be impacted by shortening lead times for certain components. We may incur inventory provisions or impairments if our inventory or supply or capacity commitments exceed demand for our products or demand declines. While supply for H100 continued to improve, we are still constrained on H200. Our next generation data center architecture, Blackwell, is in production, and we plan on shipping customer samples in the second quarter. We expect to ramp customer shipments of Blackwell in the second half of the fiscal year. We believe the initial demand for Blackwell is well ahead of the projected supply for this fiscal year. We expect supply constraints for our Blackwell offerings will continue into next year.

Our customer orders and longer-term demand estimates may change or may not be correct, as we have experienced in the past. Product transitions are complex and can impact our revenue as we often ship both new and prior architecture products simultaneously and we and our channel partners prepare to ship and support new products. Due to our product introduction cycles, we are almost always in various stages of transitioning the architectures of our Data Center, Gaming, and Professional Visualization products. We have begun a broader and faster Data Center product launch cadence to meet a growing and diverse set of AI opportunities. The increased frequency of these transitions may magnify the challenges associated with managing our supply and demand due to long manufacturing lead times. Qualification time for new products, customers anticipating product transitions and channel partners reducing channel inventory of prior architectures ahead of new product introductions can reduce or create volatility in our revenue. We have experienced and may in the future experience reduced demand for current generation architectures when customers anticipate transitions, and we may be unable to sell multiple product architectures at the same time for current and future architecture transitions. If we are unable to execute our architectural transitions as planned for any reason, our financial results may be negatively impacted. The increasing frequency and complexity of newly introduced products could result in unanticipated quality or production issues that could increase the magnitude of inventory provisions, warranty, or other costs or result in product delays. Deployment of new products to customers creates additional challenges due to the complexity of our technologies, which has impacted and may in the future impact the timing of customer purchases or otherwise impact our demand. While we have managed prior product transitions and have sold multiple product architectures at the same time, these transitions are difficult, may impair our ability to predict demand and impact our supply mix, and may cause us to incur additional costs.

Many end customers often do not purchase directly from us but instead purchase indirectly through multiple OEMs, ODMs, system integrators, distributors, and other channel partners. As a result, the decisions made by our multiple OEMs, ODMs, system integrators, distributors, and other channel partners, and in response to changing market conditions and changes in end-user demand for our products, have impacted and could in the future continue to impact our ability to accurately forecast demand, particularly as they are based on estimates provided by various downstream parties.

If we underestimate our customers' future demand for our products, our foundry partners may not have adequate lead-time or capacity to increase production and we may not be able to obtain sufficient inventory to fill orders on a timely basis. If our contract manufacturers experience supply constraints, we may not be able to increase supply to meet customer demand in a timely manner, or at all. If we cannot procure sufficient supply to meet demand or otherwise fail to fulfill our customers’ orders on a timely basis, or at all, our customer relationships could be damaged, we could lose revenue and market share and our reputation could be harmed. Additionally, since some of our products are part of a complex data center buildout, supply constraints or availability issues with respect to any one component have had and may have a broader revenue impact.

If we overestimate our customers’ future demand for our products, or if customers cancel or defer orders or choose to purchase from our competitors, we may not be able to reduce our inventory or other contractual purchase commitments. In the past, we have experienced a reduction in average selling prices, including due to channel pricing programs that we have implemented and may continue to implement, as a result of our overestimation of future demand, and we may need to continue these reductions. We have had to increase prices for certain of our products as a result of our suppliers’ increase in prices, and we may need to continue to do so for other products in the future. We have also written down our inventory, incurred cancellation penalties, and recorded impairments and may have to do so in the future. These impacts were amplified by our placement of non-cancellable and non-returnable purchasing terms well in advance of our historical lead times and could be exacerbated if we need to make changes to the design of future products. The risk of these impacts has increased and may continue to increase as our purchase obligations and prepaids have grown and are expected to continue to grow and become a greater portion of our total supply. All of these factors may negatively impact our gross margins and financial results.

We build technology and introduce products for new and innovative use cases and applications, such as NVIDIA DGX Cloud services, NVIDIA AI Foundations, Omniverse platform, LLMs, and generative AI models. Our demand estimates for new use cases, applications, and services can be incorrect and create volatility in our revenue or supply levels, and we may not be able to generate significant revenue from these use cases, applications, and services. Recent technologies, such as generative AI models, have emerged, and while they have driven increased demand for Data Center, the long-term trajectory is unknown. Because our products may be used in multiple use cases and applications, it is difficult for us to estimate with any reasonable degree of precision the impact of generative AI models on our reported revenue or forecasted demand. Additionally, we started shipping our CPU product offerings, the Grace CPU and Grace Hopper Superchips, in the third quarter of fiscal year 2024. Our inability to accurately predict our CPU demand may create volatility in our revenue or supply levels.

Challenges in estimating demand could become more pronounced or volatile in the future on both a global and regional basis. Extended lead times may occur if we experience other supply constraints caused by natural disasters, pandemics or other events. In addition, geopolitical tensions, such as those involving Taiwan and China, which comprise a significant portion of our revenue and where we have suppliers, contract manufacturers, and assembly partners who are critical to our supply continuity, could have a material adverse impact on us.

The use of our GPUs other than that for which they were designed and marketed, including new and unexpected use cases, has impacted and can in the future impact demand for our products, including by leading to inconsistent spikes and drops in demand. For example, several years ago, our Gaming GPUs began to be used for mining digital currencies, such as Ethereum. It is difficult for us to estimate with any reasonable degree of precision the past or current impact of cryptocurrency mining, or forecast the future impact of cryptocurrency mining, on demand for our products. Volatility in the cryptocurrency market, including new compute technologies, price changes in cryptocurrencies, government cryptocurrency policies and regulations, new cryptocurrency standards and changes in the method of verifying blockchain transactions, has impacted and can in the future impact cryptocurrency mining and demand for our products and can further impact our ability to estimate demand for our products. Changes to cryptocurrency standards and processes including, but not limited to, the Ethereum 2.0 merge in 2022, have reduced and may in the future decrease the usage of GPUs for Ethereum mining. This has created and may in the future create increased aftermarket sales of our GPUs, which could negatively impact retail prices for our GPUs and reduce demand for our new GPUs. In general, our new products or previously sold products may be resold online or on the unauthorized “gray market,” which also makes demand forecasting difficult. Gray market products and reseller marketplaces compete with our new products and distribution channels.

Additionally, we depend on developers, customers and other third parties to build, enhance, and maintain accelerated computing applications that leverage our platforms. We also rely on third-party content providers and publishers to make their content available on our platforms, such as GeForce NOW. Failure by developers, customers, and other third parties to build, enhance, and maintain applications that leverage our platforms, or failure by third-party content providers or publishers to make their content available on reasonable terms or at all for use by our customers or end users on our platforms, could adversely affect customer demand.

International sales and operations are a significant part of our business, which exposes us to risks that could harm our business.

We sell our products internationally, and we also have operations and conduct business internationally. Our semiconductor wafers are manufactured, assembled, tested and packaged by third parties located outside of the United States, and we generated 48% of our revenue during the first quarter in fiscal year 2025 from sales outside the United States. We have not received licenses from the USG to ship restricted products to China. We ramped new products designed specifically for China that do not require an export control license. Our Data Center revenue in China is down significantly from the level prior to the imposition of new export control restrictions in October 2023. We expect the market in China to remain very competitive going forward. The global nature of our business subjects us to a number of risks and uncertainties, which have had in the past and could in the future have a material adverse effect on our business, financial condition and results of operations. These include domestic and international economic and political conditions in countries in which we and our suppliers and manufacturers do business, government lockdowns to control case spread of global or local health issues, differing legal standards with respect to protection of IP and employment practices, different domestic and international business and cultural practices, disruptions to capital markets, counter-inflation policies, currency fluctuations, natural disasters, acts of war or other military actions, terrorism, public health issues and other catastrophic events.

We receive a significant amount of our revenue from a limited number of partners and distributors and we have a concentration of sales to customers who purchase directly or indirectly from us, and our revenue could be adversely affected if we lose or are prevented from selling to any of these customers.

</details>

## Item 1A Risk Factors (blocks 859-876)

**AI reference: explicit | frame: risk_factor | roles: governance, offering, risk | risk: national_security, regulatory_legal | mit: power_centralization_unfair_benefits, regulation_lagging_behind_ai | responses: policies_processes | kinds: generative_llm | substantiveness: detailed | traits: hedging**

> Our position in markets relating to AI has led to increased interest in our business from regulators worldwide, including the European Union, the United States, the United Kingdom, South Korea and China.

> For example, the EU AI Act will likely become law this year. Restrictions under this and any other regulations, if implemented, could increase the costs and burdens to us and our customers, delay or halt deployment of new systems using our products, and reduce the number of new entrants and customers, negatively impacting our business and financial results.

> The increasing focus on the risks and strategic importance of AI technologies has resulted in regulatory restrictions that target products and services capable of enabling or facilitating AI and may in the future result in additional restrictions impacting some or all of our product and service offerings.

<details><summary>Passage</summary>

Our operations could be affected by the complex laws, rules and regulations to which our business is subject, and political and other actions may adversely impact our business.

We are subject to laws and regulations domestically and worldwide, affecting our operations in areas including, but not limited to, IP ownership and infringement; taxes; import and export requirements and tariffs; anti-corruption, including the Foreign Corrupt Practices Act; business acquisitions; foreign exchange controls and cash repatriation restrictions; data privacy requirements; competition and antitrust; advertising; employment; product regulations; cybersecurity; environmental, health, and safety requirements; the responsible use of AI; sustainability; cryptocurrency; and consumer laws. Compliance with such requirements can be onerous and expensive, could impact our competitive position, and may negatively impact our business operations and ability to manufacture and ship our products. There can be no assurance that our employees, contractors, suppliers, customers or agents will not violate applicable laws or the policies, controls, and procedures that we have designed to help ensure compliance with such laws, and violations could result in fines, criminal sanctions against us, our officers, or our employees, prohibitions on the conduct of our business, and damage to our reputation. Changes to the laws, rules and regulations to which we are subject, or changes to their interpretation and enforcement, could lead to materially greater compliance and other costs and/or further restrictions on our ability to manufacture and supply our products and operate our business. For example, we may face increased compliance costs as a result of changes or increases in antitrust legislation, regulation, administrative rule making, increased focus from regulators on cybersecurity vulnerabilities and risks. Our position in markets relating to AI has led to increased interest in our business from regulators worldwide, including the European Union, the United States, the United Kingdom, South Korea and China. For example, the French Competition Authority collected information from us regarding our business and competition in the graphics card and cloud service provider market as part of an ongoing inquiry into competition in those markets. We have also received requests for information from regulators in the European Union, the United Kingdom, and China regarding our sales of GPUs, our efforts to allocate supply, foundation models and our investments, partnerships and other agreements with companies developing foundation models, and we expect to receive additional requests for information in the future. Governments and regulators are considering imposing restrictions on the hardware, software, and systems used to develop frontier foundation models and generative AI. For example, the EU AI Act will likely become law this year. Restrictions under this and any other regulations, if implemented, could increase the costs and burdens to us and our customers, delay or halt deployment of new systems using our products, and reduce the number of new entrants and customers, negatively impacting our business and financial results. Revisions to laws or regulations or their interpretation and enforcement could also result in increased taxation, trade sanctions, the imposition of or increase to import duties or tariffs, restrictions and controls on imports or exports, or other retaliatory actions, which could have an adverse effect on our business plans or impact the timing of our shipments. Additionally, changes in the public perception of governments in the regions where we operate or plan to operate could negatively impact our business and results of operations.

Government actions, including trade protection and national and economic security policies of U.S. and foreign government bodies, such as tariffs, import or export regulations, including deemed export restrictions and restrictions on the activities of U.S. persons, trade and economic sanctions, decrees, quotas or other trade barriers and restrictions could affect our ability to ship products, provide services to our customers and employees, do business without an export license with entities on the U.S. Department of Commerce’s U.S. Entity List or other USG restricted parties lists (which is expected to change from time to time), and generally fulfill our contractual obligations and have a material adverse effect on our business. If we were ever found to have violated export control laws or sanctions of the U.S. or similar applicable non-U.S. laws, even if the violation occurred without our knowledge, we may be subject to various penalties available under the laws, any of which could have a material and adverse impact on our business, operating results and financial condition.

For example, in response to the war in Ukraine, the United States and other jurisdictions imposed economic sanctions and export control measures which blocked the passage of our products, services and support into Russia, Belarus, and certain regions of Ukraine. In fiscal year 2023, we stopped direct sales to Russia and closed business operations in Russia. Concurrently, the war in Ukraine has impacted sales in EMEA and may continue to do so in the future.

The increasing focus on the risks and strategic importance of AI technologies has resulted in regulatory restrictions that target products and services capable of enabling or facilitating AI and may in the future result in additional restrictions impacting some or all of our product and service offerings.

Concerns regarding third-party use of AI for purposes contrary to local governmental interests, including concerns relating to the misuse of AI applications, models, and solutions, has resulted in and could in the future result in unilateral or multilateral restrictions on products that can be used for training, modifying, tuning, and deploying LLMs. Such restrictions have limited and could in the future limit the ability of downstream customers and users worldwide to acquire, deploy and use systems that include our products, software, and services, and negatively impact our business and financial results.

Such restrictions could include additional unilateral or multilateral export controls on certain products or technology, including but not limited to AI technologies. As geopolitical tensions have increased, semiconductors associated with AI, including GPUs and associated products, are increasingly the focus of export control restrictions proposed by stakeholders in the U.S. and its allies. The United States has imposed unilateral controls restricting GPUs and associated

products, and it is likely that additional unilateral or multilateral controls will be adopted. Such controls have been and may again be very broad in scope and application, prohibit us from exporting our products to any or all customers in one or more markets, including but not limited to China, and could negatively impact our manufacturing, testing and warehousing locations and options, or could impose other conditions that limit our ability to serve demand abroad and could negatively and materially impact our business, revenue and financial results. Export controls targeting GPUs and semiconductors associated with AI, which have been imposed and are increasingly likely to be further tightened, would further restrict our ability to export our technology, products, or services even though competitors may not be subject to similar restrictions, creating a competitive disadvantage for us and negatively impacting our business and financial results. Export controls targeting GPUs and semiconductors associated with AI have subjected and may in the future subject downstream users of our products to additional restrictions on the use, resale, repair, or transfer of our products, negatively impacting our business and financial results. Controls could negatively impact our cost and/or ability to provide services such as NVIDIA AI cloud services and could impact the cost and/or ability for our cloud service providers and customers to provide services to their end customers, even outside China.

Export controls could disrupt our supply chain and distribution channels, negatively impacting our ability to serve demand, including in markets outside China and for our gaming products. The possibility of additional export controls has negatively impacted and may in the future negatively impact demand for our products, benefiting competitors that offer alternatives less likely to be restricted by further controls. Repeated changes in the export control rules are likely to impose compliance burdens on our business and our customers, negatively and materially impacting our business.

Increasing use of economic sanctions and export controls has impacted and may in the future impact demand for our products or services, negatively impacting our business and financial results. Reduced demand due to export controls could also lead to excess inventory or cause us to incur related supply charges. Additional unilateral or multilateral controls are also likely to include deemed export control limitations that negatively impact the ability of our research and development teams to execute our roadmap or other objectives in a timely manner. Additional export restrictions may not only impact our ability to serve overseas markets, but also provoke responses from foreign governments, including China, that negatively impact our supply chain or our ability to provide our products and services to customers in all markets worldwide, which could also substantially reduce our revenue. Regulators in China have inquired about our sales and efforts to supply the China market and our fulfillment of the commitments we entered at the close of our Mellanox acquisition. If the regulators conclude that we have failed to fulfill such commitments or we have violated any applicable law in China, we could be subject to various penalties or restrictions on our ability to conduct our business, any of which could have a material and adverse impact on our business, operating results and financial condition.

During the third quarter of fiscal year 2023, the USG announced export restrictions and export licensing requirements targeting China’s semiconductor and supercomputing industries. These restrictions impact exports of certain chips, as well as software, hardware, equipment and technology used to develop, produce and manufacture certain chips to China (including Hong Kong and Macau) and Russia, and specifically impact our A100 and H100 integrated circuits, DGX or any other systems or boards which incorporate A100 or H100 integrated circuits. The licensing requirements also apply to any future NVIDIA integrated circuit achieving certain peak performance and chip-to-chip I/O performance thresholds, as well as any system or board that includes those circuits. There are also now licensing requirements to export a wide array of products, including networking products, destined for certain end users and for certain end uses in China. During the second quarter of fiscal year 2024, the USG also informed us of an additional licensing requirement for a subset of A100 and H100 products destined to certain customers and other regions, including some countries in the Middle East.

In October 2023, the USG announced new and updated licensing requirements that became effective in our fourth quarter of fiscal year 2024 for exports to China and Country Groups D1, D4, and D5 (including but not limited to, Saudi Arabia, the United Arab Emirates, and Vietnam, but excluding Israel) of our products exceeding certain performance thresholds, including A100, A800, H100, H800, L4, L40, L40S and RTX 4090. The licensing requirements also apply to the export of products exceeding certain performance thresholds to a party headquartered in, or with an ultimate parent headquartered in, Country Group D5, including China. On October 23, 2023, the USG informed us that the licensing requirements were effective immediately for shipments of our A100, A800, H100, H800, and L40S products. We have not received licenses to ship these restricted products to China.

Following these export controls, we transitioned some operations, including certain testing, validation, and supply and distribution operations out of China and Hong Kong. Any future transitions could be costly and time consuming, and adversely affect our research and development and supply and distribution operations, as well as our revenue, during any such transition period. We expanded our Data Center product portfolio to offer new solutions, including those for which the USG does not require a license or advance notice before each shipment. To the extent that a customer requires products covered by the licensing requirements, we may seek a license for the customer. However, the licensing process is time-consuming. We have no assurance that the USG will grant such a license or that the USG will act on the license application in a timely manner or at all. Even if a license is offered, it may impose burdensome conditions that we or our customer or end users cannot or decide not to accept. The USG is evaluating license requests in a closed process that does not have clear standards or an opportunity for review. For example, the Notified Advanced Computing, or “NAC,” process has not resulted in approvals for exports of products to customers in China. The license process for exports to D1 and D4 countries has been time-consuming and resulted in license conditions for countries outside China. The requirements have a disproportionate impact on NVIDIA and already have disadvantaged and may in the future

disadvantage NVIDIA against certain of our competitors who sell products that are not subject to the new restrictions or may be able to acquire licenses for their products.

Management of these new licenses and other requirements is complicated and time consuming. Our competitive position has been harmed, and our competitive position and future results may be further harmed, over the long-term, if there are further changes in the USG’s export controls, including further expansion of the geographic, customer, or product scope of the controls, if customers purchase product from competitors, if customers develop their own internal solution, if we are unable to provide contractual warranty or other extended service obligations, if the USG does not grant licenses in a timely manner or denies licenses to significant customers or if we incur significant transition costs. Even if the USG grants any requested licenses, the licenses may be temporary or impose burdensome conditions that we or our customers or end users cannot or choose not to fulfill. The licensing requirements may benefit certain of our competitors, as the licensing process will make our pre-sale and post-sale technical support efforts more cumbersome and less certain and encourage customers in China to pursue alternatives to our products, including semiconductor suppliers based in China, Europe, and Israel.

Given the increasing strategic importance of AI and rising geopolitical tensions, the USG has changed and may again change the export control rules at any time and further subject a wider range of our products to export restrictions and licensing requirements, negatively impacting our business and financial results. In the event of such change, we may be unable to sell our inventory of such products and may be unable to develop replacement products not subject to the licensing requirements, effectively excluding us from all or part of the China market, as well as other impacted markets, including the Middle East. For example, the USG has already imposed conditions to limit the ability of foreign firms to create and offer as a service large-scale GPU clusters, for example by imposing license conditions on the use of products to be exported to certain countries, or by requiring chip tracking and throttling mechanisms that would disable or impair GPUs if certain system or use conditions are detected. The USG has already imposed export controls restricting certain gaming GPUs, and if the USG expands such controls to restrict additional gaming products, it may disrupt a significant portion of our supply and distribution chain and negatively impact sales of such products to markets outside China, including the U.S. and Europe. In addition, as the performance of the gaming GPUs increases over time, export controls may have a greater impact on our ability to compete in markets subject to those controls. Export controls may disrupt our supply and distribution chain for a substantial portion of our products, which are warehoused in and distributed from Hong Kong. Export controls restricting our ability to sell data center GPUs may also negatively impact demand for our networking products used in servers containing our GPUs. The USG may also impose export controls on our networking products, such as high-speed network interconnects, to limit the ability of downstream parties to create large clusters for frontier model training. Any new control that impacts a wider range of our products would likely have a disproportionate impact on NVIDIA and may disadvantage us against certain of our competitors that sell chips that are outside the scope of such control. Excessive or shifting export controls have already and may in the future encourage customers outside China and other impacted regions to “design-out” certain U.S. semiconductors from their products to reduce the compliance burden and risk, and to ensure that they are able to serve markets worldwide. Excessive or shifting export controls have already encouraged and may in the future encourage overseas governments to request that our customers purchase from our competitors rather than NVIDIA or other U.S. firms, harming our business, market position, and financial results. As a result, excessive or shifting export controls may negatively impact demand for our products and services not only in China, but also in other markets, such as Europe, Latin America, and Southeast Asia. Excessive or shifting export controls increase the risk of investing in U.S. advanced semiconductor products, because by the time a new product is ready for market, it may be subject to new unilateral export controls restricting its sale. At the same time, such controls may increase investment in foreign competitors, which would be less likely to be restricted by U.S. controls.

Additionally, restrictions imposed by the Chinese government on the duration of gaming activities and access to games may adversely affect our Gaming revenue, and increased oversight of digital platform companies may adversely affect our Data Center revenue. The Chinese government may impose restrictions on the sale to certain customers of our products, or any products containing components made by our partners and suppliers. For example, the Chinese government announced restrictions relating to certain sales of products containing certain products made by Micron, a supplier of ours. Further restrictions on our products or the products of our suppliers could negatively impact our business and financial results.

Finally, our business depends on our ability to receive consistent and reliable supply from our overseas partners, especially in Taiwan. Any new restrictions that negatively impact our ability to receive supply of components, parts, or services from Taiwan, would negatively impact our business and financial results.

</details>

# Context passages: implicit mentions, not classified

## unknown section (blocks 8-9)

**Terms: Nvidia (NVIDIA)**

Commission file number: 0-23985

NVIDIA CORP ORATION

## unknown section (blocks 29-30)

**Terms: Nvidia (NVIDIA)**

The number of shares of common stock, $0.001 par value, outstanding as of May 24, 2024, was 2.46 billion.

NVIDIA Corporation

## Item 1 Legal Proceedings (blocks 54-62)

**Terms: Nvidia (NVIDIA)**

Investors and others should note that we announce material financial information to our investors using our investor relations website, press releases, SEC filings and public conference calls and webcasts. We also use the following social media channels as a means of disclosing information about the company, our products, our planned financial and other announcements and attendance at upcoming investor and industry conferences, and other matters, and for complying with our disclosure obligations under Regulation FD:

NVIDIA Corporate Blog (http://blogs.nvidia.com)

NVIDIA Technical Blog (http://developer.nvidia.com/blog/)

NVIDIA LinkedIn Page (http://www.linkedin.com/company/nvidia)

NVIDIA Facebook Page (https://www.facebook.com/nvidia)

NVIDIA Instagram Page (https://www.instagram.com/nvidia)

NVIDIA X Account (https://x.com/nvidia)

In addition, investors and others can view NVIDIA videos on YouTube (https://www.YouTube.com/nvidia).

The information we post through these social media channels may be deemed material. Accordingly, investors should monitor these accounts and the blog, in addition to following our press releases, SEC filings and public conference calls and webcasts. This list may be updated from time to time. The information we post through these channels is not a part of this Quarterly Report on Form 10-Q. These channels may be updated from time to time on NVIDIA's investor relations website.

## Item 1 Legal Proceedings (blocks 64-65)

**Terms: Nvidia (NVIDIA)**

Item 1. Financial Statements (Unaudited)

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 91-92)

**Terms: Nvidia (NVIDIA)**

See accompanying Notes to Condensed Consolidated Financial Statements.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 107-108)

**Terms: Nvidia (NVIDIA)**

See accompanying Notes to Condensed Consolidated Financial Statements.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 147-148)

**Terms: Nvidia (NVIDIA)**

See accompanying Notes to Condensed Consolidated Financial Statements.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 172-173)

**Terms: Nvidia (NVIDIA)**

See accompanying Notes to Condensed Consolidated Financial Statements.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 212-213)

**Terms: Nvidia (NVIDIA)**

See accompanying Notes to Condensed Consolidated Financial Statements.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 223-224)

**Terms: Nvidia (NVIDIA)**

Principles of Consolidation

Our condensed consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.

## Item 1 Legal Proceedings (blocks 230-231)

**Terms: Nvidia (NVIDIA)**

In December 2023, the FASB issued a new accounting standard which provides for new and updated income tax disclosures, including disaggregation of rate reconciliation and income taxes paid. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. We expect to adopt this standard in our annual reporting starting with fiscal year 2026. We are currently evaluating the impact of this standard on our Consolidated Financial Statements .

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 234-236)

**Terms: data center (data center)**

Note 2 - Leases

Our lease obligations primarily consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2025 and 2035.

Future minimum lease payments under our non-cancelable operating leases as of April 28, 2024 were as follows:

## Item 1 Legal Proceedings (blocks 250-252)

**Terms: data center (data centers)**

Long-term operating lease liabilities | $ 1,281

In addition, we have operating leases, primarily for our data centers, that are expected to commence during fiscal year 2025 with lease terms of 2 to 11 years for $ 923 million.

Operating lease expenses were $ 80 million and $ 59 million for the first quarter of fiscal years 2025 and 2024, respectively. Short-term and variable lease expenses for the first quarter of fiscal years 2025 and 2024 were not significant.

## Item 1 Legal Proceedings (blocks 259-260)

**Terms: Nvidia (NVIDIA)**

As of April 28, 2024, our operating leases had a weighted average remaining lease term of 6.3 years and a weighted average discount rate of 3.89 %. As of January 28, 2024, our operating leases had a weighted average remaining lease term of 6.1 years and a weighted average discount rate of 3.76 %.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 296-297)

**Terms: Nvidia (NVIDIA)**

(2) Calculated as net income divided by diluted weighted average shares.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 318-319)

**Terms: Nvidia (NVIDIA)**

Total | $ 31,211 | $ 3 | $ ( 112 ) | $ 31,102 | $ 7,251 | $ 23,851

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 347-348)

**Terms: Nvidia (NVIDIA)**

The gross unrealized losses are related to fixed income securities, driven primarily by changes in interest rates. Net realized gains and losses were not significant for all periods presented.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 383-384)

**Terms: Nvidia (NVIDIA)**

Our marketable equity securities have readily determinable fair values and are recorded in long-term other assets on our Condensed Consolidated Balance Sheets at fair value with changes in fair value recorded in Other income and expense, net on our Condensed Consolidated Statements of Income. Marketable equity securities totaled $ 287 million and $ 225 million as of April 28, 2024 and January 28, 2024, respectively. The net unrealized and realized gains and losses of investments in marketable securities were not significant for the first quarter of fiscal years 2025 and 2024.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 409-410)

**Terms: Nvidia (NVIDIA)**

Amortization expense associated with intangible assets was $ 143 million and $ 181 million for the first quarter of fiscal year 2025 and 2024, respectively.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 442-443)

**Terms: Nvidia (NVIDIA)**

(1) As of April 28, 2024 and January 28, 2024, there were an additional $ 3.3 billion and $ 2.5 billion of short-term prepaid supply and capacity agreements included in Prepaid expenses and other current assets, respectively.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 481-482)

**Terms: Nvidia (NVIDIA)**

Revenue allocated to remaining performance obligations, which includes deferred revenue and amounts that will be invoiced and recognized as revenue in future periods, was $ 1.3 billion as of April 28, 2024. We expect to recognize approximately 38 % of this revenue over the next twelve months and the remainder thereafter. This excludes revenue related to performance obligations for contracts with a length of one year or less.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 513-514)

**Terms: Nvidia (NVIDIA)**

As of April 28, 2024, we were in compliance with the required covenants, which are non-financial in nature, under the outstanding notes.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 543-544)

**Terms: Nvidia (NVIDIA)**

We have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Condensed Consolidated Financial Statements for such indemnifications.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 548-552)

**Terms: GPU (GPU), Nvidia (NVIDIA)**

Securities Class Action and Derivative Lawsuits

The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses, including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. On August 25, 2023, a majority of a three-judge Ninth Circuit panel affirmed in part and reversed in part the district court’s dismissal of the case, with a third judge dissenting on the basis that the district court did not err in dismissing the case. On November 15, 2023, the Ninth Circuit denied NVIDIA’s petition for rehearing en banc of the Ninth Circuit panel’s majority decision to reverse in part the dismissal of the case, which NVIDIA had filed on October 10, 2023. On November 21, 2023, NVIDIA filed a motion with the Ninth Circuit for a stay of the mandate pending NVIDIA’s petition for a writ of certiorari in the Supreme Court of the United States and the Supreme Court’s resolution of the matter. On December 5, 2023, the Ninth Circuit granted NVIDIA’s motion to stay the mandate. NVIDIA filed a petition for a writ of certiorari on March 4, 2024. Four amicus briefs in support of NVIDIA’s petition were filed on April 5, 2024.

The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The stay remains in place. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

Another putative derivative action was filed on October 30, 2023 in the Court of Chancery of the State of Delaware, captioned Horanic v. Huang, et al. (Case No. 2023-1096-KSJM). This lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty and insider trading based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and reform of unspecified corporate governance measures. This derivative matter is stayed pending the final resolution of In Re NVIDIA Corporation Securities Litigation action.

## Item 1 Legal Proceedings (blocks 554-555)

**Terms: Nvidia (NVIDIA)**

As of April 28, 2024, there are no accrued contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 577-578)

**Terms: Nvidia (NVIDIA)**

Operating income (loss) | $ 2,160 | $ 1,046 | $ ( 1,066 ) | $ 2,140

NVIDIA Corporation and Subsidiaries

## Item 1 Legal Proceedings (blocks 604-606)

**Terms: data center (Data Center)**

Revenue:

Data Center | $ 22,563 | $ 4,284

Compute | 19,392 | 3,357

## Item 1 Legal Proceedings (blocks 612-613)

**Terms: Nvidia (NVIDIA)**

Total revenue | $ 26,044 | $ 7,192

NVIDIA Corporation and Subsidiaries

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 636-639)

**Terms: Nvidia (NVIDIA)**

This Quarterly Report on Form 10-Q contains forward-looking statements based on management’s beliefs and assumptions and on information currently available to management. In some cases, you can identify forward-looking statements by terms such as “may,” “will,” “should,” “could,” “goal,” “would,” “expect,” “plan,” “anticipate,” “believe,” “estimate,” “project,” “predict,” “potential” and similar expressions intended to identify forward-looking statements. These statements involve known and unknown risks, uncertainties and other factors, which may cause our actual results, performance, time frames or achievements to be materially different from any future results, performance, time frames or achievements expressed or implied by the forward-looking statements. We discuss many of these risks, uncertainties and other factors in this Quarterly Report on Form 10-Q and our Annual Report on Form 10-K for the fiscal year ended January 28, 2024 in greater detail under the heading “Risk Factors” of such reports. Given these risks, uncertainties, and other factors, you should not place undue reliance on these forward-looking statements. Also, these forward-looking statements represent our estimates and assumptions only as of the date of this filing. You should read this Quarterly Report on Form 10-Q completely and understand that our actual future results may be materially different from what we expect. We hereby qualify our forward-looking statements by these cautionary statements. Except as required by law, we assume no obligation to update these forward-looking statements publicly, or to update the reasons actual results could differ materially from those anticipated in these forward-looking statements, even if new information becomes available in the future.

All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries.

© 2024 NVIDIA Corporation. All rights reserved.

The following discussion and analysis of our financial condition and results of operations should be read in conjunction with the risk factors set forth in Item 1A. “Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended January 28, 2024 and Part II, Item 1A. “Risk Factors” of this Quarterly Report on Form 10-Q and our Condensed Consolidated Financial Statements and related Notes thereto, as well as other cautionary statements and risks described elsewhere in this Quarterly Report on Form 10-Q and our other filings with the SEC, before deciding to purchase, hold, or sell shares of our common stock.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 724-726)

**Terms: Nvidia (NVIDIA)**

Revenue by geographic region is designated based on the billing location even if the revenue may be attributable to end customers, such as enterprises and gamers in a different location. Revenue from sales to customers outside of the United States accounted for 48% and 67% of total revenue for the first quarter of fiscal years 2025 and 2024, respectively.

We refer to customers who purchase products directly from NVIDIA as direct customers, such as original equipment manufacturers, or OEMs, original device manufacturers, or ODMs, system integrators, add-in board manufacturers, and distributors. We also have indirect customers, who purchase products through our direct customers; indirect customers include public cloud providers, consumer internet companies, enterprises, startups, and public sector entities.

Sales to one direct customer, Customer A, represented 13% of total revenue and sales to a second direct customer, Customer B, represented 11% of total revenue for the first quarter of fiscal year 2025, both of which were attributable to the Compute & Networking segment.

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 730-732)

**Terms: data center (Data Center)**

Gross profit consists of total net revenue less cost of revenue.

Our overall gross margin increased to 78.4% for the first quarter of fiscal year 2025 from 64.6% for the first quarter of fiscal year 2024. The year over year increase was primarily due to strong Data Center revenue growth of 427%.

Provisions for inventory and excess inventory purchase obligations totaled $393 million and $134 million for the first quarter of fiscal years 2025 and 2024, respectively. Sales of previously reserved inventory and settlements of excess inventory purchase obligations resulted in a provision release of $114 million and $50 million for the first quarter of fiscal years 2025 and 2024, respectively. The net effect on our gross margin was an unfavorable impact of 1.1% and 1.2% in the first quarter of fiscal years 2025 and 2024, respectively.

## Item 4 Controls and Procedures (blocks 819-820)

**Terms: Nvidia (NVIDIA)**

Inherent Limitations on Effectiveness of Controls

Our management, including our Chief Executive Officer and Chief Financial Officer, does not expect that our disclosure controls and procedures or our internal controls, will prevent all error and all fraud. A control system, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within NVIDIA have been detected.

## Item 1A Risk Factors (blocks 825-826)

**Terms: Nvidia (NVIDIA)**

Other than the risk factors listed below, there have been no material changes from the risk factors previously described under Item 1A of our Annual Report on Form 10-K for the fiscal year ended January 28, 2024.

Purchasing or owning NVIDIA common stock involves investment risks including, but not limited to, the risks described in Item 1A of our Annual Report on Form 10-K for the fiscal year ended January 28, 2024, and below. Any one of those risks could harm our business, financial condition and results of operations or reputation, which could cause our stock price to decline. Additional risks, trends and uncertainties not presently known to us or that we currently believe are immaterial may also harm our business, financial condition, results of operations or reputation.

## Item 1A Risk Factors (blocks 836-838)

**Terms: data center (data center)**

rapidly changing technology or customer requirements;

the availability of sufficient data center capacity and energy for customers to procure;

new product introductions and transitions resulting in less demand for existing products;

## Item 2 Unregistered Sales of Equity Securities and Use of Proceeds (blocks 879-881)

**Terms: Nvidia (NVIDIA)**

In August 2023, our Board of Directors approved a $25.0 billion increase to our share repurchase program without expiration. During the first quarter of fiscal year 2025, we repurchased 9.9 million shares of our common stock for $8.0 billion. As of April 28, 2024, we were authorized, subject to certain specifications, to repurchase up to $14.5 billion of additional shares of our common stock.

The repurchases can be made in the open market, in privately negotiated transactions, pursuant to a Rule 10b5-1 trading plan or in structured share repurchase programs, and can be made in one or more larger repurchases, in compliance with Rule 10b-18 of the Exchange Act, subject to market conditions, applicable legal requirements, and other factors. The program does not obligate NVIDIA to acquire any particular amount of common stock and the program may be suspended at any time at our discretion.

In the first quarter of fiscal year 2025, we paid $98 million in cash dividends. Our cash dividend program and the payment of future cash dividends under that program are subject to our Board of Directors' continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.

## Item 6 Exhibits (blocks 900-902)

**Terms: Nvidia (NVIDIA)**

Exhibit No. | Exhibit Description | Incorporated by Reference — Schedule/Form | Exhibit | Filing Date

3.1 | Bylaws of NVIDIA Corporation, Amended and Restated as of March 12, 2024 | 8-K | 3.1 | 3/14/2024

10.1+ | Variable Compensation Plan - Fiscal Year 2025 | 8-K | 10.1 | 3/14/2024

## Item 6 Exhibits (blocks 919-920)

**Terms: Nvidia (NVIDIA)**

Copies of above exhibits not contained herein are available to any shareholder upon written request to:

Investor Relations: NVIDIA Corporation, 2788 San Tomas Expressway, Santa Clara, CA 95051.

## Item 6 Exhibits (blocks 923-925)

**Terms: Nvidia (NVIDIA)**

Date: May 29, 2024

NVIDIA Corporation

By: | /s/ Colette M. Kress
