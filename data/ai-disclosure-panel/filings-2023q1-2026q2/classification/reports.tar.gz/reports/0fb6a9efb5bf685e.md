# Salesforce, Inc. | 10-Q | fiscal year 2024

- Report length: 46,099 words
- Direct AI mentions (classified): 12, of which about AI: 12, false candidates: 0, flagged for review: 0
- Context passages (not classified): 26; groups: industry (19), compute_infrastructure (13), general (1), data_training (1)
- Frames: risk_factor (9), business (3)
- Roles: risk (9), offering (3)
- Risk types: regulatory_legal (6), operational_reliability (2), reputational_ethical (2), market_demand (2), strategic_competitive (1), information_integrity (1)
- MIT subdomains: other (3), lack_of_capability_robustness (2), regulation_lagging_behind_ai (2), exposure_to_toxic_content (2), unfair_discrimination_misrepresentation (2), compromise_of_privacy (2), devaluation_of_human_effort (2), false_or_misleading_information (1)
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: unspecified (9), generative_llm (3), traditional_ml (1)
- Substantiveness: generic (8), specific (3), detailed (1)
- Disclosure traits: hedging (8)
- Trait activation rate: 0.667 (boilerplate (0.0), hedging (0.667), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 1A (8), Item 2 (3), Item 1 (1)
- Named entities: Customer 360, Einstein GPT

## Item 1 LEGAL PROCEEDINGS (blocks 259-260)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> With the Customer 360 platform, the Company delivers a single source of truth, connecting customer data with integrated artificial intelligence across systems, apps and devices to help companies sell, service, market and conduct commerce from anywhere.

<details><summary>Passage</summary>

Description of Business

Salesforce, Inc. (the “Company”) is a global leader in customer relationship management technology that brings companies and customers together. With the Customer 360 platform, the Company delivers a single source of truth, connecting customer data with integrated artificial intelligence across systems, apps and devices to help companies sell, service, market and conduct commerce from anywhere. Since its founding in 1999, Salesforce has pioneered innovations in cloud, mobile, social, analytics and artificial intelligence, enabling companies of every size and industry to transform their businesses in the all-digital, work-from-anywhere era.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 683-685)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: operational_reliability, regulatory_legal | mit: lack_of_capability_robustness, regulation_lagging_behind_ai | kinds: unspecified | substantiveness: generic | traits: hedging**

> uncertainties regarding AI technologies and its integration into our product offerings; the effect of evolving domestic and foreign government regulations, including those related to the provision of services on the Internet, those related to accessing the Internet, and those addressing data privacy, cybersecurity, cross-border data transfers and import and export controls;

<details><summary>Passage</summary>

ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

This Quarterly Report on Form 10-Q contains forward-looking statements within the meaning of Section 27A of the Securities Act of 1933, as amended (“Securities Act”), and Section 21E of the Securities Exchange Act of 1934, as amended (“Exchange Act”). Words such as “expects,” “anticipates,” “aims,” “projects,” “intends,” “plans,” “believes,” “estimates,” “seeks,” “assumes,” “may,” “should,” “could,” “would,” “foresees,” “forecasts,” “predicts,” “targets” and “commitments,” and variations of such words and similar expressions are intended to identify such forward-looking statements, which may consist of, among other things, trend analyses and statements regarding future events, future financial performance, anticipated growth, and industry prospects. These forward-looking statements are based on current expectations, estimates and forecasts, as well as the beliefs and assumptions of our management, and are subject to risks and uncertainties that are difficult to predict, including: our ability to maintain security levels and service performance that meet the expectations of our customers, and the resources and costs required to avoid unanticipated downtime and prevent, detect and remediate performance degradation and security breaches; the expenses associated with our data centers and third-party infrastructure providers; our ability to secure additional data center capacity; our reliance on third-party hardware, software and platform providers; uncertainties regarding AI technologies and its integration into our product offerings; the effect of evolving domestic and foreign government regulations, including those related to the provision of services on the Internet, those related to accessing the Internet, and those addressing data privacy, cybersecurity, cross-border data transfers and import and export controls; current and potential litigation involving us or our industry, including litigation involving acquired entities, and the resolution or settlement thereof; regulatory developments and regulatory investigations involving us or affecting our industry; our ability to successfully introduce new services and product features, including any efforts to expand our services; the success of our strategy of acquiring or making investments in complementary businesses, joint ventures, services, technologies and intellectual property rights; our ability to complete, on a timely basis or at all, announced transactions; our ability to realize the benefits from acquisitions, strategic partnerships, joint ventures and investments, and successfully integrate acquired businesses and technologies; our ability to compete in the markets in which we participate; the success of our business strategy and our plan to build our business, including our strategy to be a leading provider of enterprise cloud computing applications and platforms; our ability to execute our business plans; our ability to continue to grow unearned revenue and remaining performance obligation; the pace of change and innovation in enterprise cloud computing services; the seasonal nature of our sales cycles; our ability to limit customer attrition and costs related to those efforts; the success of our international expansion strategy; the demands on our personnel and infrastructure resulting from significant growth in our customer base and operations, including as a result of acquisitions; our ability to preserve our workplace culture, including as a result of our decisions regarding our current and future office environments or remote work policies; our dependency on the development and maintenance of the infrastructure of the Internet; our real estate and office facilities strategy and related costs and uncertainties; fluctuations in, and our ability to predict, our operating results and cash flows; the variability in our results arising from the accounting for term license revenue products; the performance and fair value of our investments in complementary businesses through our strategic investment portfolio; the impact of future gains or losses from our strategic investment portfolio, including gains or losses from overall market conditions that may affect the publicly traded companies within our strategic investment portfolio; our ability to protect our intellectual property rights; our ability to maintain and enhance our brands; the impact of foreign currency exchange rate and interest rate fluctuations on our results; the valuation of our deferred tax assets and the release of related valuation allowances; the potential availability of additional tax assets in the future; the impact of new accounting pronouncements and tax laws; uncertainties affecting our ability to estimate our tax rate; uncertainties regarding our tax obligations in connection with potential jurisdictional transfers of intellectual property, including the tax rate, the timing of transfers and the value of such transferred intellectual property; uncertainties regarding the effect of general economic, business and market conditions, including inflationary pressures, general economic downturn or recession, market volatility, increasing interest rates, changes in monetary policy and the prospect of a shutdown of the U.S. federal government; the potential impact of financial institution instability; the impact of geopolitical events, including the war in Ukraine and the Israel-Hamas war; uncertainties regarding the impact of expensing stock options and other equity awards; the sufficiency of our capital resources; our ability to execute our share repurchase program; our ability to comply with our debt covenants and lease obligations; the impact of climate change, natural disasters and actual or threatened public health emergencies; expected benefits of and timing of completion of the restructuring plan and the expected costs and charges of the restructuring plan, including, among other things, the risk that the restructuring costs and charges may be greater than we anticipate, our restructuring efforts may adversely affect our internal programs and ability to recruit and retain skilled and motivated personnel, our restructuring efforts may be distracting to employees and management, our restructuring efforts may negatively impact our business operations and reputation with or ability to serve customers, and our restructuring efforts may not generate their intended benefits to the extent or as quickly as anticipated; and our ability to achieve our aspirations, goals and projections related to our environmental, social and governance (“ESG”) initiatives, including our ability to comply with evolving legal standards and federal and state regulations concerning ESG matters.

These and other risks and uncertainties may cause our actual results or outcomes to differ materially and adversely from those expressed in our forward-looking statements. Readers are directed to risks and uncertainties identified below under “Risk Factors” and elsewhere in this report for additional detail regarding factors that may cause actual results or outcomes to be different than those expressed in our forward-looking statements. Except as required by law, we undertake no obligation to revise or update publicly any forward-looking statements for any reason.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 688-691)

**AI reference: explicit | frame: business | roles: offering | kinds: generative_llm | substantiveness: specific**

> We are investing in generative artificial intelligence across all products that will change how our customers help their customers.

> Over the long term, we expect to see additional operating expense improvements while also continuing to invest for growth, innovate our service offerings, including our artificial intelligence service offerings, and expand our leadership role in the cloud computing industry.

<details><summary>Passage</summary>

Salesforce, Inc. is a global leader in customer relationship management (“CRM”) technology that brings companies and customers together in the digital age. Founded in 1999, we enable companies of every size and industry to take advantage of powerful technologies to connect to their customers in a whole new way and help them transform their businesses around the customer in this digital-first world.

Our Customer 360 platform unites sales, service, marketing, commerce and IT teams by connecting customer data across systems, apps and devices to create a complete view of customers. With this single source of customer truth, teams can be more responsive, productive and efficient, deliver intelligent, personalized experiences across every channel and increase productivity. With Slack, we provide a digital headquarters where companies, employees, governments and stakeholders can create success from anywhere. We are investing in generative artificial intelligence across all products that will change how our customers help their customers.

We continue to focus on several key growth levers, including driving multiple service offering adoption, increasing our penetration with enterprise and international customers and expanding our industry-specific reach with more vertical software solutions. These growth levers often require a more sophisticated go-to-market approach and, as a result, we may incur additional costs upfront to obtain new customers and expand our relationships with existing customers, including additional sales and marketing expenses specific to subscription and support revenue. As a result, we have seen that customers with many of these characteristics drive higher annual revenues and have lower attrition rates than our company average.

In addition to our focus on top line growth levers, we are also focused on reducing our operating expenses to improve our operating margin. For example, in January 2023, we announced a restructuring plan (the “Restructuring Plan”) intended to reduce operating costs, improve operating margins, and continue advancing our ongoing commitment to profitable growth. The Restructuring Plan included a reduction of our workforce by approximately ten percent and office space reductions within certain markets, both of which were largely complete as of the first quarter of fiscal 2024. In addition to the Restructuring Plan, we continue to focus on evaluating and operationalizing future programs to further our transformational efforts. We have started to see improvements in our operating expenses across all operating categories, with the most opportunity in sales a nd marketing expense and general and administrative expenses. Over the long term, we expect to see additional operating expense improvements while also continuing to invest for growth, innovate our service offerings, including our artificial intelligence service offerings, and expand our leadership role in the cloud computing industry.

</details>

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 861-863)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> We continue to invest in technology to support the development of new, and improve existing, technologies, including our artificial intelligence technologies, and the integration of acquired technologies combined with our anticipated revenue growth in line with these incremental expenses.

<details><summary>Passage</summary>

For the three and nine months ended October 31, 2023, the decrease in research and development expenses in absolute dollars and as a percentage of revenue was primarily due to a decrease in employee-related costs, including stock-based compensation expense. Our research and development headcount decreased by four percent since October 31, 2022 due, in part, to the Restructuring Plan and our hiring pause that began in the second quarter of fiscal 2023.

We expect that research and development expenses will likely remain consistent or increase as a percentage of revenues in the near term. We continue to invest in technology to support the development of new, and improve existing, technologies, including our artificial intelligence technologies, and the integration of acquired technologies combined with our anticipated revenue growth in line with these incremental expenses.

For the three and nine months ended October 31, 2023, the decrease in marketing and sales expenses in absolute dollars and as a percentage of revenue was primarily due to a decrease in employee-related costs, including stock-based compensation expense. Our marketing and sales headcount decreased by 18 percent since October 31, 2022 due, in part, to the Restructuring Plan and our hiring pause that began in second quarter of fiscal 2023.

</details>

## Item 1A RISK FACTORS (blocks 1011-1013)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: reputational_ethical | mit: exposure_to_toxic_content, unfair_discrimination_misrepresentation | kinds: unspecified | substantiveness: generic**

> Social and ethical issues, including the use or capabilities of AI in our offerings.

<details><summary>Passage</summary>

Any discontinuance by third-party developers and providers in embracing our technology delivery model and enterprise cloud computing services, or customers asking us for warranties for third-party applications, integrations, data and content.

Social and ethical issues, including the use or capabilities of AI in our offerings.

Risks related to our aspirations and disclosures related to ESG matters.

</details>

## Item 1A RISK FACTORS (blocks 1145-1147)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: market_demand | mit: other | kinds: unspecified | substantiveness: generic | traits: hedging**

> Pricing and packaging strategies for enterprise and other customers for subscriptions to our existing and future service offerings, including for our AI offerings, may not be widely accepted by new or existing customers.

<details><summary>Passage</summary>

In addition, larger customers and governmental entities often demand more configuration, integration services and features. As a result of these factors, these sales opportunities often require us to devote greater sales support and professional services resources to individual customers, driving up costs and time required to complete sales and diverting our own sales and professional services resources to a smaller number of larger transactions, while potentially requiring us to delay revenue recognition on some of these transactions until the technical or implementation requirements have been met.

Pricing and packaging strategies for enterprise and other customers for subscriptions to our existing and future service offerings, including for our AI offerings, may not be widely accepted by new or existing customers. Our adoption of or failure to adopt, as well as the manner and time of, changes to our pricing and packaging models and strategies may harm our business.

For large enterprise customers, professional services are often performed by us, a third party, or a combination of our own staff and a third party. Our strategy is to work with third parties to increase the breadth of capability and depth of capacity for delivery of these services to our customers. If a customer is not satisfied with the quality of work performed by us or a third party or with the type of services or solutions delivered, we could incur additional costs to address the situation, the profitability of that work might be impaired, and the customer’s dissatisfaction with our services could damage our ability to obtain additional work from that customer. In addition, negative publicity related to our customer relationships, regardless of its accuracy, may further damage our business by affecting our ability to compete for new business with current or prospective customers.

</details>

## Item 1A RISK FACTORS (blocks 1168-1173)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: market_demand, strategic_competitive | mit: other | kinds: unspecified | substantiveness: generic | traits: hedging**

> Our efforts to expand our current service offerings may not succeed and may reduce our revenue growth rate. In addition, the markets for certain of our offerings, including our AI offerings, remain relatively new and it is uncertain whether our efforts, and related investments, will ever result in significant revenue for us.

> If we are unable to develop enhancements to, and new features for, our existing or new services that keep pace with rapid technological developments, our business could be harmed. For example, we may be required to continuously enhance our AI offerings to improve the quality of content provided to our customers.

<details><summary>Passage</summary>

Our efforts to expand our service offerings and to develop and integrate our existing services in order to keep pace with technological developments may not succeed and may reduce our revenue growth rate and harm our business.

We derive a significant portion of our revenue from subscriptions to our CRM enterprise cloud computing application services, and we expect this will continue for the foreseeable future. Our efforts to expand our current service offerings may not succeed and may reduce our revenue growth rate. In addition, the markets for certain of our offerings, including our AI offerings, remain relatively new and it is uncertain whether our efforts, and related investments, will ever result in significant revenue for us. Further, the introduction of significant platform changes and upgrades may not result in long term revenue growth.

T a b l e o f C o n t e n t s

In July 2021, we completed our acquisition of Slack, our largest acquisition to date. Slack is a relatively new category of business technology in a rapidly evolving market for software, programs and tools used by knowledge workers. We may not succeed in enhancing and improving the features, integrations and capabilities of Slack, or effectively introduce compelling new features, integrations and capabilities that reflect or anticipate the changing nature of the market which may result in an inability to attract new users and organizations and increase revenue from existing paid customers.

If we are unable to develop enhancements to, and new features for, our existing or new services that keep pace with rapid technological developments, our business could be harmed. For example, we may be required to continuously enhance our AI offerings to improve the quality of content provided to our customers. The success of enhancements, new features and services depends on several factors, including the timely completion, introduction and market acceptance of the feature, service or enhancement by customers, administrators and developers, as well as our ability to integrate all of our product and service offerings and develop adequate selling capabilities in new markets. Failure in this regard may significantly impair our revenue growth as well as negatively impact our operating results if the additional costs are not offset by additional revenues. In addition, because our services are designed to operate over various network technologies and on a variety of mobile devices, operating systems and computer hardware and software platforms using a standard browser, we will need to continuously modify and enhance our services to keep pace with changes in hardware, software, communication, browser, app development platform and database technologies, as well as continue to maintain and support our services on legacy systems. We may not be successful in either developing these modifications and enhancements or in bringing them to market timely.

Additionally, if we fail to anticipate or identify significant technology trends and developments early enough, or if we do not devote appropriate resources to adapting to such trends and developments, our business could be harmed. Uncertainties about the timing and nature of new network platforms or technologies, modifications to existing platforms or technologies, including text messaging capabilities, or changes in customer usage patterns thereof could increase our research and development or service delivery expenses or lead to our increased reliance on certain vendors. Any failure of our services to operate effectively with future network platforms and technologies could reduce the demand for our services, result in customer dissatisfaction and harm our business.

</details>

## Item 1A RISK FACTORS (blocks 1183-1186)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: information_integrity, operational_reliability, regulatory_legal, reputational_ethical | mit: compromise_of_privacy, exposure_to_toxic_content, false_or_misleading_information, lack_of_capability_robustness, unfair_discrimination_misrepresentation | kinds: generative_llm, traditional_ml | substantiveness: detailed | traits: hedging**

> Social and ethical issues, including the use or capabilities of AI in our offerings, may result in reputational harm and liability.

> We are increasingly building AI into many of our offerings, including generative AI. As with many innovations, AI and our Customer 360 platform present additional risks and challenges that could affect their adoption and therefore our business. For example, the development of AI and Customer 360, the latter of which provides information regarding our customers’ customers, presents emerging ethical issues. If we enable or offer solutions that draw controversy due to their perceived or actual impact on human rights, privacy, employment, or in other social contexts, we may experience new or enhanced governmental or regulatory scrutiny, brand or reputational harm, competitive harm or legal liability.

> Known risks of generative AI currently include risks related to accuracy, bias, toxicity, privacy, and security and data provenance. For example, AI technologies, including generative AI, may create content that appears correct but is factually inaccurate or flawed, or contains copyrighted or other protected material, and if our customers or others use this flawed content to their detriment, we may be exposed to brand or reputational harm, competitive harm, and/or legal liability.

<details><summary>Passage</summary>

Our success depends on the willingness of a growing community of third-party developers and technology providers to build applications and provide integrations, data and content that are complementary to our services. Without the continued development of these applications and provision of such integrations, data and content, both current and potential customers may not find our services sufficiently attractive, which could impact future sales. In addition, for those customers who authorize a third-party technology partner to access their data, we do not provide any warranty related to the functionality, security or integrity of the data access, transmission or processing. Despite contract provisions to protect us, customers may look to us to support and provide warranties for the third-party applications, integrations, data and content, even though not developed or sold by us, which may expose us to potential claims, liabilities and obligations, all of which could harm our reputation and our business.

Social and ethical issues, including the use or capabilities of AI in our offerings, may result in reputational harm and liability.

Policies we adopt or choose not to adopt on social and ethical issues, especially regarding the use of our products, may be unpopular with some of our employees or with our customers or potential customers, and have in the past impacted and may in the future impact our ability to attract or retain employees and customers. We also may choose not to conduct business with potential customers or discontinue or not expand business with existing customers due to these policies. Further, actions taken by our customers and employees, including through the use or misuse of our products or new technologies for illegal activities or improper information sharing, may result in reputational harm or possible liability, particularly in light of upcoming regulatory requirements like the Digital Services Act (“DSA”) from the EU. For example, we have been subject to allegations in legal proceedings that we should be liable for the use of certain of our products by third parties. Although we believe that we have a strong defense against these allegations, legal proceedings can be lengthy, expensive and disruptive to our operations and the outcome of any claims or litigation, regardless of the merits, is inherently uncertain. Regardless of outcome, these types of claims could cause reputational harm to our brand or result in liability.

We are increasingly building AI into many of our offerings, including generative AI. As with many innovations, AI and our Customer 360 platform present additional risks and challenges that could affect their adoption and therefore our business. For example, the development of AI and Customer 360, the latter of which provides information regarding our customers’ customers, presents emerging ethical issues. If we enable or offer solutions that draw controversy due to their perceived or actual impact on human rights, privacy, employment, or in other social contexts, we may experience new or enhanced governmental or regulatory scrutiny, brand or reputational harm, competitive harm or legal liability. Data practices by us or others that result in controversy could also impair the acceptance of AI solutions. This in turn could undermine confidence in the decisions, predictions, analysis or other content that our AI applications produce, subjecting us to competitive harm, legal liability and brand or reputational harm. The rapid evolution of AI will require the application of resources to develop, test and maintain our products and services to help ensure that AI is implemented ethically in order to minimize unintended, harmful impact. Uncertainty around new and emerging AI applications such as generative AI content creation will require additional investment in the development of proprietary datasets, machine learning models and systems to test for accuracy, bias and other variables, which are often complex, may be costly and could impact our profit margin. Moreover, the move from AI content classification to AI content generation through our development of Einstein GPT and other generative AI products brings additional risks and responsibility. Known risks of generative AI currently include risks related to accuracy, bias, toxicity, privacy, and security and data provenance. For example, AI technologies, including generative AI, may create content that appears correct but is factually inaccurate or flawed, or contains copyrighted or other protected material, and if our customers or others use this flawed content to their detriment, we may be exposed to brand or reputational harm, competitive harm, and/or legal liability. Developing, testing and deploying AI systems may also increase the cost profile of our offerings due to the nature of the computing costs involved in such systems. If we are unable to mitigate these risks, or if we incur excessive expenses in our efforts to do so, our reputation, business, operating results and financial condition may be harmed.

</details>

## Item 1A RISK FACTORS (blocks 1199-1206)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: compromise_of_privacy, devaluation_of_human_effort | kinds: unspecified | substantiveness: generic | traits: hedging**

> Privacy concerns and laws as well as evolving regulation of cloud computing, AI services, cross-border data transfer restrictions and other domestic or foreign regulations may limit the use and adoption of our services and adversely affect our business.

<details><summary>Passage</summary>

Legal and Regulatory Risks

Privacy concerns and laws as well as evolving regulation of cloud computing, AI services, cross-border data transfer restrictions and other domestic or foreign regulations may limit the use and adoption of our services and adversely affect our business.

Regulation related to the provision of services over the Internet is evolving, as federal, state and foreign governments continue to adopt new, or modify existing, laws and regulations addressing data privacy, cybersecurity, data protection, data sovereignty and the collection, processing, storage, hosting, transfer and use of data, generally. In some cases, data privacy laws and regulations, such as the EU’s General Data Protection Regulation (“GDPR”), impose obligations directly on Salesforce as both a data controller and a data processor, as well as on many of our customers. In addition, new domestic data privacy laws, such as the California Consumer Privacy Act (“CCPA”) as amended by the California Privacy Rights Act (“CPRA”), and laws that have recently passed and/or gone into effect in many other states similarly impose new obligations on us and many of our customers, potentially as both businesses and service providers. These laws continue to evolve, and as various states introduce similar proposals, we and our customers could be exposed to additional regulatory burdens. Further, laws and legislative proposals such as the EU’s proposed e-Privacy Regulation are increasingly aimed at the use of personal information for marketing purposes, and the tracking of individuals’ online activities. The EU has been developing new requirements related to the use of data, including in the DSA, that may impose additional rules and restrictions on the use of the data in our products and services.

In addition, various safe harbors have historically been provided to those who hosted content provided by others, such as safe harbors from monetary damages for copyright infringement arising from copyrighted content provided by customers and others and for defamation and other torts arising from information provided by customers and others. There is an increasing demand for repealing or limiting these safe harbors by either judicial decision or legislation, and we have active legal proceedings that have been impacted by the repeal or limiting of safe harbors that were previously available to us. Loss of these safe harbors may require altering or limiting some of our services or may require additional contractual terms to avoid liabilities for our customers’ misconduct.

Although we monitor the regulatory, judicial and legislative environment and have invested in addressing these developments, these laws may require us to make additional changes to our practices and services to enable us or our customers to meet the new legal requirements, and may also increase our potential liability exposure through new or higher potential penalties for noncompliance, including as a result of penalties, fines and lawsuits related to data breaches. Furthermore, privacy laws and regulations are subject to differing interpretations and may be inconsistent among jurisdictions. These and other requirements are causing increased scrutiny among customers, particularly in the public sector and highly regulated industries,

T a b l e o f C o n t e n t s

and may be perceived differently from customer to customer. These developments could reduce demand for our services, require us to take on more onerous obligations in our contracts, restrict our ability to store, transfer and process data or, in some cases, impact our ability or our customers' ability to offer our services in certain locations, to deploy our solutions, to reach current and prospective customers, or to derive insights from customer data globally. For example, on July 16, 2020, the Court of Justice of the European Union (“CJEU”) invalidated the EU-U.S. Privacy Shield Framework, one of the mechanisms that allowed companies, including Salesforce, to transfer personal data from the European Economic Area (“EEA”) to the United States. Even though the CJEU decision upheld the Standard Contractual Clauses (“SCCs”) as an adequate transfer mechanism, the decision creates uncertainty around the validity of all EU-to-U.S. data transfers. Depending on how the CJEU’s decision is enforced, the cost and complexity of providing our services in certain markets may increase. While the EU and U.S. governments have recently adopted the EU-U.S. Data Privacy Framework to foster EU-to-U.S. data transfers and address the concerns raised in the aforementioned CJEU decision, it is uncertain whether this framework will be overturned in court like the previous two EU-U.S. bilateral cross-border transfer frameworks. As a result, regulators may be inclined to interpret the CJEU’s decision, and the logic behind it, as significantly restricting certain cross-border transfers. Certain countries outside of the EEA (e.g., China) have also passed or are considering passing laws requiring varying degrees of local data residency. By way of further example, statutory damages available through a private right of action for certain data breaches under the CPRA and potentially other states’ laws, may increase our and our customers’ potential liability and the demands our customers place on us.

The costs of compliance with, and other burdens imposed by, privacy laws, regulations and standards may limit the use and adoption of our services, reduce overall demand for our services, make it more difficult to meet expectations from our commitments to customers and our customers’ customers, lead to significant fines, penalties or liabilities for noncompliance, impact our reputation, or slow the pace at which we close sales transactions, in particular where customers request specific warranties and unlimited indemnity for noncompliance with privacy laws, any of which could harm our business. In March 2023, Salesforce launched the Hyperforce EU Operating Zone, which is designed to enable storage and processing of customer data solely within the EU. This EU service may enhance our ability to attract and retain customers operating in the EU, but may also increase the cost and complexity of supporting those customers, and our customers may request similar offerings in other territories.

</details>

## Item 1A RISK FACTORS (blocks 1209-1211)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: other | kinds: unspecified | substantiveness: generic | traits: hedging**

> Regulators in certain industries have adopted and may in the future adopt regulations or interpretive positions regarding the use of cloud computing, AI services, and other outsourced services.

<details><summary>Passage</summary>

Industry-specific regulations and other requirements and standards are evolving and unfavorable industry-specific laws, regulations, interpretive positions or standards could harm our business.

Our customers and potential customers conduct business in a variety of industries, including financial services, the public sector, healthcare and telecommunications. Regulators in certain industries have adopted and may in the future adopt regulations or interpretive positions regarding the use of cloud computing, AI services, and other outsourced services. The costs of compliance with, and other burdens imposed by, industry-specific laws, regulations and interpretive positions may limit our customers’ use and adoption of our services and reduce overall demand for our services. Compliance with these regulations may also require us to devote greater resources to support certain customers, which may increase costs and lengthen sales cycles. For example, some financial services regulators have imposed guidelines for use of cloud computing services that

T a b l e o f C o n t e n t s

</details>

## Item 1A RISK FACTORS (blocks 1213-1215)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: regulation_lagging_behind_ai | kinds: generative_llm | substantiveness: generic | traits: hedging**

> Further, countries are applying their data and consumer protection laws to AI, and particularly generative AI, and/or are considering legal frameworks on AI. Any failure or perceived failure by Salesforce to comply with such requirements could have an adverse impact on our business.

<details><summary>Passage</summary>

Further, in some cases, industry-specific, regionally-specific or product-specific laws, regulations or interpretive positions may impact our ability, as well as the ability of our customers, partners and data providers, to collect, augment, analyze, use, transfer and share personal and other information that is integral to certain services we provide. The interpretation of many of these statutes, regulations and rulings is evolving in the courts and administrative agencies and an inability to comply may have an adverse impact on our business and results. This impact may be particularly acute in countries that have passed or are considering passing legislation that requires data to remain localized “in country,” as this may impose financial costs on companies required to store data in jurisdictions not of their choosing and to use nonstandard operational processes that add complexity and are difficult and costly to integrate with global processes. This is also true with respect to the global proliferation of laws regulating the financial services industry, including its use of cloud services. In Europe, the Digital Operational Resilience Act (DORA), which aims to ensure the resilience of the EU financial sectors, including through mandatory risk management, incident reporting, resilience testing and third-party outsourcing restrictions, was formally adopted by the Council of the EU in November 2022. The UK is advancing similar legislation and other countries may follow.

Further, countries are applying their data and consumer protection laws to AI, and particularly generative AI, and/or are considering legal frameworks on AI. Any failure or perceived failure by Salesforce to comply with such requirements could have an adverse impact on our business.

There are various statutes, regulations and rulings relevant to direct email marketing and text-messaging industries, including the Telephone Consumer Protection Act (“TCPA”) and related Federal Communication Commission orders, which impose significant restrictions on the ability to utilize telephone calls and text messages to mobile telephone numbers as a means of communication, when the prior consent of the person being contacted has not been obtained. We have been, and may in the future be, subject to one or more class-action lawsuits, as well as individual lawsuits, containing allegations that one of our businesses or customers violated the TCPA. A determination that we or our customers violated the TCPA or other communications-based statutes could expose us to significant damage awards that could, individually or in the aggregate, materially harm our business. In addition, many jurisdictions across the world are currently considering, or have already begun implementing, changes to antitrust and competition laws, regulations or interpretative positions to enhance competition in digital markets and address practices by certain digital platforms that they perceive to be anticompetitive. These regulatory efforts could result in laws, regulations or interpretative positions that may require us to change certain of our business practices, undertake new compliance obligations or otherwise may have an adverse impact on our business and results.

</details>

## Item 1A RISK FACTORS (blocks 1225-1227)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: devaluation_of_human_effort | kinds: unspecified | substantiveness: generic | traits: hedging**

> Additionally, the intellectual property ownership and license rights, including copyright, surrounding AI technologies, which we are increasingly building into our product offerings, has not been fully addressed by U.S. courts or other federal or state laws or regulations, and the use or adoption of AI technologies in our products and services may expose us to copyright infringement or other intellectual property misappropriation claims.

<details><summary>Passage</summary>

Any failure to obtain registration or protection of our intellectual property rights could impair our ability to protect our proprietary technology and our brand, causing us to incur significant expenses and harm our business.

If we fail to protect our intellectual property rights adequately, our competitors may gain access to our technology, affecting our brand, causing us to incur significant expenses and harming our business. Any of our patents, trademarks or other intellectual property rights may be challenged by others or invalidated through administrative process or litigation. While we have many U.S. patents and pending U.S. and international patent applications, we may be unable to obtain patent protection for the technology covered in our patent applications or the patent protection may not be obtained quickly enough to meet our business needs. In addition, our existing patents and any patents issued in the future may not provide us with competitive advantages, or may be successfully challenged by third parties. Similar uncertainty applies to our U.S. and international trademark registrations and applications. Furthermore, legal standards relating to the validity, enforceability and scope of protection of intellectual property rights are uncertain, and we also may face proposals to change the scope of protection for some intellectual property rights in the U.S. and elsewhere. Additionally, the intellectual property ownership and license rights, including copyright, surrounding AI technologies, which we are increasingly building into our product offerings, has not been fully addressed by U.S. courts or other federal or state laws or regulations, and the use or adoption of AI technologies in our products and services may expose us to copyright infringement or other intellectual property misappropriation claims. Effective patent, trademark, copyright and trade secret protection may not be available to us in every country in which our services are available and legal changes and uncertainty in various countries’ intellectual property regimes may result in making conduct that we believe is lawful to be deemed violative of others’ rights. The laws of some foreign countries may not be as protective of intellectual property rights as those in the U.S., and mechanisms for enforcement of intellectual property rights may be inadequate. Also, our involvement in standard-setting activity, our contribution to open source projects, various competition law regimes or the need to obtain licenses from others may require us to license our intellectual property in certain circumstances. Accordingly, despite our efforts, we may be unable to prevent third parties from using our intellectual property.

We may be required to spend significant resources and expense to monitor and protect our intellectual property rights. We may initiate claims or litigation against third parties for infringement of our proprietary rights or to establish the validity of our proprietary rights. If we fail to protect our intellectual property rights, it could impact our ability to protect our technology and brand. Furthermore, any litigation, whether or not it is resolved in our favor, could result in significant expense to us, cause us to divert time and resources from our core business, and harm our business.

</details>

# Context passages: implicit mentions, not classified

## Item 1 LEGAL PROCEEDINGS (blocks 282-286)

**Terms: customer concentration (Significant Customers, single customer)**

The Company operates as one operating segment. Operating segments are defined as components of an enterprise for which separate financial information is evaluated regularly by the chief operating decision maker (“CODM”) in deciding how to allocate resources and assess performance. Over the past few years, the Company has completed a number of acquisitions which have allowed the Company to expand its offerings, presence and reach in various market segments of the enterprise cloud computing market. While the Company has offerings in multiple enterprise cloud computing market segments, including as a result of the Company's acquisitions, and operates in multiple countries, the Company’s business operates in one operating segment because most of the Company's service offerings operate on the Customer 360 Platform and are deployed in a nearly identical manner, and the Company’s CODM evaluates the Company’s financial information and resources, and assesses the performance of these resources, on a consolidated basis.

Concentrations of Credit Risk, Significant Customers and Investments

The Company’s financial instruments that are exposed to concentrations of credit risk consist primarily of cash and cash equivalents, marketable securities and accounts receivable. The Company monitors and manages the overall exposure of its cash balances to individual financial institutions on an ongoing basis. The Company’s marketable securities portfolio consists primarily of investment-grade securities, and the Company’s policies limit the amount of credit exposure to any one issuer. The Company does not require collateral for accounts receivable. The Company maintains an allowance for its doubtful accounts receivable for estimated credit losses. This allowance is based upon historical loss patterns, the number of days that billings are past due, an evaluation of the potential risk of loss associated with delinquent accounts and current market conditions and reasonable and supportable forecasts of future economic conditions to inform adjustments to historical loss patterns. The Company records the allowance against bad debt expense through the condensed consolidated statements of operations, included in general and administrative expense, up to the amount of revenues recognized to date. Any incremental allowance is recorded as an offset to unearned revenue on the condensed consolidated balance sheets. Receivables are written off and charged against the recorded allowance when the Company has exhausted collection efforts without success.

As of October 31, 2023, one customer accounted for approximately six percent of accounts receivable, and no other customers accounted for more than five percent of accounts receivable. No single customer accounted for more than five percent of accounts receivable as of January 31, 2023. No single customer accounted for five percent or more of total revenue during the three and nine months ended October 31, 2023 and 2022. As of October 31, 2023 and January 31, 2023, assets located outside the Americas were 14 percent and 15 percent of total assets, respectively. As of October 31, 2023 and January 31, 2023, assets located in the United States were 84 percent and 83 percent of total assets, respectively.

The Company is also exposed to concentrations of risk in its strategic investment portfolio, including within specific industries, as the Company primarily invests in enterprise cloud companies, technology st artups and system integrators. As of October 31, 2023, the Company held two investments, both privately held, with carrying values that were individually greater than five percent of its total strategic investments portfolio and represented 16 percent of the portfolio in aggregate. As of January 31, 2023, the Company held two investments, both privately held, with carrying values that were individuall y greater than five percent of its strategic investment portfolio and represented 16 percent of the portfolio in aggregate.

## Item 1 LEGAL PROCEEDINGS (blocks 434-436)

**Terms: sale-leaseback (Asset-backed securities)**

Mortgage-backed obligations | 260 | 0 | ( 13 ) | 247

Asset-backed securities | 1,329 | 0 | ( 18 ) | 1,311

Municipal securities | 166 | 0 | ( 5 ) | 161

## Item 1 LEGAL PROCEEDINGS (blocks 445-447)

**Terms: sale-leaseback (Asset-backed securities)**

Mortgage-backed obligations | 190 | 0 | ( 12 ) | 178

Asset-backed securities | 1,004 | 1 | ( 20 ) | 985

Municipal securities | 175 | 0 | ( 6 ) | 169

## Item 1 LEGAL PROCEEDINGS (blocks 498-500)

**Terms: sale-leaseback (Asset-backed securities)**

Mortgage-backed obligations | 0 | 247 | 0 | 247

Asset-backed securities | 0 | 1,311 | 0 | 1,311

Municipal securities | 0 | 161 | 0 | 161

## Item 1 LEGAL PROCEEDINGS (blocks 517-519)

**Terms: sale-leaseback (Asset-backed securities)**

Mortgage-backed obligations | 0 | 178 | 0 | 178

Asset-backed securities | 0 | 985 | 0 | 985

Municipal securities | 0 | 169 | 0 | 169

## Item 1 LEGAL PROCEEDINGS (blocks 531-533)

**Terms: data center (data centers)**

Leases

The Company has leases for corporate offices, data centers and equipment under non-cancelable operating and finance leases with various expiration dates.

Total operating lease costs were $ 163 million and $ 239 million for the three months ended October 31, 2023 and 2022, respectively, and were $ 823 million and $ 692 million for the nine months ended October 31, 2023 and 2022, respectively. Included in operating lease costs are amounts related to restructuring charges, which are discussed in Note 8 “Restructuring.”

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 721-723)

**Terms: data center (data center), data centre capacity (data center capacity)**

Cost of Revenues

Cost of subscription and support revenues primarily consists of expenses related to delivering our service and providing support, including the costs of data center capacity, certain fees paid to various third parties for the use of their technology, services and data, employee-related costs such as salaries and benefits, and allocated overhead. Our cost of subscription and support revenues also includes amortization of acquisition-related intangible assets, such as the amortization of the cost associated with an acquired company’s research and development efforts. Also included in the cost of subscription and support revenues are expenses incurred supporting the free user base of Slack, including third-party hosting costs and employee-related costs, including stock-based compensation expense, specific to customer experience and technical operations.

Cost of professional services and other revenues consists primarily of employee-related costs associated with these services, including stock-based compensation expense, the cost of subcontractors, certain third-party fees and allocated overhead. We believe that our professional services organization facilitates the adoption of our service offerings, helps us to secure larger subscription revenue contracts and supports our customers’ success. The cost of professional services may exceed revenues from professional services in future fiscal periods.

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 845-848)

**Terms: data center (data center, data centers), data centre capacity (data center capacity)**

Total cost of revenues | $ 6,393 | 25 % | $ 6,260 | 27 % | $ 133

For the three and nine months ended October 31, 2023, the increase in cost of revenues in absolute dollars was primarily due to an increase in service delivery costs which were partially offset by third-party expenses and amortization of purchased intangibles. We have increased our headcount associated with our data centers, customer support and professional services by one percent since October 31, 2022 to meet the higher demand for services from our customers. Cost of revenue as a percentage of total revenue during the three and nine months ended October 31, 2023 decreased by two percent from the same periods a year ago as a result of a decrease in absolute dollars related to third-party expenses, amortization of purchased intangibles and stock-based compensation expense, which was primarily a result of the workforce reductions associated with the Restructuring Plan.

We intend to continue to invest additional resources in our enterprise cloud computing services and data center capacity to allow us to scale with our customers and continue to evolve our security measures. The timing of these expenses may adversely affect our cost of revenues as a percentage of revenues in the near term due to fluctuations in demand for our service offerings.

Operating Expenses

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 890-892)

**Terms: sale-leaseback (asset-backed securities)**

Liquidity and Capital Resources

At October 31, 2023, our principal sources of liquidity were cash, cash equivalents and marketable securities totaling $11.9 billion and accounts receivable of $4.9 billion. Our cash equivalents and marketable securities are comprised primarily of corporate notes and obligations, U.S. treasury securities, U.S. agency obligations, asset-backed securities, foreign government obligations, mortgage-backed obligations, covered bonds, time deposits, money market mutual funds and municipal securities. Our credit agreement (the “Revolving Loan Credit Agreement”), which as of October 31, 2023, provides the ability to borrow up to $3.0 billion in unsecured financing (the “Credit Facility”), also serves as a source of liquidity.

Cash from operations could continue to be affected by various risks and uncertainties, including, but not limited to, the risks detailed in Part II, Item 1A, “Risk Factors.” We believe our existing cash, cash equivalents, marketable securities, cash provided by operating activities, unbilled amounts related to contracted non-cancelable subscription agreements, which are not reflected on the balance sheet, and, if necessary, our borrowing capacity under our Credit Facility will be sufficient to meet our working capital, capital expenditure and debt maintenance needs over the next 12 months.

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 912-913)

**Terms: sale-leaseback (off-balance sheet)**

In December 2020, we entered into the Revolving Loan Credit Agreement, which provides for a $3.0 billion unsecured revolving Credit Facility that matures in December 2025. There were no outstanding borrowings under the Credit Facility as of October 31, 2023. We may use the proceeds of future borrowings under the Credit Facility for general corporate purposes, which may include, without limitation, financing the consideration for, fees, costs and expenses related to any acquisition. In April 2022 and May 2023, we amended the Revolving Loan Credit Agreement to reflect certain immaterial administrative changes.

We do not have any special purpose entities and we do not engage in off-balance sheet financing arrangements.

## Item 2 UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS (blocks 917-920)

**Terms: colocation (co-location), data center (data center, data centers)**

Contractual Obligations

Our principal commitments consist of obligations under leases for office space, co-location data center facilities and our development and test data center, as well as leases for computer equipment, software, furniture and fixtures. As of October 31, 2023, the future non-cancelable minimum payments under these commitments were approximately $4.8 billion, with payments of $1.0 billion due in the next 12 months and $3.8 billion due thereafter. As of October 31, 2023, we have additional operating leases that have not yet commenced totaling $84 million. In addition to our leasing arrangements, we have other contractual commitments associated with agreements that are enforceable and legally binding, including those with infrastructure service providers. As of October 31, 2023, our total commitments under these agreements were approximately $17.5 billion, of which payments of $1.3 billion are due in the next 12 months and $16.2 billion are due thereafter. We generally expect to satisfy these commitments with cash on hand and cash provided by operating activities.

During the three months ended October 31, 2023 and in future quarters, we have made, and expect to continue to make, additional investments in our infrastructure to scale our operations to increase productivity and enhance our security measures. We plan to upgrade or replace various internal systems to scale with our overall growth. While we continue to make investments in our infrastructure including offices, information technology and data centers, as well as investments with infrastructure service providers, to provide capacity for the growth of our business, our strategy may continue to change related to these investments and we may slow the pace of our investments.

T a b l e o f C o n t e n t s

## Item 3 DEFAULTS UPON SENIOR SECURITIES (blocks 933-934)

**Terms: data center (data center)**

Foreign Currency Exchange Risk

We primarily conduct our business in the following locations: the United States, Europe, Canada, Latin America, Asia Pacific and Japan. The expanding global scope of our business exposes us to the risk of fluctuations in foreign currency markets, including emerging markets. This exposure is the result of selling in multiple currencies, operating in countries where the functional currency is the local currency and growth in our international investments, including data center expansion, costs associated with third-party infrastructure providers and additional headcount in foreign countries. Specifically, our results of operations and cash flows are subject to fluctuations in the following currencies: the Euro, British Pound Sterling, Japanese Yen, Canadian Dollar, Australian Dollar and Brazilian Real against the United States Dollar (“USD”). These exposures may change over time as business practices evolve and economic conditions change. Changes in foreign currency exchange rates could have an adverse impact on our financial results and cash flows.

## Item 3 DEFAULTS UPON SENIOR SECURITIES (blocks 960-962)

**Terms: tenant credit risk (counterparty risk)**

The borrowings under our Credit Facility bear interest, at our option, at a base rate plus a spread of 0.00% to 0.125% or an adjusted benchmark rate plus a spread of 0.50% to 1.125%, in each case with such spread being determined based on our credit rating. We are also obligated to pay an ongoing commitment fee on undrawn amounts. As of October 31, 2023, there was no outstanding borrowing amount under the Credit Facility.

The bank counterparties to our derivative contracts potentially expose us to credit-related losses in the event of their nonperformance. To mitigate that risk, we only contract with counterparties who meet the minimum requirements under our counterparty risk assessment process. We monitor ratings, credit spreads and potential downgrades on at least a quarterly basis. Based on our ongoing assessment of counterparty risk, we adjust our exposure to various counterparties. We generally enter into master netting arrangements, which reduce credit risk by permitting net settlement of transactions with the same counterparty. However, we do not have any master netting arrangements in place with collateral features.

Strategic Investments

## Item 1A RISK FACTORS (blocks 992-996)

**Terms: data center (data center)**

Operational and Execution Risks

Any breaches in our security measures or those of our third-party data center hosting facilities, cloud computing platform providers or third-party service partners, or the underlying infrastructure of the Internet that cause unauthorized access to a customer’s data, our data or our IT systems, or the blockage or disablement of authorized access to our services.

Any defects or disruptions in our services that diminish demand for our services.

Any interruptions or delays in services from third parties, including data center hosting facilities, cloud computing platform providers and other hardware and software vendors, or from our inability to adequately plan for and manage service interruptions or infrastructure capacity requirements.

An inability to realize the expected business or financial benefits of company and technology acquisitions.

## Item 1A RISK FACTORS (blocks 1036-1038)

**Terms: data center (data center)**

Operational and Execution Risks

If our security measures or those of our third-party data center hosting facilities, cloud computing platform providers or third-party service partners, or the underlying infrastructure of the Internet are breached, and unauthorized access is obtained to a customer’s data, our data or our IT systems, or authorized access is blocked or disabled, our services may be perceived as not being secure, customers may curtail or stop using our services, and we may incur significant reputational harm, legal exposure and liabilities, or a negative financial impact.

Our services involve the storage and transmission of our customers’ and our customers’ customers’ proprietary and other sensitive data, including financial, health and other personal information. We can provide no assurances that our security measures designed to protect our customers’ and our customers’ customers’ data will be effective. Our services and underlying infrastructure may in the future be materially breached or compromised as a result of the following:

## Item 1A RISK FACTORS (blocks 1056-1060)

**Terms: infrastructure-as-a-service (platform-as-a-service), uptime (downtime)**

A security breach or incident could result in unauthorized parties obtaining access to, or the denial of authorized access to, our IT systems or data, or our customers’ systems or data, including intellectual property and proprietary, sensitive or other confidential information. A security breach could also result in a loss of confidence in the security of our services, damage our reputation, negatively impact our future sales, disrupt our business and lead to increases in insurance premiums and legal, regulatory and financial exposure and liability. Finally, the detection, prevention and remediation of known or potential security vulnerabilities, including those arising from third-party hardware or software, may result in additional financial burdens due to additional direct and indirect costs, such as additional infrastructure capacity spending to mitigate any system degradation and the reallocation of resources from development activities.

For example, in April 2022, we learned a threat actor had obtained unauthorized access to several databases on Heroku, a Salesforce platform-as-a-service. The threat actor downloaded stored customer security credentials and passwords for logging into GitHub, a third-party code hosting service used by both Heroku and Heroku customers. The threat actor also was able to download passwords for a subset of customer user accounts and access the encryption key. While we do not believe this incident materially affected our business or financial results, there is no assurance that such circumstances or other similar incidents in the future could not result in a material adverse effect on our business.

Defects or disruptions in our services could diminish demand for our services and subject us to substantial liability.

Because our services are complex and incorporate a variety of hardware, proprietary software, third-party and open-source software, our services may have errors or defects that could result in unanticipated downtime for our subscribers and harm to our reputation and our business. Our customers may also use our services in unanticipated ways that may cause a disruption in services for other customers attempting to access their data. Across the industry, cloud services frequently contain undetected errors when first introduced or when new versions or enhancements are released. We may also encounter difficulties integrating

T a b l e o f C o n t e n t s

## Item 1A RISK FACTORS (blocks 1063-1066)

**Terms: data center (data center), supply chain constraints (supply chain constraints)**

Since our customers use our services for important aspects of their business, any errors, defects, disruptions in service or other performance problems could hurt our reputation and may damage our customers’ businesses. As a result, customers could elect to not renew our services or delay or withhold payment to us. We could also lose future sales or customers may make warranty or other claims against us, which could result in an increase in our allowance for doubtful accounts, an increase in collection cycles for accounts receivable or the expense and risk of litigation.

Any interruptions or delays in services from third parties, including data center hosting facilities, cloud computing platform providers and other hardware and software vendors, or from our inability to adequately plan for and manage service interruptions or infrastructure capacity requirements, could impair the delivery of our services and harm our business.

We currently serve our customers from third-party data center hosting facilities and cloud computing platform providers located in the United States and other countries. We also rely on computer hardware purchased or leased from, software licensed from, and cloud computing platforms provided by, third parties in order to offer our services, including database software, hardware and data from a variety of vendors. Any disruption or damage to, or failure of our systems generally, including the systems of our third-party platform providers, could result in interruptions in our services and harm our business. We have from time to time experienced interruptions in our services and such interruptions may occur in the future. The COVID-19 pandemic disrupted and continues to disrupt the supply chain of hardware needed to maintain these third-party systems or to run our business, which affects our and our suppliers’ operations. In addition, supply chain disruptions due to geopolitical developments in Europe and indirect effects have further complicated existing supply chain constraints. As we increase our reliance on these third-party systems, particularly with respect to third-party cloud computing platforms, our exposure to damage from service interruptions or other performance or quality issues may increase. Interruptions in our services or other performance or quality issues may cause us to issue credits or pay penalties, cause customers to make warranty or other claims against us or to terminate their subscriptions, and adversely affect our attrition rates and our ability to attract new customers, all of which would reduce our revenue. Our business and reputation would also be harmed if our customers and potential customers believe our services are unreliable.

For many of our offerings, our production environment and customers’ data are replicated in near real time in a separate facility located elsewhere. Certain offerings, including some offerings of companies added through acquisitions, may be served through alternate facilities or arrangements. We do not control the operation of any of these facilities, and they may be vulnerable to damage or interruption from earthquakes, floods, fires, power loss, telecommunications failures and similar events. They may also be subject to break-ins, sabotage, intentional acts of destruction or vandalism or similar misconduct, as well as local administrative actions (including shelter-in-place or similar orders), changes to legal or permitting requirements and litigation to stop, limit or delay operation. In addition, supply chain disruptions due to geopolitical developments in Europe may also lead to power disruptions in regions where our facilities are located. Despite precautions taken at these facilities, such as disaster recovery and business continuity arrangements, the occurrence of any of the foregoing events or risks, or a natural disaster or public health emergency, an act of terrorism, a decision to close the facilities without adequate notice or other unanticipated problems or operational failures at these facilities could result in lengthy interruptions in our services, and no assurance can be provided that any such interruptions would be remediated without significant cost or in a timely manner or at all.

## Item 1A RISK FACTORS (blocks 1069-1070)

**Terms: data center (data center), data centre capacity (data center capacity), uptime (outages)**

through purchase or license and integrated into our services, and no assurance can be provided that such equivalent technology would be developed or obtained in a timely manner or at all.

If we do not accurately plan for our infrastructure capacity requirements and we experience significant strains on our data center capacity, our customers could experience performance degradation or service outages that may subject us to financial liabilities, result in customer losses and harm our reputation and business. As we add data centers and capacity and continue to move to cloud computing platform providers, we move or transfer our data and our customers’ data from time to time. Despite precautions taken during this process, any unsuccessful data transfers may impair the delivery of our services, which may damage our business.

## Item 1A RISK FACTORS (blocks 1118-1120)

**Terms: uptime (outages)**

The Internet’s infrastructure comprises many different networks and services that are highly fragmented and distributed by design. This infrastructure is run by a series of independent third-party organizations that work together to provide the infrastructure and supporting services of the Internet under the governance of the Internet Corporation for Assigned Numbers and Names (“ICANN”) and the Internet Assigned Numbers Authority, now under the stewardship of ICANN.

The Internet has experienced a variety of outages and other delays as a result of damages to portions of its infrastructure, denial-of-service attacks or related cyber incidents, and it could face outages and delays in the future, potentially reducing the availability of the Internet to us or our customers for delivery of our services. Any resulting interruptions in our services or the ability of our customers to access our services could result in a loss of potential or existing customers and harm our business.

In addition, certain countries have implemented, or may implement, legislative and technological actions that either do or can effectively regulate access to the Internet, including the ability of Internet service providers to limit access to specific websites or content. Other countries have attempted, are attempting or may attempt to change or limit the legal protections available to businesses that depend on the Internet for the delivery of their services. These actions could potentially limit or interrupt access to our services from certain countries or Internet service providers, increase our risk or add liabilities, impede our growth, productivity and operational effectiveness, result in the loss of potential or existing customers and harm our business.

## Item 1A RISK FACTORS (blocks 1149-1151)

**Terms: data science (data scientists)**

Our success depends substantially upon the continued services of our executive officers and other key members of management, particularly our chief executive officer. From time to time, there may be changes in our management team resulting from the hiring, departure or realignment of executives. For example, in January 2023, Bret Taylor, our former co-CEO and Vice Chair of our Board of Directors, resigned from these positions with our company. Such changes may be disruptive to our business. We are also substantially dependent on the continued service of our existing development and operations personnel because of the complexity of our services and technologies. Our executive officers, key management, development or operations personnel could terminate their employment with us at any time. Effective succession planning for management is important to our long-term success. If we do not develop adequate succession planning for our key personnel, the loss of one or more of our key employees or groups of employees could seriously harm our business.

The technology industry is subject to substantial and continuous competition for engineers with high levels of experience in designing, developing and managing software and technology services, as well as competition for sales executives, data scientists and operations personnel. We have experienced, and currently experience, challenges with significant competition in talent recruitment and retention, and may not in the future be successful in recruiting or retaining talent or achieving the workforce diversity goals we have set publicly. We have from time to time experienced, and we expect to continue to experience, difficulty in hiring, developing, integrating and retaining highly skilled employees with appropriate qualifications. These difficulties may be amplified by evolving restrictions on immigration, travel, or availability of visas for skilled technology workers. If we fail to attract new personnel or fail to retain and motivate our current personnel, our business and future growth prospects could be severely harmed.

In January 2023, we announced the Restructuring Plan, which is intended to reduce operating costs, improve operating margins and continue advancing our ongoing commitment to profitable growth. The Restructuring Plan includes a reduction of our workforce and select real estate exits and office space reductions within certain markets. The actions associated with the employee restructuring under the Restructuring Plan are expected to be substantially complete by the end of fiscal 2024, subject to local law and consultation requirements. This Restructuring Plan, or any similar actions taken in the future, could negatively impact our ability to attract, integrate, retain and motivate key employees.

## Item 1A RISK FACTORS (blocks 1163-1165)

**Terms: data curation (data preparation)**

software companies that provide their product or service free of charge as a single product or when bundled with other offerings, or only charge a premium for advanced features and functionality, as well as companies that offer solutions that are sold without a direct sales organization;

vendors who offer software tailored to specific services as opposed to our full suite of service offerings, including suppliers of traditional business intelligence and data preparation products, integration software vendors, marketing vendors or e-commerce solutions vendors;

productivity tool and email providers, unified communications providers and consumer application companies that have entered the business software market; and

## Item 1A RISK FACTORS (blocks 1231-1232)

**Terms: export controls (export control regulations)**

T a b l e o f C o n t e n t s

Our solutions are subject to export and import controls where we conduct our business activities, including the U.S. Commerce Department’s Export Administration Regulations, U.S. Customs regulations, U.S. supply chain regulations and various economic and trade sanctions regulations established by the U.S. Treasury Department’s Office of Foreign Assets Control. If we fail to comply with applicable trade laws, we and certain of our employees could be subject to substantial civil or criminal penalties, including the possible loss of trade privileges; fines, which may be imposed on us and responsible employees or managers; and, in extreme cases, the incarceration of responsible employees or managers. Obtaining necessary authorizations, including any required licenses, may be time-consuming, requires expenditure of corporate resources, is not guaranteed, and may result in the delay or loss of sales opportunities or the ability to realize value from certain acquisitions or engagements. Acquisitions may also subject us to successor liability and other integration compliance risks. Furthermore, export control laws and economic sanctions may prohibit or limit the transfer of certain products and services to embargoed or sanctioned countries, governments and parties. We can provide no assurance that any of the precautions we take to prevent our solutions from being provisioned or provided to sanctions targets in violation of applicable regulations will be effective, and, accordingly, our solutions could be provisioned or provided to those targets, including by our resellers or other third parties, which could have negative consequences for our business, including government investigations, penalties and reputational harm. Changes in our solutions or trade regulations may create delays in the introduction, sale and deployment of our solutions in international markets or prevent the export or import of our solutions to certain countries, governments or persons altogether. Any decreased use of our solutions or limitation on our ability to export or sell our solutions may adversely affect our business, financial condition and results of operations. Import and export control regulations in the United States and other countries are subject to change and uncertainty, including as a result of geopolitical developments and relations between the United States and China, the United States and Russia, war in Ukraine and the Israel-Hamas war. Regulators in the United States and elsewhere have signaled an increased emphasis on sanctions and export control enforcement, including several recent high-profile enforcement actions and increased pressure for companies to self-disclose potential violations.

## Item 1A RISK FACTORS (blocks 1236-1237)

**Terms: data center (data center)**

If we experience significant fluctuations in our rate of anticipated growth and fail to balance our expenses with our revenue forecasts, our business could be harmed and the market price of our common stock could decline.

Due to the unpredictability of future general economic and financial market conditions, including from the global economic impact of war in Ukraine and the Israel-Hamas war, the pace of change and innovation in enterprise cloud computing services, the impact of foreign currency exchange rate fluctuations, the growing complexity of our business, including the use of multiple pricing and packaging models and the increasing amount of revenue from software license sales, and our increasing focus on enterprise cloud computing services, we may not be able to realize our projected revenue growth plans. We plan our expense and investment levels based on estimates of future revenue and future anticipated rate of growth. We may not be able to adjust our spending appropriately if the addition of new subscriptions or the renewals of existing subscriptions fall short of our expectations, and unanticipated events may cause us to incur expenses beyond what we anticipated. A portion of our expenses may also be fixed in nature for some minimum amount of time, such as with costs capitalized to obtain revenue contracts, data center and infrastructure service contracts or office leases, so it may not be possible to reduce costs in a timely manner, or at all, without the payment of fees to exit certain obligations early. As a result, our revenues, operating results and cash flows may fluctuate significantly on a quarterly basis and revenue growth rates may not be sustainable and may decline in the future. In some periods, we have not been able to, and may not be able in the future to provide continued operating margin expansion, which could harm our business and cause the market price of our common stock to decline.

## Item 1A RISK FACTORS (blocks 1290-1292)

**Terms: data center (data center), data centre capacity (data center capacity)**

the costs associated with acquiring new businesses and technologies and the follow-on costs of integration and consolidating the results of acquired businesses;

expenses related to our real estate or changes in the nature or extent of our use of existing real estate, including our office leases and our data center capacity and expansion;

timing of additional investments in our enterprise cloud computing application and platform services and in our consulting services;

## Item 1A RISK FACTORS (blocks 1318-1320)

**Terms: data center (data center)**

recruitment or departure of key personnel;

disruptions in our service due to computer hardware, software, network or data center problems;

T a b l e o f C o n t e n t s

## Item 1A RISK FACTORS (blocks 1345-1347)

**Terms: data center (data center)**

Climate change may have an impact on our business.

While we seek to mitigate our business risks associated with climate change by establishing robust environmental programs and partnering with organizations who are also focused on mitigating their own climate-related risks, we recognize that there are inherent climate-related risks wherever business is conducted. Any of our primary locations may be vulnerable to the adverse effects of climate change. For example, our offices globally have historically experienced, and are projected to continue to experience, climate-related events at an increasing frequency, including drought, water scarcity, heat waves, cold waves, flooding, wildfires and resultant air quality impacts and power shutoffs associated with wildfire prevention. These events in turn have impacts on inflation risks, food security, water security (including for water availability for data center cooling), and on our employees’ health and well-being. Furthermore, it is more difficult to mitigate the impact of these events on our employees working remotely or at client sites. Changing market dynamics, global policy developments and the increasing frequency and impact of extreme weather events on critical infrastructure in the United States and elsewhere have the potential to disrupt our business, the business of third-party providers or suppliers that we rely on to conduct our business and the business of our customers, and may cause us to experience higher attrition, losses and additional costs to maintain or resume operations. Additionally, failure to uphold, meet or make timely forward progress against our public commitments and goals related to climate action could adversely affect our reputation with investors, suppliers and customers, our financial performance or our ability to recruit and retain talent.

T a b l e o f C o n t e n t s
