# T-Mobile US, Inc. | 10-K | fiscal year 2022

- Report length: 77,171 words
- Direct AI mentions (classified): 0, of which about AI: 0, false candidates: 0, flagged for review: 0
- Context passages (not classified): 23; groups: industry (25), compute_infrastructure (2)
- Frames: none
- Roles: none
- Risk types: none
- MIT subdomains: none
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: none
- Substantiveness: none
- Disclosure traits: none
- Trait activation rate: n/a
- Sections: none
- Named entities: none

# Context passages: implicit mentions, not classified

## Item 1 Business (blocks 122-124)

**Terms: IoT connectivity (connected devices)**

We provide wireless communications services to a variety of customers needing connectivity, but focus primarily on two categories of customers:

Postpaid customers generally are qualified to pay after receiving wireless communications services utilizing phones, High Speed Internet, tablets, wearables, DIGITS and other connected devices; and

Prepaid customers generally pay for wireless communications services, including High Speed Internet, in advance. Our prepaid customers include customers of T-Mobile and Metro by T-Mobile.

## Item 1 Business (blocks 151-152)

**Terms: tower infrastructure (cell sites)**

We plan to evaluate future spectrum purchases in future auctions and in the secondary market to further augment our current spectrum position.

As of December 31, 2022, we had equipment deployed on approximately 79,000 macro cell sites and 41,000 small cell/distributed antenna system sites across our network.

## Item 1 Business (blocks 157-158)

**Terms: network capex (network investment)**

Competition

The wireless communications services industry is highly competitive. We are the second largest provider of wireless communications services in the U.S. as measured by our total postpaid and prepaid customers. Our competitors include other national carriers, such as AT&T Inc. (“AT&T”) and Verizon Communications, Inc. (“Verizon”). In addition, our competitors include numerous smaller and regional carriers, MVNOs, including Comcast Corporation, Charter Communications, Inc., Altice USA, Inc. and DISH, many of which offer no-contract, postpaid and prepaid service plans. Competitors also include providers who offer similar communication services, such as voice, messaging and data services, using alternative technologies. Competitive factors within the wireless communications services industry include pricing, market saturation, service and product offerings, customer experience, network investment and quality, development and deployment of technologies and regulatory changes. Some of our competitors have shown a willingness to use aggressive pricing or offer bundled services as a potential source of differentiation.

## Item 1 Business (blocks 202-204)

**Terms: tower infrastructure (cell sites)**

Investing in renewable energy, as evidenced by our RE100 pledge, a global initiative that unites businesses committed to 100% renewable electricity. We first met this goal in 2021 and then again in 2022 by matching our electricity usage with renewable energy credits acquired through a variety of sources, including through our engagement in Virtual Power Purchasing Agreements and a Green Direct tariff agreement with nine clean energy providers for expected annual provision of approximately 3.5 million megawatt hours of renewable electricity;

Continuously testing and evaluating new, efficient equipment for our facilities, including switch stations, cell sites, retail stores and customer experience centers to reduce energy consumption; and

Promoting the circular economy through our device reuse and recycle program, which collects millions of devices for reuse, resale, and recycling annually.

## Item 1A Risk Factors (blocks 254-256)

**Terms: critical infrastructure (critical infrastructure)**

human error, such as responding to deceptive communications or unintentionally executing malicious code;

unauthorized access to our IT and business systems or to our network and critical infrastructure and those of our suppliers and other providers;

supplier failures or delays; and

## Item 2 Properties (blocks 382-386)

**Terms: call centre (call centers), data center (data centers), tower infrastructure (cell sites)**

Total | 100 % | 100 %

Wireless communication systems primarily consist of assets used to operate our wireless network and information technology data centers, including switching equipment, radio frequency equipment, tower assets, High Speed Internet routers, construction in progress and leasehold improvements related to the wireless network and asset retirement costs.

Land, buildings and building equipment primarily consist of land and land improvements, central office buildings or any other buildings that house network equipment, buildings used for administrative and other purposes, related construction in progress and certain network service equipment.

Data processing equipment and other primarily consists of data processing equipment, office equipment, capitalized software, leased wireless devices, construction in progress and leasehold improvements.

We also lease distributed antenna systems and small cell sites, as well as properties throughout the United States that contain data and switching centers, customer call centers, retail locations, warehouses and administrative spaces.

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 448-450)

**Terms: tower infrastructure (cell sites)**

Network Integration

As of December 31, 2022, we have decommissioned substantially all Sprint macro sites targeted for shut down. Our integration and decommissioning initiatives also included the acceleration or termination of certain of our operating and financing leases for cell sites, switch sites and network equipment. To achieve Merger synergies in network costs, we continue to perform rationalization activities to identify duplicative networks, backhaul services and other agreements, in addition to decommissioning certain small cell sites and distributed antenna systems.

To allow for the realization of these synergies associated with network integration, we retired certain legacy networks, including the legacy Sprint CDMA network in the second quarter and the legacy Sprint LTE network in the third quarter of 2022. Customers impacted by the decommissioning of these networks have been excluded from our customer base and postpaid account base. See the “ Performance Measures ” section of this MD&A for more details.

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 454-456)

**Terms: tower infrastructure (cell sites)**

Severance costs associated with the reduction of redundant processes and functions; and

The decommissioning of certain small cell sites and distributed antenna systems to achieve Merger synergies in network costs.

For more information regarding our restructuring activities, see Note 20 – Restructuring Costs of the Notes to the Consolidated Financial Statements.

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 645-647)

**Terms: IoT connectivity (connected devices)**

Total Postpaid Accounts

A postpaid account is generally defined as a billing account number that generates revenue. Postpaid accounts generally consist of customers that are qualified for postpaid service utilizing phones, High Speed Internet, tablets, wearables, DIGITS or other connected devices, where they generally pay after receiving service.

(in thousands) | 2022 | 2022 Versus 2021 — 2021 | 2020 | 2021 Versus 2020 — # Change | % Change | # Change | % Change

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 680-682)

**Terms: IoT connectivity (connected devices)**

Customers

A customer is generally defined as a SIM number with a unique T-Mobile identifier which is associated with an account that generates revenue. Customers are qualified either for postpaid service utilizing phones, High Speed Internet, tablets, wearables, DIGITS or other connected devices, where they generally pay after receiving service, or prepaid service, where they generally pay in advance of receiving service.

The following table sets forth the number of ending customers:

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 695-697)

**Terms: IoT connectivity (connected devices)**

Higher postpaid phone customers, primarily due to growth in new customer account relationships;

Higher postpaid other customers, primarily due to growth in other connected devices, including growth in High Speed Internet and wearable products; and

• Higher prepaid customers, primarily due to the continued success of our prepaid business due to promotional activity and rate plan offers, including the introduction of our prepaid High Speed Internet offering, partially offset by lower prepaid industry demand associated with continued industry shift to postpaid plans.

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 735-737)

**Terms: IoT connectivity (connected devices)**

Total net customer additions increased 920,000, or 16%, primarily from:

Higher postpaid other net customer additions, primarily due to an increase in postpaid High Speed Internet net customer additions and other connected devices, partially offset by lower net additions from mobile internet devices; and

Higher postpaid phone net customer additions, primarily due to lower churn, partially offset by lower gross additions driven by industry switching activity normalizing closer to pre-Pandemic levels; partially offset by

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 753-755)

**Terms: IoT connectivity (connected devices)**

Postpaid Average Revenue Per Account

Postpaid ARPA represents the average monthly postpaid service revenue earned per account. Postpaid ARPA is calculated as Postpaid revenues for the specified period divided by the average number of postpaid accounts during the period, further divided by the number of months in the period. We believe postpaid ARPA provides management, investors and analysts with useful information to assess and evaluate our postpaid service revenue realization and assist in forecasting our future postpaid service revenues on a per account basis. We consider postpaid ARPA to be indicative of our revenue growth potential given the increase in the average number of postpaid phone customers per account and increases in postpaid other customers, including High Speed Internet, tablets, wearables, DIGITS or other connected devices.

The following table sets forth our operating measure ARPA:

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 764-766)

**Terms: IoT connectivity (connected devices)**

Average Revenue Per User

Average Revenue per User (“ARPU”) represents the average monthly service revenue earned per customer. ARPU is calculated as service revenues for the specified period divided by the average number of customers during the period, further divided by the number of months in the period. We believe ARPU provides management, investors and analysts with useful information to assess and evaluate our service revenue per customer and assist in forecasting our future service revenues generated from our customer base. Postpaid phone ARPU excludes postpaid other customers and related revenues, which include High Speed Internet, tablets, wearables, DIGITS and other connected devices.

The following table sets forth our operating measure ARPU:

## Item 8 Financial Statements and Supplementary Data (blocks 982-984)

**Terms: lawful interception (subscriber data)**

We tested internal controls in the revenue accounting processes, including those in place to (a) establish revenue recognition accounting policies for promotional offers, (b) record revenue and the related promotional offers in accordance with the established accounting policies and (c) reconcile the various systems to the Company’s general ledger.

We created data visualizations to evaluate recorded revenue and trends in the related subscriber data.

For a selection of equipment revenue transactions, we compared the amounts recognized to contractual agreements or other source documents and tested the mathematical accuracy of the recorded revenue.

## Item 8 Financial Statements and Supplementary Data (blocks 1230-1232)

**Terms: dark fibre (long-haul fiber)**

The preparation of financial statements in conformity with U.S. generally accepted accounting principles (“GAAP”) requires our management to make estimates and assumptions which affect our consolidated financial statements and accompanying notes. Estimates are based on historical experience, where applicable, and other assumptions which our management believes are reasonable under the circumstances, including, but not limited to, the valuation of assets acquired and liabilities assumed through our merger (the “Merger”) with Sprint Corporation (“Sprint”) and through our acquisitions of affiliates and the potential impacts arising from macroeconomic trends. These estimates are inherently subject to judgment and actual results could differ from those estimates.

On September 6, 2022, Sprint Communications LLC, a Kansas limited liability company and wholly owned subsidiary of the Company (“Sprint Communications”), Sprint LLC, a Delaware limited liability company and wholly owned subsidiary of the Company, and Cogent Infrastructure, Inc., a Delaware corporation (the “Buyer”) and a wholly owned subsidiary of Cogent Communications Holdings, Inc., entered into a Membership Interest Purchase Agreement (the “Wireline Sale Agreement”), pursuant to which the Buyer will acquire the U.S. long-haul fiber network and operations (including the non-U.S. extensions thereof) of Sprint Communications and its subsidiaries (the “Wireline Business”). Such transactions contemplated by the Wireline Sale Agreement are collectively referred to as the “Wireline Transaction.”

The assets and liabilities of the Wireline Business disposal group are classified as held for sale and presented within Other current assets and Other current liabilities on our Consolidated Balance Sheets as of December 31, 2022. The fair value of the Wireline Business disposal group, less costs to sell, will be reassessed during each reporting period it remains classified as held for sale, and any remeasurement to the lower of carrying amount or fair value less costs to sell will be reported as an adjustment included within Loss on disposal group held for sale on our Consolidated Statements of Comprehensive Income. Unless otherwise specified, the amounts and information presented in the Notes to the Consolidated Financial Statements include assets and liabilities that have been reclassified as held for sale as of December 31, 2022.

## Item 8 Financial Statements and Supplementary Data (blocks 1258-1260)

**Terms: data center (data centers)**

Property and Equipment

Property and equipment consists of buildings and equipment, wireless communications systems, leasehold improvements, capitalized software, leased wireless devices and construction in progress. Buildings and equipment include certain network server equipment. Wireless communications systems include assets to operate our wireless network and information technology data centers, including tower assets, leasehold improvements and asset retirement costs. Leasehold improvements include asset improvements other than those related to the wireless network.

Property and equipment are recorded at cost less accumulated depreciation and impairments, if any, in Property and equipment, net on our Consolidated Balance Sheets. We generally depreciate property and equipment over the period the property and equipment provide economic benefit using the straight-line method. Depreciable life studies are performed periodically to confirm the appropriateness of depreciable lives for certain categories of property and equipment. These studies take into account actual usage, physical wear and tear, replacement history and assumptions about technology evolution. When these factors indicate the useful life of an asset is different from the previous assessment, the remaining book value is depreciated prospectively over the adjusted remaining estimated useful life. Leasehold improvements are depreciated over the shorter of their estimated useful lives or the related lease term.

## Item 8 Financial Statements and Supplementary Data (blocks 1340-1343)

**Terms: dark fibre (dark fiber), tower infrastructure (Cell Site, cell sites)**

Leases

Cell Site, Retail Store and Office Facility Leases

We are a lessee for non-cancelable operating and financing leases for cell sites, switch sites, retail stores, network equipment, office facilities and dark fiber. We recognize a right-of-use asset and lease liability for operating leases based on the net present value of future minimum lease payments. The right-of-use asset for an operating lease is based on the lease liability. Lease expense is recognized on a straight-line basis over the non-cancelable lease term and renewal periods that are considered reasonably certain.

In addition, we have financing leases for certain network equipment. We recognize a right-of-use asset and lease liability for financing leases based on the net present value of future minimum lease payments. The right-of-use asset for a finance lease is based on the lease liability. Expense for our financing leases is comprised of the amortization expense associated with the right-of-use asset and interest expense recognized based on the effective interest method.

## Item 8 Financial Statements and Supplementary Data (blocks 1907-1909)

**Terms: IoT connectivity (connected devices)**

We provide wireless communications services to three primary categories of customers:

Postpaid customers generally include customers who are qualified to pay after receiving wireless communications services utilizing phones, High Speed Internet, tablets, wearables, DIGITS or other connected devices;

Prepaid customers generally include customers who pay for wireless communications services in advance; and

## Item 8 Financial Statements and Supplementary Data (blocks 2160-2162)

**Terms: dark fibre (long-haul fiber)**

Wireline Impairment

We provide wireline communication services to domestic and international customers via the legacy Sprint Wireline U.S. long-haul fiber network (including non-U.S. extensions thereof) acquired through the Merger. The legacy Sprint Wireline network is primarily comprised of owned property and equipment, including land, buildings, communication systems and data processing equipment, fiber optic cable and operating lease right-of-use assets. Previously, the operation of the legacy Sprint CDMA and LTE wireless networks was supported by the legacy Sprint Wireline network. During the second quarter of 2022, we retired the legacy Sprint CDMA network and began the orderly shut-down of the LTE network.

We assess long-lived assets for impairment when events or circumstances indicate that they might be impaired. During the second quarter of 2022, we determined that the retirement of the legacy Sprint CDMA and LTE wireless networks triggered the need to assess the Wireline long-lived assets for impairment, as these assets no longer support our wireless network and the associated customers and cash flows in a significant manner. In evaluating whether the Wireline long-lived assets were impaired, we estimated the fair value of these assets using a combination of the cost, income and market approaches, including market participant assumptions. The fair value measurement of the Wireline assets was estimated using significant inputs not observable in the market (Level 3).

## Item 8 Financial Statements and Supplementary Data (blocks 2190-2192)

**Terms: dark fibre (dark fiber), tower infrastructure (cell sites)**

Lessee

We are a lessee for non-cancelable operating and financing leases for cell sites, switch sites, retail stores, network equipment and office facilities with contractual terms that generally extend through 2035. Additionally, we lease dark fiber through non-cancelable operating leases with contractual terms that generally extend through 2040. The majority of cell site leases have a non-cancelable term of five to 15 years with several renewal options that can extend the lease term for five to 50 years. In addition, we have financing leases for network equipment that generally have a non-cancelable lease term of three to five years . The financing leases do not have renewal options and contain a bargain purchase option at the end of the lease.

On January 3, 2022, we entered into the Crown Agreement with CCI that modified the terms of our leased towers from CCI. The Crown Agreement modifies the monthly rental payments we will pay for sites currently leased by us, extends the non-cancellable lease term for the majority of our sites through December 2033 and will allow us the flexibility to facilitate our network integration and decommissioning activities through new site builds and termination of duplicate tower locations. The initial non-cancellable term is through December 31, 2033, followed by three optional five-year renewals. As a result of this modification, we remeasured the associated right-of use assets and lease liabilities resulting in an increase of $ 5.3 billion to each on the effective date of the modification, with a corresponding gross increase to both deferred tax liabilities and assets of $ 1.3 billion.

## Item 8 Financial Statements and Supplementary Data (blocks 2274-2276)

**Terms: tower infrastructure (cell sites)**

Note 20 – Restructuring Costs

Upon close of the Merger, we began implementing restructuring initiatives to realize cost efficiencies and reduce redundancies. The major activities associated with the Merger restructuring initiatives to date include contract termination costs associated with the rationalization of retail stores, distribution channels, duplicative network and backhaul services and other agreements, severance costs associated with the integration of redundant processes and functions and the decommissioning of certain small cell sites and distributed antenna systems to achieve Merger synergies in network costs.

The following table summarizes the expenses incurred in connection with our Merger restructuring initiatives:

## Item 8 Financial Statements and Supplementary Data (blocks 2282-2284)

**Terms: tower infrastructure (cell sites)**

The expenses associated with our Merger restructuring initiatives are included in Costs of services and Selling, general and administrative on our Consolidated Statements of Comprehensive Income.

Our Merger restructuring initiatives also include the acceleration or termination of certain of our operating and financing leases for cell sites, switch sites, retail stores, network equipment and office facilities. Incremental expenses associated with accelerating amortization of the right-of-use assets on lease contracts were $ 1.7 billion, $ 873 million and $ 153 million for the years ended December 31, 2022, 2021 and 2020, respectively, and are included in Costs of services and Selling, general and administrative on our Consolidated Statements of Comprehensive Income.

The changes in the liabilities associated with our Merger restructuring initiatives, including expenses incurred and cash payments, are as follows:
