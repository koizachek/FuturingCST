# Alphabet Inc. | 10-K | fiscal year 2022

- Report length: 49,332 words
- Direct AI mentions (classified): 12, of which about AI: 12, false candidates: 0, flagged for review: 0
- Context passages (not classified): 35; groups: industry (20), compute_infrastructure (10), security_misuse (5), governance_regulation (4), general (1), euphemisms (1), data_training (1)
- Frames: business (11), risk_factor (1)
- Roles: adoption (7), offering (5), risk (1)
- Risk types: operational_reliability (1), regulatory_legal (1), reputational_ethical (1)
- MIT subdomains: ai_pursuing_own_goals (1), lack_of_capability_robustness (1), other (1)
- Adoption stage: deployed (6), planned (1)
- Business functions: not_stated (3), rd_product (2), it_cybersecurity (2), marketing_sales (1)
- Governance responses: none
- Kinds of AI: unspecified (10), traditional_ml (2), computer_vision (1)
- Substantiveness: generic (6), specific (5), detailed (1)
- Disclosure traits: hedging (1)
- Trait activation rate: 0.083 (boilerplate (0.0), hedging (0.083), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 1 (5), Item 7 (4), Item 1A (2), Item 8 (1)
- Named entities: DeepMind, Google, Google Assistant, Google Cloud, Google Cloud Platform, Lens, Pixel 7, Pixel 7 Pro, Pixel Watch, Translate

## Item 1 BUSINESS (blocks 121-123)

**AI reference: explicit | frame: business | roles: adoption | adoption: planned | functions: rd_product | kinds: unspecified | substantiveness: generic**

> That unconventional spirit has been a driving force throughout our history, inspiring us to tackle big problems and invest in moonshots, such as our long-term opportunities in artificial intelligence (AI).

<details><summary>Passage</summary>

Overview

As our founders Larry and Sergey wrote in the original founders' letter, "Google is not a conventional company. We do not intend to become one." That unconventional spirit has been a driving force throughout our history, inspiring us to tackle big problems and invest in moonshots, such as our long-term opportunities in artificial intelligence (AI). We continue this work under the leadership of Alphabet and Google CEO Sundar Pichai.

Alphabet is a collection of businesses — the largest of which is Google. We report Google in two segments, Google Services and Google Cloud; we also report all non-Google businesses collectively as Other Bets. Alphabet's structure is about helping each of our businesses prosper through strong leaders and independence.

</details>

## Item 1 BUSINESS (blocks 125-127)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> Google Assistant offers the best way to get things done seamlessly across different devices, providing intelligent help throughout a person's day, no matter where they are.

<details><summary>Passage</summary>

The Internet is one of the world’s most powerful equalizers; it propels ideas, people and businesses large and small. Our mission to organize the world’s information and make it universally accessible and useful is as relevant today as it was when we were founded in 1998. Since then, we have evolved from a company that helps people find answers to a company that also helps people get things done.

We are focused on building an even more helpful Google for everyone, and we aspire to give everyone the tools they need to increase their knowledge, health, happiness, and success. Google Search helps people find information and make sense of the world in more natural and intuitive ways, with trillions of searches on Google every year. YouTube provides people with entertainment, information, and opportunities to learn something new. Google Assistant offers the best way to get things done seamlessly across different devices, providing intelligent help throughout a person's day, no matter where they are. Google Cloud helps customers solve today’s business challenges, improve productivity, reduce costs, and unlock new growth engines. We are continually innovating and building new products and features that will help our users, partners, customers, and communities and have invested more than $100 billion in research and development in the last five years in support of these efforts.

Table of Contents Alphabet Inc.

</details>

## Item 1 BUSINESS (blocks 129-133)

**AI reference: explicit | frame: business | roles: adoption, offering | adoption: deployed | functions: marketing_sales, rd_product | kinds: computer_vision, traditional_ml | substantiveness: detailed**

> AI already powers Google’s core products that help billions of people every day and has been at the foundation of our core ads quality systems for years, helping large and small businesses all over the world to produce and run effective and efficient ad campaigns that help grow their businesses.

> Some of our most popular products at Google — including Lens and Translate — were built entirely using artificial intelligence technologies such as optical character recognition and machine learning.

> Google Cloud continues to build AI into numerous solutions that our customers can use to develop AI-powered applications — including processing documents, images, and translation — to understand and analyze data more efficiently, and to use packaged solutions for a variety of industries.

<details><summary>Passage</summary>

Many companies get comfortable doing what they have always done, making only incremental changes. This incrementalism leads to irrelevance over time, especially in technology, where change tends to be revolutionary, not evolutionary. People thought we were crazy when we acquired YouTube and Android and when we launched Chrome, but those efforts have matured into major platforms for digital video and mobile devices and a safer, popular browser. We continue to look toward the future and to invest for the long term within each of our segments. As we said in the original founders' letter, we will not shy away from high-risk, high-reward projects that we believe in, as they are the key to our long-term success.

The power of AI

We believe that AI is a foundational and transformational technology that will provide compelling and helpful benefits to people and society through its capacity to assist, complement, empower, and inspire people in almost every field of human endeavor. As an information and computer science company, we will continue to be at the forefront of advancing the frontier of AI. Through our path-breaking and field-defining research and development, we responsibly and boldly develop more capable and useful AI every day.

AI already powers Google’s core products that help billions of people every day and has been at the foundation of our core ads quality systems for years, helping large and small businesses all over the world to produce and run effective and efficient ad campaigns that help grow their businesses. AI makes it possible to search in new languages, with multiple inputs, such as using images and text at the same time with the Google App. Some of our most popular products at Google — including Lens and Translate — were built entirely using artificial intelligence technologies such as optical character recognition and machine learning. Google Cloud continues to build AI into numerous solutions that our customers can use to develop AI-powered applications — including processing documents, images, and translation — to understand and analyze data more efficiently, and to use packaged solutions for a variety of industries. In all these examples, AI significantly enhances the usefulness and multiplies the value of these products and services to people and organizations.

Our view is that AI is now, and more than ever, critical to delivering on our mission. As we bring our breakthrough AI innovations into the real world to assist people and benefit society everywhere, we are also pursuing further advancements that will help to unlock scientific discoveries and to tackle humanity's greatest challenges and opportunities.

</details>

## Item 1 BUSINESS (blocks 144-145)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> We see tremendous potential for devices to be helpful and make people's lives easier by combining the best of our AI, software, and hardware.

> This potential is reflected in our latest generation of hardware products such as the new Pixel 7 and Pixel 7 Pro, and the very first Pixel Watch.

<details><summary>Passage</summary>

and using apps. Working with content creators and partners, we continue to build new ways for people around the world to find great digital content.

Fueling all of these great digital experiences are extraordinary platforms and hardware. That is why we continue to invest in platforms like our Android mobile operating system, Chrome browser, and Chrome operating system, as well as growing our family of hardware devices. We see tremendous potential for devices to be helpful and make people's lives easier by combining the best of our AI, software, and hardware. This potential is reflected in our latest generation of hardware products such as the new Pixel 7 and Pixel 7 Pro, and the very first Pixel Watch. Creating products that people rely on every day is a journey that we are investing in for the long-term.

</details>

## Item 1 BUSINESS (blocks 156-157)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> Google Cloud Platform provides leading technology in cybersecurity; data, analytics, AI, and machine learning; and infrastructure.

<details><summary>Passage</summary>

Google Cloud

Google was a company built in the cloud, and we continue to invest in our Google Cloud offerings, including Google Cloud Platform and Google Workspace. Google Cloud Platform provides leading technology in cybersecurity; data, analytics, AI, and machine learning; and infrastructure. Our cybersecurity products help customers detect, protect, and respond to a broad range of cybersecurity threats. Our data cloud unifies data lakes, data warehouses, data governance, and advanced machine learning into a single platform that can analyze data across any cloud. We provide customers an open, reliable, and scalable infrastructure that enables them to run workloads anywhere — on our Cloud, at the edge, or in their data centers. Additionally, Google Workspace's easy-to-use and secure communication and collaboration tools, which include apps like Gmail, Docs, Drive, Calendar, Meet, and more, enable secure hybrid work, boosting productivity and collaboration.

</details>

## Item 1A RISK FACTORS (blocks 225-227)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: not_stated | kinds: unspecified | substantiveness: generic**

> The investments that we are making across our businesses, such as in AI, reflect our ongoing efforts to innovate and provide products and services that are useful to users, advertisers, publishers, customers, and content providers.

<details><summary>Passage</summary>

Our ongoing investment in new businesses, products, services, and technologies is inherently risky, and could divert management attention and harm our business, financial condition, and operating results.

We have invested and expect to continue to invest in new businesses, products, services, and technologies. The investments that we are making across our businesses, such as in AI, reflect our ongoing efforts to innovate and provide products and services that are useful to users, advertisers, publishers, customers, and content providers. Our investments span a wide range of industries beyond online advertising. Such investments ultimately may not be commercially viable or may not result in an adequate return of capital and, in pursuing new strategies, we may incur unanticipated liabilities. These endeavors may involve significant risks and uncertainties, including diversion of resources and management attention from current operations and the use of alternative investment, governance, or compensation structures that may fail to adequately align incentives across the company or otherwise accomplish their objectives.

Within Google Services, we continue to invest heavily in hardware, including our smartphones, home devices, and wearables, which is a highly competitive market with frequent introduction of new products and services, rapid adoption of technological advancements by competitors, short product life cycles, evolving industry standards, continual improvement in performance characteristics, and price and feature sensitivity on the part of consumers and businesses. There can be no assurance we will be able to provide hardware that competes effectively.

</details>

## Item 1A RISK FACTORS (blocks 229-231)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: operational_reliability, regulatory_legal, reputational_ethical | mit: ai_pursuing_own_goals, lack_of_capability_robustness, other | kinds: unspecified | substantiveness: generic | traits: hedging**

> In addition, new and evolving products and services, including those that use AI, require significant investment and raise ethical, technological, legal, regulatory, and other challenges, which may negatively affect our brands and demand for our products and services.

<details><summary>Passage</summary>

Within Google Cloud, we devote significant resources to develop and deploy our enterprise-ready cloud services, including Google Cloud Platform and Google Workspace. We are incurring costs to build and maintain infrastructure to support cloud computing services, invest in cybersecurity, and hire talent, particularly to support and scale our sales force. At the same time, our competitors are rapidly developing and deploying cloud-based services. Pricing and delivery models are competitive and constantly evolving, and we may not attain sufficient scale and profitability to achieve our business objectives. Further, our business with public sector customers may present additional risks, including regulatory compliance risks. For instance, we may be subject to government audits and cost reviews, and any failure to comply or any deficiencies found may expose us to legal, financial, and/or reputational risks. Evolving laws and regulations may require us to make new capital investments, build new products, and seek partners to deliver localized services in other countries, and we may not be able to meet sovereign operating requirements.

Within Other Bets, we are investing significantly in the areas of health, life sciences, and transportation, among others. These investment areas face intense competition from large, experienced, and well-funded competitors, and our offerings, many of which involve the development of new and emerging technologies, may not be successful, or be able to compete effectively or operate at sufficient levels of profitability.

In addition, new and evolving products and services, including those that use AI, require significant investment and raise ethical, technological, legal, regulatory, and other challenges, which may negatively affect our brands and demand for our products and services. Because all of these investment areas are inherently risky, no assurance can be given that such strategies and offerings will be successful or will not harm our reputation, financial condition, and operating results.

</details>

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 434-435)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: generic**

> We also may develop new products incorporating AI innovations that could affect our monetization trends.

<details><summary>Passage</summary>

• As online advertising evolves, we continue to expand our product offerings, which may affect our monetization.

As interactions between users and advertisers change, and as online user behavior evolves, we continue to expand our product offerings to serve these changing needs, which may affect our monetization. For example, revenues from ads on YouTube and Google Play monetize at a lower rate than our traditional search ads. We also may develop new products incorporating AI innovations that could affect our monetization trends. Additionally, when developing new products and services we generally focus first on user experience before prioritizing monetization.

</details>

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 443-446)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: it_cybersecurity | kinds: unspecified | substantiveness: generic**

> We also expect to continue to invest in our technical infrastructure, including servers, network equipment, and data centers, to support the growth of our business and our long-term initiatives, in particular in support of AI.

<details><summary>Passage</summary>

• As we continue to serve our users and expand our businesses, we will invest heavily in operating and capital expenditures.

We continue to make significant research and development investments in areas of strategic focus as we seek to develop new, innovative offerings and improve our existing offerings across our businesses. We also expect to continue to invest in our technical infrastructure, including servers, network equipment, and data centers, to support the growth of our business and our long-term initiatives, in particular in support of AI. In addition acquisitions and strategic investments contribute to the breadth and depth of our offerings, expand our expertise in engineering and other functional areas, and build strong partnerships around strategic initiatives. For example, in September 2022 we closed the acquisition of Mandiant to help expand our offerings in dynamic cyber defense and response.

• We face continuing changes in regulatory conditions, laws, and public policies, which could affect our business practices and financial results.

Changes in social, political, economic, tax, and regulatory conditions or in laws and policies governing a wide range of topics and related legal matters have resulted in fines and caused us to change our business practices. As these global trends continue, our cost of doing business may increase, our ability to pursue certain business models or offer certain products or services may be limited, and we may need to change our business practices. Examples include the antitrust complaints filed by the U.S. Department of Justice and a number of state Attorneys General; pending litigation in the U.S., EU, and around the world that could diminish or eliminate safe harbor protection for websites and online platforms; and the Digital Markets Act and Digital Services Act in Europe and various legislative proposals in the U.S. focused on large technology platforms. For additional information see Item 1A Risk Factors and Legal Matters in Note 10 of the Notes to Consolidated Financial Statements included in Part II, Item 8.

</details>

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 553-555)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: not_stated | kinds: unspecified | substantiveness: specific**

> As AI is critical to delivering our mission of bringing our breakthrough innovations into the real world, beginning in January 2023, we will update our segment reporting relating to certain of Alphabet's AI activities.

> DeepMind, previously reported within Other Bets, will be reported as part of Alphabet's corporate costs, reflecting its increasing collaboration with Google Services, Google Cloud, and Other Bets.

<details><summary>Passage</summary>

In January 2023, we completed an assessment of the useful lives of our servers and network equipment, resulting in a change in the estimated useful life of our servers and certain network equipment to six years, which we expect to result in a reduction of depreciation of approximately $3.4 billion for the full fiscal year 2023 for assets in service as of December 31, 2022, recorded primarily in cost of revenues and R&D expenses.

As AI is critical to delivering our mission of bringing our breakthrough innovations into the real world, beginning in January 2023, we will update our segment reporting relating to certain of Alphabet's AI activities. DeepMind, previously reported within Other Bets, will be reported as part of Alphabet's corporate costs, reflecting its increasing collaboration with Google Services, Google Cloud, and Other Bets. Prior periods will be recast to conform to the revised presentation. See Note 15 of the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for information relating to our segments.

Table of Contents Alphabet Inc.

</details>

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 710-717)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: it_cybersecurity | kinds: unspecified | substantiveness: generic**

> technical infrastructure, which consists of our investments in servers and network equipment for computing, storage, and networking requirements for ongoing business activities, including AI, (collectively referred to as our information technology assets) and data center land and building construction;

<details><summary>Passage</summary>

Capital Expenditures and Leases

We make investments in land and buildings for data centers and offices and information technology assets through purchases of property and equipment and lease arrangements to provide capacity for the growth of our services and products.

Capital Expenditures

Our capital investments in property and equipment consist primarily of the following major categories:

technical infrastructure, which consists of our investments in servers and network equipment for computing, storage, and networking requirements for ongoing business activities, including AI, (collectively referred to as our information technology assets) and data center land and building construction; and

office facilities, ground-up development projects, and building improvements (also referred to as "fit-outs").

Construction in progress consists primarily of technical infrastructure and office facilities which have not yet been placed in service. The time frame from date of purchase to placement in service of these assets may extend from months to years. For example, our data center construction projects are generally multi-year projects with multiple

Table of Contents Alphabet Inc.

</details>

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1750-1752)

**AI reference: explicit | frame: business | roles: adoption | adoption: deployed | functions: not_stated | kinds: unspecified | substantiveness: specific**

> As AI is critical to delivering our mission of bringing our breakthrough innovations into the real world, beginning in January 2023, we will update our segment reporting relating to certain of Alphabet's AI activities.

> DeepMind, previously reported within Other Bets, will be reported as part of Alphabet's corporate costs, reflecting its increasing collaboration with Google Services, Google Cloud, and Other Bets.

<details><summary>Passage</summary>

Unallocated corporate costs primarily include corporate initiatives, corporate shared costs, such as finance and legal, including certain fines and settlements, as well as costs associated with certain shared R&D activities. Additionally, hedging gains (losses) related to revenue are included in corporate costs.

As AI is critical to delivering our mission of bringing our breakthrough innovations into the real world, beginning in January 2023, we will update our segment reporting relating to certain of Alphabet's AI activities. DeepMind, previously reported within Other Bets, will be reported as part of Alphabet's corporate costs, reflecting its increasing collaboration with Google Services, Google Cloud, and Other Bets. Prior periods will be recast to conform to the revised presentation.

Our operating segments are not evaluated using asset information.

</details>

# Context passages: implicit mentions, not classified

## unknown section (blocks 99-101)

**Terms: data center (data centers)**

fluctuations in our capital expenditures;

our plans to continue to invest in new businesses, products, services and technologies, systems, land and buildings for data centers, and infrastructure, as well as to continue to invest in acquisitions and strategic investments;

our pace of hiring and our plans to provide competitive compensation programs;

## unknown section (blocks 114-116)

**Terms: server lifecycle (useful life of servers)**

the expected financial effect of our announced workforce reduction and office space optimization;

our expectation that the change in estimated useful life of servers and certain network equipment will have a favorable effect on our 2023 operating results;

as well as other statements regarding our future operations, financial condition and prospects, and business strategies. Forward-looking statements may appear throughout this report and other documents we file with the Securities and Exchange Commission (SEC), including without limitation, the following sections: Part I, Item 1 "Business;" Part I, Item 1A "Risk Factors;" and Part II, Item 7 "Management’s Discussion and Analysis of Financial Condition and Results of Operations." Forward-looking statements generally can be identified by words such as "anticipates," "believes," "estimates," "expects," "intends," "plans," "predicts," "projects," "will be," "will continue," "may," "could," "will likely result," and similar expressions. These forward-looking statements are based on current expectations and assumptions that are subject to risks and uncertainties, which could cause our actual results to differ materially from those reflected in the forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Annual Report on Form 10-K, and in particular, the risks discussed in Part I, Item 1A, "Risk Factors" of this report and those discussed in other documents we file with the SEC. We undertake no obligation to revise or publicly release the results of any revision to these forward-looking statements, except as required by law. Given these risks and uncertainties, readers are cautioned not to place undue reliance on such forward-looking statements.

## Item 1 BUSINESS (blocks 162-164)

**Terms: emerging technologies (disruptive technologies)**

Competition

Our business is characterized by rapid change as well as new and disruptive technologies. We face formidable competition in every aspect of our business, including, among others, from:

general purpose search engines and information services;

## Item 1 BUSINESS (blocks 173-175)

**Terms: digital assistant (digital assistant)**

providers of workspace communication and connectivity products; and

digital assistant providers.

Competing successfully depends heavily on our ability to develop and distribute innovative products and technologies to the marketplace across our businesses. For example, for advertising, competing successfully depends on attracting and retaining:

## Item 1 BUSINESS (blocks 182-186)

**Terms: renewable energy (carbon-free energy, renewable energy)**

In 2007, we became the first major company to be carbon neutral for our operations.

In 2017, we became the first major company to match 100% of our annual electricity use with renewable energy, which we have achieved for five consecutive years.

In 2020, we issued $5.75 billion in sustainability bonds—the largest sustainability or green bond issuance by any company in history at the time. The net proceeds from the issuance were used to fund environmentally and socially responsible projects in the following eight areas: energy efficiency, clean energy, green buildings, clean transportation, circular economy and design, affordable housing, commitment to racial equity, and support for small businesses and COVID-19 crisis response. As of 2022, we had fully allocated the net proceeds from our sustainability bonds as outlined in our Sustainability Bond Impact Report published in 2022.

Our sustainability strategy is focused on three key pillars: accelerating the transition to carbon-free energy and a circular economy, empowering everyone with technology, and benefiting the people and places where we operate.

Table of Contents Alphabet Inc.

## Item 1 BUSINESS (blocks 188-191)

**Terms: megawatt (gigawatts), renewable energy (carbon-free energy)**

achieve net-zero emissions across all of our operations and value chain, including our consumer hardware products;

become the first major company to run on carbon-free energy 24 hours a day, seven days a week, 365 days a year;

enable 5 gigawatts of new carbon-free energy through investments in our key manufacturing regions; and

help more than 500 cities and local governments reduce an aggregate of 1 gigaton (one billion tons) of carbon emissions annually.

## Item 1 BUSINESS (blocks 193-195)

**Terms: data center (data centers), water usage (water stress)**

We are committed to helping people make more sustainable choices by empowering them with technology. We introduced eco-friendly routing in Google Maps; new features to book flights or purchase appliances that have lower carbon footprints; and when people come to Google Search with questions about climate change, we show information from authoritative sources like the United Nations.

To benefit the people and places where we operate, we have set goals to replenish more water than we consume by 2030 and to support water security in communities where we operate. We are focused on three areas: enhancing our stewardship of water resources across Google offices and data centers; replenishing our water use and improving watershed health and ecosystems in water-stressed communities; and sharing technology and tools that help everyone predict, prevent, and recover from water stress. At Google we remain steadfast in our commitment to sustainability, and we will continue to lead and encourage others to join us in improving the health of our planet. We are proud of what we have achieved so far, and we are energized to help move the world closer to a more sustainable and carbon-free future for all.

More information on our approach to sustainability can be found in our annual sustainability reports, including Google’s Environmental Report. The contents of our sustainability reports are not incorporated by reference into this Annual Report on Form 10-K or in any other report or document we file with the SEC. For additional information about risks and uncertainties applicable to our commitments to attain certain sustainability goals, see Risk Factors in Item 1A of this Annual Report on Form 10-K.

## Item 1A RISK FACTORS (blocks 241-243)

**Terms: disinformation (misinformation)**

Our business depends on strong brands, and failing to maintain and enhance our brands would hurt our ability to expand our base of users, advertisers, customers, content providers, and other partners.

Our strong brands have significantly contributed to the success of our business. Maintaining and enhancing the brands within Google Services, Google Cloud, and Other Bets increases our ability to enter new categories and launch new and innovative products and services that better serve the needs of our users, advertisers, customers, content providers, and other partners. Our brands have been, and may in the future be, negatively affected by a number of factors, including, among others, reputational issues, third-party content shared on our platforms, data privacy and security issues and developments, and product or technical performance failures. For example, if we fail to respond appropriately to the sharing of misinformation or objectionable content on our services and/or products or objectionable practices by advertisers, or otherwise to adequately address user concerns, our users may lose confidence in our brands.

Furthermore, failure to maintain and enhance our brands could harm our business, reputation, financial condition, and operating results. Our success will depend largely on our ability to remain a technology leader and continue to provide high-quality, trustworthy, innovative products and services that are truly useful and play a valuable role in a range of settings.

## Item 1A RISK FACTORS (blocks 246-248)

**Terms: data center (data center), export controls (export controls)**

We rely on contract manufacturers to manufacture or assemble our hardware products and servers and networking equipment used in our technical infrastructure, and we may supply the contract manufacturers with components to assemble the hardware products and equipment. We also rely on other companies to participate in the distribution of our products and services. Our business could be negatively affected if we are not able to engage these companies with the necessary capabilities or capacity on reasonable terms, or if those we engage fail to meet their obligations (whether due to financial difficulties or other reasons), or make adverse changes in the pricing or other material terms of our arrangements with them.

We have experienced and/or may in the future experience supply shortages, price increases, and/or longer lead times that could negatively affect our operations, driven by raw material, component availability, manufacturing capacity, labor shortages, industry allocations, logistics capacity, inflation, foreign currency exchange rates, tariffs, sanctions and export controls, trade disputes and barriers, geopolitical tensions, armed conflicts, natural disasters or pandemics, the effects of climate change (such as sea level rise, drought, flooding, heat waves, wildfires and resultant air quality effects and power shutoffs associated with wildfire prevention, and increased storm severity), power loss, and significant changes in the financial or business condition of our suppliers. In addition, some of the components we use in our technical infrastructure and our hardware products are available from only one or limited sources, and we may not be able to find replacement vendors on favorable terms in the event of a supply chain disruption. A significant supply interruption that affects us or our vendors could delay critical data center upgrades or expansions and delay consumer product availability.

We may enter into long-term contracts for materials and products that commit us to significant terms and conditions. We may face costs for materials and products that are not consumed due to market demand, technological change, changed consumer preferences, quality, product recalls, and warranty issues. For instance, because certain of our hardware supply contracts have volume-based pricing or minimum purchase requirements, if the volume of our hardware sales decreases or does not reach projected targets, we could face increased materials and manufacturing costs or other financial liabilities that could make our products more costly per unit to manufacture and harm our financial condition and operating results. Furthermore, certain of our competitors may negotiate more favorable contractual terms based on volume and other commitments that may provide them with competitive advantages and may affect our supply.

## Item 1A RISK FACTORS (blocks 253-254)

**Terms: data center (data centers)**

Interruption to, interference with, or failure of our complex information technology and communications systems could hurt our ability to effectively provide our products and services, which could harm our reputation, financial condition, and operating results.

The availability of our products and services and fulfillment of our customer contracts depend on the continuing operation of our information technology and communications systems. Our systems are vulnerable to damage, interference, or interruption from modifications or upgrades, terrorist attacks, state-sponsored attacks, natural disasters or pandemics, geopolitical tensions or armed conflicts, the effects of climate change (such as sea level rise, drought, flooding, heat waves, wildfires and resultant air quality effects and power shutoffs associated with wildfire prevention, and increased storm severity), power loss, telecommunications failures, computer viruses, software bugs, ransomware attacks, computer denial of service attacks, phishing schemes, or other attempts to harm or access our systems. Some of our data centers are located in areas with a high risk of major earthquakes or other natural disasters. Our data centers are also subject to break-ins, sabotage, and intentional acts of vandalism, and, in some cases, to potential disruptions resulting from problems experienced by facility operators or disruptions as a result of geopolitical tensions and conflicts happening in the area. Some of our systems are not fully redundant, and disaster recovery planning cannot account for all eventualities. The occurrence of a natural disaster or pandemic, closure of a facility, or other unanticipated problems affecting our data centers could result in lengthy interruptions in our service. In addition, our products and services are highly technical and complex and have contained in the past, and may contain in the future, errors or vulnerabilities, which could result in interruptions in or failure of our services or systems. Any of these incidents could impede or prevent us from effectively offering products and providing services, which could harm our reputation, financial condition, and operating results.

## Item 1A RISK FACTORS (blocks 260-262)

**Terms: export controls (export controls)**

an evolving foreign policy landscape that may adversely affect our revenues and could subject us to new regulatory costs and challenges (including new customer requirements), in addition to other adverse effects that we are unable to effectively anticipate;

sanctions, export controls, and trade restrictions that limit our ability to operate in certain jurisdictions or to comply with local laws, including as a result of geopolitical tensions or armed conflicts, such as the ongoing conflict in Ukraine;

political unrest, conflict, and changes in governmental regimes that may adversely affect demand and usage of our products and services, may limit the ability for people in certain areas to access and use our products and services, or may impede us from offering products or providing services to a particular market;

## Item 1A RISK FACTORS (blocks 286-288)

**Terms: disinformation (disinformation), influence operations (election interference)**

Table of Contents Alphabet Inc.

our lack of visibility over our encrypted services, the scale of activity on our platform, or other factors, including factors outside of our control such as a natural disaster or pandemic, and we may learn of such incidents or activity via third parties. Such incidents and activities may include the use of user data or our systems in a manner inconsistent with our terms, contracts or policies, the existence of false or undesirable user accounts, election interference, improper ad purchases, activities that threaten people’s safety on- or off-line, or instances of spamming, scraping, or spreading disinformation. While we may not determine some of these incidents to be material at the time they occurred and we may remedy them quickly, there is no guarantee that these issues will not ultimately result in significant legal, financial, and reputational harm, including government inquiries and enforcement actions, litigation, and negative publicity. There is also no guarantee that a series of issues may not be determined to be material at a later date in the aggregate, even if they may not be material individually at the time of their occurrence.

We may also be unsuccessful in our efforts to enforce our policies or otherwise prevent or remediate any such incidents. Any of the foregoing developments may negatively affect user trust and engagement, harm our reputation and brands, require us to change our business practices in ways that harm our business operations, and adversely affect our business and financial results. Any such developments may also subject us to additional litigation and regulatory inquiries, which could result in monetary penalties and damages, divert management’s time and attention, and lead to enhanced regulatory oversight.

## Item 1A RISK FACTORS (blocks 290-292)

**Terms: disinformation (disinformation, misinformation), influence operations (election interference)**

We, like others in the industry, face violations of our content guidelines across our platforms, including sophisticated attempts by bad actors to manipulate our hosting and advertising systems to fraudulently generate revenues, or to otherwise generate traffic that does not represent genuine user interest or intent. While we invest significantly in efforts to promote high-quality and relevant results and to detect and prevent low-quality content and invalid traffic, we have been unable and may continue to be unable to detect and prevent all such abuses or promote uniformly high-quality content.

Many websites violate or attempt to violate our guidelines, including by seeking to inappropriately rank higher in search results than our search engine's assessment of their relevance and utility would rank them. Such efforts have affected, and may continue to affect, the quality of content on our platforms and lead them to display false, misleading, or undesirable content. Although English-language web spam in our search results has been reduced, and web spam in most other languages is limited, we expect web spammers will continue to seek inappropriate ways to improve their rankings. We continuously combat web spam in our search results, including through indexing technology that makes it harder for spam-like, less useful web content to rank highly. We also continue to invest in and deploy proprietary technology to detect and prevent web spam on our platforms. We also face other challenges from low-quality and irrelevant content websites, including content farms, which are websites that generate large quantities of low-quality content to help them improve their search rankings. We are continually launching algorithmic changes designed to detect and prevent abuse from low-quality websites. We also face other challenges on our platforms, including violations of our content guidelines involving incidents such as attempted election interference, activities that threaten the safety and/or well-being of our users on- or off-line, and the spreading of misinformation or disinformation.

If we fail to either detect and prevent an increase in problematic content or effectively promote high-quality content, it could hurt our reputation for delivering relevant information or reduce use of our platforms, harming our financial condition and operating results. It may also subject us to litigation and regulatory actions, which could result in monetary penalties and damages and divert management’s time and attention.

## Item 1A RISK FACTORS (blocks 300-305)

**Terms: Digital Services Act (Digital Markets Act, Digital Services Act), data sovereignty (data localization), text and data mining (Copyright in the Digital Single Market)**

New or changing laws and regulations, or new interpretations or applications of existing laws and regulations in a manner inconsistent with our practices, have resulted in, and may continue to result in, less useful products and services, altered business practices, limited ability to pursue certain business models or offer certain products and services, substantial costs, and civil or criminal liability. Examples include laws and regulations regarding:

Competition and technology platforms’ business practices: Laws and regulations focused on large technology platforms, including the Digital Markets Act in the European Union (EU); regulations in South Korea and elsewhere that affect Google Play’s billing policies, fees, and business model; as well as regulations under consideration in a range of jurisdictions.

Data privacy, collection, and processing: Laws and regulations further restricting the collection, processing, and/or sharing of user or advertising-related data, including privacy and data protection laws, laws affecting the processing of children's data (as discussed further below), data breach notification laws, and laws limiting data transfers (including data localization laws).

Copyright and other intellectual property : Copyright and related laws, including the EU Directive on Copyright in the Digital Single Market and European Economic Area transpositions, which may introduce new licensing regimes, increase liability with respect to content uploaded by users or linked to from our platforms, or create property rights in news publications that could require payments to news agencies and publishers.

Content moderation : Various laws covering content moderation and removal, and related disclosure obligations, such as the EU's Digital Services Act, Florida’s Senate Bill 7072 and Texas’ House Bill 20, and laws and proposed legislation in Singapore, Australia, and the United Kingdom that impose penalties for failure to remove certain types of content or require disclosure of information about the operation of our services and algorithms, which may make it harder for services like Google Search and YouTube to detect and deal with low-quality, deceptive, or harmful content.

Consumer protection : Consumer protection laws, including the EU’s New Deal for Consumers, which could result in monetary penalties and create a range of new compliance obligations.

## Item 1A RISK FACTORS (blocks 316-318)

**Terms: biometric privacy (Biometric Information Privacy Act)**

Various state and foreign privacy laws and regulations, such as the California Consumer Privacy Act of 2018, the California Privacy Rights Act, the Virginia Consumer Data Protection Act, the Colorado Privacy Act, the Connecticut Data Privacy Act, and the Utah Consumer Privacy Act, all of which give new data privacy rights to their respective residents (including, in California, a private right of action in the event of a data breach resulting from our failure to implement and maintain reasonable security procedures and practices) and impose significant obligations on controllers and processors of consumer data.

State laws governing the processing of biometric information, such as the Illinois Biometric Information Privacy Act and the Texas Capture or Use of Biometric Identifier Act, which impose obligations on businesses that collect or disclose consumer biometric information.

Various federal, state, and foreign laws governing how companies provide age appropriate experiences to children and minors, including the collection and processing of children and minor’s data. These include the Children’s Online Privacy Protection Act of 1998, the United Kingdom Age-Appropriate Design Code, and the California Age Appropriate Design Code, all of which address the use and disclosure of the personal data of children and minors and impose obligations on online services or products directed to or likely to be accessed by children.

## Item 1A RISK FACTORS (blocks 320-322)

**Terms: Digital Services Act (Digital Markets Act)**

Table of Contents Alphabet Inc.

The EU’s Digital Markets Act, which will require in-scope companies to obtain user consent for combining data across certain products and require search engines to share anonymized data with rival companies, among other changes.

Further, we are subject to evolving laws and regulations that dictate whether, how, and under what circumstances we can transfer, process and/or receive personal data. Previously available transfer mechanisms, such as the EU-U.S. and the Swiss-U.S. Privacy Shield frameworks, were invalidated in 2020, and other bases for data transfer and storage, such as Standard Contractual Clauses, remain subject to ongoing review in ways that may require us to adapt our existing contractual arrangements. The validity of various data transfer mechanisms remains subject to legal, regulatory, and political developments in both Europe and the U.S., including the potential adoption of the U.S.-EU Data Privacy Framework. Until the U.S.-EU Data Privacy Framework is adopted by the EU, the legal uncertainty and ongoing enforcement action from supervisory authorities related to cross-border transfers of personal data, could harm our ability to process and transfer personal data outside of the European Economic Area and could in turn harm our ability to provide, and our customers’ ability to use, some of our products and services.

## Item 2 PROPERTIES (blocks 379-380)

**Terms: data center (data centers)**

ITEM 2. PROPERTIES

Our headquarters are located in Mountain View, California. We own and lease office facilities and data centers around the world, primarily in North America, Europe, and Asia. We believe our existing facilities are in good condition and suitable for the conduct of our business.

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 500-502)

**Terms: data center (data centers)**

Content acquisition costs, which are payments to content providers from whom we license video and other content for distribution on YouTube and Google Play (we pay fees to these content providers based on revenues generated or a flat fee).

Expenses associated with our data centers (including bandwidth, compensation expenses, depreciation, energy, and other equipment costs) as well as other operations costs (such as content review as well as customer and product support costs).

Inventory and other costs related to the hardware we sell.

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 636-638)

**Terms: data center (data center)**

The increase in TAC from 2021 to 2022 was due to an increase in TAC paid to distribution partners and to Google Network partners, primarily driven by growth in revenues subject to TAC. The TAC rate was 22% in both 2021 and 2022. The TAC rate on Google Search & other revenues and the TAC rate on Google Network revenues were both substantially consistent from 2021 to 2022.

The increase in other cost of revenues from 2021 to 2022 was primarily due to increases in data center costs and other operations costs as well as hardware costs.

Table of Contents Alphabet Inc.

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 688-689)

**Terms: sale-leaseback (asset-backed securities)**

Cash, Cash Equivalents, and Marketable Securities

As of December 31, 2022 , we had $113.8 billion in cash, cash equivalents, and short-term marketable securities. Ca sh equivalents and marketable securities a re comprised of time deposits, money market funds, highly liquid government bonds, corporate debt securities, mortgage-backed and asset-backed securities, and marketable equity securities.

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 738-739)

**Terms: renewable energy (renewable energy)**

As of December 31, 2022, we had material non-cancelable contractual obligations of $32.0 billion , of which $17.3 billion was short-term. These amounts represent the non-cancelable portion of agreements or the minimum cancellation fee and are primarily related to commitments to purchase licenses, technical infrastructure, inventory, and network capacity. For those agreements with variable terms, we do not estimate the non-cancelable obligation beyond any minimum quantities and/or pricing as of December 31, 2022.

In addition we regularly enter into multi-year, non-cancellable agreements to purchase renewable energy and energy attributes, such as renewable energy certificates. These agreements do not include a minimum dollar commitment. The amounts to be paid under these agreements are based on the actual volumes to be generated and are not readily determinable.

## Item 7A QUANTITATIVE AND QUALITATIVE DISCLOSURES ABOUT MARKET RISK (blocks 770-772)

**Terms: sale-leaseback (asset-backed securities)**

Interest Rate Risk

Our Corporate Treasury investment strategy is to achieve a return that w ill allow us to preserve capital and maintain liquidity. We invest primarily in debt securities, including government bonds, corporate debt securities, mortgage-backed and asset-backed securities, money market and other funds, time deposits, and interest rate derivatives. By policy, we limit the amount of credit exposure to any one issuer. Our investments in both fixed rate and floating rate interest earning securities carry a degree of interest rate risk. Fixed rate securities may have their fair market value adversely affected due to a rise in interest rates, while floating rate securities may produce less income than predicted if interest rates fall. Unrealized gains or losses on our marketable debt securities are primarily due to interest rate fluctuations as compared to interest rates at the time of purchase. For certain fixed and variable rate debt securities, we have elected the fair value option for which changes in fair value are recorded in other income (expense), net. We measure securities for which we have not elected the fair value option at fair value with gains and losses recorded in AOCI until the securities are sold, less any expected credit losses.

We use value-at-risk (VaR) analysis to determine the potential effect of fluctuations in interest rates on the value of our marketable debt security portfolio. The VaR is the expected loss in fair value, for a given confidence interval, for our investment portfolio due to adverse movements in interest rates. We use a variance/covariance VaR model with 95% confidence interval. The estimated one-day loss in fair value of marketable debt securities as of December 31, 2021 and 2022 are shown below (in millions):

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1046-1048)

**Terms: data center (data centers)**

Content acquisition costs, which are payments to content providers from whom we license video and other content for distribution on YouTube and Google Play (we pay fees to these content providers based on revenues generated or a flat fee).

Expenses associated with our data centers (including bandwidth, compensation expenses, depreciation, energy, and other equipment costs) as well as other operations costs (such as content review as well as customer and product support costs).

Inventory and other costs related to the hardware we sell.

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1074-1075)

**Terms: sale-leaseback (asset-backed securities)**

Cash Equivalents

We invest excess cash primarily in government bonds, corporate debt securities, mortgage-backed and asset-backed securities, time deposits, and money market funds.

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1102-1104)

**Terms: data center (data centers)**

Property and Equipment

Property and equipment includes the following categories: land and buildings, information technology assets, construction in progress, leasehold improvements, and furniture and fixtures. Land and buildings include land, offices, data centers, and related building improvements. Information technology assets include servers and network equipment. Construction in progress is the construction or development of property and equipment that have not yet been placed in service.

We account for property and equipment at cost less accumulated depreciation. We compute depreciation using the straight-line method over the estimated useful lives of the assets, which we regularly evaluate. Land is not depreciated. We depreciate buildings over periods of seven to 25 years. We depreciate information technology assets generally over periods of four to five years (generally, four years for servers and five years for network equipment). We depreciate leasehold improvements over the shorter of the remaining lease term or the estimated useful lives of the assets. Depreciation for buildings, information technology assets, leasehold improvements, and furniture and fixtures commences once they are ready for our intended use.

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1150-1152)

**Terms: take-or-pay (Revenue Backlog, remaining performance obligations, revenue backlog)**

(1) Regions represent Europe, the Middle East, and Africa (EMEA); Asia-Pacific (APAC); and Canada and Latin America ("Other Americas").

Revenue Backlog

As of December 31, 2022, we had $ 64.3 billion of remaining performance obligations (“revenue backlog”), primarily related to Google Cloud. Our revenue backlog represents commitments in customer contracts for future services that have not yet been recognized as revenue. The amount and timing of revenue recognition for these commitments is largely driven by our ability to deliver in accordance with relevant contract terms and when our customers utilize services, which could affect our estimate of revenue backlog and when we expect to recognize such as revenue. We expect to recognize approximately half of the revenue backlog as revenues over the next 24 months with the remaining to be recognized thereafter. Revenue backlog includes related deferred revenue currently recorded as well as amounts that will be invoiced in future periods, and excludes contracts with an original expected term of one year or less and cancellable contracts.

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1166-1168)

**Terms: sale-leaseback (asset-backed securities)**

Corporate debt securities | Level 2 | 35,605 | 194 | ( 223 ) | 35,576 | 12 | 35,564

Mortgage-backed and asset-backed securities | Level 2 | 18,829 | 96 | ( 112 ) | 18,813 | 0 | 18,813

Total investments with fair value change reflected in Other Comprehensive Income (2) | $ 112,855 | $ 548 | $ ( 573 ) | $ 112,830 | $ 5,150 | $ 107,680

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1174-1176)

**Terms: sale-leaseback (asset-backed securities)**

Corporate debt securities | Level 2 | 2,503 | 0 | 2,503

Mortgage-backed and asset-backed securities | Level 2 | 1,007 | 0 | 1,007

Total investments with fair value change recorded in Net Income | $ 18,523 | $ 7,499 | $ 11,024

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1187-1189)

**Terms: sale-leaseback (asset-backed securities)**

Corporate debt securities | Level 2 | 28,578 | 8 | ( 1,569 ) | 27,017 | 1 | 27,016

Mortgage-backed and asset-backed securities | Level 2 | 16,176 | 5 | ( 1,242 ) | 14,939 | 0 | 14,939

Total investments with fair value change reflected in Other Comprehensive Income (2) | $ 91,087 | $ 77 | $ ( 4,856 ) | $ 86,308 | $ 5,577 | $ 80,731

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1195-1197)

**Terms: sale-leaseback (asset-backed securities)**

Corporate debt securities | Level 2 | 3,744 | 65 | 3,679

Mortgage-backed and asset-backed securities | Level 2 | 1,686 | 2 | 1,684

Total investments with fair value change recorded in Net Income | $ 18,893 | $ 7,741 | $ 11,152

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1219-1221)

**Terms: sale-leaseback (asset-backed securities)**

Corporate debt securities | 22,737 | ( 152 ) | 303 | ( 5 ) | 23,040 | ( 157 )

Mortgage-backed and asset-backed securities | 11,502 | ( 106 ) | 248 | ( 6 ) | 11,750 | ( 112 )

Total | $ 67,082 | $ ( 494 ) | $ 622 | $ ( 13 ) | $ 67,704 | $ ( 507 )

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1225-1227)

**Terms: sale-leaseback (asset-backed securities)**

Corporate debt securities | 11,228 | ( 440 ) | 15,125 | ( 1,052 ) | 26,353 | ( 1,492 )

Mortgage-backed and asset-backed securities | 7,725 | ( 585 ) | 6,964 | ( 657 ) | 14,689 | ( 1,242 )

Total | $ 39,992 | $ ( 2,029 ) | $ 35,527 | $ ( 2,750 ) | $ 75,519 | $ ( 4,779 )

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1349-1351)

**Terms: data center (data centers)**

Note 4. Leases

We have entered into operating lease agreements primarily for data centers, land, and offices throughout the world with lease periods expiring between 2023 and 2063.

Components of operating lease expense were as follows (in millions):

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1377-1379)

**Terms: renewable energy (renewable energy)**

Unconsolidated VIEs

We have investments in VIEs in which we are not the primary beneficiary. These VIEs include private companies that are primarily early stage companies and certain renewable energy entities in which activities involve power generation using renewable sources.

We have determined that the governance structures of these entities do not allow us to direct the activities that would significantly affect their economic performance. Therefore, we are not the primary beneficiary, and the results of operations and financial position of these VIEs are not included in our consolidated financial statements. We account for these investments as non-marketable equity securities or equity method investments.

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1531-1533)

**Terms: data licensing (content licensing agreements)**

Commitments

We have content licensing agreements with future fixed or minimum guaranteed commitments of $ 12.3 billion as of December 31, 2022, of which the majority will be paid over seven years commencing in 2023.

Table of Contents Alphabet Inc.
