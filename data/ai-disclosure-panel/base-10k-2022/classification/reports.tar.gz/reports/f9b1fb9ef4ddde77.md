# NVIDIA CORP | 10-K | fiscal year 2023

- Report length: 48,839 words
- Direct AI mentions (classified): 21, of which about AI: 20, false candidates: 1, flagged for review: 0
- Context passages (not classified): 78; groups: products_vendors (66), compute_infrastructure (17)
- Frames: business (12), risk_factor (7), governance (1)
- Roles: offering (11), risk (8), market_driver (1), governance (1)
- Risk types: market_demand (3), regulatory_legal (3), reputational_ethical (2), strategic_competitive (2), national_security (1)
- MIT subdomains: other (8), compromise_of_privacy (1)
- Adoption stage: none
- Business functions: none
- Governance responses: policies_processes (1)
- Kinds of AI: unspecified (11), traditional_ml (6), generative_llm (5), recommendation (1)
- Substantiveness: detailed (8), specific (7), generic (5)
- Disclosure traits: hedging (5)
- Trait activation rate: 0.25 (boilerplate (0.0), hedging (0.25), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 1 (7), Item 1A (7), Item 7 (5), Item 15 (1)
- Named entities: Advanced Micro Devices, Inc., Alibaba Group, Alphabet Inc., Amazon, Inc., Ambarella, Inc., Applied Optoelectronics, Inc., Arista Networks, Baidu, Inc., Broadcom Inc., Cisco Systems, Inc., GeForce GTX, GeForce RTX, Grace CPU, Hewlett Packard Enterprise Company, Intel Corporation, Juniper Networks, Inc., Lumentum Holdings, Marvell Technology Group, NVIDIA, NVIDIA AI, NVIDIA AI Enterprise, NVIDIA Bluefield DPU, NVIDIA DGX Cloud, NVIDIA DLSS, NVIDIA DRIVE, NVIDIA DRIVE Hyperion, NVIDIA DRIVE Sim, NVIDIA Omniverse, NVIDIA Omniverse Avatar, NVIDIA RTX, Omniverse, Qualcomm Incorporated, Renesas Electronics Corporation, SHIELD, Samsung, Tesla, Inc.

## Item 1 BUSINESS (blocks 88-101)

**AI reference: explicit | frame: business | roles: offering | kinds: generative_llm, recommendation, traditional_ml | substantiveness: detailed**

> NVIDIA pioneered accelerated computing to help solve the most challenging computational problems.

> Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, artificial intelligence, or AI, data science, autonomous vehicles, or AV, robotics, metaverse and 3D internet applications.

> GPU-powered deep learning is being adopted by thousands of enterprises to deliver services and products that would have been immensely difficult with traditional coding.

<details><summary>Passage</summary>

Our Company

NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Since our original focus on PC graphics, we have expanded to several other large and important computationally intensive fields. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, artificial intelligence, or AI, data science, autonomous vehicles, or AV, robotics, metaverse and 3D internet applications.

The GPU was initially used to simulate human imagination, enabling the virtual worlds of video games and films. Today, it also simulates human intelligence, enabling a deeper understanding of the physical world. Its parallel processing capabilities, supported by thousands of computing cores, are essential to running deep learning algorithms. This form of AI, in which software writes itself by learning from large amounts of data, can serve as the brain of computers, robots and self-driving cars that can perceive and understand the world. GPU-powered deep learning is being adopted by thousands of enterprises to deliver services and products that would have been immensely difficult with traditional coding. Some of the most recent applications of GPU-powered deep learning include recommendation systems, which are AI algorithms trained to understand the preferences, previous decisions, and characteristics of people and products using data gathered about their interactions, large language models, which can recognize, summarize, translate, predict and generate text and other content based on knowledge gained from massive datasets, and generative AI, which uses algorithms that create new content, including audio, code, images, text, simulations, and videos, based on the data they have been trained on.

NVIDIA has a platform strategy, bringing together hardware, systems, software, algorithms, libraries, and services to create unique value for the markets we serve. While the computing requirements of these end markets are diverse, we address them with a unified underlying architecture leveraging our GPUs and software stacks. The programmable nature of our architecture allows us to support several multi-billion-dollar end markets with the same underlying technology by using a variety of software stacks developed either internally or by third-party developers and partners. The large and growing number of developers across our platforms strengthens our ecosystem and increases the value of our platform to our customers.

Innovation is at our core. We have invested over $37 billion in research and development since our inception, yielding inventions that are essential to modern computing. Our invention of the GPU in 1999 defined modern computer graphics and established NVIDIA as the leader in computer graphics. With our introduction of the CUDA programming model in 2006, we opened the parallel processing capabilities of our GPU for general purpose computing. This approach significantly accelerates the most demanding high-performance computing, or HPC, applications in fields such as aerospace, bio-science research, mechanical and fluid simulations, and energy exploration. Today, our GPUs and networking accelerate many of the fastest supercomputers across the world. In addition, the massively parallel compute architecture of our GPUs and associated software are well suited for deep learning and machine learning, powering the era of AI. While traditional CPU-based approaches no longer deliver advances on the pace described by Moore’s Law, NVIDIA accelerated computing delivers performance improvements on a pace ahead of Moore’s Law, giving the industry a path forward.

Gamers choose NVIDIA GPUs to enjoy immersive, increasingly cinematic virtual worlds. GPUs also help underpin the world’s fastest growing spectator sport, eSports, which attracts hundreds of millions of viewers to watch top-quality live video gaming. In addition to serving the growing number of gamers, the market for gaming GPUs is expanding because of the burgeoning population of live streamers, broadcasters, artists and creators.

Researchers and developers use our GPUs to accelerate a wide range of important applications, from simulating molecular dynamics to climate forecasting. With support for more than 2,800 applications - including 23 of the top 25 HPC applications - NVIDIA GPUs enable some of the most promising areas of discovery, from climate prediction to materials science and from wind tunnel simulation to genomics. Including GPUs and networking, NVIDIA powers over 70% of the supercomputers on the global TOP500 list, including 23 of the top 30 systems on the Green500 list.

The world’s leading cloud service providers, or CSPs, and consumer internet companies use our GPUs and broader data center-scale accelerated computing platforms to enable, accelerate or enrich the services they deliver to billions of end-users, including search, recommendations, social networking, online shopping, live video, translation, AI assistants, navigation, and cloud computing.

A rapidly growing number of enterprises and startups across a broad range of industries use our GPUs and software to bring automation to the products and services they build. The transportation industry is turning to our platforms for autonomous driving; the healthcare industry is leveraging them for enhanced medical imaging and acceleration of drug discovery; and the financial services industry is using them for fraud detection.

Professional designers use our GPUs and software to create visual effects in movies and to design buildings and products ranging from cell phones to commercial aircraft.

Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

Termination of the Arm Share Purchase Agreement

In February 2022, NVIDIA and SoftBank Group Corp., or SoftBank, announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm Limited, or Arm, from SoftBank. The parties agreed to terminate because of significant regulatory challenges preventing the completion of the transaction. We recorded an acquisition termination cost of $1.35 billion in fiscal year 2023 reflecting the write-off of the prepayment provided at signing.

</details>

## Item 1 BUSINESS (blocks 103-120)

**AI reference: explicit | frame: business | roles: offering | kinds: generative_llm, traditional_ml | substantiveness: detailed**

> The NVIDIA computing platform is focused on accelerating the most compute-intensive workloads, such as AI, data analytics, graphics and scientific computing, across hyperscale, cloud, enterprise, public sector, and edge data centers.

> In the field of AI, NVIDIA’s platform accelerates both deep learning and machine learning workloads.

> NVIDIA will offer enterprise customers NVIDIA AI cloud services directly and through our network of partners.

<details><summary>Passage</summary>

We report our business results in two segments.

The Compute & Networking segment includes our Data Center accelerated computing platform; networking; automotive AI Cockpit, autonomous driving development agreements, and autonomous vehicle solutions; electric vehicle computing platforms; Jetson for robotics and other embedded platforms; NVIDIA AI Enterprise and other software; and cryptocurrency mining processors, or CMP.

The Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro/NVIDIA RTX GPUs for enterprise workstation graphics; virtual GPU, or vGPU, software for cloud-based visual and virtual computing; automotive platforms for infotainment systems; and Omniverse Enterprise software for building and operating metaverse and 3D internet applications.

Our Markets

We specialize in markets in which our computing platforms can provide tremendous acceleration for applications. These platforms incorporate processors, interconnects, software, algorithms, systems, and services to deliver unique value. Our platforms address four large markets where our expertise is critical: Data Center, Gaming, Professional Visualization, and Automotive.

Data Center

The NVIDIA computing platform is focused on accelerating the most compute-intensive workloads, such as AI, data analytics, graphics and scientific computing, across hyperscale, cloud, enterprise, public sector, and edge data centers. The platform consists of our energy efficient GPUs, data processing units, or DPUs, interconnects and systems, our CUDA programming model, and a growing body of software libraries, software development kits, or SDKs, application frameworks and services, which are either available as part of the platform or packaged and sold separately.

For both AI and HPC applications, the NVIDIA accelerated computing platform greatly increases computer and data center performance and power efficiency relative to conventional CPU-only approaches. In the field of AI, NVIDIA’s platform accelerates both deep learning and machine learning workloads. Deep learning is a computer science approach where neural networks are trained to recognize patterns from massive amounts of data in the form of images, sounds and text - in some instances better than humans - and in turn provide predictions in production use cases. Machine learning is a related approach that leverages algorithms as well

as data to learn how to make determinations or predictions. HPC, which includes scientific computing, uses numerical computational approaches to solve large and complex problems.

We are engaged with thousands of organizations working on AI in a multitude of industries, from automating tasks such as consumer product and service recommendations, to chatbots for the automation of or assistance with live customer interactions, to enabling fraud detection in financial services, to optimizing oil exploration and drilling. These organizations include the world’s leading consumer internet and cloud services companies, enterprises and startups seeking to implement AI in transformative ways across multiple industries. We partner with industry leaders to help transform their applications or their computing platforms. We also have partnerships in transportation, retail, healthcare, and manufacturing, among others, to accelerate the adoption of AI.

At the foundation of the NVIDIA accelerated computing platform are our GPUs, which excel at parallel workloads such as the training and inferencing of neural networks. They are available in industry standard servers from every major computer maker and CSP, as well as in our DGX AI supercomputer, a purpose-built system for deep learning and GPU accelerated applications. To facilitate customer adoption, we have also built other ready-to-use system reference designs around our GPUs, including HGX for hyperscale and supercomputing data centers, EGX for enterprise and edge computing, IGX for high-precision edge AI, and AGX for autonomous machines.

In fiscal year 2023, we introduced the Hopper architecture of data center GPUs, and started shipping the first Hopper-based GPU – the flagship H100. Hopper includes a Transformer Engine, designed to accelerate the training of AI transformer models by an order of magnitude over the prior generation. H100 is ideal for accelerating applications such as large language models, deep recommender systems, genomics and complex digital twins.

NVIDIA will offer enterprise customers NVIDIA AI cloud services directly and through our network of partners. Examples of these services include NVIDIA DGX Cloud, which is cloud-based infrastructure and software for training AI models, and customizable pretrained AI models. NVIDIA has partnered with leading cloud service providers to host these services in their data centers.

Our networking solutions include InfiniBand and Ethernet network adapters and switches, related software, and cables. This has enabled us to architect end-to-end data center-scale computing platforms that can interconnect thousands of compute nodes with high-performance networking. While historically the server was the unit of computing, as AI and HPC workloads have become extremely large spanning thousands of compute nodes, the data center has become the new unit of computing, with networking as an integral part.

Beyond GPUs, NVIDIA has expanded its data center processor portfolio to include DPUs, currently shipping in the market, and CPUs with samples planned to ship in the first half of fiscal year 2024. The NVIDIA Bluefield DPU is supported by foundational data-center-infrastructure-on-a-chip software, or DOCA, that lets developers build software-defined, hardware-accelerated networking, security, storage and management applications for BlueField DPUs. Partners supporting Bluefield include many of the top security, storage and networking companies. We can optimize across the entire computing, networking and storage stack to deliver data center-scale computing solutions. The Grace CPU is designed for AI infrastructure and high-performance computing, providing the highest performance and twice the memory bandwidth and energy-efficiency compared to today’s leading server chips.

While our approach starts with powerful chips, what makes it a full-stack computing platform is our large body of software, including the CUDA parallel programming model, the CUDA-X collection of application acceleration libraries, Application Programming Interfaces, or APIs, SDKs and tools, and domain-specific application frameworks. We also offer the NVIDIA GPU Cloud registry, or NGC, a comprehensive catalog of easy-to-use, optimized software stacks across a range of domains including scientific computing, deep learning, and machine learning. With NGC, AI developers, researchers and data scientists can get started with the development of AI and HPC applications and deploy them on DGX systems, NVIDIA-Certified systems from our partners, or with NVIDIA’s cloud partners.

In addition to software that is delivered to customers as an integral part of our data center computing platform, we offer paid licenses to NVIDIA AI Enterprise, a comprehensive suite of enterprise-grade AI software; and NVIDIA vGPU software for graphics-rich virtual desktops and workstations.

</details>

## Item 1 BUSINESS (blocks 123-145)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: detailed**

> Our gaming platforms leverage our GPUs and sophisticated software to enhance the gaming experience with smoother, higher quality graphics.

> We developed NVIDIA RTX to bring next generation graphics and AI to games.

> NVIDIA’s Automotive market is comprised of AV, AI cockpit, electric vehicle computing platforms, and infotainment platform solutions.

<details><summary>Passage</summary>

Gaming is the largest entertainment industry, with PC gaming as the predominant platform. Many factors propel computer gaming’s growth, including new high production value games and franchises, the continued rise of competitive gaming or eSports, social connectivity and the increasing popularity of game streamers, modders, or gamers who create game modifications, and creators.

Our gaming platforms leverage our GPUs and sophisticated software to enhance the gaming experience with smoother, higher quality graphics. We developed NVIDIA RTX to bring next generation graphics and AI to games. NVIDIA RTX features ray tracing technology for real-time, cinematic-quality rendering. Ray tracing, which has long been used for special effects in the movie industry, is a computationally intensive technique that simulates the physical behavior of light to achieve greater realism in computer-generated scenes. NVIDIA RTX also features deep learning super sampling, or NVIDIA DLSS, our AI technology that boosts frame rates while generating beautiful, sharp images for games.

Our products for the gaming market include GeForce RTX and GeForce GTX GPUs for gaming desktop and laptop PCs, GeForce NOW cloud gaming for playing PC games on underpowered devices, SHIELD for high quality streaming on TV, as well as system-on-chips (SOCs) and development services for game consoles.

In fiscal year 2023, we introduced the GeForce RTX 40 Series of gaming GPUs, based on the Ada Lovelace architecture. The 40 Series features our third generation RTX technology, third generation NVIDIA DLSS, and fourth generation Tensor Cores to deliver up to 4X the performance of the previous generation.

Professional Visualization

We serve the Professional Visualization market by working closely with independent software vendors, or ISVs, to optimize their offerings for NVIDIA GPUs. Our GPU computing platform enhances productivity and introduces new capabilities for critical workflows in many fields, such as design and manufacturing and digital content creation. Design and manufacturing encompass computer-aided design, architectural design, consumer-products manufacturing, medical instrumentation, and aerospace. Digital content creation includes professional video editing and post-production, special effects for films, and broadcast-television graphics.

The NVIDIA RTX platform makes it possible to render film-quality, photorealistic objects and environments with physically accurate shadows, reflections and refractions using ray tracing in real-time. Many leading 3D design and content creation applications developed by our ecosystem partners now support RTX, allowing professionals to accelerate and transform their workflows with NVIDIA RTX GPUs and software.

Digital images used in product design need to mirror reality. This requires simulating the physical behavior of light and materials, or physically-based rendering. NVIDIA Omniverse is a virtual world simulation and collaboration platform for 3D workflows, such as building and operating metaverse and 3D internet applications, available as a software subscription for enterprise use and free for individual use. Omniverse, virtual reality, or VR, and augmented reality, or AR, are being incorporated in a growing number of enterprise applications. Virtual car showrooms, surgical training, architectural walkthroughs, and bringing historical scenes to life all deploy these technologies, powered by our GPUs.

Automotive

NVIDIA’s Automotive market is comprised of AV, AI cockpit, electric vehicle computing platforms, and infotainment platform solutions. Leveraging our technology leadership in AI and building on our long-standing automotive relationships, we are delivering a complete end-to-end solution for the AV market under the DRIVE Hyperion brand. NVIDIA has demonstrated multiple applications of AI within the car: AI can drive the car itself as a pilot in fully autonomous mode or it can also be a co-pilot, assisting the human driver while creating a safer driving experience.

NVIDIA is working with several hundred partners in the automotive ecosystem including automakers, truck makers, tier-one suppliers, sensor manufacturers, automotive research institutions, HD mapping companies, and startups to develop and deploy AI systems for self-driving vehicles. Our unified AI computing architecture starts with training deep neural networks using our GPUs, and then running a full perception, fusion, planning and control stack within the vehicle on the NVIDIA DRIVE Hyperion platform. The DRIVE Hyperion platform consists of the high-performance, energy efficient DRIVE AGX computing hardware, a reference sensor set that supports full self-driving capability as well as an open, modular DRIVE Software

platform. The DRIVE Software platform includes DRIVE Chauffeur for autonomous driving, mapping and parking services, Drive Concierge for intelligent in-vehicle experiences, and real time conversational AI capability based on NVIDIA Omniverse Avatar software.

In addition, we offer a scalable data center-based simulation solution, NVIDIA DRIVE Sim, based on NVIDIA Omniverse software, for digital cockpit development, as well as for testing and validating a self-driving platform. NVIDIA's unique end-to-end, software-defined approach is designed for continuous innovation and continuous development, enabling cars to receive over-the-air updates to add new features and capabilities throughout the life of a vehicle.

Business Strategies

NVIDIA’s key strategies that shape our overall business approach include:

Advancing the NVIDIA accelerated computing platform. NVIDIA’s accelerated computing platform can solve complex problems in significantly less time and with lower power consumption than alternative computational approaches. Indeed, it can help solve problems that were previously deemed unsolvable. We work to deliver continued performance leaps that outpace Moore’s Law by leveraging innovation across the architecture, chip design, system, interconnect, and software layers. This full-stack innovation approach allows us to deliver order-of-magnitude performance advantages relative to legacy approaches in our target markets, which include Data Center, Gaming, Professional Visualization, and Automotive. While the computing requirements of these end markets are diverse, we address them with a unified underlying architecture leveraging our GPUs, CUDA and networking technologies as the fundamental building blocks. The programmable nature of our architecture allows us to make leveraged investments in research and development: we can support several multi-billion-dollar end markets with shared underlying technology by using a variety of software stacks developed either internally or by third-party developers and partners. We utilize this platform approach in each of our target markets.

Extending our technology and platform leadership in AI. We provide a complete, end-to-end accelerated computing platform for deep learning and machine learning, addressing both training and inferencing. This includes GPUs, interconnects, systems, our CUDA programming language, algorithms, libraries, and other software. GPUs are uniquely suited to AI, and we will continue to add AI-specific features to our GPU architecture to further extend our leadership position. Our AI technology leadership is reinforced by our large and expanding ecosystem in a virtuous cycle. Our GPU platforms are available from virtually every major server maker and CSP, as well as on our own AI supercomputer. There are 3.8 million developers worldwide using CUDA and our other software tools to help deploy our technology in our target markets. We evangelize AI through partnerships with hundreds of universities and over 13,000 startups through our Inception program. Additionally, our Deep Learning Institute provides instruction on the latest techniques on how to design, train, and deploy neural networks in applications using our accelerated computing platform.

Extending our technology and platform leadership in computer graphics. We believe that computer graphics is fundamental to the continued expansion and evolution of computing. We apply our research and development resources to enhance the user experience for consumer entertainment and professional visualization applications, and create new virtual world and simulation capabilities. Our technologies are instrumental in driving gaming forward, as developers leverage our libraries and algorithms to deliver an optimized gaming experience on our GeForce platform. Our computer graphics platforms leverage not only our industry-leading GeForce and NVIDIA RTX GPUs, but also optimized software stacks. For example, GeForce Experience enhances each gamer’s experience by optimizing their PC’s settings, as well as enabling the recording and sharing of gameplay. Our Studio drivers enhance and accelerate a number of popular creative applications. Omniverse is real-time 3D design collaboration and virtual world simulation software that empowers artists, designers and creators to connect and collaborate in leading design applications. We also enable interactive graphics applications - such as games, movie and photo editing and design software - to be accessed by almost any device, almost anywhere, through our cloud platforms such as vGPU for enterprise and GeForce NOW for gaming.

Advancing the leading autonomous vehicle platform. We believe the advent of AV will soon revolutionize the transportation industry. In our view, AI is the key technology enabler of this opportunity, as the algorithms required for autonomous driving - such as perception, localization, and planning - are too complex for legacy hand-coded approaches and will use multiple trained neural networks instead. Therefore, we provide a full functionally safe AI-based hardware and software solution for the AV market under the DRIVE brand, which we are bringing to market through our partnerships with automotive original equipment manufacturers, or

OEMs, tier-1 suppliers, and start-ups. Our AV solution also includes the GPU-based hardware required to train the neural networks before their in-vehicle deployment, as well as to re-simulate their operation prior to any over-the-air software updates. We believe our comprehensive, top-to-bottom and end-to-end approach will enable the transportation industry to solve the complex problems arising from the shift to autonomous driving.

Leveraging our intellectual property, or IP. We believe our IP is a valuable asset that can be accessed by our customers and partners through license and development agreements when they desire to build such capabilities directly into their own products, or have us do so through a custom development. Such license and development arrangements can further enhance the reach of our technology.

</details>

## Item 1 BUSINESS (blocks 148-152)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: detailed**

> Our developer program makes our products available to developers prior to launch in order to encourage the development of AI frameworks, SDKs, and APIs for software applications and game titles that are optimized for our platforms.

> Our Deep Learning Institute provides in-person and online training for developers in industries and organizations around the world to build AI and accelerated computing applications that leverage our platforms.

<details><summary>Passage</summary>

Members of our sales team have technical expertise and product and industry knowledge. We also employ a team of application engineers and solution architects to assist our partner network in designing, testing, and qualifying system designs that incorporate our platforms. We believe that the depth and quality of our design support are key to improving our partner network’s time-to-market, maintaining a high level of customer satisfaction, and fostering relationships that encourage our end customers and partner network to use the next generation of our products within each platform.

To encourage the development of applications optimized for our platforms and software, we seek to establish and maintain strong relationships in the software development community. Engineering and marketing personnel engage with key software developers to promote and discuss our platforms, as well as to ascertain individual product requirements and solve technical problems. Our developer program makes our products available to developers prior to launch in order to encourage the development of AI frameworks, SDKs, and APIs for software applications and game titles that are optimized for our platforms. Our Deep Learning Institute provides in-person and online training for developers in industries and organizations around the world to build AI and accelerated computing applications that leverage our platforms.

As NVIDIA’s business has evolved from a focus primarily on gaming products to broader markets, and from chips to platforms, systems and software, so, too, have our avenues to market. Thus, in addition to sales to customers in our partner network, certain of our products are also sold direct to CSPs, enterprise customers, retail channels and consumers.

Seasonality

Our computing platforms serve a diverse set of markets such as consumer gaming, enterprise and cloud data centers, professional workstations, and automotive. Our consumer products typically see stronger revenue in the second half of our fiscal year. In addition, based on the production schedules of key customers, some of our products for notebooks and game consoles typically generate stronger revenue in the second and third quarters, and weaker revenue in the fourth and first quarters. In fiscal year 2023, our supply exceeded our demand in several areas, and our revenue did not follow historical seasonal patterns. Historical seasonality trends may not repeat.

</details>

## Item 1 BUSINESS (blocks 160-168)

**AI reference: explicit | frame: business | roles: market_driver | kinds: unspecified | substantiveness: generic**

> A significant source of competition comes from companies that provide or intend to provide GPUs, CPUs, DPUs, embedded SoCs, and other accelerated, AI computing processor products, and providers of semiconductor-based high-performance interconnect products based on InfiniBand, Ethernet, Fibre Channel and proprietary technologies.

<details><summary>Passage</summary>

The market for our products is intensely competitive and is characterized by rapid technological change and evolving industry standards. We believe that the principal competitive factors in this market are performance, breadth of product offerings, access to customers and partners and distribution channels, software support, conformity to industry standard APIs, manufacturing capabilities, processor pricing, and total system costs. We believe that our ability to remain competitive will depend on how well we are able to anticipate the features and functions that customers and partners will demand and whether we are able to deliver consistent volumes of our products at acceptable levels of quality and at competitive prices. We expect competition to increase from both existing competitors and new market entrants with products that may be lower priced than ours or may provide better performance or additional features not provided by our products. In addition, it is possible that new competitors or alliances among competitors could emerge and acquire significant market share.

A significant source of competition comes from companies that provide or intend to provide GPUs, CPUs, DPUs, embedded SoCs, and other accelerated, AI computing processor products, and providers of semiconductor-based high-performance interconnect products based on InfiniBand, Ethernet, Fibre Channel and proprietary technologies. Some of our competitors may have greater marketing, financial, distribution and manufacturing resources than we do and may be more able to adapt to customer or technological changes. We expect an increasingly competitive environment in the future.

Our current competitors include:

suppliers and licensors of hardware and software for discrete and integrated GPUs, custom chips and other accelerated computing solutions, including solutions offered for AI, such as Advanced Micro Devices, Inc., or AMD, and Intel Corporation, or Intel;

large cloud services companies with internal teams designing chips and software that incorporate accelerated or AI computing functionality as part of their internal solutions or platforms, such as Alibaba Group, Alphabet Inc., Amazon, Inc., and Baidu, Inc.;

suppliers of Arm-based CPUs and companies that incorporate CPUs as part of their internal solutions or platforms;

suppliers of SoC products that are used in servers or embedded into automobiles, autonomous machines, and gaming devices, such as Ambarella, Inc., AMD, Broadcom Inc., or Broadcom, Intel, Qualcomm Incorporated, Renesas Electronics Corporation, and Samsung, or companies with internal teams designing SoC products for internal use, such as Tesla, Inc.; and

suppliers of interconnect, switch cable solutions, and DPUs such as AMD, Applied Optoelectronics, Inc., Arista Networks, Broadcom, Cisco Systems, Inc., or Cisco, Hewlett Packard Enterprise Company, Intel, Juniper Networks, Inc., Lumentum Holdings, and Marvell Technology Group, as well as internal teams of system vendors and large cloud services companies.

</details>

## Item 1 BUSINESS (blocks 177-185)

**AI reference: explicit | frame: governance | roles: governance | responses: policies_processes | kinds: unspecified | substantiveness: detailed**

> Compliance with existing or future governmental regulations, including, but not limited to, those pertaining to IP ownership and infringement, taxes, import and export requirements and tariffs, anti-corruption, business acquisitions, foreign exchange controls and cash repatriation restrictions, data privacy requirements, competition and antitrust, advertising, employment, product regulations, cybersecurity, environmental, health and safety requirements, the responsible use of AI, climate change, cryptocurrency, and consumer laws, could increase our costs, impact our competitive position, and otherwise may have a material adverse impact on our business, financial condition and results of operations in subsequent periods.

<details><summary>Passage</summary>

Our worldwide business activities are subject to various laws, rules, and regulations of the United States as well as of foreign governments.

During the third quarter of fiscal year 2023, the U.S. government announced new license requirements that impact certain exports to China (including Hong Kong and Macau) and Russia of some of our data center products. The impact of the new license requirements is difficult to quantify, and it may be challenging for us to manage our operations and forecast our operating results due to these requirements. Refer to “Item 1A. Risk Factors- Risks Related to Regulatory, Legal, Our Stock and Other Matters” for a discussion of this potential impact.

Additionally, our acquisitions may be subject to government regulatory reviews, and the cost to comply with such regulations or costs incurred where regulatory challenges prevent the completion of an acquisition could have a material impact on our business. In February 2022, we announced the termination of the Share Purchase Agreement by which we would have acquired Arm due to significant regulatory challenges preventing the completion of the transaction. We recorded an acquisition termination cost of $1.35 billion in fiscal year 2023 reflecting the write-off of the prepayment provided at signing.

Compliance with laws, rules, and regulations has not otherwise had a material effect upon our capital expenditures, results of operations, or competitive position and we do not currently anticipate material capital expenditures for environmental control facilities. Compliance with existing or future governmental regulations, including, but not limited to, those pertaining to IP ownership and infringement, taxes, import and export requirements and tariffs, anti-corruption, business acquisitions, foreign exchange controls and cash repatriation restrictions, data privacy requirements, competition and antitrust, advertising, employment, product regulations, cybersecurity, environmental, health and safety requirements, the responsible use of AI,

climate change, cryptocurrency, and consumer laws, could increase our costs, impact our competitive position, and otherwise may have a material adverse impact on our business, financial condition and results of operations in subsequent periods. Refer to “Item 1A. Risk Factors” for a discussion of these potential impacts.

Environmental, Social and Corporate Governance

NVIDIA invents computing technologies that improve lives and address global challenges. Our goal is to integrate sound environmental, social and corporate governance, or ESG, principles and practices into every aspect of the Company. The Nominating and Corporate Governance Committee of our Board of Directors is responsible for reviewing and discussing with management our practices related to ESG. We assess our programs annually in consideration of stakeholder expectations, market trends, and business risks and opportunities. These issues are important for our continued business success and reflect the topics of highest concern to NVIDIA and our stakeholders.

The following section and the Human Capital Management Section below provide an overview of our principles and practices. More information can be found on the Corporate Responsibility section of our website and in our annual Corporate Responsibility Report, or CR Report. Information contained on our website or in our annual CR Report is not incorporated by reference into this or any other report we file with the Securities and Exchange Commission, or the SEC. Refer to “Item 1A. Risk Factors” for a discussion of risks and uncertainties we face related to ESG.

</details>

## Item 1 BUSINESS (blocks 187-190)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: detailed**

> We plan to build Earth-2, a digital twin of the Earth on NVIDIA AI and NVIDIA Omniverse platforms.

> Earth-2 will enable scientists, companies, and policy makers to do ultra-high-resolution predictions of the impact of climate change and explore mitigation and adaptation strategies.

<details><summary>Passage</summary>

In the area of sustainability, we address our climate impacts across our product lifecycle and assess risks, including current and emerging regulations and market impacts.

In our CR Report published in July 2022, we published metrics related to our environmental impact for fiscal year 2022. Fiscal year 2023 metrics are expected to be published in the first half of fiscal year 2024. There has been no material impact to our capital expenditures, results of operations or competitive position associated with global sustainability regulations, compliance, or costs from sourcing renewable energy. By the end of fiscal year 2025, our goal is to purchase or generate enough renewable energy to match 100% of our global electricity usage for our offices and data centers.

Whether it is creation of technology to power next-generation laptops or designs to support high-performance supercomputers, improving energy efficiency is important in our research, development, and design processes. GPUs are inherently more energy efficient than other forms of computing because they are optimized for throughput, performance per watt, and certain AI workloads. The energy efficiency of our products is evidenced by our continued strong presence on the Green500 list of the most energy-efficient systems. We powered 23 of the top 30 most energy efficient systems, including the top supercomputer, on the November 2022 Green500 list.

We plan to build Earth-2, a digital twin of the Earth on NVIDIA AI and NVIDIA Omniverse platforms. Earth-2 will enable scientists, companies, and policy makers to do ultra-high-resolution predictions of the impact of climate change and explore mitigation and adaptation strategies.

</details>

## Item 1A RISK FACTORS (blocks 271-273)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: reputational_ethical | mit: other | kinds: unspecified | substantiveness: generic**

> Issues relating to the responsible use of our technologies, including AI, may result in reputational and financial harm and liability.

<details><summary>Passage</summary>

Increased scrutiny from shareholders, regulators, and others regarding our environmental, social and governance responsibilities could result in financial, reputational and operational harm.

Issues relating to the responsible use of our technologies, including AI, may result in reputational and financial harm and liability.

Adequately protecting our IP rights could be costly, and our ability to compete could be harmed if we are unsuccessful or if we are prohibited from making or selling our products.

</details>

## Item 1A RISK FACTORS (blocks 293-298)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: strategic_competitive | mit: other | kinds: unspecified | substantiveness: specific | traits: hedging**

> We will offer enterprise customers NVIDIA AI cloud services directly and through our network of partners.

> NVIDIA AI cloud services may not be successful and will take time, resources and investment.

> We also offer or plan to offer standalone software solutions for AI including NVIDIA AI Enterprise, NVIDIA Omniverse, NVIDIA DRIVE for automotive, and several other software solutions.

<details><summary>Passage</summary>

We invest in research and development in markets where we have a limited operating history, which may not produce meaningful revenue for several years, if at all. If we fail to develop or monetize new products and technologies, or if they do not become widely adopted, our financial results could be adversely affected. Obtaining design wins may involve a lengthy process and depend on our ability to anticipate and provide features and functionality that customers will demand. They also do not guarantee revenue. Failure to obtain a design win may prevent us from obtaining future design wins in subsequent generations. We cannot ensure that the products and technologies we bring to market will provide value to our customers and partners. If we fail any of these key success criteria, our financial results may be harmed.

We will offer enterprise customers NVIDIA AI cloud services directly and through our network of partners. Examples of these services include NVIDIA DGX Cloud, which is cloud-based infrastructure and software for training AI models, and customizable pretrained AI models. NVIDIA has partnered with leading cloud service providers to host these services in their data centers, and we entered into multi-year cloud service agreements in the second half of fiscal year 2023 to support these offerings and our research and development activities. NVIDIA AI cloud services may not be successful and will take time, resources and investment. We also offer or plan to offer standalone software solutions for AI including NVIDIA AI Enterprise, NVIDIA Omniverse, NVIDIA DRIVE for automotive, and several other software solutions. These new

business models or strategies may not be successful and we may fail to sell any meaningful standalone software or as-a-service solutions. We may incur significant costs and may not achieve any significant revenue from these offerings.

Competition in our current and target markets could cause us to lose market share and revenue.

Our target markets remain competitive, and competition may intensify with expanding and changing product and service offerings, industry standards, customer needs, new entrants and consolidations. Our competitors’ products, services and technologies, including those mentioned above in this Annual Report on Form 10-K, may be cheaper or provide better functionality or features than ours, which has resulted and may in the future result in lower than expected selling prices for our products. Some of our competitors operate their own fabrication facilities, have longer operating histories, larger customer bases, more comprehensive IP portfolios and patent protections, new designs and more design wins, and greater financial, sales, marketing and distribution resources than we do. These competitors may be able to acquire market share and/or prevent us from doing so, more effectively identify and capitalize upon opportunities in new markets and end user customer trends, more quickly transition their products, and secure sufficient foundry capacity and packaging materials during a supply-constrained environment, which could harm our business. Some of our customers have in-house expertise and internal development capabilities similar to some of ours and can use or develop their own solutions to replace those we are providing. For example, others may offer cloud-based services that compete with our AI cloud service offerings, and we may not be able to establish market share sufficient to achieve scale necessary to meet our business objectives. If we are unable to successfully compete in this environment, demand for our products, services and technologies could decrease, which would cause our revenue to decline.

</details>

## Item 1A RISK FACTORS (blocks 313-315)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: market_demand | mit: other | kinds: unspecified | substantiveness: generic**

> the demand for accelerated or AI-related cloud services, including our own software and AI cloud service offerings;

<details><summary>Passage</summary>

business decisions made by third parties;

the demand for accelerated or AI-related cloud services, including our own software and AI cloud service offerings;

the demand for cryptocurrency mining; or

</details>

## Item 1A RISK FACTORS (blocks 323-327)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: market_demand | mit: other | kinds: generative_llm | substantiveness: specific**

> We build technology and products for use cases and applications that may be new or may not yet exist.

> Examples include our Omniverse platform and third-party large language models and generative models.

> Our demand estimates for these use cases and applications can be incorrect and create volatility in our revenue or supply levels, and we may not be able to generate any revenue from these use cases and applications.

<details><summary>Passage</summary>

revenue has sequentially declined. All of these factors may negatively impact our gross margins and financial results.

We build technology and products for use cases and applications that may be new or may not yet exist. Examples include our Omniverse platform and third-party large language models and generative models. Our demand estimates for these use cases and applications can be incorrect and create volatility in our revenue or supply levels, and we may not be able to generate any revenue from these use cases and applications.

Challenges in estimating demand could become more pronounced or volatile in the future on both a global and regional basis. Extended lead times may occur if we experience other supply constraints caused by natural disasters, pandemics or other events, such as the COVID-19 pandemic. In addition, geopolitical tensions, such as those involving Taiwan and China, which comprise a significant portion of our revenue and where we have suppliers, contract manufacturers, and assembly partners who are critical to our supply continuity, could have a material adverse impact on us.

The use of our GPUs for other than that for which they were designed and marketed, including new and unexpected use cases, has impacted and can in the future impact demand for our products, including by leading to inconsistent spikes and drops in demand. For example, a number of years ago, our Gaming GPUs began to be used for digital currency mining, including blockchain-based platforms such as Ethereum. It is difficult for us to estimate with any reasonable degree of precision, the past or current impact of cryptocurrency mining, or forecast the future impact of cryptocurrency mining, on demand for our products. Volatility in the cryptocurrency market, including new compute technologies, price changes in cryptocurrencies, government cryptocurrency policies and regulations, new cryptocurrency standards, and changes in the method of verifying blockchain transactions, has impacted and can in the future impact cryptocurrency mining and demand for our products and can further impact our ability to estimate demand for our products. Changes to cryptocurrency standards and processes including, but not limited to, the recently implemented Ethereum 2.0 merge may decrease the usage of GPUs for Ethereum mining as well as create increased aftermarket sales of our GPUs, which could negatively impact retail prices for our GPUs and reduce demand for our new GPUs. We previously introduced Lite Hash Rate, or LHR, GeForce GPUs with limited Ethereum mining capability and provided CMP products in an effort to address demand from gamers and direct miners to CMP. With the Ethereum 2.0 merge, NVIDIA Ampere and Ada Lovelace architectures no longer include LHR. In addition, our new products or previously sold products may be resold online or on the unauthorized “gray market,” which also makes demand forecasting difficult. Gray market products and reseller marketplaces compete with our new products and distribution channels.

Additionally, we depend on developers and other third parties to build accelerated computing applications that leverage our platforms. We also rely on third-party content providers and publishers to make their content available on our platforms such as GeForce NOW. Failure by developers to build applications that leverage our platforms, or failure by third-party content providers or publishers to make their content available on reasonable terms or at all for use by our customers or end users on our platforms, could adversely affect customer demand.

</details>

## Item 1A RISK FACTORS (blocks 418-429)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: national_security, regulatory_legal, strategic_competitive | mit: other | kinds: unspecified | substantiveness: detailed | traits: hedging**

> The increasing focus on the strategic importance of AI technologies has already resulted in regulatory restrictions that target products and services capable of enabling or facilitating AI, and may in the future result in additional restrictions impacting some or all of our product and service offerings.

> Such controls may be very broad in scope and application, prohibit us from exporting our products to any or all customers in one or more markets, including but not limited to China, and could negatively impact our manufacturing, testing, and warehousing locations and options, or could impose other conditions that limit our ability to serve demand abroad and could negatively and materially impact our business, revenue, and financial results.

> Export controls targeting GPUs and semiconductors associated with AI, which are increasingly likely, would restrict our ability to export our technology, products, or services even though competitors may not be subject to similar restrictions, creating a competitive disadvantage for us and negatively impacting our business and financial results.

<details><summary>Passage</summary>

Our operations could be affected by the complex laws, rules and regulations to which our business is subject, and political and other actions may adversely impact our business.

We are subject to laws and regulations domestically and worldwide, affecting our operations in areas including, but not limited to, IP ownership and infringement; taxes; import and export requirements and tariffs; anti-corruption, including the Foreign Corrupt Practices Act; business acquisitions; foreign exchange controls and cash repatriation restrictions; data privacy requirements; competition and antitrust; advertising; employment; product regulations; cybersecurity; environmental, health, and safety requirements; the responsible use of AI; climate change; cryptocurrency; and consumer laws. Compliance with such requirements can be onerous and expensive, could impact our competitive position, and may negatively impact our business operations and ability to manufacture and ship our products. There can be no assurance that our employees, contractors, suppliers, customers or agents will not violate applicable laws or the policies, controls, and procedures that we have designed to help ensure compliance with such laws, and violations could result in fines, criminal sanctions against us, our officers, or our employees, prohibitions on the conduct of our business, and damage to our reputation. Changes to the laws, rules and regulations to which we are subject, or changes to their interpretation and enforcement could lead to materially greater compliance and other costs and/or further restrictions on our ability to manufacture and supply our products and operate our business. For example, we may face increased compliance costs as a result of changes or increases in anti-competition legislation, regulation, administrative rule making, increased focus from regulators on cybersecurity vulnerabilities and risks, and enforcement activity resulting from growing public concern over concentration of economic power in corporations. Revisions to laws or regulations or their interpretation and enforcement could also result in increased taxation, trade sanctions, the imposition of or increase to import duties or tariffs, restrictions and controls on imports or exports, or other retaliatory actions, which could have an adverse effect on our business plans or impact the timing of our shipments. Additionally, changes in the public perception of governments in the regions where we operate or plan to operate could negatively impact our business and results of operations.

Government actions, including trade protection and national security policies of U.S. and foreign government bodies, such as tariffs, import or export regulations, including deemed export restrictions, trade and economic sanctions, decrees, quotas or other trade barriers and restrictions could affect our ability to ship products, provide services to our customers and employees, do business without an export license with entities on the U.S. Department of Commerce’s U.S. Entity List or other U.S. government restricted parties lists (which is expected to change from time to time), and generally fulfill our contractual obligations and have a material adverse effect on our business. If we were ever found to have violated export control laws or sanctions of the U.S. or similar applicable non-U.S. laws, even if the violation occurred without our knowledge, we may be subject to various penalties available under the laws, any of which could have a material and adverse impact on our business, operating results and financial condition.

For example, in response to the war in Ukraine, the United States and other jurisdictions imposed economic sanctions and export control measures which blocked the passage of our products, services and support into Russia, Belarus, and certain regions of Ukraine. In fiscal year 2023, we stopped direct sales to Russia and closed business operations in Russia. Concurrently, the war in Ukraine has impacted end customer sales in EMEA and may continue to do so in the future.

The increasing focus on the strategic importance of AI technologies has already resulted in regulatory restrictions that target products and services capable of enabling or facilitating AI, and may in the future result in additional restrictions impacting some or all of our product and service offerings. Such restrictions could include additional unilateral or multilateral export controls on certain products or technology, including but not limited to AI technologies. As geopolitical tensions have increased, semiconductors associated with AI, including GPUs and associated products, are increasingly the focus of export control restrictions proposed by stakeholders in the U.S. and its allies, and it is likely that additional unilateral or multilateral controls will be adopted. Such controls may be very broad in scope and application, prohibit us from exporting our products to any or all customers in one or more markets, including but not limited to China, and could negatively impact our manufacturing, testing, and warehousing locations and options, or could impose other conditions that limit our ability to serve demand abroad and could negatively and materially impact our business, revenue, and financial results. Export controls targeting GPUs and semiconductors associated with AI, which are increasingly likely, would restrict our ability to export our technology, products, or services even though competitors may not be subject to similar restrictions, creating a competitive disadvantage for us and

negatively impacting our business and financial results. Increasing use of economic sanctions may also impact demand for our products or services, negatively impacting our business and financial results. Additional unilateral or multilateral controls are also likely to include deemed export control limitations that negatively impact the ability of our research and development teams to execute our roadmap or other objectives in a timely manner. Additional export restrictions may not only impact our ability to serve overseas markets, but also provoke responses from foreign governments, including China, that negatively impact our supply chain or our ability to provide our products and services to customers in all markets worldwide, which could also substantially reduce our revenue.

During the third quarter of fiscal year 2023, the U.S. government, or USG, announced new export restrictions and export licensing requirements targeting China’s semiconductor and supercomputing industries. These restrictions impact exports of certain chips, as well as software, hardware, equipment, and technology used to develop, produce, and manufacture certain chips, to China (including Hong Kong and Macau) and Russia, and specifically impact our A100 and H100 integrated circuits, DGX or any other systems or boards which incorporate A100 or H100 integrated circuits and our A100X. The new license requirements also apply to any future NVIDIA integrated circuit achieving certain peak performance and chip-to-chip I/O performance thresholds, as well as any system or board that includes those circuits. There are also now licensing requirements to export a wide array of products, including networking products, destined for certain end users and for certain end uses in China.

We are required to transition certain operations out of China (including Hong Kong), which could be costly and time consuming, and adversely affect our research and development and supply and distribution operations, as well as our revenue, during any such transition period.

We have engaged with customers in China to provide alternative products not subject to the new license requirements, such as our new A800 offering. To the extent that a customer requires products covered by the new license requirements, we may seek a license for the customer but have no assurance that the USG will grant any exemptions or licenses for any customer, or that the USG will act on them in a timely manner. The new requirements may have a disproportionate impact on NVIDIA and may disadvantage NVIDIA against certain of our competitors who sell products that are not subject to the new restrictions or may be able to acquire licenses for their products.

Management of these new license and other requirements is complicated and time consuming. Our results and competitive position may be harmed if customers in China do not want to purchase our alternative product offerings, if customers purchase product from competitors, if customers develop their own internal solution, if we are unable to provide contractual warranty or other extended service obligations, if the USG does not grant licenses in a timely manner or denies licenses to significant customers, or if we incur significant transition costs. Additionally, if we are unable to sell our alternative product offerings in China, we may have excess inventory, harming our results. Even if the USG grants any requested licenses, the licenses may be temporary or impose burdensome conditions that we cannot or choose not to fulfill. The new requirements may benefit certain of our competitors, as the licensing process will make our pre-sale and post-sale technical support efforts more cumbersome and less certain, and encourage customers in China to pursue alternatives to our products, including semiconductor suppliers based in China, Europe, and Israel.

Additionally, restrictions imposed by the Chinese government on the duration of gaming activities and access to games may adversely affect our Gaming revenue, and increased oversight of digital platform companies may adversely affect our Data Center revenue.

</details>

## Item 1A RISK FACTORS (blocks 433-435)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal, reputational_ethical | mit: other | kinds: unspecified | substantiveness: generic | traits: hedging**

> Concerns relating to the responsible use of new and evolving technologies, such as AI, in our products and services may result in reputational and financial harm and liability, and may cause us to incur costs to resolve such issues.

> If we enable or offer solutions that draw controversy due to their perceived or actual impact on society, such as AI solutions that have unintended consequences or are controversial because of their impact on human rights, privacy, employment, or other social, economic, or political issues, or if we are unable to develop effective internal policies and frameworks relating to the responsible development and use of AI models and systems offered through our sales channels, we may experience brand or reputational harm, competitive harm or legal liability.

<details><summary>Passage</summary>

customers, or discontinue or not expand business with existing customers due to our policies. These factors may negatively harm our brand, reputation and business activities or expose us to liability.

Issues relating to the responsible use of our technologies, including AI in our offerings, may result in reputational and financial harm and liability.

Concerns relating to the responsible use of new and evolving technologies, such as AI, in our products and services may result in reputational and financial harm and liability, and may cause us to incur costs to resolve such issues. We are increasingly building AI capabilities into many of our products and services. AI poses emerging ethical issues and presents risks and challenges that could affect its adoption, and therefore our business. If we enable or offer solutions that draw controversy due to their perceived or actual impact on society, such as AI solutions that have unintended consequences or are controversial because of their impact on human rights, privacy, employment, or other social, economic, or political issues, or if we are unable to develop effective internal policies and frameworks relating to the responsible development and use of AI models and systems offered through our sales channels, we may experience brand or reputational harm, competitive harm or legal liability. Compliance with government regulation in the area of AI ethics may also increase the cost of related research and development, and changes in AI-related regulation could disproportionately impact and disadvantage us and require us to change our business practices, which may negatively impact our financial results. Our failure to address concerns relating to the responsible use of AI by us or others could undermine public confidence in AI and slow adoption of AI in our products and services or cause reputational harm.

</details>

## Item 1A RISK FACTORS (blocks 441-446)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: compromise_of_privacy, other | kinds: traditional_ml | substantiveness: generic | traits: hedging**

> Concerns about our practices or the ultimate use of our products and services with regard to the collection, use, retention, security or disclosure of personal information or other privacy-related matters, including for use in AI, even if unfounded, could damage our reputation and adversely affect our operating results.

> Additionally, several states and localities have enacted measures related to the use of artificial intelligence and machine learning in products and services.

> Furthermore, there exists a proposed European regulation related to AI that, if adopted, could impose onerous obligations that may disproportionately impact and disadvantage us and require us to change our business practices.

<details><summary>Passage</summary>

We may process sensitive, confidential or personal data or information that is subject to privacy and security laws, regulations, industry standards, external and internal policies, contracts and other obligations that govern the processing of such data by us and on our behalf. Concerns about our practices or the ultimate use

of our products and services with regard to the collection, use, retention, security or disclosure of personal information or other privacy-related matters, including for use in AI, even if unfounded, could damage our reputation and adversely affect our operating results. The theft, loss, or misuse of personal data in our possession or by one of our partners could result in damage to our reputation, regulatory proceedings, disruption of our business activities or increased security costs and costs related to defending legal claims.

In the United States, federal, state and local authorities have enacted numerous data privacy and security laws, including for data breach notification, personal data privacy, and consumer protection. The California Consumer Privacy Act of 2018, or CCPA, gives California residents the right to access, delete and opt-out of certain sharing of their personal information, and to receive detailed information about how it is used and shared. The CCPA allows for statutory fines of up to $7,500 per violation and the law created a private right of action for certain data breaches. The California Privacy Rights Act of 2020, or CPRA, became operative in 2023, and restricts the use of certain categories of sensitive personal information; further restricts the use of cross-contextual advertising techniques; restricts the retention of personal information; expands the types of data breaches subject to the private right of action; and establishes the California Privacy Protection Agency which can impose administrative fines for noncompliance. Virginia, Colorado, Utah and Connecticut have each passed their own privacy legislation which differ from the CPRA and each become effective in 2023. Similar laws are being considered in several other states, as well as at the federal and local levels. Additionally, several states and localities have enacted measures related to the use of artificial intelligence and machine learning in products and services. If we become subject to additional data privacy laws, the risk of enforcement action against us could increase.

Worldwide regulatory authorities are also considering and have approved various legislative proposals concerning data protection. The European Union adopted the General Data Protection Regulation, or GDPR, and the United Kingdom similarly adopted the U.K. GDPR, governing the strict handling of personal data of persons within the European Economic Area, or EEA, and the United Kingdom, respectively, including its use and protection and the ability of persons whose data is stored to access, correct, and delete such data about themselves. If we are found not to comply, we could be subject to penalties of up to €20 million or 4% of worldwide revenue, whichever is greater, and classes of individuals or consumer protection organizations may initiate litigation related to our processing of their personal data. Furthermore, there exists a proposed European regulation related to AI that, if adopted, could impose onerous obligations that may disproportionately impact and disadvantage us and require us to change our business practices.

In the ordinary course of business, we may transfer personal data from Europe, China, and other jurisdictions to the United States or other countries. Certain jurisdictions have enacted data localization laws and cross-border personal data transfer laws. For example, the GDPR generally restricts the transfer of personal data to countries outside of the EEA. The European Commission released a set of “Standard Contractual Clauses” designed for entities to validly transfer personal data out of the EEA to jurisdictions that the European Commission has not found to provide an adequate level of protection, including the United States. While the European Union and United States governments have recently announced an agreement in principle on a new bilateral cross-border transfer mechanism, it is uncertain whether this agreement will be overturned in court like the previous two European Union-United States bilateral cross-border transfer agreements. These mechanisms are subject to legal challenges, and there is no assurance that we can satisfy or rely on these measures to lawfully transfer personal data to the United States. Other jurisdictions have enacted or are considering similar cross-border personal data transfer laws and local personal data residency laws, any of which would increase the cost and complexity of doing business and could result in fines from regulators. For example, China law imposes various requirements relating to data processing and data localization. Data broadly defined as important under China law, including personal data, may not be transferable outside of China without prior assessment and approval by the Cyberspace Administration of China, or CAC. Compliance with these requirements, including CAC assessments and any deemed failures of such assessments, could cause us to incur liability, prevent us from using data collected in China, or impact our ability to transfer data outside of China. The inability to import personal data to the United States could significantly and negatively impact our business operations, limit our ability to collaborate with parties that are subject to European, China, and other data privacy and security laws, or require us to increase our personal data processing capabilities in Europe and/or elsewhere at significant expense. Some European regulators have prevented companies from transferring personal data out of Europe for allegedly violating the GDPR’s cross-border data transfer limitations, which could negatively impact our business.

</details>

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 504-507)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, AV, robotics, metaverse and 3D internet applications.

<details><summary>Passage</summary>

Our Company and Our Businesses

NVIDIA pioneered accelerated computing to help solve the most challenging computational problems. Since our original focus on PC graphics, we have expanded to several other large and important computationally intensive fields. Fueled by the sustained demand for exceptional 3D graphics and the scale of the gaming market, NVIDIA has leveraged its GPU architecture to create platforms for scientific computing, AI, data science, AV, robotics, metaverse and 3D internet applications.

Our two operating segments are "Compute & Networking" and "Graphics." Refer to Note 17 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K for additional information.

Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

</details>

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 510-515)

**AI reference: explicit | frame: business | roles: offering, risk | risk: market_demand | mit: other | kinds: generative_llm | substantiveness: detailed | traits: hedging**

> We will offer enterprise customers NVIDIA AI cloud services directly and through our network of partners.

> NVIDIA AI cloud services may not be successful and will take time, resources and investment.

<details><summary>Passage</summary>

Our supply, which includes inventory on hand, purchase obligations and prepaid supply agreements, has grown significantly due to current supply chain conditions, complexity of our products, and recent reductions in demand. At the end of fiscal year 2023, purchase obligations and prepaid supply agreements represented more than half of our total supply. Inventory provisions for excess inventory and purchase obligations totaled $2.17 billion in fiscal year 2023. We may incur inventory provisions if our inventory or supply commitments are misaligned with demand for our products.

Product transitions are complex as we often ship both new and legacy architecture products simultaneously and we and our channel partners prepare to ship and support new products. We are currently transitioning the architecture of our Data Center, Professional Visualization, and Gaming products. Qualification time for new products, customers anticipating product transitions and channel partners reducing channel inventory of legacy architectures ahead of new product introductions can create reductions or volatility in our revenue. While we have managed prior product transitions and have previously sold multiple product architectures at the same time, these transitions are difficult and prior trends may not continue.

We build technology and products for use cases and applications that may be new or may not yet exist. Examples include our Omniverse platform and third-party large language models and generative models. Our demand estimates for these use cases and applications can be incorrect and create volatility in our revenue or supply levels, and we may not be able to generate any revenue from these use cases and applications.

NVIDIA AI Cloud Service Offerings

We will offer enterprise customers NVIDIA AI cloud services directly and through our network of partners. Examples of these services include NVIDIA DGX Cloud, which is cloud-based infrastructure and software for training AI models, and customizable pretrained AI models. NVIDIA has partnered with leading cloud service providers to host these services in their data centers.

We entered into multi-year cloud service agreements in the second half of fiscal year 2023 to these offerings and our research and development activities. NVIDIA AI cloud services may not be successful and will take time, resources and investment. We also offer or plan to offer standalone software solutions for AI including NVIDIA AI Enterprise, NVIDIA Omniverse, NVIDIA DRIVE for automotive, and several other software solutions. These new business models or strategies may not be successful and we may fail to sell any meaningful standalone software or as-a-service solutions. We may incur significant costs and may not achieve any significant revenue from these offerings.

</details>

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 517-519)

**AI reference: none**

<details><summary>Passage</summary>

Global Trade

During the third quarter of fiscal year 2023, the USG announced new license requirements that, with certain exceptions, impact exports to China (including Hong Kong and Macau) and Russia of our A100 and H100 integrated circuits, DGX or any other systems or boards which incorporate A100 or H100 integrated circuits and our A100X. We are required to transition certain operations out of China (including Hong Kong), including research and development and supply and distribution operations. We have engaged with customers in China to provide alternative products not subject to the new license requirements, such as our new A800 offering.

Management of these new license and other requirements is complicated and time consuming. Our results and competitive position may be harmed if customers in China do not want to purchase our alternative product offerings, if customers purchase product from competitors, or if customers develop their own internal solution, if the USG does not grant licenses in a timely manner or denies licenses to significant customers, or if we incur significant transition costs.

</details>

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 535-546)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> Data Center revenue was up 41% from a year ago led by strong growth from hyperscale customers and also reflects purchases made by several CSP partners to support multi-year cloud service agreements for our new NVIDIA AI cloud service offerings and our research and development activities.

> Automotive revenue was up 60% from a year ago reflecting growth in sales of self-driving solutions, computing solutions for electric vehicle makers and strength in sales of AI cockpit solutions.

<details><summary>Passage</summary>

Net income per diluted share | $ 1.74 | $ 3.85 | Down 55%

We specialize in markets where our computing platforms can provide tremendous acceleration for applications. These platforms incorporate processors, interconnects, software, algorithms, systems, and services to deliver unique value. Our platforms address four large markets where our expertise is critical: Data Center, Gaming, Professional Visualization, and Automotive.

Revenue for fiscal year 2023 revenue was $26.97 billion, flat compared with a year ago.

Data Center revenue was up 41% from a year ago led by strong growth from hyperscale customers and also reflects purchases made by several CSP partners to support multi-year cloud service agreements for our new NVIDIA AI cloud service offerings and our research and development activities.

Gaming revenue was down 27% from a year ago reflecting lower sell-in to partners to help reduce channel inventory levels as global macro-economic conditions and COVID-19 related disruptions in China weighed on gaming demand.

Professional Visualization revenue was down 27% from a year ago reflecting a lower sell-in to partners to help reduce channel inventory levels.

Automotive revenue was up 60% from a year ago reflecting growth in sales of self-driving solutions, computing solutions for electric vehicle makers and strength in sales of AI cockpit solutions. The increase also included growth in automotive development arrangements.

OEM and Other revenue was down 61% from a year ago driven by notebook OEM and CMP. CMP revenue was nominal in fiscal year 2023 and $550 million in fiscal year 2022.

Gross margin for fiscal year 2023 declined from a year ago, driven by $2.17 billion of inventory charges largely relating to excess supply of NVIDIA Ampere architecture Gaming and Data Center products as compared to the demand expectations for these products, particularly for the expected demand in China. The inventory charges were comprised of $1.04 billion for inventory on hand and $1.13 billion for inventory purchase obligations in excess of our demand expectations.

Operating expenses, which included a $1.35 billion acquisition termination charge related to the Arm transaction, were up 50% from a year ago. The increase also reflected compensation, data center infrastructure, and engineering development costs.

Cash, cash equivalents and marketable securities were $13.30 billion.

</details>

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 548-553)

**AI reference: explicit | frame: business | roles: offering | kinds: generative_llm | substantiveness: specific**

> We completed two new large language models for cloud AI services — NVIDIA NeMo LLM and NVIDIA BioNeMo LLM.

<details><summary>Passage</summary>

Market Platform Highlights

Data Center revenue for fiscal year 2023 was $15.01 billion, up 41% from fiscal year 2022. The strong growth in Data Center revenue was influenced by hyperscaler and cloud usage of our accelerated computing platforms and networking portfolio. In Data Center, we announced the NVIDIA Hopper GPU architecture and began ramping the first products based on the architecture, including the NVIDIA H100 Tensor Core GPU. The NVIDIA OVX server reference design launched for digital twins and other Omniverse applications. We completed two new large language models for cloud AI services — NVIDIA NeMo LLM and NVIDIA BioNeMo LLM. Additionally, we announced the NVIDIA Spectrum-4 end-to-end 400Gbps networking platform and began shipping Quantum-2 in December 2022.

Gaming revenue for fiscal year 2023 was $9.07 billion, down 27% from fiscal year 2022. Gaming results were influenced by the rapid change in economic conditions causing excess inventory with our channel partners. We introduced pricing programs for our channel partners and started undershipping GPU supply to the partners so that we could lower inventory in the channel. As we exited fiscal year 2023, we have made meaningful progress in establishing lower inventory levels with our channel partners. In Gaming, we announced the new Ada Lovelace GPU architecture, and introduced the first products based on Ada, including the GeForce RTX 4090, RTX 4080, and RTX 4070 Ti desktop GPUs and laptop GPUs featured in over 170 laptop designs. We introduced NVIDIA DLSS 3 for over 50 games and applications. We brought GeForce RTX 4080-class performance to the GeForce NOW Ultimate membership tier.

Professional Visualization revenue for fiscal year 2023 was $1.54 billion, down 27% from fiscal year 2022. Professional Visualization results were influenced by the rapid change in economic conditions causing excess inventory with our OEM partners. In Professional Visualization, we added new NVIDIA Ampere architecture RTX GPUs for workstations. We also announced Omniverse Avatar Cloud Engine and Omniverse Cloud and released a major update to NVIDIA Omniverse Enterprise.

Automotive revenue for fiscal year 2023 grew 60% compared to fiscal year 2022 to $903 million. In Automotive, we started production of the NVIDIA DRIVE Orin autonomous vehicle SOC and introduced next-generation NVIDIA DRIVE Thor.

</details>

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 609-614)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> The year-on-year increase was led by growth from hyperscale customers and also reflects purchases made by several CSP partners to support multi-year cloud service agreements for our new NVIDIA AI cloud service offerings and our research and development activities.

<details><summary>Passage</summary>

Total | $ 26,974 | $ 26,914 | $ 60 | — %

Compute & Networking - The year-on-year increase was led by growth from hyperscale customers and also reflects purchases made by several CSP partners to support multi-year cloud service agreements for our new NVIDIA AI cloud service offerings and our research and development activities. The increase was also related to the growth in Automotive. CMP contributed an insignificant amount in fiscal year 2023 compared to $550 million in fiscal year 2022.

Graphics - The year-on-year decrease primarily reflects lower sell-in to partners to help reduce channel inventory levels as global macro-economic conditions and COVID-19 related disruptions in China weighed on gaming demand.

Concentration of Revenue

Revenue from sales to customers outside of the United States accounted for 69% and 84% of total revenue for fiscal years 2023 and 2022, respectively. The decline in revenue outside the U.S. was primarily driven by China and Taiwan related to Data Center and Gaming. Revenue by geographic region is allocated to countries based on the billed location even if the revenue may be attributable to end customers in a different location.

No customer represented 10% or more of total revenue for fiscal years 2023 and 2022.

</details>

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1612-1615)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: specific**

> The Compute & Networking segment includes our Data Center accelerated computing platform; networking; automotive AI Cockpit, autonomous driving development agreements, and autonomous vehicle solutions; electric vehicle computing platforms; Jetson for robotics and other embedded platforms; and NVIDIA AI Enterprise and other software; and CMP.

<details><summary>Passage</summary>

Our Chief Executive Officer, who is considered to be our chief operating decision maker, or CODM, reviews financial information presented on an operating segment basis for purposes of making decisions and assessing financial performance.

The Compute & Networking segment includes our Data Center accelerated computing platform; networking; automotive AI Cockpit, autonomous driving development agreements, and autonomous vehicle solutions; electric vehicle computing platforms; Jetson for robotics and other embedded platforms; and NVIDIA AI Enterprise and other software; and CMP.

The Graphics segment includes GeForce GPUs for gaming and PCs, the GeForce NOW game streaming service and related infrastructure, and solutions for gaming platforms; Quadro/NVIDIA RTX GPUs for enterprise workstation graphics; vGPU software for cloud-based visual and virtual computing; automotive platforms for infotainment systems; and Omniverse Enterprise software for building and operating metaverse and 3D internet applications.

Operating results by segment include costs or expenses that are directly attributable to each segment, and costs or expenses that are leveraged across our unified architecture and therefore allocated between our two segments.

</details>

# Context passages: implicit mentions, not classified

## unknown section (blocks 9-10)

**Terms: Nvidia (NVIDIA)**

Commission file number: 0-23985

NVIDIA CORP ORATION

## unknown section (blocks 38-42)

**Terms: Nvidia (NVIDIA)**

Portions of the registrant's Proxy Statement for its 2023 Annual Meeting of Shareholders to be filed with the Securities and Exchange Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Annual Report on Form 10-K are incorporated by reference into Part III, Items 10-14 of this Annual Report on Form 10-K.

NVIDIA CORPORATION

Page

## unknown section (blocks 72-79)

**Terms: Nvidia (NVIDIA)**

Investors and others should note that we announce material financial information to our investors using our investor relations website, press releases, SEC filings and public conference calls and webcasts. We also use the following social media channels as a means of disclosing information about the company, our products, our planned financial and other announcements and attendance at upcoming investor and industry conferences, and other matters and for complying with our disclosure obligations under Regulation FD:

NVIDIA Twitter Account (https://twitter.com/nvidia)

NVIDIA Corporate Blog (http://blogs.nvidia.com)

NVIDIA Facebook Page (https://www.facebook.com/nvidia)

NVIDIA LinkedIn Page (http://www.linkedin.com/company/nvidia)

NVIDIA Instagram Page (https://www.instagram.com/nvidia)

In addition, investors and others can view NVIDIA videos on YouTube (https://www.YouTube.com/nvidia).

The information we post through these social media channels may be deemed material. Accordingly, investors should monitor these accounts and the blog, in addition to following our press releases, SEC filings and public conference calls and webcasts. This list may be updated from time to time. The information we post through these channels is not a part of this Annual Report on Form 10-K. These channels may be updated from time to time on NVIDIA's investor relations website.

## unknown section (blocks 81-84)

**Terms: Nvidia (NVIDIA)**

This Annual Report on Form 10-K contains forward-looking statements which are based on our management's beliefs and assumptions and on information currently available to our management. In some cases, you can identify forward-looking statements by terms such as “may,” “will,” “should,” “could,” “goal,” “would,” “expect,” “plan,” “anticipate,” “believe,” “estimate,” “project,” “predict,” “potential” and similar expressions intended to identify forward-looking statements. These statements involve known and unknown risks, uncertainties and other factors, which may cause our actual results, performance, time frames or achievements to be materially different from any future results, performance, time frames or achievements expressed or implied by the forward-looking statements. We discuss many of these risks, uncertainties and other factors in this Annual Report on Form 10-K in greater detail under the heading “Risk Factors.” Given these risks, uncertainties and other factors, you should not place undue reliance on these forward-looking statements. Also, these forward-looking statements represent our estimates and assumptions only as of the date of this filing. You should read this Annual Report on Form 10-K completely and with the understanding that our actual future results may be materially different from what we expect. We hereby qualify our forward-looking statements by these cautionary statements. Except as required by law, we assume no obligation to update these forward-looking statements publicly, or to update the reasons actual results could differ materially from those anticipated in these forward-looking statements, even if new information becomes available in the future.

All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries.

In addition, statements that “we believe” and similar statements reflect our beliefs and opinions on the relevant subject. These statements are based upon information available to us as of the filing date of this Annual Report on Form 10-K, and while we believe such information forms a reasonable basis for such statements, such information may be limited or incomplete, and our statements should not be read to indicate that we have conducted an exhaustive inquiry into, or review of, all potentially available relevant information. These statements are inherently uncertain and investors are cautioned not to unduly rely upon these statements.

© 2023 NVIDIA Corporation. All rights reserved.

## Item 1 BUSINESS (blocks 156-158)

**Terms: GPU (GPU)**

production of our products. As a result, we can focus our resources on product design, additional quality assurance, marketing, and customer support. We have placed non-cancellable inventory orders for certain product components in advance of our historical lead times, paid premiums and provided deposits to secure future supply and capacity and may need to continue to do so in the future.

We have expanded our supplier relationships to build redundancy and resilience in our operations. We utilize suppliers, such as Taiwan Semiconductor Manufacturing Company Limited and Samsung Electronics Co. Ltd, to produce our semiconductor wafers. We then utilize independent subcontractors and contract manufacturers, such as Amkor Technology, BYD Auto Co. Ltd., or BYD Auto, Hon Hai Precision Industry Co., or Hon Hai, King Yuan Electronics Co., Ltd., Omni Logistics, LLC, Siliconware Precision Industries Company Ltd., and Wistron Corporation to perform assembly, testing, and packaging of most of our products and platforms. We use contract manufacturers such as Flex Ltd., Jabil Inc., and Universal Scientific Industrial Co., Ltd., to manufacture our standard and custom adapter card products and switch systems, and Fabrinet to manufacture our networking cables. We purchase substrates from Ibiden Co. Ltd., Kinsus Interconnect Technology Corporation, and Unimicron Technology Corporation, and memory from Micron Technology, Samsung Semiconductor, Inc., or Samsung, and SK Hynix. We often consign key components or materials such as the GPU, SoC, memory, and integrated circuit to the contract manufacturers.

We typically receive semiconductor products from our subcontractors, perform incoming quality assurance and configuration using test equipment purchased from industry-leading suppliers such as Advantest America Inc. and Chroma ATE Inc., and then ship the semiconductors to contract manufacturers, such as BYD Auto and Hon Hai, distributors, motherboard and add-in card, or AIC, customers from our third-party warehouses in Hong Kong, Israel, and the United States. Generally, these manufacturers assemble and test the boards based on our design kit and test specifications, and then ship our products to retailers, system builders, or OEMs as motherboard and AIC solutions.

## Item 1 BUSINESS (blocks 194-197)

**Terms: Nvidia (NVIDIA)**

Recruitment

As the demand for global technical talent continues to be competitive, we have grown our technical workforce and have been successful in attracting top talent to NVIDIA. We have attracted strong talent globally with our differentiated hiring strategies for university, professional, executive and diverse recruits. The COVID-19 pandemic created expanded hiring opportunities in new geographies and provided increased

flexibility for employees to work from locations of their choice. Our workforce is about 80% technical and about 50% hold advanced degrees.

## Item 1 BUSINESS (blocks 201-202)

**Terms: Nvidia (NVIDIA)**

To evaluate employee sentiment and engagement, we use pulse surveys, a suggestion box, and an anonymous third-party platform. Pulse surveys help us gain insight into employee experience and provide ideas so that we can prioritize areas to take action. The suggestion box is an always-on, interactive tool where employees share their thoughts about making our company a better place to work. The anonymous third-party platform is designed to protect the identity of the reporter and provide a mechanism for reporters to follow an investigation and receive responses.

We want NVIDIA to be a place where people can build their careers over their lifetime. Our employees tend to come and stay. In fiscal year 2023, our overall turnover rate was 5.3%.

## Item 1 BUSINESS (blocks 236-245)

**Terms: Nvidia (NVIDIA, nvidia)**

Timothy S. Teter | 56 | Executive Vice President and General Counsel

Jen-Hsun Huang co-founded NVIDIA in 1993 and has served as our President, Chief Executive Officer and a member of the Board of Directors since our inception. From 1985 to 1993, Mr. Huang was employed at LSI Logic Corporation, a computer chip manufacturer, where he held a variety of positions including as Director of Coreware, the business unit responsible for LSI's SOC. From 1983 to 1985, Mr. Huang was a microprocessor designer for AMD, a semiconductor company. Mr. Huang holds a B.S.E.E. degree from Oregon State University and an M.S.E.E. degree from Stanford University.

Colette M. Kress joined NVIDIA in 2013 as Executive Vice President and Chief Financial Officer. Prior to NVIDIA, Ms. Kress most recently served as Senior Vice President and Chief Financial Officer of the Business Technology and Operations Finance organization at Cisco Systems, Inc., a networking equipment company, since 2010. At Cisco, Ms. Kress was responsible for financial strategy, planning, reporting and business

development for all business segments, engineering and operations. From 1997 to 2010 Ms. Kress held a variety of positions at Microsoft Corporation, or Microsoft, a software company, including, beginning in 2006, Chief Financial Officer of the Server and Tools division, where Ms. Kress was responsible for financial strategy, planning, reporting and business development for the division. Prior to joining Microsoft, Ms. Kress spent eight years at Texas Instruments Incorporated, a semiconductor company, where she held a variety of finance positions. Ms. Kress holds a B.S. degree in Finance from University of Arizona and an M.B.A. degree from Southern Methodist University.

Ajay K. Puri joined NVIDIA in 2005 as Senior Vice President, Worldwide Sales and became Executive Vice President, Worldwide Field Operations in 2009. Prior to NVIDIA, he held positions in sales, marketing, and general management over a 22-year career at Sun Microsystems, Inc., a computing systems company. Mr. Puri previously held marketing, management consulting, and product development positions at Hewlett-Packard Company, an information technology company, Booz Allen Hamilton Inc., a management and technology consulting company, and Texas Instruments Incorporated. Mr. Puri holds a B.S.E.E. degree from the University of Minnesota, an M.S.E.E. degree from the California Institute of Technology and an M.B.A. degree from Harvard Business School.

Debora Shoquist joined NVIDIA in 2007 as Senior Vice President of Operations and in 2009 became Executive Vice President of Operations. Prior to NVIDIA, Ms. Shoquist served from 2004 to 2007 as Executive Vice President of Operations at JDS Uniphase Corp., a provider of communications test and measurement solutions and optical products for the telecommunications industry. She served from 2002 to 2004 as Senior Vice President and General Manager of the Electro-Optics business at Coherent, Inc., a manufacturer of commercial and scientific laser equipment. Previously, she worked at Quantum Corp., a data protection company, as President of the Personal Computer Hard Disk Drive Division, and at Hewlett-Packard Corp. Ms. Shoquist holds a B.S. degree in Electrical Engineering from Kansas State University and a B.S. degree in Biology from Santa Clara University.

Timothy S. Teter joined NVIDIA in 2017 as Senior Vice President, General Counsel and Secretary and became Executive Vice President, General Counsel and Secretary in February 2018. Prior to NVIDIA, Mr. Teter spent more than two decades at the law firm of Cooley LLP, where he focused on litigating patent and technology related matters. Prior to attending law school, he worked as an engineer at Lockheed Missiles and Space Company, an aerospace company. Mr. Teter holds a B.S. degree in Mechanical Engineering from the University of California at Davis and a J.D. degree from Stanford Law School.

Available Information

Our annual reports on Form 10-K, quarterly reports on Form 10-Q, current reports on Form 8-K and, if applicable, amendments to those reports filed or furnished pursuant to Section 13(a) or 15(d) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, are available free of charge on or through our website, http://www.nvidia.com , as soon as reasonably practicable after we electronically file such material with, or furnish it to, the Securities and Exchange Commission, or the SEC. The SEC’s website, http://www.sec.gov , contains reports, proxy and information statements, and other information regarding issuers that file electronically with the SEC. Our web site and the information on it or connected to it are not a part of this Annual Report on Form 10-K.

## Item 1A RISK FACTORS (blocks 246-247)

**Terms: Nvidia (NVIDIA)**

ITEM 1A. RISK FACTORS

In evaluating NVIDIA, the following risk factors should be considered in addition to the other information in this Annual Report on Form 10-K. Purchasing or owning NVIDIA common stock involves investment risks including, but not limited to, the risks described below. Any one of the following risks could harm our business, financial condition, results of operations or reputation, which could cause our stock price to decline, and you may lose all or a part of your investment. Additional risks, trends and uncertainties not presently known to us or that we currently believe are immaterial may also harm our business, financial condition, results of operations or reputation.

## Item 1A RISK FACTORS (blocks 282-284)

**Terms: accelerated computing (accelerated computing)**

Failure to meet the evolving needs of our industry and markets may adversely impact our financial results.

Our accelerated computing platforms experience rapid changes in technology, customer requirements, competitive products, and industry standards.

Our success depends on our ability to:

## Item 1A RISK FACTORS (blocks 317-319)

**Terms: data center (Data Center)**

Our supply, which includes inventory on hand, purchase obligations and prepaid supply agreements, has grown significantly due to current supply chain conditions, complexity of our products, and recent reductions in demand. At the end of fiscal year 2023, purchase obligations and prepaid supply agreements represented more than half of our total supply. We may incur inventory provisions if our inventory or supply commitments are misaligned with demand for our products.

Our demand predictions may not be correct, as we have experienced from time to time. Product transitions are complex and frequently negatively impact our revenue as we often ship both new and legacy architecture products simultaneously and we and our channel partners prepare to ship and support new products. Our architecture transitions of Data Center, Professional Visualization, and Gaming products may impair our ability to predict demand and impact our supply mix. Qualification time for new products, customers anticipating product transitions and channel partners reducing channel inventory of legacy architectures ahead of new product introductions can create reductions or volatility in our revenue. We have experienced and may in the future experience reduced demand for current generation architectures when customers anticipate transitions, and we may be unable to sell multiple product architectures at the same time for current and future architecture transitions. While we have managed prior product transitions and have previously sold multiple product architectures at the same time, these transitions are difficult and prior trends may not continue. If we are unable to execute our architectural transitions as planned for any reason, our financial results may be negatively impacted.

We sell most of our products through channel partners, who sell to distributors, retailers, and/or end customers. As a result, the decisions made by our channel partners, distributors, retailers, and in response to changing market conditions and changes in end user demand for our products have impacted and could in the future continue to impact our ability to properly forecast demand, particularly as they are based on estimates provided by various downstream parties.

## Item 1A RISK FACTORS (blocks 343-345)

**Terms: data center (Data Center)**

Our hardware and software product offerings are complex and they have in the past and may in the future contain defects or security vulnerabilities, or experience failures or unsatisfactory performance due to any number of issues in design, fabrication, packaging, materials and/or use within a system. These risks may increase as our products are introduced into new devices, markets, technologies and applications or as new versions are released. These risks further increase when we rely on partners to supply and manufacture components that are used in our products, as these arrangements reduce our direct control over production. Although arrangements with component providers may contain provisions for product defect expense reimbursement, we generally remain responsible to the customer for warranty product defects that may occur from time to time. Some failures in our products or services have been in the past and may in the future be only discovered after a product or service has been shipped or used. Undiscovered vulnerabilities in our products or services could result in loss of data or intangible property, or expose our end customers to unscrupulous third parties who develop and deploy malicious software programs that could attack our products or services. Defects or failure of our products to perform to specifications could lead to substantial damage to the products or the product in which our device has been integrated by OEMs, ODMs, AIBs and automotive manufacturers and tier 1 automotive suppliers, and to the user of such end product. Any such defect may cause us to incur significant warranty, support and repair or replacement costs as part of a product recall or otherwise, write-off the value of related inventory, and divert the attention of our engineering and management personnel from our product development efforts to find and correct the issue. Our efforts to remedy these issues may not be timely or satisfactory to our customers. An error or defect in new products, releases, or related software drivers after commencement of commercial shipments could result in failure to achieve market acceptance, loss of design wins, temporary or permanent withdrawal from a product or market, and harm to our relationships with existing and prospective customers and partners and consumers’ perceptions of our brand, which would in turn negatively impact our business operations, gross margin, revenue and/or financial results. We may be required to reimburse our customers, partners or consumers, including for costs to repair or replace products in the field or in connection with indemnification obligations, or pay fines imposed by regulatory agencies.

For example, a defect was identified in a third-party component embedded in certain Data Center products. This defect has had, and other defects may in the future have, an adverse effect on our cost and supply of components and finished goods. These costs could be significant in future periods. We recorded a net warranty liability during fiscal year 2023 primarily in connection with this defect. While we believe we have accurately recorded for warranty obligations, we may need to record additional amounts in the future if our estimate proves to be incorrect. In general, if a product liability claim regarding any of our products is brought against us, even if the alleged damage is due to the actions or inactions of a third party, such as within our supply chain, the cost of defending the claim could be significant and would divert the efforts of our technical and management personnel and harm our business. Further, our business liability insurance may be inadequate or future coverage may be unavailable on acceptable terms, which could adversely impact our financial results.

## Item 1A RISK FACTORS (blocks 363-370)

**Terms: Nvidia (NVIDIA), data center (data center, data centers), hyperscaler (cloud service provider)**

To defend against cyber-attacks, we must continuously engineer more secure products and enhance security and reliability features, which is expected to result in increased expenses. We must also continue to develop our security measures, ensure our suppliers have appropriate security measures in place, and continue to meet the evolving security requirements of our customers, applicable industry standards, and government regulations. While we take steps to detect and remediate certain vulnerabilities that we have identified, we may not always be able to detect all vulnerabilities in our security controls, systems or software, including third-party software we have installed, as such threats and techniques change frequently and may not be detected until after a security incident has occurred. Further, we may experience delays in developing and deploying remedial measures designed to address identified vulnerabilities. These vulnerabilities could result in reputational and financial harm.

We hold confidential and proprietary information, including information from partners and customers. Breaches of our security measures, along with reported or perceived vulnerabilities or unapproved dissemination of proprietary information or sensitive or confidential data about us or third parties could expose us and the parties affected to a risk of loss or misuse of this information, potentially resulting in litigation and subsequent liability, regulatory inquiries or actions, damage to our brand and reputation or other harm, including financial, to our business. For example, we hold propriety game source code from third-party partners in our GFN service. Breaches of our GFN security measures, which have happened in the past, could expose our partners to a risk of loss or misuse of this source code, damage both us and our partners, and expose NVIDIA to potential litigation and liability. If we or a third party we rely on experience a security incident, which has occurred in the past, or are perceived to have experienced a security incident, we may experience adverse consequences, including government enforcement actions, additional reporting requirements and/or oversight, restrictions on processing data, litigation, indemnification obligations, reputational harm, diversion of funds, financial loss, loss of data, material disruptions in our systems and operations, supply chain, and ability to produce, sell and distribute our goods and services, and other similar harms. Inability to fulfill orders, delayed sales, lower margins or lost customers as a result of these disruptions could adversely affect our financial results, stock price and reputation.

Business disruptions could harm our operations, lead to a decline in revenue and increase our costs .

Our worldwide operations could be disrupted by natural disasters and extreme weather conditions, power or water shortages, telecommunications failures, cloud service provider outages, terrorist attacks, or acts of violence, political and/or civil unrest, acts of war or other military actions, epidemics or pandemics and other natural or man-made disasters and catastrophic events. Our corporate headquarters, a large portion of our current data center capacity, and a portion of our research and development activities are located in California, and other critical business operations, finished goods inventory, and some of our suppliers are located in Asia, making our operations vulnerable to natural disasters such as earthquakes, wildfires, or other business disruptions occurring in these geographical areas. Catastrophic events can also have an impact on third-party vendors who provide us critical infrastructure services for IT and research and development systems and personnel. Geopolitical and domestic political developments and other events beyond our control, can increase economic volatility globally. Political instability, changes in government or adverse political developments in or around any of the major countries in which we do business would also likely harm our business, financial condition and results of operations. Worldwide geopolitical tensions and conflicts, including but not limited to China, Hong Kong, Israel, Korea and Taiwan where the manufacture of our product components and final assembly of our products are concentrated may result in changing regulatory requirements, and other disruptions that could impact our operations and operating strategies, product demand, access to global markets, hiring, and profitability. For example, other countries have restricted and may continue in the future to restrict business with the State of Israel, where we have engineering, sales support operations and manufacturing, and companies with Israeli operations, including by economic boycotts. Our operations could be harmed and our costs could increase if manufacturing, logistics or other operations are disrupted for any reason, including natural disasters, high heat events or water shortages, information technology system failures, military actions or economic, business, labor, environmental, public health, or political issues. The ultimate impact on us, our third-party foundries and other suppliers of being located and consolidated in certain geographical areas is unknown. In the event a disaster, war or catastrophic event affects us, the third-party systems on which we rely, or our customers, our business could be harmed as a result of declines in revenue, increases in expenses, and substantial expenditures and time spent to fully resume operations. All of these risks and conditions could materially adversely affect our future sales and operating results.

Climate change may have a long-term impact on our business.

Climate change may have an increasingly adverse impact on our business and those of our customers, partners and vendors. Water and energy availability and reliability in the communities where we conduct business is critical, and certain of our facilities may be vulnerable to the impacts of extreme weather events. Extreme heat and wind coupled with dry conditions in Northern California may lead to power safety shut offs due to wildfire risk, which can have adverse implications for our Santa Clara, California headquarter offices and data centers, including impairing the ability of our employees to work effectively. Climate change, its impact on our supply chain and critical infrastructure worldwide, and its potential to increase political instability in regions where we, our customers, partners and our vendors do business, may disrupt our business and cause us to experience higher attrition, losses and costs to maintain or resume operations. Although we maintain insurance coverage for a variety of property, casualty, and other risks, the types and amounts of insurance we obtain vary depending on availability and cost. Some of our policies have large deductibles and broad exclusions, and our insurance providers may be unable or unwilling to pay a claim. Losses not covered by insurance may be large, which could harm our results of operations and financial condition.

Our business and those of our suppliers and customers, may also be subject to climate-related laws, regulations and lawsuits. Regulations such as carbon taxes, fuel or energy taxes, and pollution limits could result in greater direct costs, including costs associated with changes to manufacturing processes or the procurement of raw materials used in manufacturing processes, increased capital expenditures to improve facilities and equipment, and higher compliance and energy costs to reduce emissions, as well as greater indirect costs resulting from our customers, suppliers or both incurring additional compliance costs that are passed on to us. These costs and restrictions could harm our business and results of operations by increasing our expenses or requiring us to alter our operations and product design activities. Stakeholder groups may find us insufficiently responsive to the implications of climate change, and therefore we may face legal action or reputational harm. We may not achieve our stated goal to source 100% of our global electricity use from renewable energy by the end of fiscal year 2025, which could harm our reputation, or we may incur additional,

## Item 1A RISK FACTORS (blocks 372-376)

**Terms: GPU (GPUs), Nvidia (NVIDIA)**

unexpected costs to achieve such a goal. We may also experience contractual disputes due to supply chain delays arising from climate change-related disruptions, which could result in increased litigation and costs.

We also face risks related to business trends that may be influenced by climate change concerns. We may face decreased demand for computationally powerful but energy intensive products, such as our GPUs, despite their energy efficient design and operation, and/or increased consumer or customer expectations around the energy efficiency of our products, could negatively impact our business.

We may not be able to realize the potential benefits of business investments or acquisitions, and we may not be able to successfully integrate acquisition targets, which could hurt our ability to grow our business, develop new products or sell our products.

We have acquired and invested and may continue to do so in businesses that offer products, services and technologies that we believe will help expand or enhance our existing strategic objectives. Acquisitions or investments involve significant challenges and risks and could impair our ability to grow our business, develop new products or sell our products and ultimately could have a negative impact on our financial results. If we pursue a particular transaction, we may limit our ability to enter into other transactions that could help us achieve our other strategic objectives. If we are unable to timely complete acquisitions, including due to delays and challenges in obtaining regulatory approvals, we may be unable to pursue other transactions, we may not be able to retain critical talent from the target company, technology may evolve and make the acquisition less attractive, and other changes can take place which could reduce the anticipated benefits of the transaction and negatively impact our business. For example, in February 2022, NVIDIA and SoftBank announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm from SoftBank due to significant regulatory challenges preventing the completion of the transaction. We recorded in operating expenses a $1.35 billion charge in fiscal year 2023 reflecting the write-off of the prepayment provided at signing. Regulators could also impose conditions that reduce the ultimate value of our acquisitions. In addition, to the extent that our perceived ability to consummate acquisitions has been harmed, future acquisitions may be more difficult, complex or expensive. Further, if we hold investments in publicly traded companies, they could create volatility in our results and may generate losses up to the value of the investment.

Additional risks related to acquisitions or strategic investments include, but are not limited to:

## Item 1A RISK FACTORS (blocks 456-458)

**Terms: GPU (GPU)**

We currently and will likely continue to face legal, administrative and regulatory proceedings, claims, demands and/or investigations involving shareholder, consumer, competition and/or other issues relating to

our business. For example, we are defending on appeal the dismissal of a securities class action lawsuit from multiple shareholders asserting claims that we and certain of our officers made false and/or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand in 2017 and 2018. Litigation and regulatory proceedings are inherently uncertain, and adverse rulings could occur, including monetary damages or fines, or an injunction stopping us from manufacturing or selling certain products, engaging in certain business practices, or requiring other remedies, such as compulsory licensing of patents. An unfavorable outcome or settlement may result in a material adverse impact. Regardless of the outcome, litigation can be costly, time-consuming, and disruptive to our operations.

## Item 1A RISK FACTORS (blocks 463-464)

**Terms: Nvidia (NVIDIA)**

Delaware law and our certificate of incorporation, bylaws and agreement with Microsoft could delay or prevent a change in control.

The anti-takeover provisions of the Delaware General Corporation Law may discourage, delay, or prevent a change in control. Provisions in our certificate of incorporation and bylaws could make it more difficult for a third party to acquire a majority of our outstanding stock. These provisions include the ability of our Board of Directors to create and issue preferred stock, change the number of directors, and to make, amend or repeal our bylaws without prior shareholder approval; the inability of our shareholders to act by written consent or call special meetings; advance notice requirements for director nominations and shareholder proposals; and a super-majority voting requirement to amend some provisions in our certificate of incorporation and bylaws. Under our agreement with Microsoft for the Xbox, if someone makes an offer to purchase at least 30% of our outstanding common stock, Microsoft may have first and last rights of refusal to purchase the stock. These provisions could delay or prevent a change in control of NVIDIA, discourage proxy contests, and make it more difficult for shareholders to elect directors of their choosing and to cause us to take other corporate actions they desire.

## Item 2 PROPERTIES (blocks 467-468)

**Terms: data center (data center)**

ITEM 2. PROPERTIES

Our headquarters is in Santa Clara, California. We own and lease approximately 3 million square feet of office and building space for our corporate headquarters. In addition, we lease data center space in Santa Clara, California. We also own and lease facilities for data centers, research and development, and/or sales and administrative purposes throughout the U.S. and in various international locations, primarily in China, India, Israel, and Taiwan. We believe our existing facilities, both owned and leased, are in good condition and suitable for the conduct of our business. We do not identify or allocate assets by operating segment. For additional information regarding obligations under leases, refer to Note 3 of the Notes to the Consolidated Financial Statements in Part IV, Item 15 of this Annual Report on Form 10-K, which information is hereby incorporated by reference.

## Item 5 MARKET FOR REGISTRANT’S COMMON EQUITY, RELATED STOCKHOLDER MATTERS AND ISSUER PURCHASES OF EQUITY SECURITIES (blocks 478-480)

**Terms: Nvidia (NVIDIA)**

On May 23, 2022, our Board of Directors increased and extended our share repurchase program to repurchase additional common stock up to a total of $15 billion through December 2023. Since the inception of our share repurchase program, we have repurchased an aggregate of 1.10 billion shares for a total cost of $17.12 billion through January 29, 2023. During fiscal year 2023, we repurchased 63 million shares for $10.04 billion. As of January 29, 2023, we are authorized, subject to certain specifications, to repurchase shares of our common stock up to $7.23 billion through December 2023.

The repurchases can be made in the open market, in privately negotiated transactions, pursuant to a Rule 10b5-1 trading plan or in structured share repurchase programs, and can be made in one or more larger repurchases, in compliance with Rule 10b-18 of the Exchange Act, subject to market conditions, applicable legal requirements, and other factors. The program does not obligate NVIDIA to acquire any particular amount of common stock and the program may be suspended at any time at our discretion.

In fiscal year 2023, we paid $398 million in quarterly cash dividends. Our cash dividend program and the payment of future cash dividends under that program are subject to our Board of Directors' continuing determination that the dividend program and the declaration of dividends thereunder are in the best interests of our shareholders.

## Item 5 MARKET FOR REGISTRANT’S COMMON EQUITY, RELATED STOCKHOLDER MATTERS AND ISSUER PURCHASES OF EQUITY SECURITIES (blocks 495-497)

**Terms: Nvidia (NVIDIA)**

1/28/2018 | 1/27/2019 | 1/26/2020 | 1/31/2021 | 1/30/2022 | 1/29/2023

NVIDIA Corporation | $ 100.00 | $ 66.00 | $ 103.63 | $ 215.33 | $ 378.94 | $ 338.18

S&P 500 | $ 100.00 | $ 94.60 | $ 119.36 | $ 137.01 | $ 165.79 | $ 154.80

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 525-526)

**Terms: Nvidia (NVIDIA)**

Termination of the Arm Share Purchase Agreement

In February 2022, NVIDIA and SoftBank announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm from SoftBank due to significant regulatory challenges preventing the completion of the transaction. We recorded an acquisition termination cost of $1.35 billion in fiscal year 2023 reflecting the write-off of the prepayment provided at signing.

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 568-569)

**Terms: Nvidia (NVIDIA)**

For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

Our customer programs involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 582-584)

**Terms: Nvidia (nvidia)**

Results of Operations

A discussion regarding our financial condition and results of operations for fiscal year 2023 compared to fiscal year 2022 is presented below. A discussion regarding our financial condition and results of operations for fiscal year 2022 compared to fiscal year 2021 can be found under Item 7 in our Annual Report on Form 10-K for the fiscal year ended January 30, 2022, filed with the SEC on March 18, 2022, which is available free of charge on the SEC’s website at http://www.sec.gov and at our investor relations website, http://investor.nvidia.com.

The following table sets forth, for the periods indicated, certain items in our Consolidated Statements of Income expressed as a percentage of revenue.

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 619-620)

**Terms: GPU (GPUs)**

Compute & Networking - The gross margin of our Compute & Networking segment decreased during fiscal year 2023 when compared to fiscal year 2022, primarily due to inventory provisions.

Graphics - The gross margin of our Graphics segment decreased during fiscal year 2023 when compared to fiscal year 2022, primarily due to inventory and related provisions and lower margins of GeForce GPUs.

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 632-634)

**Terms: data center (data center)**

% of revenue | 41.3 % | 27.6 %

The increase in research and development expense for fiscal year 2023 was primarily driven by increased compensation, employee growth, engineering development costs, and data center infrastructure.

The increase in sales, general and administrative expense for fiscal year 2023 was primarily driven by increased compensation and employee growth.

## Item 9A CONTROLS AND PROCEDURES (blocks 731-732)

**Terms: Nvidia (NVIDIA)**

Inherent Limitations on Effectiveness of Controls

Our management, including our Chief Executive Officer and Chief Financial Officer, does not expect that our disclosure controls and procedures or our internal controls, will prevent all error and all fraud. A control system, no matter how well conceived and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Further, the design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within NVIDIA have been detected.

## Item 10 DIRECTORS, EXECUTIVE OFFICERS AND CORPORATE GOVERNANCE (blocks 751-752)

**Terms: Nvidia (nvidia)**

Code of Conduct

Information regarding our Code of Conduct required by this item will be contained in our 2023 Proxy Statement under the caption “Information About the Board of Directors and Corporate Governance - Code of Conduct,” and is hereby incorporated by reference. The full text of our Code of Conduct and Financial Team Code of Conduct are published on the Investor Relations portion of our website, under Governance, at www.nvidia.com. If we make any amendments to either code, or grant any waiver from a provision of either code to any executive officer or director, we will promptly disclose the nature of the amendment or waiver on our website or in a report on Form 8-K. The contents of our website are not a part of this Annual Report on Form 10-K.

## Item 12 SECURITY OWNERSHIP OF CERTAIN BENEFICIAL OWNERS AND MANAGEMENT AND RELATED STOCKHOLDER MATTERS (blocks 755-757)

**Terms: Nvidia (NVIDIA)**

ITEM 12. SECURITY OWNERSHIP OF CERTAIN BENEFICIAL OWNERS AND MANAGEMENT AND RELATED STOCKHOLDER MATTERS

Ownership of NVIDIA Securities

Information regarding ownership of NVIDIA securities required by this item will be contained in our 2023 Proxy Statement under the caption “Security Ownership of Certain Beneficial Owners and Management,” and is hereby incorporated by reference.

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 781-785)

**Terms: Nvidia (NVIDIA)**

Report of Independent Registered Public Accounting Firm

To the Board of Directors and Shareholders of NVIDIA Corporation

Opinions on the Financial Statements and Internal Control over Financial Reporting

We have audited the accompanying consolidated balance sheets of NVIDIA Corporation and its subsidiaries (the “Company”) as of January 29, 2023 and January 30, 2022, and the related consolidated statements of income, comprehensive income, shareholders' equity and cash flows for each of the three years in the period ended January 29, 2023, including the related notes and financial statement schedule listed in the index appearing under Item 15(a)(2) (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of January 29, 2023, based on criteria established in Internal Control - Integrated Framewor k (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of January 29, 2023 and January 30, 2022, and the results of its operations and its cash flows for each of the three years in the period ended January 29, 2023 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of January 29, 2023, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 804-806)

**Terms: Nvidia (NVIDIA)**

We have served as the Company’s auditor since 2004.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 832-834)

**Terms: Nvidia (NVIDIA)**

See accompanying notes to the consolidated financial statements.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 850-852)

**Terms: Nvidia (NVIDIA)**

See accompanying notes to the consolidated financial statements.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 890-892)

**Terms: Nvidia (NVIDIA)**

See accompanying notes to the consolidated financial statements.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 922-924)

**Terms: Nvidia (NVIDIA)**

See accompanying notes to the consolidated financial statements.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 969-971)

**Terms: Nvidia (NVIDIA)**

See accompanying notes to the consolidated financial statements.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 974-976)

**Terms: Nvidia (NVIDIA)**

Our Company

Headquartered in Santa Clara, California, NVIDIA was incorporated in California in April 1993 and reincorporated in Delaware in April 1998.

All references to “NVIDIA,” “we,” “us,” “our” or the “Company” mean NVIDIA Corporation and its subsidiaries.

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 982-983)

**Terms: Nvidia (NVIDIA)**

Principles of Consolidation

Our consolidated financial statements include the accounts of NVIDIA Corporation and our wholly-owned subsidiaries. All intercompany balances and transactions have been eliminated in consolidation.

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 990-992)

**Terms: Nvidia (NVIDIA)**

Revenue from product sales is recognized upon transfer of control of products to customers in an amount that reflects the consideration we expect to receive in exchange for those products. Certain products are

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 996-997)

**Terms: Nvidia (NVIDIA)**

For products sold with a right of return, we record a reduction to revenue by establishing a sales return allowance for estimated product returns at the time revenue is recognized, based primarily on historical return rates. However, if product returns for a fiscal period are anticipated to exceed historical return rates, we may determine that additional sales return allowances are required to properly reflect our estimated exposure for product returns.

Our customer programs involve rebates, which are designed to serve as sales incentives to resellers of our products in various target markets, and marketing development funds, or MDFs, which represent monies paid to our partners that are earmarked for market segment development and are designed to support our partners’ activities while also promoting NVIDIA products. We account for customer programs as a reduction to revenue and accrue for potential rebates and MDFs based on the amount we expect to be claimed by customers.

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1007-1009)

**Terms: Nvidia (NVIDIA)**

We use the closing trading price of our common stock on the date of grant, minus a dividend yield discount, as the fair value of awards of restricted stock units, or RSUs, and performance stock units that are based on our corporate financial performance targets, or PSUs. We use a Monte Carlo simulation on the date of grant to estimate the fair value of performance stock units that are based on market conditions, or market-based PSUs. The compensation expense for RSUs and market-based PSUs is recognized using a straight-line

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1020-1022)

**Terms: Nvidia (NVIDIA)**

As of January 29, 2023, we had a valuation allowance of $ 1.48 billion related to capital loss carryforwards, state, and certain other deferred tax assets that management determined are not likely to be realized due to jurisdictional projections of future taxable income, including capital gains, tax attributes usage limitation by certain jurisdictions, and potential utilization limitations of tax attributes acquired as a result of stock ownership changes. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax assets as an income tax benefit during the period.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1035-1037)

**Terms: Nvidia (NVIDIA)**

Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, marketable securities, and accounts receivable. Our investment policy requires the purchase of highly-rated fixed income securities, the diversification of investment type and credit exposures, and includes certain limits on our portfolio duration. We perform ongoing credit evaluations of our customers’ financial condition and maintain an allowance for potential credit losses. This allowance consists of an amount

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1052-1054)

**Terms: Nvidia (NVIDIA)**

The quantitative impairment test considers both the income approach and the market approach to estimate a reporting unit’s fair value. The income and market valuation approaches consider factors that include, but are not limited to, prospective financial information, growth rates, residual values, discount rates and comparable multiples from publicly traded companies in our industry and require us to make certain assumptions and estimates regarding industry economic factors and the future profitability of our business.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1067-1070)

**Terms: Nvidia (NVIDIA)**

Termination of the Arm Share Purchase Agreement

In February 2022, NVIDIA and SoftBank announced the termination of the Share Purchase Agreement whereby NVIDIA would have acquired Arm from SoftBank. The parties agreed to terminate due to significant

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1081-1083)

**Terms: Nvidia (NVIDIA)**

Total cash consideration | 7,049

Fair value of Mellanox equity awards assumed by NVIDIA (3) | 85

Total purchase consideration | $ 7,134

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1102-1106)

**Terms: Nvidia (NVIDIA)**

We allocated the purchase price to tangible and identified intangible assets acquired and liabilities assumed based on the estimated fair values.

The goodwill is primarily attributable to the planned growth in the combined business of NVIDIA and Mellanox. Goodwill is not amortized to earnings, but instead is reviewed for impairment at least annually, absent any interim indicators of impairment. Goodwill recognized in the acquisition is not expected to be deductible for foreign tax purposes. Goodwill arising from the Mellanox acquisition has been allocated to the Compute and Networking segment. Refer to Note 17 – Segment Information for further details on segments.

The operating results of Mellanox have been included in our consolidated financial statements for fiscal year 2021 since the acquisition date of April 27, 2020. Revenue attributable to Mellanox was approximately 10 % for fiscal year 2021. There is not a practical way to determine net income attributable to Mellanox due to

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1128-1130)

**Terms: Nvidia (NVIDIA)**

Supplemental Unaudited Pro Forma Information

The following unaudited pro forma financial information summarizes the combined results of operations for NVIDIA and Mellanox as if the companies were combined as of the beginning of fiscal year 2020:

Pro Forma

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1136-1138)

**Terms: Nvidia (NVIDIA)**

The unaudited pro forma information presented above includes adjustments related to amortization of acquired intangible assets, adjustments to stock-based compensation expense, fair value of acquired inventory, and transaction costs. The unaudited pro forma information is for informational purposes only and is not necessarily indicative of our consolidated results of operations of the combined business had the acquisition actually occurred at the beginning of fiscal year 2020 or of the results of our future operations of the combined businesses.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1142-1144)

**Terms: data center (data center)**

Note 3 - Leases

Our lease obligations primarily consist of operating leases for our headquarters complex, domestic and international office facilities, and data center space, with lease periods expiring between fiscal years 2024 and 2035.

Future minimum lease payments under our non-cancelable operating leases as of January 29, 2023, are as follows:

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1158-1160)

**Terms: data center (data centers)**

Long-term operating lease liabilities | $ 902

In addition to above, we have operating leases, primarily for our data centers, that are expected to commence within fiscal years 2024 and 2025 with lease terms of 2 to 8 years for $ 463 million.

Operating lease expense for fiscal years 2023, 2022, and 2021 was $ 193 million, $ 168 million, $ 145 million, respectively. Short-term and variable lease expenses for fiscal years 2023, 2022, and 2021 were not significant.

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1167-1169)

**Terms: Nvidia (NVIDIA)**

As of January 29, 2023, our operating leases had a weighted average remaining lease term of 6.8 years and a weighted average discount rate of 3.21 %. As of January 30, 2022, our operating leases had a weighted average remaining lease term of 7.1 years and a weighted average discount rate of 2.51 %.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1193-1195)

**Terms: Nvidia (NVIDIA)**

As of January 29, 2023, there was $ 6.56 billion of aggregate unearned stock-based compensation expense. This amount is expected to be recognized over a weighted average period of 2.6 years for RSUs, PSUs, and market-based PSUs, and 1.0 year for ESPP.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1210-1215)

**Terms: Nvidia (NVIDIA)**

Amended and Restated 2007 Equity Incentive Plan

In 2007, our shareholders approved the NVIDIA Corporation 2007 Equity Incentive Plan, as most recently amended and restated, or the 2007 Plan.

The 2007 Plan authorizes the issuance of incentive stock options, non-statutory stock options, restricted stock, restricted stock units, stock appreciation rights, performance stock awards, performance cash awards, and other stock-based awards to employees, directors and consultants. Only our employees may receive incentive stock options. As of January 29, 2023, up to 47 million shares of our common stock could be issued pursuant to stock awards granted under the 2007 Plan, of which 2 million shares were issuable upon the exercise of outstanding stock options. All options are fully vested, the last of which will expire by December 2023 if not exercised. Currently, we grant RSUs, PSUs and market-based PSUs under the 2007 Plan, under which, as of January 29, 2023, there were 160 million shares available for future grants.

Subject to certain exceptions, RSUs granted to employees vest (A) over a four-year period, subject to continued service, with 25 % vesting on a pre-determined date that is close to the anniversary of the date of grant and 6.25 % vesting quarterly thereafter, (B) over a three-year period, subject to continued service, with 40 % vesting on a pre-determined date that is close to the anniversary of the date of grant and 7.5 % vesting quarterly thereafter, or (C) over a four-year period, subject to continued service, with 6.25 % vesting quarterly. PSUs vest over a four-year period, subject to continued service, with 25 % vesting on a pre-determined date that is close to the anniversary of the date of grant and 6.25 % vesting quarterly thereafter. Market-based PSUs vest 100 % on approximately the three-year anniversary of the date of grant. However, the number of shares subject to both PSUs and market-based PSUs that are eligible to vest is generally determined by the Compensation Committee based on achievement of pre-determined criteria.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1218-1220)

**Terms: Nvidia (NVIDIA)**

Amended and Restated 2012 Employee Stock Purchase Plan

In 2012, our shareholders approved the NVIDIA Corporation 2012 Employee Stock Purchase Plan, as most recently amended and restated, or the 2012 Plan.

Employees who participate in the 2012 Plan may have up to 15 % of their earnings withheld to purchase shares of common stock. The Board may decrease this percentage at its discretion. Each offering period is approximately 24 months, which is generally divided into four purchase periods of six months . The price of common stock purchased under our 2012 Plan will be equal to 85 % of the lower of the fair market value of the common stock on the commencement date of each offering period or the fair market value of the common stock on each purchase date within the offering. As of January 29, 2023, we had 230 million shares reserved for future issuance under the 2012 Plan.

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1233-1235)

**Terms: Nvidia (NVIDIA)**

The total fair value of RSUs and PSUs, as of their respective vesting dates, during the years ended January 29, 2023, January 30, 2022, and January 31, 2021, was $ 4.27 billion, $ 5.56 billion, and $ 2.67 billion, respectively.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1263-1265)

**Terms: Nvidia (NVIDIA)**

(1) During the first quarter of fiscal year 2023, we commenced amortization of a $ 630 million in-process research and development intangible asset related to our acquisition of Mellanox.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1291-1293)

**Terms: Nvidia (NVIDIA)**

Total | $ 20,930 | $ — | $ ( 17 ) | $ 20,913 | $ 1,695 | $ 19,218

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1318-1320)

**Terms: Nvidia (NVIDIA)**

The fair values of our financial assets and liabilities are determined using quoted market prices of identical assets or quoted market prices of similar assets from active markets. We review fair value hierarchy classification on a quarterly basis.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1357-1359)

**Terms: Nvidia (NVIDIA)**

(1) In fiscal years 2023 and 2022, we recorded an inventory reserve expense of approximately $ 1.04 billion and $ 173 million in cost of revenue, respectively.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1386-1388)

**Terms: Nvidia (NVIDIA)**

(1) Refer to Note 2 - Business Combination for further details on the Arm acquisition.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1424-1426)

**Terms: Nvidia (NVIDIA)**

Revenue related to remaining performance obligations represents the contracted license and development arrangements and support for hardware and software. This includes deferred revenue currently recorded and amounts that will be invoiced in future periods. As of January 29, 2023, $ 652 million of revenue related to

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1443-1445)

**Terms: Nvidia (NVIDIA)**

In fiscal year 2022, we repaid the $ 1.00 billion of 2.20 % Notes Due 2021.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1471-1473)

**Terms: Nvidia (NVIDIA)**

We have entered into several long-term supply agreements, under which we have made advance payments and have $ 810 million remaining unpaid. As of January 29, 2023, we had outstanding inventory purchase and long-term supply obligations totaling $ 4.92 billion, inclusive of the $ 810 million. Under our manufacturing relationships with our foundry suppliers, subcontractors and contract manufacturers, cancellation of outstanding purchase commitments is generally allowed but may result in the payment of costs incurred through the date of cancellation. Other non-inventory purchase obligations of $ 3.14 billion include $ 2.23 billion of multi-year cloud service agreements.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1495-1497)

**Terms: data center (Data Center)**

Balance at end of period | $ 82 | $ 46 | $ 22

In the second quarter of fiscal year 2023, we recorded $ 122 million in product warranty liabilities primarily related to a defect identified in a third-party component embedded in certain Data Center products. In the third quarter of fiscal year 2023, we recognized a warranty-related benefit of approximately $ 70 million in cost of revenue due to favorable product recovery.

In connection with certain agreements that we have entered in the past, we have provided indemnities for matters such as tax, product, and employee liabilities. We have included intellectual property indemnification provisions in our technology-related agreements with third parties. Maximum potential future payments cannot be estimated because many of these agreements do not have a maximum stated liability. We have not recorded any liability in our Consolidated Financial Statements for such indemnifications.

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1499-1502)

**Terms: GPU (GPU), Nvidia (NVIDIA)**

Securities Class Action and Derivative Lawsuits

The plaintiffs in the putative securities class action lawsuit, captioned 4:18-cv-07669-HSG, initially filed on December 21, 2018 in the United States District Court for the Northern District of California, and titled In Re NVIDIA Corporation Securities Litigation, filed an amended complaint on May 13, 2020. The amended complaint asserted that NVIDIA and certain NVIDIA executives violated Section 10(b) of the Securities Exchange Act of 1934, as amended, or the Exchange Act, and SEC Rule 10b-5, by making materially false or misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand between May 10, 2017 and November 14, 2018. Plaintiffs also alleged that the NVIDIA executives who they named as defendants violated Section 20(a) of the Exchange Act. Plaintiffs sought class certification, an award of unspecified compensatory damages, an award of reasonable costs and expenses,

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1504-1507)

**Terms: GPU (GPU), Nvidia (NVIDIA)**

(Continued)

including attorneys’ fees and expert fees, and further relief as the Court may deem just and proper. On March 2, 2021, the district court granted NVIDIA’s motion to dismiss the complaint without leave to amend, entered judgment in favor of NVIDIA and closed the case. On March 30, 2021, plaintiffs filed an appeal from judgment in the United States Court of Appeals for the Ninth Circuit, case number 21-15604. Oral argument on the appeal was held on May 10, 2022.

The putative derivative lawsuit pending in the United States District Court for the Northern District of California, captioned 4:19-cv-00341-HSG, initially filed January 18, 2019 and titled In re NVIDIA Corporation Consolidated Derivative Litigation, was stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. On February 22, 2022, the court administratively closed the case, but stated that it would reopen the case once the appeal in the In Re NVIDIA Corporation Securities Litigation action is resolved. The lawsuit asserts claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, waste of corporate assets, and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs are seeking unspecified damages and other relief, including reforms and improvements to NVIDIA’s corporate governance and internal procedures.

The putative derivative actions initially filed September 24, 2019 and pending in the United States District Court for the District of Delaware, Lipchitz v. Huang, et al. (Case No. 1:19-cv-01795-UNA) and Nelson v. Huang, et. al. (Case No. 1:19-cv-01798- UNA), remain stayed pending resolution of the plaintiffs’ appeal in the In Re NVIDIA Corporation Securities Litigation action. The lawsuits assert claims, purportedly on behalf of us, against certain officers and directors of the Company for breach of fiduciary duty, unjust enrichment, insider trading, misappropriation of information, corporate waste and violations of Sections 14(a), 10(b), and 20(a) of the Exchange Act based on the dissemination of allegedly false, and misleading statements related to channel inventory and the impact of cryptocurrency mining on GPU demand. The plaintiffs seek unspecified damages and other relief, including disgorgement of profits from the sale of NVIDIA stock and unspecified corporate governance measures.

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1509-1511)

**Terms: Nvidia (NVIDIA)**

As of January 29, 2023, we have not recorded any accrual for contingent liabilities associated with the legal proceedings described above based on our belief that liabilities, while possible, are not probable. Further, except as specifically described above, any possible loss or range of loss in these matters cannot be reasonably estimated at this time. We are engaged in legal actions not described above arising in the ordinary course of business and, while there can be no assurance of favorable outcomes, we believe that the ultimate outcome of these actions will not have a material adverse effect on our operating results, liquidity or financial position.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1547-1549)

**Terms: Nvidia (NVIDIA)**

Income tax expense (benefit) | $ ( 187 ) | ( 4.5 ) % | $ 189 | 1.9 % | $ 77 | 1.7 %

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1579-1581)

**Terms: Nvidia (NVIDIA)**

Our tax attributes remain subject to audit and may be adjusted for changes or modification in tax laws, other authoritative interpretations thereof, or other facts and circumstances. Utilization of tax attributes may also

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1602-1604)

**Terms: Nvidia (NVIDIA)**

During fiscal year 2023, we repurchased 63 million shares for $ 10.04 billion. Since the inception of our share repurchase program through January 29, 2023, we have repurchased an aggregate of 1.10 billion shares under our share repurchase program for a total cost of $ 17.12 billion. As of January 29, 2023, we were authorized, subject to certain specifications, to repurchase an additional $ 7.23 billion of shares through December 2023.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1617-1619)

**Terms: Nvidia (NVIDIA)**

Our CODM does not review any information regarding total assets on a reportable segment basis. Depreciation and amortization expense directly attributable to each reportable segment is included in operating results for each segment. However, the CODM does not evaluate depreciation and amortization expense by operating segment and, therefore, it is not separately presented. There is no intersegment revenue. The accounting policies for segment reporting are the same as for our consolidated financial statements. The table below presents details of our reportable segments and the “All Other” category.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1652-1654)

**Terms: Nvidia (NVIDIA)**

No customer represented 10% or more of total revenue for fiscal years 2023, 2022 and 2021.

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1660-1662)

**Terms: data center (Data Center)**

Revenue: | (In millions)

Data Center | $ 15,005 | $ 10,613 | $ 6,696

Gaming | 9,067 | 12,462 | 7,759

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1674-1675)

**Terms: Nvidia (NVIDIA)**

Total long-lived assets | $ 3,807 | $ 2,778

NVIDIA CORPORATION AND SUBSIDIARIES

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1696-1702)

**Terms: Nvidia (NVIDIA)**

Exhibit No. | Exhibit Description | Incorporated by Reference — Schedule/Form | File Number | Exhibit | Filing Date

2.1 | Agreement and Plan of Merger, dated March 10, 2019, by and among NVIDIA Corporation, NVIDIA International Holdings Inc., Mellanox Technologies Ltd. and Teal Barvaz Ltd. | 8-K | 0-23985 | 2.1 | 3/11/2019

2.2^ | Share Purchase Agreement, dated September 13, 2020, by and among NVIDIA, NVIDIA Holdings, Arm, SoftBank, and Vision Fund | 8-K | 0-23985 | 2.1 | 9/14/2020

3.1 | Restated Certificate of Incorporation | 10-K | 0-23985 | 3.1 | 3/18/2022

3.2 | Amendment to Restated Certificate of Incorporation of NVIDIA Corporation | 8-K | 0-23985 | 3.1 | 6/6/2022

3.3 | Bylaws of NVIDIA Corporation, Amended and Restated as of March 3, 2022 | 8-K | 0-23985 | 3.1 | 3/9/2022

4.1 | Reference is made to Exhibits 3.1, 3.2 and 3.3

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1717-1719)

**Terms: Nvidia (NVIDIA)**

4.16 | Form of 2031 Note | 8-K | 0-23985 | Annex D-1 to Exhibit 4.2 | 6/16/2021

10.1 | Form of Indemnity Agreement between NVIDIA Corporation and each of its directors and officers | 8-K | 0-23985 | 10.1 | 3/7/2006

10.2+ | Amended and Restated 2007 Equity Incentive Plan

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1734-1739)

**Terms: Nvidia (NVIDIA)**

10.17+ | Fiscal Year 2023 Variable Compensation Plan | 8-K | 0-23985 | 10.1 | 3/9/2022

10.18+ | Offer Letter between NVIDIA Corporation and Colette Kress, dated September 13, 2013 | 8-K | 0-23985 | 10.1 | 9/16/2013

10.19+ | Offer Letter between NVIDIA Corporation and Tim Teter, dated December 16, 2016 | 8-K | 0-23985 | 10.1 | 1/19/2017

10.20+ | Offer Letter between NVIDIA Corporation and Donald Robertson, dated May 21, 2019 | 8-K | 0-23985 | 10.1 | 6/17/2019

10.21 | Form of Commercial Paper Dealer Agreement between NVIDIA Corporation, as Issuer, and the Dealer party thereto | 8-K | 0-23985 | 10.1 | 12/15/2017

21.1 | List of Registrant's Subsidiaries

## Item 15 EXHIBIT AND FINANCIAL STATEMENT SCHEDULES (blocks 1757-1758)

**Terms: Nvidia (NVIDIA)**

Copies of above exhibits not contained herein are available to any shareholder upon written request to:

Investor Relations: NVIDIA Corporation, 2788 San Tomas Expressway, Santa Clara, CA 95051

## Item 16 FORM 10-K SUMMARY (blocks 1762-1764)

**Terms: Nvidia (NVIDIA)**

Pursuant to the requirements of Section 13 or 15(d) of the Securities Exchange Act of 1934, the Registrant has duly caused this report to be signed on its behalf by the undersigned, thereunto duly authorized, on February 24, 2023.

NVIDIA Corporation

By: | /s/ Jen-Hsun Huang
