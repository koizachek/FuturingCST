# AMAZON COM INC | 10-K | fiscal year 2022

- Report length: 40,661 words
- Direct AI mentions (classified): 5, of which about AI: 5, false candidates: 0, flagged for review: 0
- Context passages (not classified): 15; groups: compute_infrastructure (10), industry (6), techniques (4)
- Frames: business (4), risk_factor (1)
- Roles: offering (4), risk (1), adoption (1)
- Risk types: regulatory_legal (1)
- MIT subdomains: regulation_lagging_behind_ai (1)
- Adoption stage: deployed (1)
- Business functions: rd_product (1)
- Governance responses: none
- Kinds of AI: traditional_ml (3), unspecified (1), nlp (1)
- Substantiveness: specific (3), generic (1), detailed (1)
- Disclosure traits: none
- Trait activation rate: 0.0 (boilerplate (0.0), hedging (0.0), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 8 (2), Item 1 (1), Item 1A (1), Item 7 (1)
- Named entities: AWS, Alexa, CF Dynamic Advances LLC, Rensselaer Polytechnic Institute

## Item 1 Business (blocks 86-87)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> We serve developers and enterprises of all sizes, including start-ups, government agencies, and academic institutions, through AWS, which offers a broad set of on-demand technology services, including compute, storage, database, analytics, and machine learning, and other services.

<details><summary>Passage</summary>

Developers and Enterprises

We serve developers and enterprises of all sizes, including start-ups, government agencies, and academic institutions, through AWS, which offers a broad set of on-demand technology services, including compute, storage, database, analytics, and machine learning, and other services.

</details>

## Item 1A Risk Factors (blocks 278-279)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: regulatory_legal | mit: regulation_lagging_behind_ai | kinds: unspecified | substantiveness: generic**

> We are subject to general business regulations and laws, as well as regulations and laws specifically governing the Internet, physical, e-commerce, and omnichannel retail, digital content, web services, electronic devices, advertising, artificial intelligence technologies and services, and other products and services that we offer or sell.

<details><summary>Passage</summary>

Government Regulation Is Evolving and Unfavorable Changes Could Harm Our Business

We are subject to general business regulations and laws, as well as regulations and laws specifically governing the Internet, physical, e-commerce, and omnichannel retail, digital content, web services, electronic devices, advertising, artificial intelligence technologies and services, and other products and services that we offer or sell. These regulations and laws cover taxation, privacy, data use, data protection, data security, data localization, network security, consumer protection, pricing, content, copyrights, distribution, transportation, mobile communications, electronic device certification, electronic waste, energy consumption, environmental regulation, electronic contracts and other communications, competition, employment, trade and protectionist measures, web services, the provision of online payment services, registration, licensing, and information reporting requirements, unencumbered Internet access to our services or access to our facilities, the design and operation of websites, health, safety, and sanitation standards, the characteristics, legality, and quality of products and services, product labeling, the commercial operation of unmanned aircraft systems, healthcare, and other matters. It is not clear how existing laws governing issues such as property ownership, libel, privacy, data use, data protection, data security, data localization, network security, and consumer protection apply to aspects of our operations such as the Internet, e-commerce, digital content, web services, electronic devices, advertising, and artificial intelligence technologies and services. A large number of jurisdictions regulate our operations, and the extent, nature, and scope of such regulations is evolving and expanding as the scope of our businesses expand. We are regularly subject to formal and informal reviews, investigations, and other proceedings by governments and regulatory authorities under existing laws, regulations, or interpretations or pursuing new and novel approaches to regulate our operations. For example, we face a number of open investigations based on claims that aspects of our operations violate competition rules, including aspects of Amazon’s U.S. and European marketplace for sellers, particularly with respect to use of data, fulfillment services, and featured offers, and legislative and regulatory initiatives in Europe and elsewhere allow authorities to restrict or prohibit certain operations or actions pre-emptively without the need to assess specific competitive effects. Unfavorable regulations, laws, decisions, or interpretations by government or regulatory authorities applying those laws and regulations, or inquiries, investigations, or enforcement actions threatened or initiated by them, could cause us to incur substantial costs, expose us to unanticipated civil and criminal liability or penalties (including substantial monetary fines), diminish the demand for, or availability of, our products and services, increase our cost of doing business, require us to change our business practices in a manner materially adverse to our business, damage our reputation, impede our growth, or otherwise have a material effect on our operations. The media, political, and regulatory scrutiny we face, which may continue to increase, amplifies these risks.

</details>

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 343-345)

**AI reference: explicit | frame: business | roles: adoption, offering | adoption: deployed | functions: rd_product | kinds: traditional_ml | substantiveness: detailed**

> We believe that advances in technology, specifically the speed and reduced cost of processing power, data storage and analytics, improved wireless connectivity, and the practical applications of artificial intelligence and machine learning, will continue to improve users’ experience on the Internet and increase its ubiquity in people’s lives.

> To best take advantage of these continued advances in technology, we are investing in AWS, which offers a broad set of on-demand technology services, including compute, storage, database, analytics, and machine learning, and other services, to developers and enterprises of all sizes.

<details><summary>Passage</summary>

of suppliers, seasonality, and changes in payment and other terms over time, including the effect of balancing pricing and timing of payment terms with suppliers.

We expect spending in technology and content will increase over time as we add computer scientists, designers, software and hardware engineers, and merchandising employees. Our technology and content investment and capital spending projects often support a variety of product and service offerings due to geographic expansion and the cross-functionality of our systems and operations. We seek to invest efficiently in several areas of technology and content, including AWS, and expansion of new and existing product categories and service offerings, as well as in technology infrastructure to enhance the customer experience and improve our process efficiencies. We believe that advances in technology, specifically the speed and reduced cost of processing power, data storage and analytics, improved wireless connectivity, and the practical applications of artificial intelligence and machine learning, will continue to improve users’ experience on the Internet and increase its ubiquity in people’s lives. To best take advantage of these continued advances in technology, we are investing in AWS, which offers a broad set of on-demand technology services, including compute, storage, database, analytics, and machine learning, and other services, to developers and enterprises of all sizes. We are also investing in initiatives to build and deploy innovative and efficient software and electronic devices as well as other initiatives including the development of a satellite network for global broadband service and autonomous vehicles for ride-hailing services.

We seek to efficiently manage shareholder dilution while maintaining the flexibility to issue shares for strategic purposes, such as financings, acquisitions, and aligning employee compensation with shareholders’ interests. We utilize restricted stock units as our primary vehicle for equity compensation because we believe this compensation model aligns the long-term interests of our shareholders and employees. In measuring shareholder dilution, we include all vested and unvested stock awards outstanding, without regard to estimated forfeitures. Total shares outstanding plus outstanding stock awards were 10.5 billion and 10.6 billion as of December 31, 2021 and 2022.

</details>

## Item 8 Financial Statements and Supplementary Data (blocks 746-748)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> We serve developers and enterprises of all sizes through AWS, which offers a broad set of on-demand technology services, including compute, storage, database, analytics, and machine learning, and other services.

<details><summary>Passage</summary>

Description of Business

We seek to be Earth’s most customer-centric company. In each of our segments, we serve our primary customer sets, consisting of consumers, sellers, developers, enterprises, content creators, advertisers, and employees. We serve consumers through our online and physical stores and focus on selection, price, and convenience. We offer programs that enable sellers to grow their businesses, sell their products in our stores, and fulfill orders through us, and programs that allow authors, independent publishers, musicians, filmmakers, Twitch streamers, skill and app developers, and others to publish and sell content. We serve developers and enterprises of all sizes through AWS, which offers a broad set of on-demand technology services, including compute, storage, database, analytics, and machine learning, and other services. We also manufacture and sell electronic devices. In addition, we provide advertising services to sellers, vendors, publishers, authors, and others, through programs such as sponsored ads, display, and video advertising.

We have organized our operations into three segments: North America, International, and AWS. See “Note 10 — Segment Information.”

</details>

## Item 8 Financial Statements and Supplementary Data (blocks 1116-1118)

**AI reference: explicit | frame: business | roles: offering | kinds: nlp | substantiveness: specific**

> The complaint alleges, among other things, that “Alexa Voice Software and Alexa enabled devices” infringe U.S. Patent No. 7,177,798, entitled “Natural Language Interface Using Constrained Intermediate Dictionary of Results.”

<details><summary>Passage</summary>

In November 2015, Eolas Technologies, Inc. filed a complaint against Amazon.com, Inc. in the United States District Court for the Eastern District of Texas. The complaint alleges, among other things, that the use of “interactive features” on www.amazon.com, including “search suggestions and search results,” infringes U.S. Patent No. 9,195,507, entitled “Distributed Hypermedia Method and System for Automatically Invoking External Application Providing Interaction and Display of Embedded Objects Within a Hypermedia Document.” The complaint sought a judgment of infringement together with costs and attorneys’ fees. In February 2016, Eolas filed an amended complaint seeking, among other things, an unspecified amount of damages. In February 2017, Eolas alleged in its damages report that in the event of a finding of liability Amazon could be subject to $ 130 to $ 250 million in damages. In April 2017, the case was transferred to the United States District Court for the Northern District of California. In May 2022, the district court granted summary judgment holding that the patent is invalid. In June 2022, Eolas filed a notice of appeal. We dispute the allegations of wrongdoing and intend to defend ourselves vigorously in this matter.

In May 2018, Rensselaer Polytechnic Institute and CF Dynamic Advances LLC filed a complaint against Amazon.com, Inc. in the United States District Court for the Northern District of New York. The complaint alleges, among other things, that “Alexa Voice Software and Alexa enabled devices” infringe U.S. Patent No. 7,177,798, entitled “Natural Language Interface Using Constrained Intermediate Dictionary of Results.” The complaint seeks an injunction, an unspecified amount of damages, enhanced damages , an ongoing royalty, interest, attorneys’ fees, and costs. We dispute the allegations of wrongdoing and intend to defend ourselves vigorously in this matter.

In December 2018, Kove IO, Inc. filed a complaint against Amazon Web Services, Inc. in the United States District Court for the Northern District of Illinois. The complaint alleges, among other things, that Amazon S3 and DynamoDB infringe U.S. Patent Nos. 7,814,170 and 7,103,640, both entitled “Network Distributed Tracking Wire Transfer Protocol”; and 7,233,978, entitled “Method and Apparatus for Managing Location Information in a Network Separate from the Data to Which the Location Information Pertains.” The complaint seeks an unspecified amount of damages, enhanced damages, attorneys’ fees, costs, interest, and injunctive relief. In March 2022, the case was stayed pending resolution of review petitions we filed with the United States Patent and Trademark Office. In November 2022, the stay was lifted. We dispute the allegations of wrongdoing and intend to defend ourselves vigorously in this matter.

</details>

# Context passages: implicit mentions, not classified

## Item 1 Business (blocks 93-94)

**Terms: search engine (search engines, web search)**

Competition

Our businesses encompass a large variety of product types, service offerings, and delivery channels. The worldwide marketplace in which we compete is evolving rapidly and intensely competitive, and we face a broad array of competitors from many different industry sectors around the world. Our current and potential competitors include: (1) physical, e-commerce, and omnichannel retailers, publishers, vendors, distributors, manufacturers, and producers of the products we offer and sell to consumers and businesses; (2) publishers, producers, and distributors of physical, digital, and interactive media of all types and all distribution channels; (3) web search engines, comparison shopping websites, social networks, web portals, and other online and app-based means of discovering, using, or acquiring goods and services, either directly or in collaboration with other retailers; (4) companies that provide e-commerce services, including website development and hosting, omnichannel sales, inventory and supply chain management, advertising, fulfillment, customer service, and payment processing; (5) companies that provide fulfillment and logistics services for themselves or for third parties, whether online or offline; (6) companies that provide information technology services or products, including on-premises or cloud-based infrastructure and other services; (7) companies that design, manufacture, market, or sell consumer electronics, telecommunication, and electronic devices; (8) companies that sell grocery products online and in physical stores; and (9) companies that provide advertising services, whether in digital or other formats. We believe that the principal competitive factors in our retail businesses include selection, price, and convenience, including fast and reliable fulfillment. Additional competitive factors for our seller and enterprise services include the quality, speed, and reliability of our services and tools, as well as customers’ ability and willingness to change business practices. Some of our current and potential competitors have greater resources, longer histories, more customers, greater brand recognition, and greater control over inputs critical to our various businesses. They may secure better terms from suppliers, adopt more aggressive pricing, pursue restrictive distribution agreements that restrict our access to supply, direct consumers to their own offerings instead of ours, lock-in potential customers with restrictive terms, and devote more resources to technology, infrastructure, fulfillment, and marketing. The Internet facilitates competitive entry and comparison shopping, which enhances the ability of new, smaller, or lesser-known businesses to compete against us. Each of our businesses is also subject to rapid change and the development of new business models and the entry of new and well-funded competitors. Other companies also may enter into business combinations or alliances that strengthen their competitive positions.

## Item 1A Risk Factors (blocks 156-158)

**Terms: data sovereignty (data localization)**

shorter payable and longer receivable cycles and the resultant negative impact on cash flow;

laws and regulations regarding privacy, data use, data protection, data security, data localization, network security, consumer protection, payments, advertising, and restrictions on pricing or discounts;

lower levels of use of the Internet;

## Item 1A Risk Factors (blocks 166-169)

**Terms: data center (data centers)**

As international physical, e-commerce, and omnichannel retail, cloud services, and other services grow, competition will intensify, including through adoption of evolving business models. Local companies may have a substantial competitive advantage because of their greater understanding of, and focus on, the local customer, as well as their more established local brand names. The inability to hire, train, retain, and manage sufficient required personnel may limit our international growth.

The People’s Republic of China (“PRC”) and India regulate Amazon’s and its affiliates’ businesses and operations in country through regulations and license requirements that may restrict (i) foreign investment in and operation of the Internet, IT infrastructure, data centers, retail, delivery, and other sectors, (ii) Internet content, and (iii) the sale of media and other products and services. For example, in order to meet local ownership, regulatory licensing, and cybersecurity requirements, we provide certain technology services in China through contractual relationships with third parties that hold PRC licenses to provide services. In India, the government restricts the ownership or control of Indian companies by foreign entities involved in online multi-brand retail trading activities. For www.amazon.in, we provide certain marketing tools and logistics services to third-party sellers to enable them to sell online and deliver to customers, and we hold indirect minority interests in entities that are third-party sellers on the www.amazon.in marketplace. Although we believe these structures and activities comply with existing laws, they involve unique risks, and the PRC and India may from time to time consider and implement additional changes in their regulatory, licensing, or other requirements that could impact these structures and activities. There are substantial uncertainties regarding the interpretation of PRC and Indian laws and regulations, and it is possible that these governments will

ultimately take a view contrary to ours. In addition, our Chinese and Indian businesses and operations may be unable to continue to operate if we or our affiliates are unable to access sufficient funding or, in China, enforce contractual relationships we or our affiliates have in place. Violation of any existing or future PRC, Indian, or other laws or regulations or changes in the interpretations of those laws and regulations could result in our businesses in those countries being subject to fines and other financial penalties, having licenses revoked, or being forced to restructure our operations or shut down entirely.

## Item 1A Risk Factors (blocks 212-215)

**Terms: data center (Data Centers, data centers), data centre capacity (data center capacity)**

disruptions from natural or human-caused disasters (including public health crises) or extreme weather (including as a result of climate change), geopolitical events and security issues (including terrorist attacks and armed hostilities), labor or trade disputes (including restrictive governmental actions impacting us and our third-party sellers in China or other foreign countries), and similar events.

We Face Risks Related to Successfully Optimizing and Operating Our Fulfillment Network and Data Centers

Failures to adequately predict customer demand or otherwise optimize and operate our fulfillment network and data centers successfully from time to time result in excess or insufficient fulfillment or data center capacity, service interruptions, increased costs, and impairment charges, any of which could materially harm our business. As we continue to add fulfillment and data center capability or add new businesses with different requirements, our fulfillment and data center networks become increasingly complex and operating them becomes more challenging. There can be no assurance that we will be able to operate our networks effectively.

In addition, failure to optimize inventory or staffing in our fulfillment network increases our net shipping cost by requiring long-zone or partial shipments. We and our co-sourcers may be unable to adequately staff our fulfillment network and customer service centers. For example, productivity across our fulfillment network currently is being affected by regional labor market and global supply chain constraints, which increase payroll costs and make it difficult to hire, train, and deploy a sufficient number of people to operate our fulfillment network as efficiently as we would like.

## Item 1A Risk Factors (blocks 225-227)

**Terms: data center (data centers)**

We depend on our senior management and other key personnel, including our President and CEO. We do not have “key person” life insurance policies. We also rely on other highly skilled personnel. Competition for qualified personnel in the industries in which we operate, as well as senior management, has historically been intense. For example, we experience significant competition in the technology industry, particularly for software engineers, computer scientists, and other technical staff. In addition, changes we make to our current and future work environments may not meet the needs or expectations of our employees or may be perceived as less favorable compared to other companies’ policies, which could negatively impact our ability to hire and retain qualified personnel. The loss of any of our executive officers or other key employees, the failure to successfully transition key roles, or the inability to hire, train, retain, and manage qualified personnel, could harm our business.

We also rely on a significant number of personnel to operate our stores, fulfillment network, and data centers and carry out our other operations. Failure to successfully hire, train, manage, and retain sufficient personnel to meet our needs can strain our operations, increase payroll and other costs, and harm our business and reputation. In addition, changes in laws and regulations applicable to employees, independent contractors, and temporary personnel could increase our payroll costs, decrease our operational flexibility, and negatively impact how we are able to staff our operations and supplement our workforce.

We are also subject to labor union efforts to organize groups of our employees from time to time. These organizational efforts, if successful, decrease our operational flexibility, which could adversely affect our operating efficiency. In addition, our response to any organizational efforts could be perceived negatively and harm our business and reputation.

## Item 1A Risk Factors (blocks 261-264)

**Terms: data sovereignty (data localization)**

We accept payments using a variety of methods, including credit card, debit card, credit accounts (including promotional financing), gift cards, direct debit from a customer’s bank account, consumer invoicing, physical bank check, and payment upon delivery. For existing and future payment options we offer to our customers, we currently are subject to, and may become subject to additional, regulations and compliance requirements (including obligations to implement enhanced authentication processes that could result in significant costs and reduce the ease of use of our payments products), as well as fraud. For certain payment methods, including credit and debit cards, we pay interchange and other fees, which may increase over time and raise our operating costs and lower profitability. We rely on third parties to provide certain Amazon-branded payment methods and payment processing services, including the processing of credit cards, debit cards, electronic checks, and promotional financing. In each case, it could disrupt our business if these companies become unwilling or unable to provide these services to us. We also offer co-branded credit card programs, which could adversely affect our operating results if renewed on less favorable terms or terminated. We are also subject to payment card association operating rules, including data security rules, certification requirements, and rules governing electronic funds transfers, which could change or be reinterpreted to make it difficult or impossible for us to comply. Failure to comply with these rules or requirements, as well as any breach, compromise, or failure to otherwise detect or prevent fraudulent activity involving our data security systems, could result in our being liable for card issuing banks’ costs, subject to fines and higher transaction fees, and loss of our ability to accept credit and debit card payments from our customers, process electronic funds transfers, or facilitate other types of online payments, and our business and operating results could be adversely affected.

In addition, we provide regulated services in certain jurisdictions because we enable customers to keep account balances with us and transfer money to third parties, and because we provide services to third parties to facilitate payments on their behalf. Jurisdictions subject us to requirements for licensing, regulatory inspection, bonding and capital maintenance, the use, handling, and segregation of transferred funds, consumer disclosures, maintaining or processing data, and authentication. We are also subject to or voluntarily comply with a number of other laws and regulations relating to payments, money laundering, international money transfers, privacy, data use, data protection, data security, data localization, network security, consumer

protection, and electronic fund transfers. If we were found to be in violation of applicable laws or regulations, we could be subject to additional requirements and civil and criminal penalties, or forced to cease providing certain services.

## Item 1A Risk Factors (blocks 281-282)

**Terms: data sovereignty (data localization)**

Claims, Litigation, Government Investigations, and Other Proceedings May Adversely Affect Our Business and Results of Operations

As an innovative company offering a wide range of consumer and business products and services around the world, we are regularly subject to actual and threatened claims, litigation, reviews, investigations, and other proceedings, including proceedings by governments and regulatory authorities, involving a wide range of issues, including patent and other intellectual property matters, taxes, labor and employment, competition and antitrust, privacy, data use, data protection, data security, data localization, network security, consumer protection, commercial disputes, goods and services offered by us and by third parties, and other matters. The number and scale of these proceedings have increased over time as our businesses have expanded in scope and geographic reach, as our products, services, and operations have become more complex and available to, and used by, more people, and as governments and regulatory authorities seek to regulate us on a pre-emptive basis. For example, we are litigating a number of matters alleging price fixing, monopolization, and consumer protection claims, including those brought by state attorneys general. Any of these types of proceedings can have an adverse effect on us because of legal costs, disruption of our operations, diversion of management resources, negative publicity, and other factors. The outcomes of these matters are inherently unpredictable and subject to significant uncertainties. Determining legal reserves or possible losses from such matters involves judgment and may not reflect the full range of uncertainties and unpredictable outcomes. Until the final resolution of such matters, we may be exposed to losses in excess of the amount recorded, and such amounts could be material. Should any of our estimates and assumptions change or prove to have been incorrect, it could have a material effect on our business, consolidated financial position, results of operations, or cash flows. In addition, it is possible that a resolution of one or more such proceedings, including as a result of a settlement, could involve licenses, sanctions, consent decrees, or orders requiring us to make substantial future payments, preventing us from offering certain products or services, requiring us to change our business practices in a manner materially adverse to our business, requiring development of non-infringing or otherwise altered products or technologies, damaging our reputation, or otherwise having a material effect on our operations.

## Item 1A Risk Factors (blocks 285-287)

**Terms: online classifieds (online marketplaces)**

We Face Additional Tax Liabilities and Collection Obligations

We are subject to a variety of taxes and tax collection obligations in the U.S. (federal and state) and numerous foreign jurisdictions. We may recognize additional tax expense and be subject to additional tax liabilities, including other liabilities for tax collection obligations due to changes in laws, regulations, administrative practices, principles, and interpretations related to tax, including changes to the global tax framework, competition, and other laws and accounting rules in various jurisdictions. Such changes could come about as a result of economic, political, and other conditions. An increasing number of jurisdictions are considering or have adopted laws or administrative practices that impose new tax measures, including revenue-based taxes, targeting online commerce and the remote selling of goods and services. These include new obligations to withhold or collect sales, consumption, value added, or other taxes on online marketplaces and remote sellers, or other requirements that may result in liability for third party obligations. For example, non-U.S. jurisdictions have proposed or enacted taxes on online advertising and marketplace service revenues. Proliferation of these or similar unilateral tax measures may continue unless broader international tax reform is implemented. Our results of operations and cash flows could be adversely affected by additional taxes imposed on us prospectively or retroactively or additional taxes or penalties resulting from the failure to comply with any collection obligations or failure to provide information about our customers, suppliers, and other third parties for tax reporting purposes to various government agencies. In some cases we also may not have sufficient notice to enable us to build systems and adopt processes to properly comply with new reporting or collection obligations by the effective date.

Our tax expense and liabilities are also affected by other factors, such as changes in our business operations, acquisitions, investments, entry into new businesses and geographies, intercompany transactions, the relative amount of our foreign earnings, losses incurred in jurisdictions for which we are not able to realize related tax benefits, the applicability of special or extraterritorial tax regimes, changes in foreign currency exchange rates, changes in our stock price, changes to our forecasts of income and loss and the mix of jurisdictions to which they relate, and changes in our tax assets and liabilities and their

## Item 2 Properties (blocks 302-305)

**Terms: data center (data centers)**

Physical stores (2) | 291 | — | International

Fulfillment, data centers, and other | 391,598 | 22,058 | North America

Fulfillment, data centers, and other | 148,146 | 12,613 | International

Total | 617,483 | 43,927

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 335-336)

**Terms: data center (data center)**

Forward-Looking Statements

This Annual Report on Form 10-K includes forward-looking statements within the meaning of the Private Securities Litigation Reform Act of 1995. All statements other than statements of historical fact, including statements regarding guidance, industry prospects, or future results of operations or financial position, made in this Annual Report on Form 10-K are forward-looking. We use words such as anticipates, believes, expects, future, intends, and similar expressions to identify forward-looking statements. Forward-looking statements reflect management’s current expectations and are inherently uncertain. Actual results and outcomes could differ materially for a variety of reasons, including, among others, fluctuations in foreign exchange rates, changes in global economic conditions and customer demand and spending, inflation, interest rates, regional labor market and global supply chain constraints, world events, the rate of growth of the Internet, online commerce, and cloud services, the amount that Amazon.com invests in new business opportunities and the timing of those investments, the mix of products and services sold to customers, the mix of net sales derived from products as compared with services, the extent to which we owe income or other taxes, competition, management of growth, potential fluctuations in operating results, international growth and expansion, the outcomes of claims, litigation, government investigations, and other proceedings, fulfillment, sortation, delivery, and data center optimization, risks of inventory management, variability in demand, the degree to which we enter into, maintain, and develop commercial agreements, proposed and completed acquisitions and strategic transactions, payments risks, and risks of fulfillment throughput and productivity. In addition, global economic and geopolitical conditions and additional or unforeseen circumstances, developments, or events may give rise to or amplify many of these risks. These risks and uncertainties, as well as other risks and uncertainties that could cause our actual results or outcomes to differ significantly from management’s expectations, are described in greater detail in Item 1A of Part I, “Risk Factors.”

## Item 7 Management’s Discussion and Analysis of Financial Condition and Results of Operations (blocks 461-463)

**Terms: autonomous (autonomous), autonomous vehicle (autonomous vehicles), data center (data center)**

Technology and Content

Technology and content costs include payroll and related expenses for employees involved in the research and development of new and existing products and services, development, design, and maintenance of our stores, curation and display of products and services made available in our online stores, and infrastructure costs. Infrastructure costs include servers, networking equipment, and data center related depreciation and amortization, rent, utilities, and other expenses necessary to support AWS and other Amazon businesses. Collectively, these costs reflect the investments we make in order to offer a wide variety of products and services to our customers, including expenditures related to initiatives to build and deploy innovative and efficient software and electronic devices and the development of a satellite network for global broadband service and autonomous vehicles for ride-hailing services.

We seek to invest efficiently in numerous areas of technology and content so we may continue to enhance the customer experience and improve our process efficiency through rapid technology developments, while operating at an ever increasing scale. Our technology and content investment and capital spending projects often support a variety of product and service offerings due to geographic expansion and the cross-functionality of our systems and operations. We expect spending in technology and content to increase over time as we continue to add employees and technology infrastructure. These costs are allocated to segments based on usage. The increase in technology and content costs in absolute dollars in 2022, compared to the prior year, is primarily due to increased payroll and related costs associated with technical teams responsible for expanding our existing products and services and initiatives to introduce new products and service offerings, and an increase in spending on technology infrastructure, partially offset by a reduction in depreciation and amortization expense from our change in the estimated useful lives of our servers and networking equipment. See Item 8 of Part II, “Financial Statements and Supplementary Data — Note 1 — Description of Business, Accounting Policies, and Supplemental Disclosures — Use of Estimates” for additional information on the change in estimated useful lives of our servers and networking equipment.

## Item 8 Financial Statements and Supplementary Data (blocks 755-757)

**Terms: data center (data center)**

Use of Estimates

The preparation of financial statements in conformity with GAAP requires estimates and assumptions that affect the reported amounts of assets and liabilities, revenues and expenses, and related disclosures of contingent liabilities in the consolidated financial statements and accompanying notes. Estimates are used for, but not limited to, income taxes, useful lives of equipment, commitments and contingencies, valuation of acquired intangibles and goodwill, stock-based compensation forfeiture rates, vendor funding, inventory valuation, collectability of receivables, impairment of property and equipment and operating leases, valuation and impairment of investments, self-insurance liabilities, and viewing patterns of capitalized video content. Actual results could differ materially from these estimates. We review the useful lives of equipment on an ongoing basis, and effective January 1, 2022 we changed our estimate of the useful lives for our servers from four years to five years and for our networking equipment from five years to six years . The longer useful lives are due to continuous improvements in our hardware, software, and data center designs. The effect of this change in estimate for the year ended December 31, 2022, based on servers and networking equipment that were included in “Property and equipment, net” as of December 31, 2021 and those acquired during the year ended December 31, 2022, was a reduction in depreciation and amortization expense of $ 3.6 billion and a benefit to net loss of $ 2.8 billion, or $ 0.28 per basic share and $ 0.28 per diluted share.

For the year ended December 31, 2022, we recorded approximately $ 1.1 billion, of which $ 720 million was recorded in the fourth quarter, of impairments of property and equipment and operating leases primarily related to physical stores. These charges were recorded in “Other operating expense (income), net” on our consolidated statements of operations and primarily impacted our North America segment. For the year ended December 31, 2022, we also recorded expenses of approximately

## Item 8 Financial Statements and Supplementary Data (blocks 800-801)

**Terms: autonomous (autonomous), autonomous vehicle (autonomous vehicles), data center (data center)**

Technology and Content

Technology and content costs include payroll and related expenses for employees involved in the research and development of new and existing products and services, development, design, and maintenance of our stores, curation and display of products and services made available in our online stores, and infrastructure costs. Infrastructure costs include servers, networking equipment, and data center related depreciation and amortization, rent, utilities, and other expenses necessary to support AWS and other Amazon businesses. Collectively, these costs reflect the investments we make in order to offer a wide variety of products and services to our customers, including expenditures related to initiatives to build and deploy innovative and efficient software and electronic devices and the development of a satellite network for global broadband service and autonomous vehicles for ride-hailing services. Technology and content costs are generally expensed as incurred.

## Item 8 Financial Statements and Supplementary Data (blocks 975-977)

**Terms: data center (data center)**

Note 4 — LEASES

We have entered into non-cancellable operating and finance leases for fulfillment, delivery, office, data center, physical store, and sortation facilities as well as server and networking equipment, vehicles, and aircraft. Gross assets acquired under finance leases, inclusive of those where title transfers at the end of the lease, are recorded in “ Property and equipment, net ” and were $ 72.2 billion and $ 68.0 billion as of December 31, 2021 and 2022. Accumulated amortization associated with finance leases was $ 43.4 billion and $ 45.2 billion as of December 31, 2021 and 2022.

Lease cost recognized in our consolidated statements of operations is summarized as follows (in millions):

## Item 8 Financial Statements and Supplementary Data (blocks 1103-1105)

**Terms: data center (data center)**

_

(1) Includes non-cancellable financing obligations for fulfillment, sortation, and data center facilities. Excluding interest, current financing obligations of $ 196 million and $ 266 million are recorded within “Accrued expenses and other” and $ 6.2 billion and $ 6.7 billion are recorded within “Other long-term liabilities” as of December 31, 2021 and 2022. The weighted-average remaining term of the financing obligations was 18.8 years and 17.9 years and the weighted-average imputed interest rate was 3.2 % and 3.1 % as of December 31, 2021 and 2022.

(2) Includes unconditional purchase obligations related to long-term agreements to acquire and license digital media content that are not reflected on the consolidated balance sheets and certain products offered in our Whole Foods Market stores. For those digital media content agreements with variable terms, we do not estimate the total obligation beyond any minimum quantities and/or pricing as of the reporting date. Purchase obligations associated with renewal provisions solely at the option of the content provider are included to the extent such commitments are fixed or a minimum amount is specified.
