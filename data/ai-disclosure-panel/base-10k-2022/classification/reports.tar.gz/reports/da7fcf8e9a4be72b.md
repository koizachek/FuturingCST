# US BANCORP \DE\ | 10-K | fiscal year 2022

- Report length: 19,816 words
- Direct AI mentions (classified): 0, of which about AI: 0, false candidates: 0, flagged for review: 0
- Context passages (not classified): 2; groups: workforce_society (1), industry (1)
- Frames: none
- Roles: none
- Risk types: none
- MIT subdomains: none
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: none
- Substantiveness: none
- Disclosure traits: none
- Trait activation rate: n/a
- Sections: none
- Named entities: none

# Context passages: implicit mentions, not classified

## Item 1 Business (blocks 102-104)

**Terms: upskilling (upskilling)**

Human Capital

The Company’s success depends, in large part, on its ability to attract, develop and retain skilled employees. The Company recognizes that supporting, engaging and continuously upskilling its workforce is key to meeting evolving corporate and customer needs. To further those efforts, the Company is dedicated to fostering a diverse, equitable and inclusive work environment; providing pay that is competitive and fair, as well as other benefits and programs that promote wellness; and supporting employees’ professional development through programs that promote engagement, learning and productivity. As of December 31, 2022, the Company employed a total of 78,192 employees globally, including employees from the acquisition of MUB on December 1, 2022.

Diversity, Equity and Inclusion The Company continues to expand its talent pipeline to increase the representation of women at leadership levels and people of color at all levels, including at the executive and senior management level. The Company’s hiring program includes the inclusion of at least one woman or one person of color on interview slates for all roles at the Company. In addition, the Company’s High Impact Development Program focuses on growing its leadership pipeline of women and people of color. This program creates increased visibility and connections with executive leadership, meaningful learning and development opportunities, robust action plans and cohort networking/peer support. The Company also provides inclusive leadership learning journeys designed to coach and develop its leaders in driving employee and team performance through inclusive behaviors and best practices.

## Item 1 Business (blocks 186-188)

**Terms: know your customer (customer due diligence)**

“BSA”), the Money Laundering Control Act, the USA PATRIOT Act (collectively, “AML laws”), and implementing regulations for the International Emergency Economic Powers Act and the Trading with the Enemy Act, as administered by the United States Treasury Department’s Office of Foreign Assets Control (“sanctions laws”).

As implemented by federal banking and securities regulators and the Department of the Treasury, AML laws obligate depository institutions and broker-dealers to verify their customers’ identity, verify the identity of beneficial owners of legal entity customers, conduct customer due diligence, report on suspicious activity, file reports of certain transactions in currency, and conduct enhanced due diligence on certain accounts. Sanctions laws prohibit United States persons and certain foreign affiliates from engaging in any transaction with a restricted person or restricted country. Depository institutions and broker-dealers are required by their respective federal regulators to maintain policies and procedures in order to ensure compliance with the above obligations. Federal regulators regularly examine BSA/Anti-Money Laundering (“AML”) and sanctions compliance programs to ensure their adequacy and effectiveness, and the frequency and extent of such examinations and related remedial actions have been increasing.

In January 2021, the Anti-Money Laundering Act of 2020 (“AMLA”), which amends the BSA, was enacted. Among other things, the AMLA codified a risk-based approach to anti-money laundering compliance for financial institutions; required the development of standards by the U.S. Department of the Treasury for evaluating technology and internal processes for BSA compliance; and expanded enforcement- and investigation-related authority, including a significant expansion in the available sanctions for certain BSA violations. Many of the statutory provisions in the AMLA will require additional rulemakings, reports and other measures, and the impact of the AMLA will depend on, among other things, rulemaking and implementation guidance. In June 2021, the Financial Crimes Enforcement Network, a bureau of the U.S. Department of the Treasury, issued the priorities for anti-money laundering and countering the financing of terrorism policy required under the AMLA. The priorities include corruption, cybercrime, terrorist financing, fraud, transnational crime, drug trafficking, human trafficking and proliferation financing.
