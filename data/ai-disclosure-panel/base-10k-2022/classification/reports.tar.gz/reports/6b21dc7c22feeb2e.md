# Palo Alto Networks Inc | 10-K | fiscal year 2022

- Report length: 65,654 words
- Direct AI mentions (classified): 13, of which about AI: 13, false candidates: 0, flagged for review: 0
- Context passages (not classified): 9; groups: compute_infrastructure (4), industry (4), agents (1)
- Frames: business (11), risk_factor (2)
- Roles: offering (11), risk (2)
- Risk types: market_demand (1), strategic_competitive (1)
- MIT subdomains: other (2)
- Adoption stage: none
- Business functions: none
- Governance responses: none
- Kinds of AI: traditional_ml (10), unspecified (3)
- Substantiveness: specific (10), generic (3)
- Disclosure traits: hedging (2)
- Trait activation rate: 0.154 (boilerplate (0.0), hedging (0.154), externalisation (0.0), vagueness (0.0), safe_harbour (0.0))
- Sections: Item 1 (6), Item 7 (3), Item 1A (2), Item 8 (2)
- Named entities: Zingbox, Inc.

## Item 1 BUSINESS (blocks 102-106)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> Our cybersecurity platforms and services help secure enterprise users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by industry leading artificial intelligence and automation.

> Our network security platform, which includes our ML-Powered Next-Generation Firewalls, available in a number of form factors, including physical, virtual, and containerized appliances, as well as a cloud-delivered service, has been recognized as a leader in the industry.

<details><summary>Passage</summary>

Palo Alto Networks, Inc. is a global cybersecurity provider with a vision of a world where each day is safer and more secure than the one before. We were incorporated in 2005 and are headquartered in Santa Clara, California.

We empower enterprises, organizations, service providers, and government entities to protect themselves against today’s most sophisticated cyber threats. Our cybersecurity platforms and services help secure enterprise users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by industry leading artificial intelligence and automation. We are a leading provider of zero trust solutions, starting with next-generation zero trust network access to secure today’s remote hybrid workforces and extending to securing all users, applications and infrastructure with zero trust principles. Our security solutions are designed to reduce customers’ total cost of ownership by improving operational efficiency and eliminating the need for siloed point products. Our company focuses on delivering value in five fundamental areas:

Network Security:

• Our network security platform, which includes our ML-Powered Next-Generation Firewalls, available in a number of form factors, including physical, virtual, and containerized appliances, as well as a cloud-delivered service, has been recognized as a leader in the industry. Our network security platform also includes our Cloud-Delivered Security Services, such as Threat Prevention, Advanced Threat Prevention, WildFire ® , Advanced URL Filtering, DNS Security, IoT Security, GlobalProtect™, SD-WAN, Enterprise Data Loss Prevention (“Enterprise DLP”), AIOps, SaaS Security API, and SaaS Security Inline. Through these add-on security services, our customers are able to secure their content, applications, users, and devices across our network security platform as well as the Prisma ® and Cortex ® product lines. Panorama™, our network security management solution, available as hardware or virtual machine, can centrally manage our network security platform irrespective of form factor, location, or scale.

Secure Access Service Edge:

</details>

## Item 1 BUSINESS (blocks 117-119)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> Our ML-Powered Next Generation Firewalls embed machine learning in the core of the firewall and employ inline deep learning in the cloud, empowering our customers to stop zero-day threats in real time, see and secure their entire enterprise including IoT, and reduce errors with automatic policy recommendations.

<details><summary>Passage</summary>

Products

Firewall Appliances and Software . Our ML-Powered Next Generation Firewalls embed machine learning in the core of the firewall and employ inline deep learning in the cloud, empowering our customers to stop zero-day threats in real time, see and secure their entire enterprise including IoT, and reduce errors with automatic policy recommendations. All of our firewall appliances and software incorporate our PAN-OS ® operating system and come with the same rich set of features ensuring consistent operation across our entire product line. The content, applications, users, and devices—the elements that run a business—become integral components of an enterprise’s security policy via our Content-ID™, App-ID™, User-ID™, and Device-ID technology. In addition to these components, key features include site-to-site virtual private network (“VPN”), remote access Secure Sockets Layer (“SSL”) VPN, and Quality-of-Service (“QoS”). Our appliances and software are designed for different performance requirements throughout an organization and are classified based on throughput, ranging from our PA-410, which is designed for small organizations and branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. Our firewall appliances come in a physical form factor, a containerized form factor, called CN-Series, as well as a virtual form factor, called VM-Series, that is available for virtualization and cloud environments from companies such as VMware, Inc. (“VMware”), Microsoft Corporation (“Microsoft”), Amazon.com, Inc. (“Amazon”), and Google, Inc. (“Google”), and in Kernel-based Virtual Machine (“KVM”)/OpenStack environments. We also offer Cloud NGFW, a managed next-generation firewall (“NGFW”) offering, to secure customers’ applications on Amazon Web Services (“AWS”).

Panorama. Panorama is our centralized security management solution for global control of all of our firewall appliances and software deployed on a customer’s network, as well as in their instances in public or private cloud environments. Panorama can be deployed as a virtual appliance or a physical appliance. Panorama is used for centralized policy management, device management, software licensing and updates, centralized logging and reporting, and log storage. Panorama controls the security, network address translation (“NAT”), QoS, policy-based forwarding, decryption, application override, captive portal, and distributed denial of service/denial of service (“DDoS/DoS”) protection aspects of the appliances, software, virtual and containerized systems under management. Panorama centrally manages device software and associated updates, including SSL-VPN clients, SD-WAN, dynamic content updates, and software licenses. Panorama offers network security monitoring through the ability to view logs and run reports from all managed appliances and software in one location without the need to forward the logs and reliably expands log storage for long-term event investigation and analysis.

</details>

## Item 1 BUSINESS (blocks 121-140)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> Advanced Threat Prevention . This cloud-delivered security service builds on all of the capabilities of Threat Prevention, adding the industry’s first Inline Deep Learning protection engine for Command-and-Control (“C2”).

> A machine learning module derived from the cloud sandbox environment is now delivered inline on the ML-Powered Next-Generation Firewalls to identify the majority of unknown threats without cloud connectivity.

> Advanced URL Filtering . This cloud-delivered security service offers the industry’s first Inline Deep Learning powered web protection engine.

<details><summary>Passage</summary>

Subscriptions

We offer a number of subscriptions as part of our portfolio. Of these subscription offerings, cloud-delivered security services like Threat Prevention, Advanced Threat Prevention, WildFire, Advanced URL Filtering, DNS Security, IoT Security, SaaS Security Inline, GlobalProtect, SD-WAN, Enterprise DLP and AIOps are sold as options to our firewall appliances and software, whereas Prisma Cloud, Prisma Access, Prisma SD-WAN, SaaS Security API, Cortex XDR, Cortex XSOAR, Cortex Xpanse and Cortex Data Lake are sold on a per-user, per-endpoint, or capacity-based basis. Our subscription offerings include:

Cloud-delivered Security Services:

Threat Prevention. This cloud-delivered security service provides intrusion detection and prevention capabilities and blocks vulnerability exploits, viruses, spyware, buffer overflows, denial-of-service attacks, and port scans from compromising and damaging enterprise information resources. It includes mechanisms such as protocol decoder-based analysis, protocol anomaly-based protection, stateful pattern matching, statistical anomaly detection, heuristic-based analysis, custom vulnerability and spyware “phone home” signatures, and workflows to manage popular open-source signature formats to extend our leading coverage.

Advanced Threat Prevention . This cloud-delivered security service builds on all of the capabilities of Threat Prevention, adding the industry’s first Inline Deep Learning protection engine for Command-and-Control (“C2”). It delivers real-time detection and prevention of unknown, evasive, and targeted C2 communications over HTTP, unknown-TCP, unknown-UDP and encrypted over SSL. Advanced Threat Prevention is the first offering to protect patient zero from unknown command and control in real-time.

WildFire. This cloud-delivered security service (which can also be delivered as an appliance) provides protection against targeted malware and advanced persistent threats and provides a near real-time analysis engine for detecting previously unseen malware while resisting attacker evasion techniques. The core component of this subscription goes beyond traditional sandbox environments and can operate on an end-customers’ local environment, private cloud or our public cloud. WildFire combines dynamic and static analysis, recursive analysis, and a custom-built analysis environment with network traffic profiling and fileless attack detection to discover even the most sophisticated and evasive threats. A machine learning module derived from the cloud sandbox environment is now delivered inline on the ML-Powered Next-Generation Firewalls to identify the majority of unknown threats without cloud connectivity. Once identified, whether in the cloud or inline, preventive measures are automatically generated and delivered in seconds or less across networks, clouds, endpoints, or wherever WildFire-enabled sensors are deployed. By providing this as a cloud-based subscription, all of our end-customers benefit from malware found on any of our end-customers’ networks.

Advanced URL Filtering . This cloud-delivered security service offers the industry’s first Inline Deep Learning powered web protection engine. It delivers real-time detection and prevention of unknown, evasive, and targeted web-based threats such as phishing, malware, and command-and-control. While many vendors use machine learning to categorize web content or prevent malware downloads, Advanced URL Filtering is the industry’s first inline web protection engine capable of detecting never-before-seen web-based threats and preventing them in real-time. In addition, it includes a cloud-based URL filtering database which consists of millions of URLs across many categories and is designed to analyze web traffic and prevent web-based threats such as phishing, malware, and command-and-control.

DNS Security. This cloud-delivered security service uses machine learning to proactively block malicious domains and stops attacks in progress. Unlike other solutions, it does not require endpoint routing configurations to be maintained and therefore cannot be bypassed. It allows firewalls access to DNS signatures that are generated using advanced predictive analysis, machine learning, and malicious domain data from a growing threat intelligence sharing community of which we are a part. Expanded categorization of DNS traffic and comprehensive analytics allow deep insights into threats, empowering security personnel with the context to optimize their security posture. It offers comprehensive DNS attack coverage and includes industry-first protections against multiple emerging DNS-based network attacks.

IoT Security. IoT Security is a cloud-delivered security service on our ML-Powered Next-Generation Firewalls with backward compatibility to older versions of PAN-OS. Using machine learning and our App-ID technology, it can accurately identify and classify various IoT and operational technology (“OT”) devices, including never-been-seen-before devices, mission critical OT devices and unmanaged legacy systems. It uses machine learning to baseline normal behavior, identify anomalous activity, assess risk, and provide policy recommendations to allow trusted behavior with a new Device-ID policy construct on our ML-Powered Next-Generation Firewalls. Our existing subscription-based security services have also been enhanced with IoT context to prevent threats on various devices, including IoT and OT devices.

SaaS Security API. SaaS Security API (formerly Prisma SaaS) is a multi-mode, cloud access security broker service that helps govern sanctioned SaaS application usage across all users and helps prevent breaches and non-compliance. Specifically, the service enables the discovery and classification of data stored across the supported SaaS applications, protects sensitive data from accidental exposure, identifies and protects against known and unknown malware, and performs user activity monitoring to identify potential misuse or data exfiltration. It delivers complete visibility and granular enforcement across all user, folder, and file activity within sanctioned SaaS applications, and can be combined with SaaS Security Inline for a complete integrated cloud access security broker (“CASB”).

SaaS Security Inline. SaaS Security Inline is a recent cloud-delivered security service on our ML-Powered Next Generation Firewalls that adds an inline service to automatically gain visibility and control over the tens of thousands of known and new sanctioned, unsanctioned and tolerated SaaS applications in use within organizations today. It provides enterprise data protection and compliance across all SaaS applications and prevents cloud threats in real time with best-in-class security. The solution is easy to deploy being natively integrated on our range of ML-Powered Next-Generation Firewalls, eliminating the architectural complexity of traditional CASB products, while offering low total cost of ownership. It can be combined with SaaS Security API as a complete integrated CASB.

GlobalProtect . This appliance-based subscription provides protection for users of both traditional laptop and mobile devices. It expands the boundaries of the end-users’ physical network, effectively establishing a logical perimeter that encompasses remote laptop and mobile device users irrespective of their location. When a remote user logs into the device, GlobalProtect automatically determines the closest gateway available to the roaming device and establishes a secure connection. Regardless of the operating systems, laptops, tablets and phones will stay connected to the corporate network when they are on a network of any kind and, as a result, are protected as if they never left the corporate campus. GlobalProtect ensures that the same secure application enablement policies that protect users at the corporate site are enforced for all users, independent of their location.

SD-WAN. Our SD-WAN subscription is integrated with PAN-OS, so that our end-customers can get the security features of our PAN-OS ML-Powered Next-Generation Firewall together with SD-WAN functionality. The SD-WAN overlay supports dynamic, intelligent path selection based on the applications, services and conditions of the links that each application or service is allowed to use, allowing applications to be prioritized based on criteria such as whether the application is mission-critical, latency-sensitive, or meets certain health criteria.

Enterprise DLP. This cloud-delivered security service provides consistent, reliable protection of sensitive data, such as personally identifiable information (“PII”) and intellectual property, for all traffic types, applications, and users. Native integration with our products makes it simple to deploy, and advanced machine learning minimizes management complexity. Enterprise DLP allows organizations to consistently discover, classify, monitor, and protect sensitive data, wherever it may reside. It helps minimize the risk of a data breach both on-premises and in the cloud—such as in Office/Microsoft 365™, Salesforce ® , and Box—and assists in meeting stringent data privacy and compliance regulations, including GDPR, CCPA, PCI DSS, HIPAA, and others.

AIOps for NGFW: AIOps for NGFW is a new cloud-delivered security service available on ML-Powered Next-Generation Firewalls and Panorama that run on PAN‑OS 10.0 and above, and is available in both free and licensed premium versions. AIOps for NGFW redefines firewall operational experience by empowering security teams to proactively strengthen security posture and resolve firewall disruptions. AIOps for NGFW provides continuous best practice recommendations powered by machine learning (“ML”) based on industry standards, security policy context, and advanced telemetry data collected from all Palo Alto Networks ® firewalls to improve security posture. It also intelligently predicts firewall health, performance, and capacity problems up to seven days in advance and provides actionable insights to resolve the predicted disruptions.

Cloud Security:

Prisma Cloud. Prisma Cloud is a comprehensive CNAPP, securing both cloud native and lift-and-shift applications across hybrid- and multi-cloud environments. With broad security and compliance coverage and a flexible agentless, as well as agent-based, architecture, Prisma Cloud protects cloud-native applications spanning hosts, containers, serverless architectures and other platform as a service (“PaaS”) offerings across cloud platforms. It dynamically discovers public cloud resources as they are deployed and correlates cloud data services (resource configurations, flow logs, audit logs, host and container logs, etc.) to provide timely security and compliance insights for cloud applications. The platform uses machine learning to profile user, workload, and application behaviors to identify and prevent advanced threats.

For security and development and operations teams, Prisma Cloud removes the impedance mismatch between security and cloud-driven agility by integrating with continuous integration and continuous development (“CI/CD”) tool chains to provide full lifecycle vulnerability management, compliance, infrastructure-as-code scanning, and runtime defense. With a comprehensive library of compliance frameworks, it vastly simplifies the task of maintaining compliance. Prisma Cloud accomplishes this through deep context-sharing that spans infrastructure, PaaS, users, development platforms, data, and application workloads. Seamless integration with security orchestration tools ensures rapid remediation of vulnerabilities and security issues.

</details>

## Item 1 BUSINESS (blocks 143-144)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> Unlike legacy SD-WAN solutions that introduce cost and complexity, our Prisma SD-WAN ensures an excellent user experience with application-defined policies and simplifies network and security operations using machine learning and automation.

<details><summary>Passage</summary>

Prisma Access . Prisma Access is a cloud-delivered security offering that helps organizations deliver consistent security to remote networks and mobile users. Located in more than 100 locations around the world, Prisma Access consistently inspects all traffic across all ports and provides bidirectional networking to enable branch-to-branch and branch-to-headquarter traffic. Prisma Access consolidates more point-products into a single converged cloud-delivered offering than any competing solution, transforming network security and allowing organizations to enable secure hybrid workforces. Unlike competing solutions, only Prisma Access protects all application traffic with complete, best-in-class security while ensuring an exceptional user experience with industry-leading service-level agreements (“SLA”s).

Prisma SD-WAN . Our Prisma SD-WAN solution is a next-generation SD-WAN solution that makes the secure cloud-delivered branch possible. Prisma SD-WAN enables organizations to replace traditional Multiprotocol Label Switching (“MPLS”) based WAN architectures with affordable broadband and internet transport types that promote improved bandwidth availability, redundancy and performance at a reduced cost. Prisma SD-WAN leverages real-time application performance SLAs and visibility to control and intelligently steer application traffic to deliver an exceptional user experience. Unlike legacy SD-WAN solutions that introduce cost and complexity, our Prisma SD-WAN ensures an excellent user experience with application-defined policies and simplifies network and security operations using machine learning and automation.

</details>

## Item 1 BUSINESS (blocks 146-150)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> This cloud-based subscription enables organizations to collect telemetry from endpoint, network, identity and cloud data sources and apply advanced analytics and machine learning across all data, to quickly find and stop targeted attacks, insider abuse, and compromised endpoints.

> It learns from the real-life analyst interactions and past investigations to help SOC teams with analyst assignment suggestions, playbook enhancements, and best next steps for investigations.

<details><summary>Passage</summary>

Security Operations:

Cortex XDR. This cloud-based subscription enables organizations to collect telemetry from endpoint, network, identity and cloud data sources and apply advanced analytics and machine learning across all data, to quickly find and stop targeted attacks, insider abuse, and compromised endpoints. Cortex XDR has two product tiers: XDR Prevent and XDR Pro. XDR Prevent delivers enterprise-class endpoint security focused on preventing attacks. XDR Pro extends endpoint detection and response (“EDR”) to include cross-data analytics, including network, cloud and identity data. These capabilities build on each other such that a customer can start with XDR Prevent, then upgrade to XDR Pro for endpoints or XDR Pro for cross-data analytics. Going beyond EDR, Cortex XDR detects the most complex threats using analytics across key data sources and reveals the root cause, which can significantly reduce investigation time as compared to siloed tools and manual processes.

Cortex XSOAR. Available as a cloud-based subscription or an on-premises appliance, Cortex XSOAR is a comprehensive SOAR offering that unifies playbook automation, case management, real-time collaboration, and threat intelligence management to serve security teams across the incident lifecycle. With Cortex XSOAR, security teams can standardize processes, automate repeatable tasks and manage incidents across their security product stack to improve response time and analyst productivity. It learns from the real-life analyst interactions and past investigations to help SOC teams with analyst assignment suggestions, playbook enhancements, and best next steps for investigations. Many of our customers see significantly faster SOC response times and a significant reduction in SOC alerts which require human intervention.

Cortex Xpanse. This cloud-based subscription provides attack surface management, which is the ability for an organization to identify what an attacker would see amongst all of its sanctioned and unsanctioned Internet-facing assets. In addition, Cortex Xpanse detects risky or out-of-policy communications between Internet-connected assets that can be exploited for data breaches or ransomware attacks. Cortex Xpanse continuously identifies Internet assets, risky services or misconfigurations in third parties to help secure a supply chain or identify risks for mergers and acquisitions due diligence. Finally, compliance teams use Cortex Xpanse to improve their audit processes and stay in compliance by assessing their access controls against regulatory frameworks.

Cortex Data Lake. This cloud-based subscription allows our customers to collect and analyze large amounts of context-rich network security data. This includes a collection of enhanced network logs generated by our security offerings, including those of our ML-Powered Next-Generation Firewalls and Prisma Access subscription, eliminating the need to plan for local data storage.

</details>

## Item 1 BUSINESS (blocks 157-159)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> During fiscal 2022, we introduced several new offerings, including: Prisma Cloud 3.0, Prisma Access 3.0, AIOps for NGFW, PAN-OS 10.2, and Cloud NGFW for AWS.

<details><summary>Passage</summary>

Our research and development efforts are focused on developing new hardware and software and on enhancing and improving our existing product and subscription offerings. We believe that hardware and software are both critical to expanding our leadership in the enterprise security industry. Our engineering team has deep networking, endpoint, and security expertise and works closely with end-customers to identify their current and future needs. In addition to our focus on hardware and software, our research and development team is focused on research into applications and threats, which allows us to respond to the rapidly changing application and threat landscape. We supplement our own research and development efforts with technologies and products that we license from third parties. We test our products thoroughly to certify and ensure interoperability with third-party hardware and software products.

We believe that innovation and timely development of new features and products is essential to meeting the needs of our end-customers and improving our competitive position. During fiscal 2022, we introduced several new offerings, including: Prisma Cloud 3.0, Prisma Access 3.0, AIOps for NGFW, PAN-OS 10.2, and Cloud NGFW for AWS. Additionally, we acquired productive investments that fit well within our long-term strategy.

We plan to continue to significantly invest in our research and development efforts as we evolve and extend the capabilities of our portfolio.

</details>

## Item 1A RISK FACTORS (blocks 308-309)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: market_demand | mit: other | kinds: unspecified | substantiveness: generic | traits: hedging**

> Our future success depends, in part, on our ability to expand the deployment of our portfolio with existing end-customers and create demand for our new offerings, including cloud security, AI, and analytics offerings.

> If our efforts to sell additional products and subscriptions to our end-customers are not successful or our end-customers do not renew their subscription and support agreements or renew them on less favorable terms, our revenues may grow more slowly than expected or decline.

<details><summary>Passage</summary>

If we are unable to sell new and additional product, subscription, and support offerings to our end-customers, our future revenue and operating results will be harmed.

Our future success depends, in part, on our ability to expand the deployment of our portfolio with existing end-customers and create demand for our new offerings, including cloud security, AI, and analytics offerings. This may require increasingly sophisticated and costly sales efforts that may not result in additional sales. The rate at which our end-customers purchase additional products, subscriptions, and support depends on a number of factors, including the perceived need for additional security products, including subscription and support offerings, as well as general economic conditions. Further, existing end-customers have no contractual obligation to and may not renew their subscription and support contracts after the completion of their initial contract period. Our end-customers’ renewal rates may decline or fluctuate as a result of a number of factors, including their level of satisfaction with our subscriptions and our support offerings, the frequency and severity of subscription outages, our product uptime or latency, and the pricing of our, or competing, subscriptions. Additionally, our end-customers may renew their subscription and support agreements for shorter contract lengths or on other terms that are less economically beneficial to us. We also cannot be certain that our end-customers will renew their subscription and support agreements. If our efforts to sell additional products and subscriptions to our end-customers are not successful or our end-customers do not renew their subscription and support agreements or renew them on less favorable terms, our revenues may grow more slowly than expected or decline.

</details>

## Item 1A RISK FACTORS (blocks 380-381)

**AI reference: explicit | frame: risk_factor | roles: risk | risk: strategic_competitive | mit: other | kinds: unspecified | substantiveness: generic | traits: hedging**

> Additionally, we must commit significant resources to developing new features and new cloud security, AI/analytics and other offerings before knowing whether our investments will result in products, subscriptions, and features the market will accept.

> There can be no assurance that we will successfully identify opportunities for new products and subscriptions, develop and bring new products and subscriptions to market in a timely manner, or achieve market acceptance of our products and subscriptions, including our product enhancement efforts in connection with COVID-19, or that products, subscriptions, and technologies developed by others will not render our products, subscriptions, or technologies obsolete or noncompetitive.

<details><summary>Passage</summary>

The technology in our portfolio is especially complex because it needs to effectively identify and respond to new and increasingly sophisticated methods of attack, while minimizing the impact on network performance. Additionally, some of our new features and related enhancements may require us to develop new hardware architectures that involve complex, expensive, and time-consuming research and development processes. The development of our portfolio is difficult and the timetable for commercial release and availability is uncertain as there can be long time periods between releases and availability of new features. If we experience unanticipated delays in the availability of new products, features and subscriptions, and fail to meet customer expectations for such availability, our competitive position and business prospects will be harmed.

Additionally, we must commit significant resources to developing new features and new cloud security, AI/analytics and other offerings before knowing whether our investments will result in products, subscriptions, and features the market will accept. The success of new features depends on several factors, including appropriate new product definition, differentiation of new products, subscriptions, and features from those of our competitors, and market acceptance of these products, services and features. Moreover, successful new product introduction and transition depends on a number of factors, including our ability to manage the risks associated with new product production ramp-up issues, the availability of application software for new products, the effective management of purchase commitments and inventory, the availability of products in appropriate quantities and costs to meet anticipated demand, and the risk that new products may have quality or other defects or deficiencies, especially in the early stages of introduction. There can be no assurance that we will successfully identify opportunities for new products and subscriptions, develop and bring new products and subscriptions to market in a timely manner, or achieve market acceptance of our products and subscriptions, including our product enhancement efforts in connection with COVID-19, or that products, subscriptions, and technologies developed by others will not render our products, subscriptions, or technologies obsolete or noncompetitive.

</details>

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 612-617)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> Our cybersecurity platforms and services help secure enterprise users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by industry leading artificial intelligence and automation.

> Our network security platform, which includes our ML-Powered Next-Generation Firewalls, available in a number of form factors, including physical, virtual, and containerized appliances, as well as a cloud-delivered service, has been a leader in the industry for ten consecutive years.

<details><summary>Passage</summary>

Overview

We empower enterprises, organizations, service providers, and government entities to protect themselves against today’s most sophisticated cyber threats. Our cybersecurity platforms and services help secure enterprise users, networks, clouds, and endpoints by delivering comprehensive cybersecurity backed by industry leading artificial intelligence and automation. We are a leading provider of zero trust solutions that start with the next-generation of zero trust network access to secure remote workforces and extend into securing all users, applications and infrastructure with zero trust principles. Our security solutions are designed to reduce customers’ total cost of ownership by improving operational efficiency and eliminating the need for siloed point products. Our company focuses on delivering value in five fundamental areas:

Network Security:

• Our network security platform, which includes our ML-Powered Next-Generation Firewalls, available in a number of form factors, including physical, virtual, and containerized appliances, as well as a cloud-delivered service, has been a leader in the industry for ten consecutive years. Our network security platform also includes our Cloud-Delivered Security Services, such as Threat Prevention, Advanced Threat Prevention, WildFire ® , Advanced URL Filtering, DNS Security, IoT Security, GlobalProtect™, SD-WAN, Enterprise Data Loss Prevention (“Enterprise DLP”), SaaS Security API and SaaS Security Inline. Through these add-on security services, our customers are able to secure their content, applications, users, and devices across our network security platform as well as the Prisma ® and Cortex ® product lines. Panorama™, our network security management solution, available as hardware or virtual machine, can centrally manage our network security platform irrespective of form factor, location, or scale.

Secure Access Service Edge:

</details>

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 625-630)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> Product revenue is primarily generated from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances.

> During fiscal 2022, we introduced several new offerings, including: Prisma Cloud 3.0, Prisma Access 3.0, AIOps for NGFW, PAN-OS 10.2, and Cloud NGFW for AWS.

<details><summary>Passage</summary>

For fiscal 2022 and 2021, total revenue was $5.5 billion and $4.3 billion, respectively, representing year-over-year growth of 29.3%. Our growth reflects the increased adoption of our portfolio, which consists of product, subscriptions, and support. We believe our portfolio will enable us to benefit from recurring revenues and new revenues as we continue to grow our end-customer base. As of July 31, 2022, we had end-customers in over 180 countries. Our end-customers represent a broad range of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications, and include almost all of the Fortune 100 companies and a majority of the Global 2000 companies in the world. We maintain a field sales force that works closely with our channel partners in developing sales opportunities. We primarily use a two-tiered, indirect fulfillment model whereby we sell our products, subscriptions, and support to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers.

Our product revenue grew to $1.4 billion or 24.8% of total revenue for fiscal 2022, representing year-over-year growth of 21.7%. Product revenue is primarily generated from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Our ML-Powered Next-Generation Firewall incorporates our PAN-OS operating system, which provides a consistent set of capabilities across our entire network security product line. Our products are designed for different performance requirements throughout an organization, ranging from our PA-410, which is designed for small organizations and remote or branch offices, to our top-of-the-line PA-7080, which is designed for large-scale data centers and service provider use. The same firewall functionality that is delivered in our physical appliances is also available in our VM-Series virtual firewalls, which secure virtualized and cloud-based computing environments, and in our CN-Series container firewalls, which secure container environments and traffic.

Our subscription and support revenue grew to $4.1 billion or 75.2% of total revenue for fiscal 2022, representing year-over-year growth of 32.0%. Our subscriptions provide our end-customers with near real-time access to the latest antivirus, intrusion prevention, web filtering, modern malware prevention, data loss prevention, and cloud access security broker capabilities across the network, endpoints, and the cloud. When end-customers purchase our physical, virtual, or container firewall appliances, or certain cloud offerings, they typically purchase support in order to receive ongoing security updates, upgrades, bug fixes, and repairs. In addition to the subscriptions purchased with these appliances, end-customers may also purchase other subscriptions on a per-user, per-endpoint, or capacity-based basis. We also offer professional services, including incident response, risk management, and digital forensic services.

We continue to invest in innovation as we evolve and further extend the capabilities of our portfolio, as we believe that innovation and timely development of new features and products are essential to meeting the needs of our end-customers and improving our competitive position. During fiscal 2022, we introduced several new offerings, including: Prisma Cloud 3.0, Prisma Access 3.0, AIOps for NGFW, PAN-OS 10.2, and Cloud NGFW for AWS.

We believe that the growth of our business and our short-term and long-term success are dependent upon many factors, including our ability to extend our technology leadership, grow our base of end-customers, expand deployment of our portfolio and support offerings within existing end-customers, and focus on end-customer satisfaction. To manage any future growth effectively, we must continue to improve and expand our information technology and financial infrastructure, our operating and administrative systems and controls, and our ability to manage headcount, capital, and processes in an efficient manner. While these areas present significant opportunities for us, they also pose challenges and risks that we must successfully address in order to sustain the growth of our business and improve our operating results. For additional information regarding the challenges and risks we face, see the “Risk Factors” section in Part I, Item 1A of this Annual Report on Form 10-K.

</details>

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 710-712)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances.

<details><summary>Passage</summary>

Product Revenue

Product revenue is derived from sales of our appliances, primarily our ML-Powered Next-Generation Firewall, which is available in a number of form factors, including as physical, virtual, and containerized appliances. Product revenue also includes revenue derived from software licenses of Panorama. Our appliances and software licenses include a broad set of built-in networking and security features and functionalities. We recognize product revenue at the time of hardware shipment or delivery of software license.

Year Ended July 31, — 2022 | 2021 | Change | Year Ended July 31, — 2021 | 2020 | Change

</details>

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1114-1115)

**AI reference: explicit | frame: business | roles: offering | kinds: unspecified | substantiveness: generic**

> We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence and automation.

<details><summary>Passage</summary>

Description of Business

Palo Alto Networks, Inc. (the “Company,” “we,” “us,” or “our”), headquartered in Santa Clara, California, was incorporated in March 2005 under the laws of the State of Delaware and commenced operations in April 2005. We empower enterprises, organizations, service providers, and government entities to secure their users, networks, clouds and endpoints by delivering comprehensive cybersecurity backed by artificial intelligence and automation.

</details>

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1467-1469)

**AI reference: explicit | frame: business | roles: offering | kinds: traditional_ml | substantiveness: specific**

> We believe the acquisition will accelerate our delivery of IoT security through our ML-Powered Next-Generation Firewall and Cortex offerings.

<details><summary>Passage</summary>

Zingbox, Inc.

On September 20, 2019, we completed our acquisition of Zingbox, Inc. (“Zingbox”), a privately-held Internet of Things (“IoT”) security company. We believe the acquisition will accelerate our delivery of IoT security through our ML-Powered Next-Generation Firewall and Cortex offerings. The total purchase consideration for the acquisition of Zingbox was $ 66.4 million in cash.

As part of the acquisition, we issued replacement equity awards with a total fair value of $ 5.7 million, which will be expensed over the remaining service periods as share-based compensation.

</details>

# Context passages: implicit mentions, not classified

## Item 1 BUSINESS (blocks 183-185)

**Terms: data center (data center)**

Sales, Marketing, Services and Support

Customers. Our end-customers are predominantly medium to large enterprises, service providers, and government entities. Our end-customers operate in a variety of industries, including education, energy, financial services, government entities, healthcare, Internet and media, manufacturing, public sector, and telecommunications. Our end-customers deploy our portfolio of products for a variety of security functions across a variety of deployment scenarios. Typical deployment scenarios include the enterprise perimeter, the enterprise data center, and the distributed enterprise perimeter. Our end-customer deployments typically involve at least one pair of our products along with one or more of our subscriptions, depending on size, security needs and requirements, and network comp lexi ty. No single end-customer accounted for more than 10% of our total revenue in fiscal 2022, 2021, or 2020.

Distribution. We primarily sell our products and subscription and support offerings to end-customers through our channel partners utilizing a two-tier, indirect fulfillment model whereby we sell our products and subscription and support offerings to our distributors, which, in turn, sell to our resellers, which then sell to our end-customers. Sales are generally subject to our standard, non-exclusive distributor agreement, which provides for an initial term of one year, one-year renewal terms, termination by us with 30 to 90 days written notice prior to the renewal date, and payment to us from the channel partner within 30 to 45 calendar days of the date we issue an invoice for such sales. For fiscal 2022, 53.6% of our total revenue was derived from sales to three distributors.

## Item 1A RISK FACTORS (blocks 262-263)

**Terms: discretionary spending (technology spending)**

The ongoing impact of COVID-19 is fluid and uncertain, but it has caused and may continue to cause various negative effects, including an inability to meet with our existing or potential end-customers; our end-customers deciding to delay or abandon their planned purchases; increased requests for delayed payment terms or product discounts by our end-customers and channel partners; us delaying, canceling, or withdrawing from user and industry conferences and other marketing events, including some of our own; and changes in the demand for our products, which has caused us to reprioritize our engineering and research and development efforts and make changes to our original offering roadmap. We have also seen supply chain challenges increase significantly, including chip and component shortages (in some cases, attributable to labor shortages), and at times we do not have sufficient inventory of certain of our products to promptly meet customer demand. As a result, we have experienced at times extended delivery time and increased costs for chips and components compared to historic levels; our demand generation activities, and our ability to close transactions with end-customers and partners may be negatively impacted; our ability to provide 24x7 worldwide support and/or replacement parts to our end-customers may be adversely affected; and it has been and, until the COVID-19 outbreak is contained and global economic activity stabilizes, will continue to be more difficult for us to forecast our operating results.

More generally, the pandemic has not only significantly and adversely increased economic and demand uncertainty, but it has caused a global economic slowdown, and continuing global economic uncertainty which could decrease technology spending and adversely affect demand for our offerings and harm our business and results of operations.

## Item 1A RISK FACTORS (blocks 347-349)

**Terms: attrition (attrition)**

Our future success depends, in part, on our ability to continue to hire, integrate, train, and retain qualified and highly skilled personnel. We are substantially dependent on the continued service of our existing engineering personnel because of the complexity of our offerings. Additionally, any failure to hire, integrate, train, and adequately incentivize our sales personnel or the inability of our recently hired sales personnel to effectively ramp to target productivity levels could negatively impact our growth and operating margins. Competition for highly skilled personnel, particularly in engineering, is often intense, especially in the San Francisco Bay Area, where we have a substantial presence and need for such personnel. Additionally, potential changes in U.S. immigration and work authorization laws and regulations, including in reaction to COVID-19, may make it difficult to renew or obtain visas for any highly skilled personnel that we have hired or are actively recruiting.

In addition, the industry in which we operate generally experiences high employee attrition. Although we have entered into employment offer letters with our key personnel, these agreements have no specific duration and constitute at-will employment. We do not maintain key person life insurance policies on any of our employees. The loss of one or more of our key employees, and any failure to have in place and execute an effective succession plan for key executives, could seriously harm our business. If we are unable to hire, integrate, train, or retain the qualified and highly skilled personnel required to fulfill our current or future needs, our business, financial condition, and operating results could be harmed.

Our future performance also depends on the continued services and continuing contributions of our senior management to execute on our business plan and to identify and pursue new opportunities and product innovations. The loss of services of senior management, the decrease in the effectiveness of such services due to working remotely from home, or the ineffective management of any leadership transitions, especially within our sales organization, could significantly delay or prevent the achievement of our development and strategic objectives, which could adversely affect our business, financial condition, and operating results.

## Item 1A RISK FACTORS (blocks 362-364)

**Terms: data center (data centers)**

Defects, errors, or vulnerabilities in our products, subscriptions, or support offerings, the failure of our products or subscriptions to block a virus or prevent a security breach or incident, misuse of our products, or risks of product liability claims could harm our reputation and adversely impact our operating results.

Because our products and subscriptions are complex, they have contained and may contain design or manufacturing defects or errors that are not detected until after their commercial release and deployment by our end-customers. For example, from time to time, certain of our end-customers have reported defects in our products related to performance, scalability, and compatibility. Additionally, defects may cause our products or subscriptions to be vulnerable to security attacks, cause them to fail to help secure networks, or temporarily interrupt end-customers’ networking traffic. Because the techniques used by computer hackers to access or sabotage networks change frequently and generally are not recognized until launched against a target, we may be unable to anticipate these techniques and provide a solution in time to protect our end-customers’ networks. In addition, due to the Russian invasion of Ukraine there could be a significant increase in Russian cyberattacks against our customers, resulting in an increased risk of a security breach of our end-customers’ systems. Furthermore, as a well-known provider of security solutions, our networks, products, including cloud-based technology, and subscriptions could be targeted by attacks specifically designed to disrupt our business and harm our reputation. In addition, defects or errors in our subscription updates or our products could result in a failure of our subscriptions to effectively update end-customers’ hardware and cloud-based products. Our data centers and networks may experience technical failures and downtime, may fail to distribute appropriate updates, or may fail to meet the increased requirements of a growing installed end-customer base, any of which could temporarily or permanently expose our end-customers’ networks, leaving their networks unprotected against the latest security threats. Moreover, our products must interoperate with our end-customers’ existing infrastructure, which often have different specifications, utilize multiple protocol standards, deploy products from multiple vendors, and contain multiple generations of products that have been added over time. As a result, when problems occur in a network, it may be difficult to identify the sources of these problems.

The occurrence of any such problem in our products and subscriptions, whether real or perceived, could result in:

## Item 1A RISK FACTORS (blocks 449-453)

**Terms: open source licence (open source licenses)**

Our use of open source software in our products and subscriptions could negatively affect our ability to sell our products and subscriptions and subject us to possible litigation.

Our products and subscriptions contain software modules licensed to us by third-party authors under “open source” licenses. Some open source licenses contain requirements that we make available applicable source code for modifications or derivative works we create based upon the type of open source software we use. If we combine our proprietary software with open source software in a certain manner, we could, under certain open source licenses, be required to release the source code of our proprietary software to the public. This would allow our competitors to create similar products or subscriptions with lower development effort and time and ultimately could result in a loss of product sales for us.

Although we monitor our use of open source software to avoid subjecting our products and subscriptions to conditions we do not intend, the terms of many open source licenses have not been interpreted by United States courts, and there is a risk that these licenses could be construed in a way that could impose unanticipated conditions or restrictions on our ability to commercialize our products and subscriptions. From time to time, there have been claims against companies that distribute or use open source software in their products and subscriptions, asserting that open source software infringes the claimants’ intellectual property rights. We could be subject to suits by parties claiming infringement of intellectual property rights in what we believe to be licensed open source software. If we are held to have breached the terms of an open source software license, we could be required to seek licenses from third parties to continue offering our products and subscriptions on terms that are not economically feasible, to reengineer our products and subscriptions, to discontinue the sale of our products and subscriptions if reengineering could not be accomplished on a timely basis, or to make generally available, in source code form, our proprietary code, any of which could adversely affect our business, operating results, and financial condition.

In addition to risks related to license requirements, usage of open source software can lead to greater risks than use of third-party commercial software, as open source licensors generally do not provide warranties or assurance of title or controls on origin of the software. In addition, many of the risks associated with usage of open source software, such as the lack of warranties or assurances of title, cannot be eliminated, and could, if not properly addressed, negatively affect our business. We have established processes to help alleviate these risks, including a review process for screening requests from our development organizations for the use of open source software, but we cannot be sure that our processes for controlling our use of open source software in our products and subscriptions will be effective.

## Item 2 PROPERTIES (blocks 558-560)

**Terms: data center (data centers)**

ITEM 2. PROPERTIES

Our corporate headquarters is located in Santa Clara, California, where we lease approximately 941,000 square feet of space under three lease agreements that expire in July 2028, with options to extend the lease terms through July 2046. We also lease space for personnel in Israel. In addition, we provide our cloud-based subscription offerings through data centers operated under co-location arrangements in the United States, Europe, and Asia. Refer to Note 11. Leases in Part II, Item 8 of this Annual Report on Form 10-K for more information on our operating leases. Additionally, we own 10.4 acres of land adjacent to our headquarters in Santa Clara, California, which we intend to develop to accommodate future expansion, the speed of which development has been slowed due to the current environment.

We believe that our current facilities are adequate to meet our current needs. We intend to expand our facilities or add new facilities as we add employees and enter new geographic markets, and we believe that suitable additional or alternative space will be available as needed to accommodate ongoing operations and any such growth. However, we expect to incur additional expenses in connection with such new or expanded facilities.

## Item 7 MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (blocks 746-748)

**Terms: data center (data center)**

Cost of Subscription and Support Revenue

Cost of subscription and support revenue includes personnel costs for our global customer support and technical operations organizations, customer support and repair costs, third-party professional services costs, data center and cloud hosting service costs, amortization of acquired intangible assets and capitalized software development costs, and shared costs. We expect our cost of subscription and support revenue to increase as our installed end-customer base grows and adoption of our cloud-based subscription offerings increases.

Year Ended July 31, — 2022 | 2021 | Change | Year Ended July 31, — 2021 | 2020 | Change

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1192-1194)

**Terms: custom software development (application development)**

Software Development Costs

Internally developed software includes security software developed to meet our internal needs to provide cloud-based subscription offerings to our end-customers and business software that we customize to meet our specific operational needs. These capitalized costs consist of internal compensation related costs and external direct costs incurred during the application development stage and will be amortized over a useful life of three to five years . As of July 31, 2022 and 2021, we capitalized as other assets on our consolidated balance sheets $ 130.9 million and $ 114.8 million in costs, respectively, net of accumulated amortization, for security software developed to meet our internal needs to provide our cloud-based subscription offerings. We recognized amortization expense of $ 62.4 million, $ 47.8 million, and $ 31.3 million related to these capitalized costs as cost of subscription and support revenue in our consolidated statements of operations during the years ended July 31, 2022, 2021, and 2020, respectively.

The costs to develop software that is marketed externally have not been capitalized as we believe our current software development process is essentially completed concurrent with the establishment of technological feasibility. As such, all related software development costs are expensed as incurred and included in research and development expense in our consolidated statements of operations.

## Item 8 FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA (blocks 1446-1448)

**Terms: non-human identity (machine identity)**

Aporeto, Inc.

On December 23, 2019, we completed our acquisition of Aporeto, Inc. (“Aporeto”), a privately-held machine identity-based microsegmentation company. We believe the acquisition will strengthen our cloud-native security platform capabilities delivered by Prisma Cloud. The total purchase consideration for the acquisition of Aporeto was $ 144.1 million, which consisted of the following (in millions):

Amount
